<template>
  <div class="els-page-comtainer">
    
    <a-page-header
      :class="[ fixPageHeader ? 'fixed-page-header' : '', ]"
      :title="title"
    >
      <template slot="extra">
        <a-button
          @click="handleOk"
          type="primary"
          key="2">{{ $srmI18n(`${$getLangAccount()}#i18n_title_save`, '保存') }}</a-button>
        <a-button
          @click="goBack"
          key="3">{{ $srmI18n(`${$getLangAccount()}#i18n_title_back`, '返回') }}</a-button>
      </template>
    </a-page-header>
    <div class="table-page-search-wrapper">
      <a-spin :spinning="confirmLoading">
        <a-collapse
          v-model="activeKey"
          expandIconPosition="right">
          <a-collapse-panel
            key="1"
            :header="$srmI18n(`${$getLangAccount()}#i18n_title_basicInfo`, '基本信息')"
          >
            <a-form :form="form">
              
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartCoding`, '图表编码')">
                <a-input
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartCodingMsg`, '请输入图表编码')"
                  v-decorator="['chartCode', validatorRules.chartCode]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartName`, '图表名称')">
                <a-input
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartNameMsg`, '请输入图表名称')"
                  v-decorator="['chartName', validatorRules.chartName]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartLabel`, '图表标签')">
                <a-input
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartLabelMsg`, '请输入图表标签')"
                  v-decorator="['chartLabel', validatorRules.chartLabel]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartData`, '图表数据')">
                <j-dict-select-tag
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartDataMsg`, '请选择图表数据')"
                  v-decorator="['dataId', validatorRules.dataId]"
                  :trigger-change="true"
                  dict-code="els_chart_data,data_desc,id,is_deleted=0"
                />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartType`, '图表类型')">
                <j-dict-select-tag
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartTypeMsg`, '请选择图表类型')"
                  v-decorator="['chartType', validatorRules.chartType]"
                  :trigger-change="true"
                  dict-code="chartType"
                  @change="changeChartType"
                />
              </a-form-item>
              <a-form-item
                v-show="chartType == 'echart'"
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartSubtype`, '图表子类型')">
                <j-dict-select-tag
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartSubtypeMsg`, '请选择图表子类型')"
                  v-decorator="['chartSubType', validatorRules.chartSubType]"
                  :trigger-change="true"
                  dict-code="chartSubType"
                  @change="changeSubType"
                />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_wide`, '宽')">
                <a-input-number
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_wideMsg`, '请输入宽')"
                  v-decorator="['chartWidth', validatorRules.chartWidth]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_high`, '高')">
                <a-input-number
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_highMsg`, '请输入高')"
                  v-decorator="['chartHeight', validatorRules.chartHeight]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_routerJump`, '路由跳转')">
                <a-input
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_routerJumpMsg`, '请输入路由跳转')"
                  v-decorator="['routeUrl', validatorRules.routeUrl]" />
              </a-form-item>
              
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_smallIcon`, '小图标')">
                <a-input
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_smallIconMsg`, '请输入小图标')"
                  v-decorator="['chartIcon', validatorRules.chartIcon]" >
                  <a-icon
                    slot="addonAfter"
                    type="setting"
                    @click="selectIcons"
                  />
                </a-input>
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_bg`, '背景色')">
                <a-input
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_bgMsg`, '请输入背景色')"
                  v-decorator="['backgroundColor', validatorRules.backgroundColor]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_renovate`, '自动刷新间隔(s)')">
                <a-input-number
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_noneRenovate`, '0为不刷新')"
                  v-decorator="['refreshInterval', validatorRules.refreshInterval]" />
              </a-form-item>
              <a-form-item
                :labelCol="labelCol"
                :wrapperCol="wrapperCol"
                :label="$srmI18n(`${$getLangAccount()}#i18n_title_chartExtend`, '图表扩展')">
                <a-input
                  type="textarea"
                  rows="10"
                  :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_chartExtendMsg`, '请输入图表扩展')"
                  v-decorator="['chartExt', validatorRules.chartExt]" />
                <!-- <j-code-editor
                  language="javascript"
                  v-model="editorValue"
                  :fullScreen="true"
                  :lineNumbers="false"
                  style="min-height: 100px"/> -->
              </a-form-item>
            </a-form>
          </a-collapse-panel>
        </a-collapse>
        <!-- 选择图标 -->
        <icons
          @choose="handleIconChoose"
          @close="handleIconCancel"
          :icon-choose-visible="iconChooseVisible"
        />
      </a-spin>
    </div>
  </div>
  <!-- </a-modal> -->
</template>

<script>
import { postAction } from '@/api/manage'
import pick from 'lodash.pick'
import { duplicateCheck } from '@/api/api'
import Icons from './icon/Icons'
import JCodeEditor from '@comp/els/JCodeEditor'
let chartConfig = require('./chartConfig.json')
export default {
    name: 'ChartConfigModal',
    components: {
        Icons,
        JCodeEditor
    },
    props: {
        currentEditRow: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    data () {
        return {
            editorValue: 'xxx',
            chartType: '',
            activeKey: ['1'],
            fixPageHeader: false,
            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_chartConfigure`, '图表配置'),
            visible: false,
            displayFlag: false,
            model: {},
            iconChooseVisible: false,
            labelCol: {
                xs: { span: 8 },
                sm: { span: 8 }
            },
            wrapperCol: {
                xs: { span: 8 },
                sm: { span: 8 }
            },
            confirmLoading: false,
            form: this.$form.createForm(this),
            url: {
                add: '/dashboard/chartConfig/add',
                edit: '/dashboard/chartConfig/edit'
            }
        }
    },
    computed: {
        langAccount () {
            return this.$getLangAccount()
        },

        validatorRules (){
            let account = this.langAccount
            const {$srmI18n} = this
            return {
                dataId: {rules: [{ required: true, message: $srmI18n(`${account}#i18n_title_chartDataMsg`, '请选择图表数据!') }]},
                chartCode: {rules: [{ required: true, message: $srmI18n(`${account}#i18n_title_chartCodingMsg`, '请输入图表编码!') }, {max: 50, message: $srmI18n(`${account}#i18n_title_overflow`, '内容长度不能超过50个字符')}, { validator: this.validateCode }]},
                chartName: {rules: [{ required: true, message: $srmI18n(`${account}#i18n_title_chartNameMsg`, '请输入图表名称!') }, {max: 50, message: $srmI18n(`${account}#i18n_title_overflow`, '内容长度不能超过50个字符')}]},
                chartLabel: {rules: [{max: 50, message: $srmI18n(`${account}#i18n_title_overflow`, '内容长度不能超过50个字符')}]},
                chartType: {rules: [{ required: true, message: $srmI18n(`${account}#i18n_title_chartTypeMsg`, '请选择图表类型!') }]},
                routeUrl: {rules: [{max: 100, message: $srmI18n(`${account}#i18n_title_overflow100`, '内容长度不能超过100个字符')}]},
                chartIcon: {rules: [{max: 50, message: $srmI18n(`${account}#i18n_title_overflow`, '内容长度不能超过50个字符')}]},
                backgroundColor: {rules: [{max: 50, message: $srmI18n(`${account}#i18n_title_overflow`, '内容长度不能超过50个字符')}]},
                chartWidth: {rules: [{ required: true, message: $srmI18n(`${account}#i18n_title_wideMsg`, '请输入宽!') }]},
                chartHeight: {rules: [{ required: true, message: $srmI18n(`${account}#i18n_title_highMsg`, '请输入高!') }]},
                // seq: {rules: [{ required: true, message: '请输入顺序!' }]},
                refreshInterval: {'initialValue': '0'}
            }
        }
    },
    mounted () {
        this.init()
        window.addEventListener('scroll', this.handleScroll)
    },
    methods: {
        init () {
            if(this.currentEditRow) {
                this.edit(this.currentEditRow)
            }else {
                this.add()
            }
        },
        add () {
            this.edit({})
            this.title = this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addChartConfigure`, '新增图表配置')
        },
        edit (record) {
            this.title = this.$srmI18n(`${this.$getLangAccount()}#i18n_title_editChartConfigure`, '编辑图表配置')
            this.form.resetFields()
            this.displayFlag = record.display?true:false
            this.model = Object.assign({}, record)
            this.visible = true
            this.$nextTick(() => {
                this.form.setFieldsValue(pick(this.model, 'dataId', 'chartCode', 'chartName', 'chartLabel', 'chartType', 'chartWidth', 'chartHeight', 'routeUrl', 'chartExt', 'chartIcon', 'backgroundColor', 'seq', 'display', 'refreshInterval', 'chartSubType'))
                //时间格式化
            })
            this.chartType = record.chartType
        },
        validateCode (rule, value, callback) {
        // 重复校验
            var params = {
                tableName: 'els_chart_config',
                fieldName: 'chart_code',
                fieldVal: value,
                dataId: this.model.id
            }
            duplicateCheck(params).then((res) => {
                if (res.success) {
                    callback()
                } else {
                    callback(res.message)
                }
            })
        },
        handleOk () {
            const that = this
            // 触发表单验证
            this.form.validateFields((err, values) => {
                if (!err) {
                    that.confirmLoading = true
                    let httpurl = ''
                    if(!this.model.id){
                        httpurl+=this.url.add
                    }else{
                        httpurl+=this.url.edit
                    }
                    let formData = Object.assign(this.model, values)
                    //时间格式化
                    this.model.display = this.displayFlag?1:0
                    console.log(formData)
                    postAction(httpurl, formData).then((res)=>{
                        if(res.success){
                            that.$message.success(res.message)
                            that.$emit('ok')
                        }else{
                            that.$message.warning(res.message)
                        }
                    }).finally(() => {
                        that.confirmLoading = false
                        that.goBack()
                    })
                }
            })
        },
        goBack () {
            this.$emit('hide')
        },
        selectIcons (){
            this.iconChooseVisible = true
        },
        handleIconCancel () {
            this.iconChooseVisible = false
        },
        handleIconChoose (value) {
            this.form.setFieldsValue({'chartIcon': value})
            this.iconChooseVisible = false
        },
        handleScroll () {
            var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
            if (scrollTop > 50) {
                this.fixPageHeader = true
            }else {
                this.fixPageHeader = false
            }
        },
        formatJSON (json, options) {
            var reg = null,
                formatted = '',
                pad = 0,
                PADDING = '    '
            options = options || {}
            options.newlineAfterColonIfBeforeBraceOrBracket = (options.newlineAfterColonIfBeforeBraceOrBracket === true) ? true : false
            options.spaceAfterColon = (options.spaceAfterColon === false) ? false : true
            if (typeof json !== 'string') {
                json = JSON.stringify(json)
            } else {
                json = JSON.parse(json)
                json = JSON.stringify(json)
            }
            reg = /(\[\{\}])/g
            json = json.replace(reg, '\r\n$1\r\n')
            reg = /(\[\[\]])/g
            json = json.replace(reg, '\r\n$1\r\n')
            reg = /(,)/g
            json = json.replace(reg, '$1\r\n')
            reg = /(\r\n\r\n)/g
            json = json.replace(reg, '\r\n')
            reg = /\r\n,/g
            json = json.replace(reg, ',')
            if (!options.newlineAfterColonIfBeforeBraceOrBracket) {
                reg = /:\r\n\{/g
                json = json.replace(reg, ':{')
                reg = /:\r\n\[/g
                json = json.replace(reg, ':[')
            }
            if (options.spaceAfterColon) {
                reg = /:/g
                json = json.replace(reg, ':')
            }
            (json.split('\r\n')).forEach(function (node) {
                var i = 0,
                    indent = 0,
                    padding = ''

                if (node.match(/\{$/) || node.match(/\[$/)) {
                    indent = 1
                } else if (node.match(/\}/) || node.match(/\]/)) {
                    if (pad !== 0) {
                        pad -= 1
                    }
                } else {
                    indent = 0
                }

                for (i = 0; i < pad; i++) {
                    padding += PADDING
                }

                formatted += padding + node + '\r\n'
                pad += indent
            }
            )
            return formatted
        },
        changeChartType (e) {
            this.chartType = e
        },
        changeSubType (e) {
            let config = chartConfig[e]
            config = this.formatJSON(config)
            this.form.setFieldsValue({
                chartExt: config
            })
        }
    }
}
</script>

<style lang="less" scoped>

</style>