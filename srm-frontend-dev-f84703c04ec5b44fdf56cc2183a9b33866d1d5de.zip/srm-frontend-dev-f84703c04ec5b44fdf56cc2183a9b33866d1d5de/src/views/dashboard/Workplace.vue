<template>
  <div class="home-page-container">
    <div class="page-left">
      <a-card
        :title="$srmI18n(`${$getLangAccount()}#i18n_title_mydoList`, '我的待办')"
        size="small">
        <router-link
          slot="extra"
          class="more"
          :to="{ name: 'sys-message-ElsMsgRecordList' }">
          <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_more`, '更多') }}</span>
        </router-link>
        <div class="statistics-card">
          <template v-if="cardList.length > 0">
            <div
              v-for="(card, index) in cardList"
              :key="'card_' + index"
              :style="{ backgroundImage: 'linear-gradient(to right, ' + card.color + ', ' + card.colorTo + '' }"
              :class="{ 'active-card': currentCardIndex === index }"
              @click="handleChangeTable(card.value, card.num, index)"
              class="card-item"
            >
              <div class="">
                <div style="font-size:18px;font-weight:bold;margin-bottom:8px;text-align:center">{{ card.num }}</div>
                <div>{{ card.text }}</div>
              </div>
              <div class="card-item-icon">
                <a-icon
                  style="font-size:28px"
                  type="fund"></a-icon>
              </div>
            </div>
          </template>
          <div class="card-none" v-else>
            {{ $srmI18n(`${$getLangAccount()}#i18n_field_PSWF_30240c1c`, '暂无数据') }}
          </div>
        </div>
        <vxe-grid
          border
          resizable
          autoResize
          showOverflow
          showHeaderOverflow
          align="center"
          headerAlign="center"
          row-id="id"
          ref="listGrid"
          :height="`${halfHeight - 130}`"
          size="mini"
          :seq-config="{ startIndex: (tablePage.currentPage - 1) * tablePage.pageSize }"
          :loading="loading"
          :data="tableData"
          :pager-config="tablePage"
          @page-change="handlePageChange"
        >
          <vxe-table-column
            field="msgTitle"
            :title="$srmI18n(`${$getLangAccount()}#i18n_field_msgTitle`, '消息标题')"
          ></vxe-table-column>
          <vxe-table-column :title="$srmI18n(`${$getLangAccount()}#i18n_title_newsContent`, '消息内容')">
            <template slot-scope="scope">
              <a-tooltip placement="top">
                <template slot="title">
                  <span v-html="(scope.row || {}).msgContent"></span>
                </template>
                <div
                  @click="handleGoDetail(scope)"
                  class="workbench-message-content-wrap"
                  v-html="scope.row.msgContent"
                ></div>
              </a-tooltip>
            </template>
          </vxe-table-column>
          <vxe-table-column
            field="updateTime"
            :title="$srmI18n(`${$getLangAccount()}#i18n_field_jingpinDate`, '时间')"
          ></vxe-table-column>
          <vxe-table-column
            field="sendElsAccount"
            :title="$srmI18n(`${$getLangAccount()}#i18n_title_ELSAccount`, 'ELS账号')"
          ></vxe-table-column>
          <vxe-table-column
            field="sendElsAccount_dictText"
            :title="$srmI18n(`${$getLangAccount()}#i18n_massProdHead1ec_companyCode_dictText`, '公司名称')"
          ></vxe-table-column>
        </vxe-grid>
      </a-card>
      <a-card
        style="margin-top: 6px"
        :title="$srmI18n(`${$getLangAccount()}#i18n_title_announcement`, '平台公告')"
        size="small"
      >
        <router-link
          slot="extra"
          class="more"
          target="_blank"
          :to="{ name: 'noticeList', query: { sourceFrom: 'home' } }"
        >
          <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_more`, '更多') }}</span>
        </router-link>
        <vxe-grid
          resizable
          autoResize
          showOverflow
          showHeaderOverflow
          row-id="id"
          :height="`${halfHeight - 68}`"
          size="mini"
          :show-header="true"
          :loading="loading"
          :columns="noticeColumns"
          :data="publicNotice"
        >
          <template #custom_render="{row, column}">
            <router-link
              class="row space"
              target="_blank"
              :to="{
                name: goTemplateName(row),
                query: {
                  id: row.id,
                  businessId: row.businessId,
                  businessType: row.businessType,
                  noticeTitle: row.noticeTitle,
                  elsAccount: row.templateAccount || row.busAccount,
                  templateVersion: row.templateVersion,
                  templateNumber: row.templateNumber
                }
              }"
            >
              <a>{{ row[column.property] }}</a>
            </router-link>
          </template>
        </vxe-grid>
      </a-card>
    </div>
    <div class="page-right">
      <a-card
        style="height:100%"
        :title="$srmI18n(`${$getLangAccount()}#i18n_title_application`, '快捷应用')"
        size="small"
      >
        <a
          slot="extra"
          href="#"
          @click="setFastPermission">{{
            $srmI18n(`${$getLangAccount()}#i18n_title_setup`, '设置')
          }}</a>
        <a-list
          item-layout="horizontal"
          :data-source="appList">
          <a-list-item
            slot="renderItem"
            slot-scope="item">
            <a-list-item-meta>
              <router-link
                slot="title"
                :to="item.url">
                <a-icon
                  style="margin-right:3px"
                  type="appstore" />
                {{ item.name }}
              </router-link>
            </a-list-item-meta>
          </a-list-item>
        </a-list>
      </a-card>
    </div>

    <fast-permission
      :visible="visible"
      :transferData="transferData"
      :targetKeys="targetKeys"
      @fast-permission-cancel="handleCancel"
      @fast-permission-change="handleChange"
      @fast-permission-refresh="getSelectedFastPermission"
    />
  </div>
</template>

<script>
import { getAction } from '@/api/manage'

import { ListConfig } from '@/plugins/table/gridConfig'
import { List } from 'ant-design-vue'

import FastPermission from './modules/FastPermission'

import { ajaxFindDictItems } from '@/api/api'
import { USER_ELS_ACCOUNT } from '@/store/mutation-types'
import { srmI18n, getLangAccount } from '@/utils/util'

export default {
  name: 'Workplace',
  components: {
    AList: List,
    AListItem: List.Item,
    AListItemMeta: List.Item.Meta,
    FastPermission
  },
  data() {
    return {
      currentCardIndex: null,
      currentCardValue: null,
      height: 0,
      columns: [
        { field: 'msgTitle', title: srmI18n(`${getLangAccount()}#i18n_title_newsTitle`, '消息标题') },
        { field: 'msgContent', title: srmI18n(`${getLangAccount()}#i18n_title_newsContent`, '消息内容') },
        { field: 'updateTime', title: srmI18n(`${getLangAccount()}#i18n_title_time`, '时间') }
      ],
      gridConfig: ListConfig,
      tableData: [],
      loading: false,
      tablePage: {
        total: 0,
        currentPage: 1,
        pageSize: 20,
        align: 'right',
        pageSizes: [20, 50, 100, 200, 500],
        layouts: ['Sizes', 'PrevPage', 'Number', 'NextPage', 'FullJump', 'Total']
        // perfect: true
      },
      defaultCardList: [
        {
          text: srmI18n(`${getLangAccount()}#i18n_title_itemizedAccessSheet`, '分项准入单'),
          color: '#60646f',
          colorTo: '#98a4ca',
          icon: 'fund',
          num: '0'
        },
        {
          text: srmI18n(`${getLangAccount()}#i18n_title_accessManagement`, '准入管理'),
          color: '#3d6de9',
          colorTo: '#47c2fb',
          icon: 'api',
          num: '0'
        },
        {
          text: srmI18n(`${getLangAccount()}#i18n_title_demandPool`, '需求池'),
          color: '#d49e9e',
          colorTo: '#fda984',
          icon: 'radar-chart',
          num: '0'
        }
      ],
      cardList: [],
      dictOptions: '',
      appList: [],
      publicNotice: [],
      visible: false,
      transferData: [],
      targetKeys: []
    }
  },
  computed: {
    halfHeight() {
      return (this.height - 100) / 2
    },

    langAccount() {
      return this.$getLangAccount()
    },

    noticeColumns() {
      let account = this.langAccount
      const { $srmI18n } = this
      return [
        { field: 'noticeType_dictText', title: $srmI18n(`${account}#i18n_title_type`, '类型') },
        { field: 'noticeScope_dictText', title: $srmI18n(`${account}#i18n_title_noticeScope`, '通知范围') },
        { field: 'publishUser', title: $srmI18n(`${account}#i18n_title_publisher`, '发布人') },
        { field: 'businessType_dictText', title: $srmI18n(`${account}#i18n_title_businessType`, '业务类型') },
        {
          field: 'noticeTitle',
          title: $srmI18n(`${account}#i18n_title_newsTitle`, '消息标题'),
          slots: { default: 'custom_render' }
        },
        { field: 'updateTime', title: $srmI18n(`${account}#i18n_title_time`, '时间') }
      ]
    }
  },
  methods: {
    // 调转到逻辑
    goTemplateName(data) {
      let name = 'noticeDetail'
      if (
        data &&
        (data.businessType === 'ebidding' || data.businessType === 'bidding' || data.businessType === 'enquiry')
      ) {
        name = 'noticeDetailTemplate'
      }
      return name
    },
    setFastPermission() {
      getAction('/account/fastPermission/queryAll').then(res => {
        const { success, message, result = [] } = res || {}
        if (!success) {
          this.$message.error(message)
          return
        }
        this.transferData = result.map(n => ({ ...n, title: n.name, key: n.id, description: `description_${n.name}` }))
        this.targetKeys = this.transferData.filter(n => n.selected === '1').map(item => item.key)
        this.visible = true
      })
    },
    handleCancel() {
      this.visible = false
    },
    handleChange(keys) {
      this.targetKeys = keys
    },

    getSelectedFastPermission() {
      getAction('/account/fastPermission/query').then(res => {
        if (!res.success) {
          return this.$message.error(res.message)
        }
        this.appList = res.result || []
      })
    },
    handlePageChange({ currentPage, pageSize }) {
      this.tablePage.currentPage = currentPage
      this.tablePage.pageSize = pageSize
      this.getTodoData(this.currentCardValue)
    },
    getTodoData(type) {
      let params = {
        handleFlag: 0,
        pageSize: this.tablePage.pageSize,
        pageNo: this.tablePage.currentPage,
        filter: {},
        column: 'id',
        order: 'desc'
      }
      if (type) {
        params.businessType = type
      }
      getAction('/message/elsMsgRecord/list', params)
        .then(res => {
          if (res.success) {
            let list = [...res.result.records]
            list.forEach(item => {
              if (item.extendFields) {
                Object.assign(item, JSON.parse(item.extendFields))
              }
            })
            this.tableData = list
            this.tablePage.total = res.result.total
          }
        })
        .finally(() => {
          this.loading = false
        })
    },
    handleGoDetail(scope) {
      if (scope.row.linkUrl) {
        this.$router.push({ path: scope.row.linkUrl, query: { open: true } })
      }
    },
    getTypesStatistical() {
      let pro = new Promise((resolve, reject) => {
        //根据字典Code, 初始化字典数组
        let postData = {
          busAccount: this.$ls.get(USER_ELS_ACCOUNT),
          dictCode: 'srmBusinessType'
        }
        ajaxFindDictItems(postData).then(res => {
          if (res.success) {
            this.dictOptions = res.result
            resolve()
          }
        })
      })
      pro.then(() => {
        getAction('/message/elsMsgRecord/queryBacklogCount').then(res => {
          if (res.success) {
            let data = []
            for (const key in res.result) {
              for (let i = 0; i < this.dictOptions.length; i++) {
                if (key == this.dictOptions[i].value) {
                  let item = {
                    value: key,
                    num: res.result[key],
                    text: this.dictOptions[i].text,
                    color: res.result.color || '#60646f',
                    colorTo: res.result.colorTo || '#98a4ca'
                  }
                  data.push(item)
                }
              }
            }
            if (data.length > 0) {
              this.cardList = data
            }
            // else {
            //   this.cardList = this.defaultCardList
            // }
          }
        })
      })
    },
    handleChangeTable(item, num, index) {
      if (num == 0) {
        return
      }
      if (this.currentCardIndex !== index) {
        this.currentCardIndex = index
        this.currentCardValue = item
        this.tablePage.currentPage = 1
        this.getTodoData(this.currentCardValue)
      } else {
        this.currentCardIndex = null
        this.currentCardValue = null
        this.tablePage.currentPage
        this.getTodoData(this.currentCardValue)
      }
    },
    getNoticeData() {
      const url = '/notice/purchaseNotice/getHomePageNotice'
      const params = {
        pageNo: 1,
        pageSize: 10
      }
      getAction(url, params).then(res => {
        const records = res.result.records || []
        this.publicNotice = records.length > 6 ? records.slice(0, 6) : records
        console.log('this.publicNotice :>> ', this.publicNotice)
      })
    }
  },
  created() {
    this.height = document.documentElement.clientHeight
    this.getTodoData()
    this.getNoticeData()
    this.getSelectedFastPermission()
    this.getTypesStatistical()
  }
}
</script>
<style lang="less" scoped>
@-webkit-keyframes pulse {
  0% {
    -webkit-transform: scaleX(1);
    transform: scaleX(1);
  }
  50% {
    -webkit-transform: scale3d(1.05, 1.05, 1.05);
    transform: scale3d(1.05, 1.05, 1.05);
  }
  to {
    -webkit-transform: scaleX(1);
    transform: scaleX(1);
  }
}
@keyframes pulse {
  0% {
    -webkit-transform: scaleX(1);
    transform: scaleX(1);
  }
  50% {
    -webkit-transform: scale3d(1.05, 1.05, 1.05);
    transform: scale3d(1.05, 1.05, 1.05);
  }
  to {
    -webkit-transform: scaleX(1);
    transform: scaleX(1);
  }
}
.home-page-container {
  overflow: auto;
  display: flex;
  height: 100%;
  .page-left {
    flex: 1;
    margin-right: 6px;
    min-width: 700px;
  }
  .page-right {
    width: 220px;
    height: 100%;
  }
  .statistics-card {
    display: flex;
    margin-bottom: 6px;
    color: #fff;
    width: 100%;
    padding-bottom: 10px;
    overflow-x: auto;
    .active-card {
      background-image: linear-gradient(to right, #3d6de9, #47c2fb) !important;
    }

    .card-item {
      display: flex;
      flex: none;
      margin-left: 10px;
      padding: 6px;
      border-radius: 5px;
      height: 82px;
      width: 150px;
      cursor: pointer;
      font-size: 13px;
      .card-item-icon {
        flex: 1;
        line-height: 68px;
        text-align: center;
      }
    }
    .card-none {
      color: #606266;
      width: 98%;
      margin-left: 0px;
      justify-content: center;
      align-items: center;
      height: 82px;
      display: flex;
    }
    .card-item:hover {
      animation: pulse 0.5s ease-in-out;
      -webkit-animation: pulse 1s ease-in-out;
    }
  }
  .workbench-message-content-wrap {
    cursor: pointer;
    color: #2f54eb;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
</style>
