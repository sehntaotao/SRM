<template>
  <div
    class="panel-container-workplace"
    :style="'min-height:'+minHeight">
    <a-spin :spinning="pageLoading">
      <grid-layout
        style="width:100%"
        :layout.sync="panelData"
        :col-num="12"
        :row-height="30"
        :is-draggable="true"
        :is-resizable="true"
        :is-mirrored="false"
        :vertical-compact="true"
        :margin="[10, 10]"
        :use-css-transforms="true"
        @layout-updated="layoutUpdatedEvent"
      >
        <grid-item
          v-for="item in panelData"
          :x="item.x"
          :y="item.y"
          :w="item.w"
          :h="item.h"
          :i="item.i"
          style="background:#fff"
          :class="[item.chartType == 'num' ? 'data-statis-item' : '']"
          :dragAllowFrom="item.chartType == 'num' ? '.data-statis-item' : '.ant-card-head'"
          :key="item.i">
          <a-card
            size="small"
            class="workplace_card"
            :loading="item.loading"
            :title="item.chartType != 'num' ? item.chartName : null"
            style="width:100%;height:100%">
            <vue-echarts
              v-if="item.chartType == 'echart'"
              autoresize
              theme="light"
              :options="item.config"
              :auto-resize="true" />
            <div
              v-else-if="item.chartType == 'list'"
              style="height:100%;width:100%">
              <vxe-grid
                border="inner"
                auto-resize 
                resizable
                highlight-hover-row
                show-overflow
                size="mini"
                height="auto"
                :checkbox-config="{highlight: true}"
                :columns="item.columns"
                :data="item.resultData">
              </vxe-grid>
            </div>
            <div
              v-else-if="item.chartType == 'num'"
              class="num-panel-item-new">
              <div class="row">
                <div class="title">{{ item.chartName }}</div>
                <div class="num-panel-icon">
                  <a-icon
                    :type="numIcon(item)"
                    style="font-size: 28px;color: #1890ff"></a-icon>
                </div>
              </div>
              <div class="count">{{ item.resultData }}</div>
              <!-- <div class="des">sfsff</div> -->
            </div>
          </a-card>
        </grid-item>
        <a-empty v-if="!panelData.length" />
      </grid-layout>
    </a-spin>
  </div>
</template>
<script>
import { getAction, postAction } from '@/api/manage'
import VueGridLayout from 'vue-grid-layout'
import { Empty } from 'ant-design-vue'
export default {
    components: {
        AEmpty: Empty,
        GridLayout: VueGridLayout.GridLayout,
        GridItem: VueGridLayout.GridItem
    },
    data () {
        return {
            panelData: [],
            pageLoading: true,
            url: {
                list: '/dashboard/dashboard/getDashboard/',
                data: '/dashboard/chartData/getData/',
                update: '/dashboard/chartUserConfig/saveUserConfig'
            }
        }
    },
    computed: {
        minHeight (){
            return document.body.clientHeight - 136 + 'px'
        },
        numIcon () {
            return function (item) {
                let rs = 'pay-circle'
                if (item.chartType == 'num') {
                    switch (item.chartCode) {
                    case 'fund':{
                        rs = 'pay-circle'
                        break
                    }
                    case 'growthRateForOrder':{
                        rs = 'fund'
                        break
                    }
                    case 'supplierQuantity':{
                        rs = 'shop'
                        break
                    }
                    default:
                        break
                    }
                }
                return rs
            }
        }
    },
    activated () {
        this.getDashboardList()
        let event = document.createEvent('HTMLEvents')
        event.initEvent('resize', true, true)
        event.eventType = 'message'
        window.dispatchEvent(event)
    },
    methods: {
        getDashboardList () {
            let that = this
            let pageCode = this.$route.name
            getAction(this.url.list + pageCode, {}).then(res => {
                if(res.success) {
                    let list = res.result
                    //字段转换
                    list.forEach(item => {
                    //数据必须包含x,y,w,h,i字段
                        item.x = item.xCoord
                        item.y = item.yCoord
                        item.w = item.chartWidth
                        item.h = item.chartHeight
                        item.i = item.dashboardChartId
                        item.loading = true
                        if(item.chartType == 'list') {
                            item.columns = JSON.parse(item.chartExt)
                        }
                    })
                    that.panelData = list
                    that.pageLoading = false
                    that.getResultData()
                }
            })
        },
        getResultData () {
            let that = this
            this.panelData.forEach(panel => {
                getAction(this.url.data + panel.dataId, {}).then(res => {
                    if(res.success) {
                        if(panel.chartType == 'list' || panel.chartType == 'num') {
                            panel.resultData = res.result.resultData
                        }else {
                            let chartExt = '{}'
                            if(panel.chartSubType == 'pie') {
                                chartExt = panel.chartExt && panel.chartExt.replace(/\${result_value}/g, JSON.stringify(res.result.resultData))
                                let str = JSON.stringify(res.result.resultData).replace(/"/g, '\'')
                                chartExt = chartExt && chartExt.replace(/\${result_value_fn}/g, str)
                            }else {
                                let nameArr = res.result.resultData.map(item => {
                                    return item.NAME
                                })
                                let valueArr = res.result.resultData.map(item => {
                                    let itemData =[]
                                    itemData.push(item.Jan)
                                    itemData.push(item.Feb)
                                    itemData.push(item.Mar)
                                    itemData.push(item.Apr)
                                    itemData.push(item.May)
                                    itemData.push(item.Jun)
                                    itemData.push(item.Jul)
                                    itemData.push(item.Aug)
                                    itemData.push(item.Sept)
                                    itemData.push(item.Oct)
                                    itemData.push(item.Nov)
                                    itemData.push(item.Dec)
                                    itemData.push(item.total)
                                    let value = {
                                        name: item.NAME,
                                        type: 'line',
                                        smooth: true,
                                        data: itemData
                                    }
                                    return value
                                })
                                if(panel.chartExt) {
                                    chartExt = panel.chartExt.replace(/\${result_name}/g, JSON.stringify(nameArr)).replace(/\${result_value}/g, JSON.stringify(valueArr))
                                }
                            }
                            let chartConfig = JSON.parse(chartExt, function (k, v){
                                if(v.indexOf&&v.indexOf('function')>-1){
                                    return eval('(function (){ return '+v+' }) ()')
                                }
                                return v
                            })
                            panel.config = chartConfig
                        }
                        panel.loading = false
                        that.$forceUpdate()
                    }
                })
            })
            console.log(this.panelData)
        },
        updateConfig (params) {
            let that = this
            this.pageLoading = true
            postAction(this.url.update, params).then(res => {
                let updateList = res.result
                that.panelData.forEach(item   => {
                    updateList.forEach(update => {
                        if(item.dashboardChartId == update.dashboardChartId) {
                            item.id = update.id
                        }
                    })
                })
                that.$forceUpdate()
                that.pageLoading = false
            })
        },
        layoutUpdatedEvent (newLayout) {
            console.log(newLayout)
            let params = []
            newLayout.forEach(item => {
                params.push({
                    id: item.id,
                    dashboardChartId: item.dashboardChartId,
                    xCoord: item.x,
                    yCoord: item.y,
                    chartWidth: item.w,
                    chartHeight: item.h
                })
            })
            this.updateConfig(params)
        }
    }
}
</script>
<style lang="less">
  .panel-container-workplace {
    .workplace_card{
      &:hover{
        box-shadow: 0px 0px 9px rgba(0,0,0, .5);
      }
    }
    .echarts {
      width: 100%;
      height: 100%;
    }
    .ant-card-body {
      width: 100%;
      height: calc(100% - 37px);
    }
    .num-panel-item-new {
      .row{
        display: flex;
        justify-content: space-between;
        align-items: center;
        .title {
          border-radius: 30px;
          text-align: center;
          padding: 9px 16px;
          color: white;
          background: #ed2f2f;
          line-height: 100%;
          height: 15px;
          font-weight: 600;
          -webkit-box-sizing: content-box;
          box-sizing: content-box;
        }
      }
      .count{
        padding: 10px 0;
        font-size: 18px;
        color: #494949;
        font-weight: 500;
      }
      // .num-panel-content {
      //   flex: 1;
      //   text-align: center;
      //   font-size: 32px;
      //   font-weight: bold;
      // }
    }
  }
</style>