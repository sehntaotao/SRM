<template>
  <a-form-item
    :label="index +'.' + field.label"
    validate-status="error"
    :help="field.validateOption.message"
    :label-col="field.layout.labelCol"
    :wrapper-col="field.layout.wrapperCol"
    :required="!!field.rules && field.rules.length > 0"
  >
    <a-radio-group
      v-decorator="[field.id, {
        initialValue: field.initialValue
      }]">
      <template v-for="(el, idx) of options">
        <a-radio
          :style="radioStyle"
          :value="el.value"
          :key="idx">
          {{ String.fromCharCode((65 + idx)) }}.{{ el.label }}
        </a-radio>
      </template>
    </a-radio-group>
  </a-form-item>
</template>

<script>
export default {
    name: 'RadioCom',
    props: {
        field: {
            type: Object,
            require: true
        }
    },
    inject: ['index'],
    data () {
        return {
            options: [],
            radioStyle: {
                display: 'block',
                height: '30px',
                lineHeight: '30px'
            }
        }
    },
    created () {
        this.options = this.field.options
    }
}
</script>

<style scoped>

</style>
