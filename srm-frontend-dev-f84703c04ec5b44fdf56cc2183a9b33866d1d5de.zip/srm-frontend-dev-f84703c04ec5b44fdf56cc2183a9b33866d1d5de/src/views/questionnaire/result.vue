<template>
  <div>
    <a-result
      status="success"
      :title="$srmI18n(`${$getLangAccount()}#i18n_title_submitAnswerSheetMsg`, '您的答卷已经提交，感谢您的参与！')"
      :sub-title="$srmI18n(`${$getLangAccount()}#i18n_title_answerSheetTechnologyDelivery`, '本次问卷由深圳企企通科技有限公司，提供技术支持。')"
    >
    </a-result>
  </div>
</template>

<script>

export default {
    components: {},
    data () {
        return {

        }
    },
    created () {
    },
    watch: {},
    computed: {},
    methods: {
    }
}
</script>

<style lang='scss' scoped>
</style>
