<template>
  <div>
    <div>Redis{{ $srmI18n(`${$getLangAccount()}#i18n_title_terminal`, '终端') }}</div>
  </div>
</template>
<script>
export default {
    name: 'RedisTerminal'
}
</script>
<style>

</style>
