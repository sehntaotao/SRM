<template>
  <div style="height:100%">
    <list-layout
      v-show="!showEditPage && !showDetailPage"
      ref="listPage"
      :pageData="pageData"
      :url="url"
      @afterChangeTab="handleAfterChangeTab" />
    <!-- 编辑界面 -->
    <sale-barcode-level-head-edit
      v-if="showEditPage"
      ref="editPage"
      :current-edit-row="currentEditRow"
      @hide="handleList" />
    <!-- 详情界面 -->
    <sale-barcode-level-head-detail
      v-if="showDetailPage"
      ref="detailPage"
      :current-edit-row="currentEditRow"
      @hide="handleList" />

    <!-- 新增弹窗 -->
    <BarcodeLevelTempSelectModal
      ref="temSelectModal"
      :pageData="pageData"
      @success="handleEdit"></BarcodeLevelTempSelectModal>
  </div>
</template>
<script>
import { ListMixin } from '@comp/template/list/ListMixin'
import { postAction } from '@/api/manage'
import SaleBarcodeLevelHeadEdit from './modules/SaleBarcodeLevelHeadEdit'
import SaleBarcodeLevelHeadDetail from './modules/SaleBarcodeLevelHeadDetail'
import BarcodeLevelTempSelectModal from './modules/BarcodeLevelTempSelectModal'

export default {
    mixins: [ListMixin],
    components: {
        SaleBarcodeLevelHeadEdit,
        SaleBarcodeLevelHeadDetail,
        BarcodeLevelTempSelectModal
    },
    data () {
        return {
            showDetailPage: false,
            showEditPage: false,
            currentResultRow: {},
            pageData: {
                businessType: 'barcodeLevel',
                formField: [
                    {
                        type: 'input',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_keyword`, '关键字'),
                        fieldName: 'keyWord',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseInputThekeyword`, '请输入关键字')
                    }
                ],
                form: {
                    keyWord: ''
                },
                button: [
                    {
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        icon: 'plus',
                        clickFn: this.handleAdd,
                        type: 'primary'
                    },
                    {
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'),
                        icon: 'setting',
                        clickFn: this.settingColumns
                    }
                ],
                optColumnWidth: 250,
                optColumnList: [
                    {
                        type: 'view',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'),
                        clickFn: this.handleView
                    },
                    {
                        type: 'edit',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'),
                        clickFn: this.handleEdit,
                        allow: this.showEdit
                    }
                ]
            },
            url: {
                list: '/base/barcode/saleBarcodeLevelHead/list',
                add: '/base/barcode/saleBarcodeLevelHead/add',
                delete: '/base/barcode/saleBarcodeLevelHead/delete',
                changeStatus: '/base/barcode/saleBarcodeLevelHead/changeStatus',
                invalid: '/base/barcode/saleBarcodeLevelHead/invalid',
                deleteBatch: '/base/barcode/saleBarcodeLevelHead/deleteBatch',
                columns: 'saleBarcodeLevelHeadList'
            }
        }
    },
    methods: {
        handleDetail (row) {
            this.currentEditRow = row
            this.showResultPage = false
            this.showEditPage = false
            this.showDetailPage = true
        },
        handleList () {
            this.showResultPage = false
            this.showEditPage = false
            this.showDetailPage = false
            this.$store.dispatch('SetTabConfirm', false)
            this.searchEvent()
        },
        showEdit (row) {
            return row.levelStatus == 'final' ? true : false
        },
        handleAdd () {
            let data = {
                url: '/enterprise/elsEnterpriseInfo/getPurchaseAccount',
                params: {
                    toElsAccount: this.$ls.get('Login_elsAccount'),
                    frozenFunctionValue: '1'
                }
            }
            this.$refs.temSelectModal.open(data)
        }
    }
}
</script>