<template>
  <div style="height:100%">
    <list-layout
      v-show="!showEditPage && !showDetailPage"
      ref="listPage"
      :pageData="pageData"
      :url="url"
      @afterChangeTab="handleAfterChangeTab" />
    <!-- 编辑界面 -->
    <purchase-barcode-info-head-edit
      v-if="showEditPage"
      ref="editPage"
      :current-edit-row="currentEditRow"
      @hide="handleList" />
    <!-- 详情界面 -->
    <purchase-barcode-info-head-detail
      v-if="showDetailPage"
      ref="detailPage"
      :current-edit-row="currentEditRow"
      @hide="handleList" />
  </div>
</template>
<script>
import PurchaseBarcodeInfoHeadEdit from './modules/PurchaseBarcodeInfoHeadEdit'
import PurchaseBarcodeInfoHeadDetail from './modules/PurchaseBarcodeInfoHeadDetail'
import { ListMixin } from '@comp/template/list/ListMixin'
import { getAction } from '@/api/manage'

export default {
    mixins: [ListMixin],
    components: {
        PurchaseBarcodeInfoHeadEdit,
        PurchaseBarcodeInfoHeadDetail
    },
    data () {
        return {
            showDetailPage: false,
            showEditPage: false,
            currentResultRow: {},
            pageData: {
                businessType: 'barcodeInfo',
                formField: [
                    {
                        type: 'input',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_keyword`, '关键字'),
                        fieldName: 'keyWord',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseInputThekeyword`, '请输入关键字')
                    }
                ],
                form: {
                    keyWord: ''
                },
                button: [
                    { 
                        allow: ()=> {
                            return this.btnInvalidAuth('purchaseBarcodeInfoHead:add')
                        }, 
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'), 
                        icon: 'plus', 
                        clickFn: this.handleAdd, 
                        type: 'primary'
                    },
                    {
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'),
                        icon: 'setting',
                        clickFn: this.settingColumns
                    },
                    {
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_helpText`, '帮助说明'),
                        icon: 'file-text',
                        folded: true,
                        clickFn: this.showHelpText
                    },
                    {
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentExplain`, '附件说明'),
                        icon: 'file-pdf',
                        folded: true,
                        clickFn: this.showHelpPDF
                    }
                ],
                optColumnWidth: 250,
                optColumnList: [
                    {
                        type: 'view',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'),
                        clickFn: this.handleView
                    },
                    {
                        type: 'edit',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'),
                        clickFn: this.handleEdit,
                        allow: this.showEdit
                    },
                    { type: 'edit', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_void`, '作废'), clickFn: this.handleInvalid, allow: this.showInvalid },
                    {
                        type: 'delete',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        clickFn: this.handleDelete,
                        allow: this.showDelete
                    }
                ]
            },
            url: {
                list: '/base/barcode/purchaseBarcodeInfoHead/list',
                add: '/base/barcode/purchaseBarcodeInfoHead/add',
                delete: '/base/barcode/purchaseBarcodeInfoHead/delete',
                invalid: '/base/barcode/purchaseBarcodeInfoHead/invalid',
                deleteBatch: '/base/barcode/purchaseBarcodeInfoHead/deleteBatch',
                exportXlsUrl: '/base/barcode/purchaseBarcodeInfoHead/exportXls',
                importExcelUrl: '/base/barcode/purchaseBarcodeInfoHead/importExcel',
                columns: 'purchaseBarcodeInfoHeadList'
            }
        }
    },
    methods: {
        handleResultRecord (row) {
            this.currentEditRow = row
            this.showResultPage = true
            this.showEditPage = false
            this.showDetailPage = false
        },
        handleDetail (row) {
            this.currentEditRow = row
            this.showResultPage = false
            this.showEditPage = false
            this.showDetailPage = true
        },
        handleList () {
            this.showResultPage = false
            this.showEditPage = false
            this.showDetailPage = false
            this.$store.dispatch('SetTabConfirm', false)
            this.searchEvent()
        },
        submitCallBack (row){
            this.currentEditRow = row
            this.showEditPage = false
            this.showDetailPage = true
            this.searchEvent()
        },
        showEdit (row) {
            if(this.btnInvalidAuth('purchaseBarcodeInfoHead:edit')){
                return true
            }
            return row.infoStatus == 'new' && row.auditStatus == '0' ? false : true
        },
        showInvalid (row) {
            if(this.btnInvalidAuth('purchaseBarcodeInfoHead:invalid')){
                return true
            }
            return row.infoStatus == 'publish' ? false : true
        },
        showDelete (row) {
            if(this.btnInvalidAuth('purchaseBarcodeInfoHead:delete')){
                return true
            }
            return row.infoStatus == 'new' && row.auditStatus == '0' ? false : true
        },
        handleInvalid (row) {
            let that = this
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmVoid`, '确认作废'),
                content: '是否作废此条码单？',
                onOk: function () {
                    that.loading = true
                    getAction(that.url.invalid, {id: row.id}).then(res => {
                        if(res.success) {
                            that.$message.success(res.message)
                            that.$refs.listPage.loadData() // 刷新页面
                        }else {
                            that.$message.warning(res.message)
                        }
                    }).finally(() => {
                        that.loading = false
                    })
                }
            })
        }
    }
}
</script>