<template>
  <div>
    <tile-edit-page
      ref="editPage"
      :pageData="pageData"
      :url="url"
      @goBack="goBack" />
    <field-select-modal ref="fieldSelectModal" />
  </div>
</template>

<script>
import { tileEditPageMixin } from '@comp/template/tileStyle/tileEditPageMixin'
import fieldSelectModal from '@comp/template/fieldSelectModal'
export default {
    mixins: [tileEditPageMixin],
    name: 'EditMsgConfigModal',
    components: {
        fieldSelectModal
    },
    data () {
        return {
            editItemRow: {},
            currentItemContent: '',
            pageData: {
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_rateMaintenance`, 'BP汇率维护'),
                form: {
                    exchangeYear: '',
                    originalCurrency: '',
                    targetCurrency: '',
                    exchange: ''
                },
                panels: [
                    {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_100100`, '基本信息'),
                        content: {
                            ref: 'baseForm',
                            colSpan: '12',
                            type: 'form',
                            list: [
                                {
                                    type: 'input',
                                    label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bpYear`, 'BP年'),
                                    fieldName: 'exchangeYear',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bpYear`, 'BP年')
                                },
                                {
                                    type: 'select',
                                    label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_srmCurrency`, '原始货币'),
                                    fieldName: 'originalCurrency',
                                    dictCode: 'srmCurrency',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_srmCurrency`, '原始货币')
                                },
                                {
                                    type: 'select',
                                    label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_targetCurrency`, '目标货币'),
                                    fieldName: 'targetCurrency',
                                    dictCode: 'srmCurrency',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_targetCurrency`, '目标货币')
                                },
                                {
                                    type: 'number',
                                    label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_exchange`, '汇率'),
                                    fieldName: 'exchange',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_exchange`, '汇率')
                                },
                                {
                                    type: 'date',
                                    label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_timeinForce`, '生效时间'),
                                    showTime: true,
                                    valueFormat: 'YYYY-MM-DD',
                                    fieldName: 'effectiveTime',
                                    placeholder: ''
                                }
                            ]}}
                ],
                validRules: {
                    exchangeYear: [{ required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bpYearRequired`, 'BP年为必填项') }, {
                        pattern: /^[12][0-9]{3}$/, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bpYearCorrect`, 'BP年，请书写正确的格式')
                    }],
                    originalCurrency: [{ required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_srmCurrencyRequired`, '原始货币为必填项') }],
                    targetCurrency: [{ required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_targetCurrencyRequired`, '目标货币为必填项') }],
                    exchange: [{ required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_exchangeRequired`, '汇率为必填项') }]
                }
            },
            url: {
                add: '/exchange/bpExchangeRate/add',
                edit: '/exchange/bpExchangeRate/edit',
                detail: '/exchange/bpExchangeRate/queryById'
            }

        }
    },
    methods: {

    }
}
</script>