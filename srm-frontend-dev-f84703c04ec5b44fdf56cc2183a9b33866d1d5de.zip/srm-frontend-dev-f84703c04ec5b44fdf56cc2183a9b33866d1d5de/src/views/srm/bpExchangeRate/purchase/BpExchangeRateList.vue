<template>
  <div style="height:100%">
    <list-layout
      v-show="!showEditPage && !showHisPage"
      ref="listPage"
      :pageData="pageData"
      :url="url" />
    <!-- 编辑页面 -->
    <BpExchangeRateEdit
      v-if="showEditPage"
      :current-edit-row="currentEditRow"
      @hide="hideEditPage" /> 

    <a-modal
      :title="$srmI18n(`${$getLangAccount()}#i18n_title_historicalVersion`, '历史版本')"
      :visible="visible1"
      width="700"
      @ok="handleOk"
      @cancel="handleCancel"
    >
      <div>
        <vxe-table
          align="center"
          border
          resizable
          autoResize
          showOverflow
          showHeaderOverflow
          headerAlign="center"
          row-id="id"
          height="300"
          ref="listGrid"
          size="mini"
          :data="hisTableData" >
          <vxe-table-column
            field="exchangeYear"
            :title="$srmI18n(`${$getLangAccount()}#i18n_title_exchangeYear`, 'BP汇率年')"></vxe-table-column>
          <vxe-table-column
            field="originalCurrency_dictText"
            :title="$srmI18n(`${$getLangAccount()}#i18n_title_srmCurrency`, '原始货币')"></vxe-table-column>
          <vxe-table-column
            field="targetCurrency_dictText"
            :title="$srmI18n(`${$getLangAccount()}#i18n_title_targetCurrency`, '目标货币')"></vxe-table-column>
          <vxe-table-column
            field="exchange"
            :title="$srmI18n(`${$getLangAccount()}#i18n_title_exchange`, '汇率')"></vxe-table-column>
        </vxe-table>
      </div>
    </a-modal>
    
  </div>
</template>
<script>
import BpExchangeRateEdit from './modules/BpExchangeRateEdit'
import {ListMixin} from '@comp/template/list/ListMixin'
import {getAction} from '@/api/manage'
export default {
    mixins: [ListMixin],
    components: {
        BpExchangeRateEdit
    },
    data () {
        return {
            visible1: false,
            showEditPage: false,
            showHisPage: false,
            hisTableData: [],
            pageData: {
                businessType: 'rule',
                button: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'), icon: 'plus', clickFn: this.handleAdd, type: 'primary'},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_helpText`, '帮助说明'), icon: 'file-text', folded: true, clickFn: this.showHelpText},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentExplain`, '附件说明'), icon: 'file-pdf', folded: true, clickFn: this.showHelpPDF}
                   
                ],
                optColumnList: [
                    {type: 'edit', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'), clickFn: this.handleEdit, allow: this.showEditCondition},
                    {type: 'delete', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), clickFn: this.handleDelete},
                    {type: 'history', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_numberOfHistory`, '历史记录'), clickFn: this.handleHis, allow: this.showHisCondition}
                ],
                optColumnWidth: 200,
                formField: [
                    {
                        type: 'input',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_keyword`, '关键字'),
                        fieldName: 'keyWord',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierNameOrELS`, '供应商名称/供应商ELS号')
                    }
                ],
                form: {
                    keyWord: ''
                }
            },
            url: {
                list: '/exchange/bpExchangeRate/list',
                delete: '/exchange/bpExchangeRate/delete',
                histRecordList: '/exchange/bpExchangeRateHis/historyList',
                columns: 'PurchaseBpExchangeRate'
            }
        }
    },
    methods: {
        handleAdd () {
            this.currentEditRow = null
            this.showEditPage = true
            this.$store.dispatch('SetTabConfirm', true)
        },
        changeVersion (row){
            let that = this
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_versionUpdating`, '版本更新'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterTheVersionIsUpdated`, '版本更新后,可以在历史查看旧版'),
                onOk: function () {
                    that.postData({'id': row.id})
                }
            })
        },
        postData (param){
            this.$refs.listPage.confirmLoading = true
            getAction(this.url.changeVersion, param).then((res) => {
                if (res.success) {
                    this.$message.success(res.message)
                    this.searchEvent()
                } else {
                    this.$message.warning(res.message)
                }
            }).finally(() => {
                this.$refs.listPage.confirmLoading = false
            })
        },
        handleHis (row){
            this.currentEditRow = null
            this.loading = true
            console.log(row.id) 
            getAction(this.url.histRecordList, {id: row.id}).then(res => {
                console.log(res)
                if (res.success) {
                    let list = res.result || []
                    this.hisTableData = list
                    this.visible1 = true
                }
                this.loading = false
            })
          
        },
        handleOk (){
            this.visible1 = false
        },
        handleCancel (){
            this.visible1 = false
        }

    }
}
</script>