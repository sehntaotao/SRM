<template>
  <div style="height:100%">
    <!-- 列表界面 -->
    <list-layout
      v-show="!showEditPage && !showDetailPage && !showNewRoundPage"
      ref="listPage"
      :current-edit-row="currentEditRow"
      :pageData="pageData"
      :tabsList="tabsList"
      :url="url"
      @afterChangeTab="handleAfterChangeTab" />
    <!-- 编辑界面 -->
    <purchase-bidding-edit
      v-if="showEditPage"
      ref="editPage"
      :current-edit-row="currentEditRow"
      @hide="hideEditPage"/>
    <!-- 详情界面 -->
    <purchase-bidding-detail
      v-if="showDetailPage" 
      ref="detailPage" 
      :current-edit-row="currentEditRow" 
      @hide="hideEditPage" />
    <!-- 轮次界面 -->
    <!-- <Purchase-Ebidding-New-Round 
      v-if="showNewRoundPage" 
      ref="newRoundPage" 
      :current-edit-row="currentEditRow" 
      @hide="hideNewRoundPage" /> -->
    <!-- 变更弹窗 -->
    <a-modal
      v-model="regretVisible"
      :title="$srmI18n(`${$getLangAccount()}#i18n_title_tips`, '提示')"
      @ok="handleRegret">
      <div>
        <a-radio-group
          v-model="regretValue"> 
          <a-radio
            class="radio-wrap"
            :value="0">{{ $srmI18n(`${$getLangAccount()}#i18n_title_noMoreFulfillment`, '悔标，不再寻源') }}</a-radio> 
          <a-radio
            class="radio-wrap"
            :value="1">{{ $srmI18n(`${$getLangAccount()}#i18n_title_replaceSourcing`, '悔标，重新寻源') }}</a-radio> 
          <a-radio
            class="radio-wrap"
            :value="2">{{ $srmI18n(`${$getLangAccount()}#i18n_title_priceComparison`, '重新比价/定标') }}</a-radio>
        </a-radio-group>
      </div>
    </a-modal>
  </div>
</template>
<script>
  import {ListMixin} from '@comp/template/list/ListMixin'
  import PurchaseBiddingEdit from './modules/PurchaseBiddingEdit'
  import {ajaxFindDictItems} from '@/api/api'
  import layIM from '@/utils/im/layIM.js'
  import PurchaseBiddingDetail from './modules/PurchaseBiddingDetail'
  //import PurchaseEbiddingNewRound from './modules/PurchaseEbiddingNewRound'
  import {postAction} from '@/api/manage'
  import {SET_HALL_CURRENTROW} from '@/store/mutation-types'

  export default {
    mixins: [ListMixin],
    components: {
        PurchaseBiddingEdit,
        PurchaseBiddingDetail
        //PurchaseEbiddingNewRound
    },
    data () {
        return {
            regretValue: 0,
            regretVisible: false,
            currentRow: {},
            showNewRoundPage: false,
            pageData: {
                businessType: 'bidding',
                form: {
                    ebiddingDesc: '',
                    ebiddingNumber: '',
                    ebiddingStatus: undefined
                },
                button: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'), icon: 'plus', clickFn: this.handleAdd, type: 'primary'},
                    //{label: '报价历史', icon: 'snippets', clickFn: this.showHistoryList},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_helpText`, '帮助说明'), icon: 'file-text', folded: true, clickFn: this.showHelpText},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentExplain`, '附件说明'), icon: 'file-pdf', folded: true, clickFn: this.showHelpPDF}
                ],
                formField: [
                    {
                        type: 'input',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tenderNumber`, '招标单号'),
                        fieldName: 'biddingNumber',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_enterTenderNumberTips`, '请输入招标单号')
                    }
                    // {
                    //     type: 'select',
                    //     label: '单据状态',
                    //     fieldName: 'ebiddingStatus',
                    //     dictCode: 'srmEbiddingStatus',
                    //     placeholder: '请选择单据状态'
                    // }
                ],
                optColumnWidth: 320,
                optColumnList: [
                    {type: 'chat', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_communicate`, '沟通'), clickFn: this.handleChat, allow: this.allowChat},
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'), clickFn: this.handleView},
                    {type: 'edit', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'), clickFn: this.handleEdit, allow: this.allowEdit},
                    {type: 'edit', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_newRound`, '新轮次'), clickFn: this.createNew, allow: this.allowCreateNew},
                    {type: 'delete', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), clickFn: this.handleDelete, allow: this.allowEdit},
                    {type: 'regret', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_change`, '变更'), clickFn: this.showRegret, allow: this.allowRegret},
                    {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingHall`, '招标大厅'), clickFn: this.toTender, allow: this.allowTender },
                    {type: 'record', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmRecord`, '记录'), clickFn: this.handleRecord}
                ]
            },
            tabsList: [],
            url: {
                add: '/bidding/purchaseBiddingHead/add',
                list: '/bidding/purchaseBiddingHead/list',
                delete: '/bidding/purchaseBiddingHead/delete',
                regret: '/bidding/purchaseBiddingHead/regret',
                columns: 'PurchaseBiddingHead',
                excelCode: 'ebidding' 
            }
        }
    },
    mounted () {
        this.serachTabs('srmBiddingStatus', 'biddingStatus')
      this.serachCountTabs('/bidding/purchaseBiddingHead/counts')
    },
    created () {
        this.getUrlParam()
    },
    methods: {
        handleChat (row) {
            let { id } = row
            // 创建群聊
            layIM.creatGruopChat({id, type: 'PurchaseBidding', url: this.url || ''})
        }, 
        allowChat (row){
            return false
        },
        getUrlParam (){
            let templateNumber = this.$route.query.templateNumber
            let templateVersion = this.$route.query.templateVersion
            let busAccount = this.$route.query.busAccount
            let id = this.$route.query.id
            if(templateNumber && templateVersion && id && busAccount){
                let row = {}
                row['templateNumber']=templateNumber
                row['templateVersion']=templateVersion
                row['id']=id
                row['busAccount']=busAccount
                this.currentEditRow = row
                this.showDetailPage = true
            }
        },
        submitCallBack (row){
            this.currentEditRow = row
            this.showEditPage = false
            this.showDetailPage = true
            this.searchEvent()
        },
        cancelAuditCallBack (row){
            this.currentEditRow = row
            this.showDetailPage = false
            this.showEditPage = true
            this.searchEvent()
        },
        toTender (row) {
            this.$ls.set(SET_HALL_CURRENTROW, row)
            let _t = +new Date()
            const routeUrl = this.$router.resolve({
                path: '/hall',
                query: {
                    _t
                }
            })
            window.open(routeUrl.href, '_blank')
        },
        allowTender (row) {
            return row.biddingStatus == '0'
        },
        allowEdit (row) {
            //审批中禁用
            if(row.auditStatus == '1'){
                return true
            }
            //新建不禁用
            return row.biddingStatus != '0'
        },
        allowCreateNew (row){
            //竞价结束状态5
            return row.ebiddingStatus != '5'
        },
        allowRegret (row){
            let reusltAudit = row.reusltAudit
            if(reusltAudit == '1'){
                //已授标状态6 && 审批通过2
                return row.ebiddingStatus != '6' && row.reusltAuditStatus != '2'
            }else {
                //已授标状态6
                return row.ebiddingStatus != '6'
            }
        },
        createNew (row){
            this.currentEditRow = row
            this.showNewRoundPage = true
        },
        hideNewRoundPage (){
            this.showNewRoundPage = false
        },
        showHistoryList (){
            this.$store.dispatch('SetTabConfirm', false)
            this.$router.push({
                path: '/ebidding/purchaseEbiddingHisList'
            })
        },
        showRegret (row){
            this.regretVisible = true
            this.currentRow = row
        },
        handleRegret (){
            let headId = this.currentRow.id
            postAction(this.url.regret, {id: headId, regretFlag: this.regretValue}).then(res => {
                if(res.success) {
                    this.regretVisible = false
                    this.$message.success(res.message)
                    this.$refs.listPage.loadData()
                }else {
                    this.$message.warning(res.message)
                }
            })
        }
    }
}
</script>
<style lang="less" scoped>
.radio-wrap {
    display: block;
    height: 30px;
}
</style>