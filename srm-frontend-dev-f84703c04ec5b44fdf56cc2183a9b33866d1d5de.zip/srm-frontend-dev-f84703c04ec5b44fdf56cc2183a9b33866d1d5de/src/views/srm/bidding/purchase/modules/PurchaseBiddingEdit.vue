<template>
  <div class="page-container">
    <edit-layout
      ref="editPage"
      refresh
      :page-data="pageData"
      :current-edit-row="currentEditRow"
      :url="url" />
    <field-select-modal 
      ref="fieldSelectModal" />
    <!-- 加载配置文件 -->
    <remote-js
      :src="fileSrc"
      @load="loadSuccess"
      @error="loadError" />
  </div>
</template>

<script>
import { EditMixin } from '@comp/template/edit/EditMixin'
import fieldSelectModal from '@comp/template/fieldSelectModal'
import { getAction, postAction } from '@/api/manage'

export default {
    name: 'PurchaseBiddingEdit',
    mixins: [EditMixin],
    components: {
        fieldSelectModal
    },
    data () {
        return {
            selectType: 'material',
            pageData: {
                form: {},
                groups: [
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingBankInfo`, '招标行信息'),  groupType: 'item', groupCode: 'itemInfo', type: 'grid', custom: {
                        ref: 'purchaseBiddingItemList',
                        columns: [],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addBiddingItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteItemEvent}
                        ]
                    } },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierInfo`, '供应商信息'), groupCode: 'supplierInfo', type: 'grid', custom: {
                        ref: 'biddingSupplierList',
                        columns: [
                            { 
                                type: 'checkbox', width: 40 
                            },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierAccount`, '供应商账号'),
                                field: 'toElsAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_toCompanyCode`, '供应商编码'),
                                field: 'supplierCode',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierName`, '供应商名称'),
                                field: 'supplierName',
                                width: 200
                            }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addSupplierEvent},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteSupplierEvent}
                        ]
                    } },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_evaluationExpert`, '评标专家'), groupCode: 'specialistInfo', type: 'grid', custom: {
                        ref: 'purchaseBiddingSpecialistList',
                        columns: [
                            { 
                                type: 'checkbox', width: 40 
                            },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertName`, '专家姓名'),
                                field: 'name',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertAccount`, '专家账号'),
                                field: 'subAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertType`, '专家类型'),
                                field: 'specialistClasses_dictText',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertPhone`, '专家电话'),
                                field: 'mobileTelephone',
                                width: 150
                            }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addSpecialistEvent},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.delSpecialistEvent}
                        ]
                    } },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachedDemandList`, '附件需求清单'), groupCode: 'fileDemandInfo', type: 'grid', custom: {
                        ref: 'purchaseAttachmentDemandList',
                        columns: [
                            { type: 'checkbox', width: 40 },
                            { type: 'seq', width: 60, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')},
                            { field: 'fileType', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileType`, '文件类型'), width: 120, dictCode: 'srmFileType', editRender: {name: '$select', options: []} },
                            { field: 'stageType', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_phaseType`, '阶段类型'), width: 120, dictCode: 'stageType', editRender: {name: '$select', options: []} },
                            { field: 'required', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ifRequired`, '是否必填'), width: 120, cellRender: {name: '$switch', props: {openValue: '1', closeValue: '0'}} },
                            { field: 'remark', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_remark`, '备注'), width: 220, editRender: {name: '$input'} }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addFileDemand},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteFileDemand}
                        ]
                    } },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_accessory`, '附件'), groupCode: 'fileInfo', type: 'grid', custom: {
                        ref: 'purchaseAttachmentList',
                        columns: [
                            { type: 'checkbox', width: 40 },
                            { type: 'seq', width: 60, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')},
                            { field: 'fileType_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileType`, '文件类型'), width: 120 },
                            { field: 'fileName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileName`, '文件名称'), width: 120 },
                            { field: 'uploadTime', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadTime`, '上传时间'), width: 180 },
                            { field: 'uploadElsAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploaderPerson`, '上传人'), width: 120 },
                            { field: 'grid_opration', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), width: 120, align: 'center', slots: { default: 'grid_opration' } }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'), type: 'upload', businessType: 'bidding', callBack: this.uploadCallBack}
                        ],
                        showOptColumn: true,
                        optColumnList: [
                            { type: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), clickFn: this.downloadEvent },
                            { type: 'delete', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), clickFn: this.deleteFilesEvent }
                        ]
                    } }
                ],
                formFields: [],
                publicBtn: [
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', click: this.saveEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_release`, '发布'), type: 'primary', click: this.publishEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitApproval`, '提交审批'), type: 'primary', click: this.submit },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'), click: this.goBack }
                ]
            },
            url: {
                add: '/bidding/purchaseBiddingHead/add',
                edit: '/bidding/purchaseBiddingHead/edit',
                detail: '/bidding/purchaseBiddingHead/queryById',
                public: '/bidding/purchaseBiddingHead/publish',
                submit: '/elsUflo/audit/submit',
                upload: '/attachment/purchaseAttachment/upload'
            }
        }
    },
    computed: {
        fileSrc () {
            let templateNumber = this.currentEditRow.templateNumber
            let templateVersion = this.currentEditRow.templateVersion
            let account = this.currentEditRow.templateAccount ? this.currentEditRow.templateAccount :  this.currentEditRow.busAccount
            let time = new Date().getTime()
            return `${this.$variateConfig['configFiles']}/${account}/purchase_bidding_${templateNumber}_${templateVersion}.js?t=`+time
        }
    },
    methods: {
        addBiddingItem () {
            this.selectType = 'material'
            const form = this.$refs.editPage.getPageData()
            const { mustMaterialNumber = '1' } = form
            if(mustMaterialNumber == '1'){
                let url = '/material/purchaseMaterialHead/list'
                let columns = [
                    {field: 'materialNumber', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_materialNumber`, '物料编号'), width: 150},
                    {field: 'materialDesc', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_materialDesc`, '物料描述'), width: 150},
                    {field: 'materialName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_materialName`, '物料名称'), width: 200},
                    {field: 'materialSpec', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_materialSpecification`, '物料规格'), width: 200}
                ]
                this.$refs.fieldSelectModal.open(url, {blocDel: '0', freeze: '0'}, columns, 'multiple')
            }else{
                let itemGrid = this.$refs.editPage.$refs.purchaseBiddingItemList[0]
                let itemData = {}
                this.pageConfig.itemColumns.forEach(item => {
                    if(item.defaultValue) {
                        itemData[item.field] = item.defaultValue
                    }
                })
                itemGrid.insertAt([itemData], -1)
            }
        },
        deleteItemEvent () {
            let itemGrid = this.$refs.editPage.$refs.purchaseBiddingItemList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        fieldSelectOk (data) {
            if(this.selectType == 'material'){
                let itemGrid = this.$refs.editPage.$refs.purchaseBiddingItemList[0]
                let { fullData } = itemGrid.getTableData()
                let materialList = fullData.map(item => {
                    return item.materialNumber
                })
                //过滤已有数据
                let insertData = data.filter(item => {
                    return !materialList.includes(item.materialNumber)
                })
                this.pageConfig.itemColumns.forEach(item => {
                    if(item.defaultValue) {
                        insertData.forEach(insert => {
                            if(!insert[item.field]){
                                insert[item.field] = item.defaultValue
                            }
                        })
                    }
                })
                itemGrid.insertAt(insertData, -1)
            }else if(this.selectType == 'supplier'){
                let supplierGrid = this.$refs.editPage.$refs.biddingSupplierList[0]
                let { fullData } = supplierGrid.getTableData()
                let supplierList = fullData.map(item => {
                    return item.toElsAccount
                })
                // 过滤已有数据
                let insertData = data.filter(item => {
                    return !supplierList.includes(item.toElsAccount)
                })
                insertData = insertData.map(item => {
                    return {
                        toElsAccount: item.toElsAccount,
                        supplierCode: item.supplierCode,
                        supplierName: item.supplierName,
                        supplierStatus_dictText: item.supplierStatus_dictText
                    }
                })
                supplierGrid.insertAt(insertData, -1)
            }else if(this.selectType == 'specialist'){
                let specialistGrid = this.$refs.editPage.$refs.purchaseBiddingSpecialistList[0]
                let { fullData } = specialistGrid.getTableData()
                let specialistList = fullData.map(item => {
                    return item.subAccount
                })
                // 过滤已有数据
                let insertData = data.filter(item => {
                    return !specialistList.includes(item.subAccount)
                })
                insertData = insertData.map(item => {
                    return {
                        subAccount: item.subAccount,
                        name: item.name,
                        mobileTelephone: item.mobileTelephone,
                        specialistClasses_dictText: item.specialistClasses_dictText,
                        specialistClasses: item.specialistClasses
                    }
                })
                specialistGrid.insertAt(insertData, -1)
            }
        },
        addSupplierEvent () {
            this.selectType = 'supplier'
            let url = '/supplier/supplierMaster/list'
            let columns = [
                {field: 'toElsAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierAccount`, '供应商账号'), width: 150},
                {field: 'supplierCode', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_toCompanyCode`, '供应商编码'), width: 150},
                {field: 'supplierName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierName`, '供应商名称'), width: 200},
                {field: 'supplierStatus_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierState`, '供应商状态'), width: 200},
                {field: 'cateName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierCategory`, '供应商品类'), width: 200}
            ]
            // 获取供应商范围参数
            const form = this.$refs.editPage.getPageData()
            const { supplierScope = '' } = form
            this.$refs.fieldSelectModal.open(url, { supplierStatus: supplierScope, frozenFunctionValue: '2' }, columns, 'multiple')
        },
        deleteSupplierEvent () {
            let supplierGrid = this.$refs.editPage.$refs.biddingSupplierList[0]
            let checkboxRecords = supplierGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            supplierGrid.removeCheckboxRow()
        },
        addSpecialistEvent (){
            this.selectType = 'specialist'
            let url = '/specialist/specialistInfo/list'
            let columns = [
                {field: 'name', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertName`, '专家姓名'), width: 150},
                {field: 'subAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertAccount`, '专家账号'), width: 150},
                {field: 'specialistClasses_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertType`, '专家类型'), width: 200},
                {field: 'mobileTelephone', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expertPhone`, '专家电话'), width: 200}
            ]
            // 获取供应商范围参数
            //const form = this.$refs.editPage.getPageData()
            //const { supplierScope = '' } = form
            this.$refs.fieldSelectModal.open(url, { }, columns, 'multiple')
        },
        delSpecialistEvent () {
            let specialistGrid = this.$refs.editPage.$refs.purchaseBiddingSpecialistList[0]
            let checkboxRecords = specialistGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            specialistGrid.removeCheckboxRow()
        },
        addFileDemand () {
            let demandGrid = this.$refs.editPage.$refs.purchaseAttachmentDemandList[0]
            demandGrid.insertAt({}, -1)
        },
        deleteFileDemand () {
            let demandGrid = this.$refs.editPage.$refs.purchaseAttachmentDemandList[0]
            let checkboxRecords = demandGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            demandGrid.removeCheckboxRow()
        },
        uploadCallBack (result) {
            let fileGrid = this.$refs.editPage.$refs.purchaseAttachmentList[0]
            fileGrid.insertAt(result, -1)
        },
        deleteFilesEvent (row) {
            const fileGrid = this.$refs.editPage.$refs.purchaseAttachmentList[0]
            getAction('/attachment/purchaseAttachment/delete', {id: row.id}).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success) fileGrid.remove(row)
            })
        },
        saveEvent () {
            this.$refs.editPage.postData()
        },
        publishEvent () {
            const form = this.$refs.editPage.getPageData()
            if(form.publishAudit == '1'){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitForApprovalTips`, '不可直接发布，请提交审批！'))
                return
            }
            let rows = this.$refs.editPage.getPageData().purchaseBiddingItemList || []
            // 如果基本信息中 供应商税率 0 不可以修改， 发布 招标行信息税码不能为空
            let taxCodeArr = (form.supplierTaxRate && form.supplierTaxRate == '0' && rows.find(rs => rs.taxCode)) ? rows.map(rs => rs.taxCode || '') : null
            if (taxCodeArr && taxCodeArr.includes('')) {
                this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierTaxRateTips`, '供应商税率不能为空'))
                return
            }

            let supperSize1 = this.$refs.editPage.$refs.biddingSupplierList[0].getTableData().tableData.length
            // 参与数量验证
            if (form.biddingType == '0' && form.participateQuantity && form.participateQuantity>supperSize1 ){
                this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cantBeLessOfParticipants`, '邀请供应商数量不能小于参与数量！'))
                return
            }
            this.$refs.editPage.handleSend()
        },
        submit (){
            const form = this.$refs.editPage.getPageData()
            if(form.publishAudit != '1'){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_noNeedSubmitApproval`, '无需提交审批！'))
                return
            }
            const _this = this
            const fn = (url, param, vm) => {
                console.log('vm :>> ', vm) // 编辑模板组件实例
                _this.$refs.editPage.confirmLoading = true
                postAction(url, param ).then(res =>  {
                    const type = res.success ? 'success' : 'error'
                    _this.$message[type](res.message)
                    if(res.success){
                        //_this.goBack()
                        this.$parent.submitCallBack(form)
                    }
                }).finally(() => {
                    _this.$refs.editPage.confirmLoading = false
                })
            }
            const param = {
                businessId: form.id,
                businessType: 'publishBidding',
                auditSubject: `招标单发布审批，单号：${form.biddingNumber}`,
                params: JSON.stringify(form)
            }
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitApproval`, '提交审批'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmSubmitApprovalTips`, '是否确认提交审批'),
                onOk () {
                    _this.$refs.editPage.handValidate(_this.url.submit, param, fn)
                }
            })
        }
    }
}
</script>