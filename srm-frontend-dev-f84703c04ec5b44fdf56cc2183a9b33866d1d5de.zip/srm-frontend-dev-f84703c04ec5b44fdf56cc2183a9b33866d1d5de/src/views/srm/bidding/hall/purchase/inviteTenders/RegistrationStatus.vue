<template>
  <div class="registration-status">
    <!-- <content-header
      v-if="showHeader"
      class="posA"
      :btns="btns"
      @content-header-back="goBack"
    /> -->

    <div
      class="container"
      :style="style">

      <remote-js
        v-if="currentEditRow.templateNumber"
        :src="fileSrc"
        @load="loadSuccess"
        @error="loadError" />

      <detail-layout
        ref="detailPage" 
        mode="tiled"
        :page-data="pageData"
        :url="url" />
      
    </div>
  </div>
</template>

<script>
// import ContentHeader from '@/views/srm/bidding/hall/components/content-header'
import { DetailMixin } from '@comp/template/hallDetail/DetailMixin'
export default {
    mixins: [
        DetailMixin
    ],
    components: {
        // 'content-header': ContentHeader
    },
    data () {
        return {
            isLocal: true,
            btns: [],
            showHeader: false,
            height: 400,
            pageData: {
                groups: [
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_participatingSuppliers`, '参与供应商'), groupCode: 'supplierInfo', type: 'grid', custom: {
                        ref: 'biddingSupplierList',
                        columns: [
                            { type: 'checkbox', width: 40 },
                            { type: 'seq', width: 50, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号') },
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierELSAccount`, '供应商ELS账号'), field: 'toElsAccount', width: 120 },
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_massProdHead88b_supplierErpCode`, '供应商ERP编码'), field: 'supplierCode', width: 120 },
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_massProdHeade95_supplierName`, '供应商名称'), field: 'supplierName', width: 300 },
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_responseStatus`, '响应状态'), field: 'replyStatus_dictText', width: 100},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_responseTime`, '响应时间'), field: 'replyTime', width: 140},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_contact`, '联系人'), field: 'contacts', width: 120},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_phone`, '手机号'), field: 'phone', width: 120},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_mail`, '邮件'), field: 'email', width: 150},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_viewBidsPermission`, '查看标书权限'), field: 'bidCheck_dictText', width: 120},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bidAuthority`, '投标权限'), field: 'bidQuote_dictText', width: 120},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_sourceType`, '来源类型'), field: 'sourceType_dictText', width: 120},
                            { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), width: 120, showOverflow: true, slots: { default: 'grid_opration'}}
                        ],
                        optColumnList: [
                            {type: 'risk', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_suppliersRisk`, '供应商风险'), clickFn: this.handleRisk}
                        ]
                    } }
                ]
            },
            url: {
                detail: '/bidding/purchaseBiddingHead/queryById',
                submit: '/elsUflo/audit/submit'
            }
        }
    },
    inject: [
        'currentEditRow'
    ],
    computed: {
        style () {
            const offset = this.showHeader ? 120 : 66
            return { minHeight: `${this.height - offset}px` }
        },
        fileSrc () {
            const { templateNumber = '', templateVersion = '' } = this.currentEditRow || {}
            let account = this.currentEditRow.templateAccount ? this.currentEditRow.templateAccount :  this.currentEditRow.busAccount
            const configFiles = this.$variateConfig['configFiles']
            const time = +new Date()
            const url = `${configFiles}/${account}/purchase_bidding_${templateNumber}_${templateVersion}.js?t=`+time
            return url
        }
    },
    methods: {
        //查看风险
        handleRisk ({ toElsAccount }){
            const { href } = this.$router.resolve({
                path: '/srm/base/SupplierVenture',
                query: {
                    elsAccount: toElsAccount
                }
            })
            window.open(href)
        },
        goBack () {
            console.log('back')
        }
    },
    created () {
        this.height = document.documentElement.clientHeight
    }
}
</script>

<style lang="less" scoped>
.registration-status {
    .posA {
        & +.container {
            margin-top: 44px;
        }
    }
    .container {
        background: #fff;
        padding: 12px;
    }
}
</style>
