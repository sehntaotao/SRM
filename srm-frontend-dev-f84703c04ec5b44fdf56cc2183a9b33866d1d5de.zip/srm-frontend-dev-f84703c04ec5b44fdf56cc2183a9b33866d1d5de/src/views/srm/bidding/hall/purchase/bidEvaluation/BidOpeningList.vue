<template>
  <div class="BidOpeningList">
    <content-header
      v-if="showHeader"
      class="posA"
      :btns="btns"
      :deadline="evaEndTime"
      :renderExtra="renderExtra"
    />

    <div
      class="container"
      :style="style">
    
      <a-spin :spinning="confirmLoading">
        <div class="itemBox">
          <div class="table">
            <vxe-grid
              ref="grid"
              v-bind="defaultGridOption"
              :columns="columns">
              <template slot="empty">
                <a-empty />
              </template>
            </vxe-grid>
          </div>
        </div>
      </a-spin>
    </div>

  </div>
</template>

<script>
import ContentHeader from '@/views/srm/bidding/hall/components/content-header'
import { getAction } from '@/api/manage'

export default {
    components: {
        'content-header': ContentHeader
    },
    data () {
        return {
            confirmLoading: false,
            supplierEvaScoreList: [],
            form: {},
            btns: [],
            showHeader: true,
            height: 0,
            //默认表格配置
            defaultGridOption: {
                border: true,
                resizable: true,
                autoResize: true,
                showOverflow: true,
                columnKey: true,
                highlightHoverRow: true,
                size: 'mini',
                align: 'center',
                headerAlign: 'center',
                data: [],
                radioConfig: { highlight: false, trigger: 'row' },
                checkboxConfig: { highlight: false, trigger: 'row' },
                editConfig: { trigger: 'dblclick', mode: 'cell' }
            },
            columns: [
                { type: 'seq', width: 50, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号') },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierAccount`, '供应商账号'), field: 'toElsAccount', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingPerson`, '招标负责人'), field: 'contacts', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contactNumber`, '联系电话'), field: 'phone', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_email`, '邮箱'), field: 'email', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_quotationResponse`, '报价响应'), field: 'quoteEcho', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_totalAmount`, '总报价'), field: 'totalAmount', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_quoteRank`, '报价排名'), field: 'quoteRank', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_busScore`, '商务分'), field: 'busScore', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_busRank`, '商务排名'), field: 'busRank', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tecScore`, '技术分'), field: 'tecScore', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tecRank`, '技术排名'), field: 'tecRank', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_totalScore`, '总分'), field: 'totalScore', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_synthesisRank`, '综合排名'), field: 'synthesisRank', width: 150 }
            ]
        }
    },
    inject: [
        'currentEditRow'
    ],
    computed: {
        style () {
            const offset = this.showHeader ? 120 : 66
            return { minHeight: `${this.height - offset}px` }
        },
        evaEndTime () {
            return this.currentEditRow.evaEndTime
        }
    },

    methods: {
        renderExtra (deadline, fn) {
            return (
                <div class="countdown" style="display: flex; align-items: center;">
                    <a-icon type="info-circle" />
                    <span style="margin: 0 8px;">评标截止时间</span>
                    <a-statistic-countdown
                        value={ deadline }
                        format="HH:mm:ss"
                        valueStyle={ { fontSize: '12px', color: '#ee1d1d' } }
                        finish={ fn }
                    />
                </div>
            )
        },
        deleteItemEvent (row, column, ref) {
            const grid = this.$refs[ref]
            grid.remove(row)
        },
        getData () {
            this.confirmLoading = true
            const url = '/bidding/purchaseBiddingEvaResult/queryEvaResultByBiddingId'
            const { id = '' } = this.currentEditRow || {}
            const params = { id }
            getAction(url, params)
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    const result = res.result || []
                    this.$refs.grid.loadData(result)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        init () {
            this.height = document.documentElement.clientHeight
            this.getData()
        }
    },
    created () {
        this.init()
    }
}
</script>

<style lang="less" scoped>
.BidOpeningList {
    .posA {
        & +.container {
            margin-top: 44px;
        }
    }
    .container {
        background: #fff;
        padding: 12px;
    }
    .itemBox {
        + .itemBox {
        margin-top: 12px;
        }
    }
	.title {
		padding: 0 7px;
		border: 1px solid #ededed;
		height: 34px;
		line-height: 34px;
		&.dark {
			background: #f2f2f2;
		}
	}
	.table,
	.description {
		margin-top: 10px;
	}
}
</style>

