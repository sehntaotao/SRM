<template>
  <div class="open">
    <div
      class="container"
      :style="style">

      <a-spin :spinning="confirmLoading">
        <div class="boxWrap">
          <h3 class="h3">{{ $srmI18n(`${$getLangAccount()}#i18n_title_bidCountdown`, '开标倒计时') }}</h3>

          <div class="count">
            <div class="countdown">
              <a-statistic-countdown
                :value="deadline"
                format="DD:HH:mm:ss"
                :value-style="valueStyle"
                @finish="handleFinish"
              />
            </div>
            
          </div>
          <div class="time">
            <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_day`, '天') }}</span>
            <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_time`, '时') }}</span>
            <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_branch`, '分') }}</span>
            <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_second`, '秒') }}</span>
          </div>
          <div class="info">
            <div class="row">
              <span class="tit">{{ $srmI18n(`${$getLangAccount()}#i18n_title_bidOpenStatus`, '开标状态') }}</span>
              <strong>{{ biddingStatus_dictText }}</strong>
            </div>
            <div class="row">
              <span class="tit">{{ $srmI18n(`${$getLangAccount()}#i18n_title_supervisor`, '监督人员') }}</span>
            </div>
            <div class="row">
              <span class="tit">{{ $srmI18n(`${$getLangAccount()}#i18n_title_bidOpenTime`, '开标时间') }}</span>
              {{ planOpenBidTime }}
            </div>
            <div class="row">
              <span class="tit">{{ $srmI18n(`${$getLangAccount()}#i18n_title_bidOpenPersonnel`, '开标人员') }}</span>
              {{ names }}
            </div>
          </div>
          <div class="btns">
            <a-button
              type="primary"
              :disabled="disabled"
              @click="handleOpen">
              {{ $srmI18n(`${$getLangAccount()}#i18n_title_bidOpenEnter`, '进入开标') }}
            </a-button>
          </div>
        </div>
      </a-spin>

    </div>
  </div>
</template>

<script>
import { getAction } from '@/api/manage'

export default {
    data () {
        return {
            confirmLoading: false,
            valueStyle: {
                width: '100%',
                height: '78px',
                fontSize: '46px',
                fontWeight: 700,
                color: '#727272',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                letterSpacing: '14px'
            },
            showHeader: false,
            height: 0,
            planOpenBidTime: '',
            names: '',
            biddingStatus_dictText: '',
            biddingStatus: '',
            timeStamp: '',
            deadline: null
        }
    },
    inject: [
        'currentEditRow'
    ],
    computed: {
        style () {
            const offset = this.showHeader ? 120 : 66
            return { minHeight: `${this.height - offset}px` }
        },
        disabled () {
            return this.biddingStatus !== '1'
        }
    },
    methods: {
        handleOpen () {
            this.getDetailPromise()
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    let timestamp = new Date(res.timestamp).getTime()
                    let deadline = new Date(this.planOpenBidTime).getTime()
                    if (timestamp <= deadline) {
                        this.$message.error(`未到达开标时间 ${this.planOpenBidTime}`)
                        return
                    }

                    const callback = () => {
                        const { id = '' } = this.currentEditRow || {}
                        const params = {
                            id
                        }
                        const url = '/bidding/purchaseBiddingHead/openBiddingById'
                        getAction(url, params)
                            .then(res => {
                                const type = res.success ? 'success' : 'error'
                                this.$message[type](res.message)
                                this.init()
                            })
                    }
                    this.$confirm({
                        title: '开标',
                        content: '是否确认进入开标?',
                        onOk () {
                            callback && callback()
                        },
                        onCancel () {
                            console.log('Cancel')
                        }
                    })

                })
        },
        handleFinish () {
            console.log('finish')
            this.init()
        },
        getDetailPromise () {
            const { id = '' } = this.currentEditRow || {}
            const params = {
                id,
                pageNo: 1,
                pageSize: 20
            }
            const url = '/bidding/purchaseBiddingHead/list'
            return getAction(url, params)
        },
        getMemberData () {
            this.confirmLoading = true
            const url = '/bidding/purchaseBiddingHead/queryById'
            const { id = '' } = this.currentEditRow || {}
            const params = { id }
            getAction(url, params)
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    const { purchaseBiddingSpecialistList = [] } = res.result || {}
                    const memberArr = purchaseBiddingSpecialistList.filter(n => n.memberType === '2')
                    this.names = memberArr.map(n => n.name).join(',')
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        init () {
            this.confirmLoading = true
            this.getDetailPromise()
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    this.timestamp = res.timestamp
                    const { records = [] } = res.result || {}
                    if (records && records.length) {
                        this.biddingStatus = records[0].biddingStatus
                        this.planOpenBidTime = records[0].planOpenBidTime
                        this.biddingStatus_dictText = records[0].biddingStatus_dictText
                        this.deadline = new Date(this.planOpenBidTime).getTime()
                        console.log('deadline', this.deadline)
                    }
                    this.getMemberData()
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        }
    },
    created () {
        console.log('this.currentEditRow', this.currentEditRow)
        this.height = document.documentElement.clientHeight
        this.deadline = +new Date()
        this.init()
    }
}
</script>

<style lang="less" scoped>
.open {
	.posA {
		& + .container {
			margin-top: 44px;
		}
	}
	.container {
		margin-left: -8px;
		margin-top: -8px;
		padding: 12px;
		background: #e9e9e9;
		text-align: center;
		font-weight: 400;
		font-size: 14px;
		.boxWrap {
			margin-top: 80px;
		}
	}
	.h3 {
		font-size: 24px;
		color: #3d3d3d;
	}
	.count,
	.time {
		width: 454px;
	}
	.count {
		margin: 0 auto;
		border: 1px solid #000;
		border-radius: 8px;
		height: 78px;
	}
	.time {
		display: flex;
		justify-content: space-between;
		margin: 14px auto;
		padding: 0 36px;
	}
	.info {
		line-height: 2.4;
		.tit {
			&::after {
				margin-right: 8px;
				content: ":";
			}
		}
	}
	.btns {
		margin-top: 14px;
	}
}
</style>
