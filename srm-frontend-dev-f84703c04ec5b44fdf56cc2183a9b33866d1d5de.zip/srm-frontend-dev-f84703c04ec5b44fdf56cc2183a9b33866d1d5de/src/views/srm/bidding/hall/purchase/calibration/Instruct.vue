<template>
  <div class="Instruct">
    <content-header
      v-if="showHeader"
      class="posA"
      :btns="btns"
      @content-header-record="handleRecord"
      @content-header-submit="handleSubmit"
      @content-header-save="handleSave"
      @content-header-showFlow="showFlow"
      @content-header-cancelAudit="cancelAudit"
    />

    <div
      class="container"
      :style="style">
    
      <a-spin :spinning="confirmLoading">
        <div class="itemBox">
          <div class="table">
            <vxe-grid
              ref="biddingSupplierList"
              v-bind="defaultGridOption"
              :columns="columns">
              <template slot="empty">
                <a-empty />
              </template>
            </vxe-grid>
          </div>
        </div>
      </a-spin>
    </div>
    <a-modal
      centered
      :width="960"
      :maskClosable="false"
      :visible="flowView"
      @ok="closeFlowView"
      @cancel="closeFlowView">
      <iframe
        style="width:100%;height:560px"
        title=""
        :src="currentBasePath + '/uflo/diagram?processInstanceId='+flowId"
        frameborder="0"></iframe>
    </a-modal>
  </div>
</template>

<script>
import ContentHeader from '@/views/srm/bidding/hall/components/content-header'
import { getAction, postAction, httpAction } from '@/api/manage'
const ALIAS = '__$$__'

export default {
    components: {
        'content-header': ContentHeader
    },
    data () {
        return {
            flowView: false,
            flowId: '',
            currentBasePath: this.$variateConfig['domianURL'],
            confirmLoading: false,
            purchaseBiddingItemList: [],
            form: {},
            btns: [
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_creatPriceRecord`, '生成价格记录'), type: 'primary', event: 'record' },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitApproval`, '提交审批'), type: 'primary', event: 'submit' },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_revokeApproval`, '撤销审批'), type: '', event: 'cancelAudit' },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_viewProcess`, '查看流程'), type: '', event: 'showFlow' },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', event: 'save' }
            ],
            showHeader: true,
            height: 0,
            //默认表格配置
            defaultGridOption: {
                border: true,
                resizable: true,
                autoResize: true,
                showOverflow: true,
                columnKey: true,
                highlightHoverRow: true,
                size: 'mini',
                align: 'center',
                headerAlign: 'center',
                data: [],
                radioConfig: { highlight: false, trigger: 'row' },
                checkboxConfig: { highlight: false, trigger: 'row' },
                editConfig: { trigger: 'dblclick', mode: 'cell' }
            },
            columns: [
                { type: 'seq', width: 50, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号') },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierELSAccount`, '供应商ELS账号'), field: 'toElsAccount', width: 120 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_massProdHead88b_supplierErpCode`, '供应商ERP编码'), field: 'supplierCode', width: 120 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_massProdHeade95_supplierName`, '供应商名称'), field: 'supplierName', width: 200 }
                //{ title: '应标状态', field: 'replyStatus_dictText', width: 100}
            ]
        }
    },
    inject: [
        'currentEditRow'
    ],
    computed: {
        style () {
            const offset = this.showHeader ? 120 : 66
            return { minHeight: `${this.height - offset}px` }
        },
        // 判断是否为拆分方式
        isQuotaWay () {
            const { quotaWay = '0' } = this.currentEditRow || {}
            return quotaWay !== '1'
        }
    },

    methods: {
        getDetailPromise () {
            const { id = '' } = this.currentEditRow || {}
            const params = {
                id,
                pageNo: 1,
                pageSize: 20
            }
            const url = '/bidding/purchaseBiddingHead/list'
            return getAction(url, params)
        },
        showFlow (){
            let row = this.currentEditRow
            this.flowId = row.resultFlowId
            if(!this.flowId){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_noeStatusCantView`, '当前状态不能查看流程！'))
                return
            }
            this.flowView = true
        },
        closeFlowView (){
            this.flowView = false
        },
        cancelAudit (){
            let form = this.currentEditRow
            let param = {}
            param['businessType'] = 'resultBidding'
            param['businessId'] = form.id
            param['rootProcessInstanceId'] = form.resultFlowId
            this.confirmLoading = true
            httpAction('/elsUflo/audit/cancel', param, 'post').then((res) => {
                if (res.success) {
                    this.$message.success(res.message)
                    this.getTenderData()
                } else {
                    this.$message.warning(res.message)
                }
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        deleteItemEvent (row, column, ref) {
            const grid = this.$refs[ref]
            grid.remove(row)
        },
        getData () {
            this.confirmLoading = true
            const url = '/bidding/purchaseBiddingHead/queryConfirmBidById'
            const { id = '' } = this.currentEditRow || {}
            const params = { id }
            getAction(url, params)
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    let { biddingSupplierList = [] } = res.result || {}
                    if (biddingSupplierList.length) {
                        this.purchaseBiddingItemList = biddingSupplierList[0].purchaseBiddingItemList || []
                        this.setColumns()
                    }
                    this.$refs.biddingSupplierList.loadData(biddingSupplierList)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        setColumns () {
            let priceFormatter = (row, index) => {
                return row.purchaseBiddingItemList[index].price
            }
            let itemStatusFormatter = (row, index) => {
                return row.purchaseBiddingItemList[index].itemStatus === '3' ? this.$srmI18n(`${this.$getLangAccount()}#i18n_title_wonTheBid`, '已中标') : this.$srmI18n(`${this.$getLangAccount()}#i18n_title_notWonTheBid`, '未中标')
            }
            let quoteFormatter = (row, index) => {
                return row.purchaseBiddingItemList[index].quota
            }
            let itemStatusChangeEvent = (row, column, index) => {
                let val = row[column.property]
                row.purchaseBiddingItemList[index].itemStatus = val
            }

            let quoteChangeEvent = (row, column, index) => {
                let val = row[column.property]
                row.purchaseBiddingItemList[index].quota = val
            }

            const itemColumns = this.purchaseBiddingItemList.map((item, i) => {
                let obj = {
                    title: item.materialDesc,
                    children: [
                        {
                            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_offer`, '报价'),
                            field: `price${ALIAS}${i}`,
                            formatter: ({row}) => priceFormatter(row, i),
                            width: 120
                        },
                        {
                            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contractAward`, '授标'),
                            field: `itemStatus${ALIAS}${i}`,
                            formatter: ({row}) => itemStatusFormatter(row, i),
                            width: 120,
                            editRender: {
                                name: '$select',
                                options: [
                                    { value: '3', label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_wonTheBid`, '已中标') },
                                    { value: '2', label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_notWonTheBid`, '未中标') }
                                ],
                                events: {
                                    change: ({row, column}) => itemStatusChangeEvent(row, column, i)
                                }
                            }
                        },
                        {
                            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_splitRatio`, '拆分比例(%)'),
                            field: `quota${ALIAS}${i}`,
                            visible: this.isQuotaWay,
                            formatter: ({row}) => quoteFormatter(row, i),
                            width: 120,
                            editRender: {
                                name: '$input',
                                props: { type: 'number' },
                                events: {
                                    change: ({row, column}) => quoteChangeEvent(row, column, i)
                                }
                            }
                        }
                    ]
                }
                return obj
            })
            
            this.columns = this.columns.concat(itemColumns)
        },
        handleSave () {
            let biddingSupplierList = this.$refs.biddingSupplierList.getTableData().fullData
            if (this.isQuotaWay) {
                // 完成拆分百分比之和不能超过 100 的校验
                for (let i = 0; i < this.purchaseBiddingItemList.length; i++) {
                    let materialDesc = this.purchaseBiddingItemList[i].materialDesc
                    // 拆分比例
                    let count = 0
                    biddingSupplierList.forEach(n => {
                        let quota = n.purchaseBiddingItemList[i].quota || 0
                        count += Number(quota)
                    })
                    
                    if (count !== 100) {
                        this.$message.error(`${materialDesc} , 物料授权合计须等于 100%`)
                        return
                    }
                }
            }
            
            const callback = () => {
                biddingSupplierList = biddingSupplierList.map(item => {
                    Object.keys(item).forEach(prop => {
                        if (prop.indexOf(ALIAS) !== -1) {
                            delete item[prop]
                        }
                    })
                    return item
                })

                const params = {
                    id: this.currentEditRow.id,
                    biddingSupplierList
                }
                
                const url = '/bidding/purchaseBiddingHead/saveConfirmBid'
                
                this.confirmLoading = true
                postAction(url, params)
                    .then(res => {
                        const type = res.success ? 'success' : 'error'
                        this.$message[type](res.message)
                    })
                    .finally(() => {
                        this.confirmLoading = false
                    })
            }
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_calibration`, '定标'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmCalibration`, '是否确认当前定标结果?'),
                onOk () {
                    callback && callback()
                },
                onCancel () {
                    console.log('Cancel')
                }
            })
        },
        // 提交审批
        handleSubmit () {
            this.getDetailPromise()
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }

                    this.timestamp = res.timestamp
                    const { records = [] } = res.result || {}
                    if (!records && !records.length) {
                        return
                    }
                    const { id, biddingNumber, resultAuditStatus, resultAudit, biddingStatus } = records[0] || {}
                    if (resultAudit === '0') {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_documentNotNeedSubmit`, '该单据无需提交审批'))
                        return
                    }
                    if (resultAuditStatus !== '0') {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_unapprovedSubmit`, '未审批的单据才可提交审批'))
                        return
                    }
                    if (biddingStatus !== '5') {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingSubmit`, '已定标的单据才可提交审批'))
                        return
                    }
                    const callback = () => {
                        const params = {
                            businessId: id,
                            businessType: 'resultBidding',
                            auditSubject: `招标结果审批, 单号: ${biddingNumber}`,
                            params: JSON.stringify(this.currentEditRow)
                            // params: Object.assign({}, this.currentEditRow)
                        }
                        const url = '/elsUflo/audit/submit'
                
                        this.confirmLoading = true
                        postAction(url, params)
                            .then(res => {
                                const type = res.success ? 'success' : 'error'
                                this.$message[type](res.message)
                            })
                            .finally(() => {
                                this.confirmLoading = false
                            })
                    }
                    this.$confirm({
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tips`, '提示'),
                        content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmApproveTips`, '是否确认提交审批?'),
                        onOk () {
                            callback && callback()
                        },
                        onCancel () {
                            console.log('Cancel')
                        }
                    })
                })
        },
        // 生成价格记录
        handleRecord () {
            this.getDetailPromise()
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }

                    this.timestamp = res.timestamp
                    const { records = [] } = res.result || {}
                    if (!records && !records.length) {
                        return
                    }

                    const { id, biddingStatus } = records[0] || {}
                    if (biddingStatus !== '5') {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingSubmit`, '已定标的单据才可提交审批'))
                        return
                    }
                    const callback = () => {
                        const params = { id }
                        const url = '/bidding/purchaseBiddingHead/manualCreatePrce'
                
                        this.confirmLoading = true
                        getAction(url, params)
                            .then(res => {
                                const type = res.success ? 'success' : 'error'
                                this.$message[type](res.message)
                            })
                            .finally(() => {
                                this.confirmLoading = false
                            })
                    }
                    this.$confirm({
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tips`, '提示'),
                        content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_creatPriceInfoTips`, '是否确认生成价格信息记录?'),
                        onOk () {
                            callback && callback()
                        },
                        onCancel () {
                            console.log('Cancel')
                        }
                    })
                })
        },
        init () {
            this.height = document.documentElement.clientHeight
            this.getData()
        }
    },
    created () {
        this.init()
    }
}
</script>

<style lang="less" scoped>
.Instruct {
    .posA {
        & +.container {
            margin-top: 44px;
        }
    }
    .container {
        background: #fff;
        padding: 12px;
    }
    .itemBox {
        + .itemBox {
        margin-top: 12px;
        }
    }
	.title {
		padding: 0 7px;
		border: 1px solid #ededed;
		height: 34px;
		line-height: 34px;
		&.dark {
			background: #f2f2f2;
		}
	}
	.table,
	.description {
		margin-top: 10px;
	}
}
</style>

