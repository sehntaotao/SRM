<!--
 * @Author: your name
 * @Date: 2021-05-11 15:17:08
 * @LastEditTime: 2021-05-11 15:17:25
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: /cloud-music/Users/wangdoudou/Documents/QQTProjects/srm-frontend_v4.5/src/views/hall/invite-tenders/announcement copy.vue
-->
<template>
  <div class="qualification-examination">
    qualification-examination
  </div>
</template>