<template>
  <div class="BidResultList">
    <content-header
      v-if="showHeader"
      class="posA"
      :btns="btns"
      :deadline="evaEndTime"
      :renderExtra="renderExtra"
      @content-header-save="handleSave"
    />

    <div
      class="container"
      :style="style">
    
      <a-spin :spinning="confirmLoading">
        <div class="itemBox">
          <div class="table">
            <vxe-grid
              ref="biddingRegulationList"
              v-bind="defaultGridOption"
              :columns="columns">
              <template slot="empty">
                <a-empty />
              </template>
            </vxe-grid>
          </div>
        </div>
      </a-spin>
    </div>

  </div>
</template>

<script>
import ContentHeader from '@/views/srm/bidding/hall/components/content-header'
import { getAction, postAction } from '@/api/manage'

export default {
    components: {
        'content-header': ContentHeader
    },
    data () {
        return {
            confirmLoading: false,
            supplierEvaScoreList: [],
            form: {},
            btns: [
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', event: 'save' }
            ],
            showHeader: true,
            height: 0,
            //默认表格配置
            defaultGridOption: {
                border: true,
                resizable: true,
                autoResize: true,
                showOverflow: true,
                columnKey: true,
                highlightHoverRow: true,
                size: 'mini',
                align: 'center',
                headerAlign: 'center',
                data: [],
                radioConfig: { highlight: false, trigger: 'row' },
                checkboxConfig: { highlight: false, trigger: 'row' },
                editConfig: { trigger: 'dblclick', mode: 'cell' }
            },
            columns: [
                { type: 'seq', width: 50, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号') },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_indexName`, '指标名称'), field: 'regulationName', width: 150 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_regulationDesc`, '指标说明'), field: 'regulationDetail', width: 250 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_evaluationType`, '评估类型'), field: 'regulationType_dictText', width: 120 },
                { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fullMark`, '满分'), field: 'fullMark', width: 120 }
                // { title: '分数', field: 'fullMark', width: 150 }
            ]
        }
    },
    inject: [
        'currentEditRow'
    ],
    computed: {
        style () {
            const offset = this.showHeader ? 120 : 66
            return { minHeight: `${this.height - offset}px` }
        },
        evaEndTime () {
            return this.currentEditRow.evaEndTime
        }
    },

    methods: {
        renderExtra (deadline, fn) {
            return (
                <div class="countdown" style="display: flex; align-items: center;">
                    <a-icon type="info-circle" />
                    <span style="margin: 0 8px;">评标截止时间</span>
                    <a-statistic-countdown
                        value={ deadline }
                        format="HH:mm:ss"
                        valueStyle={ { fontSize: '12px', color: '#ee1d1d' } }
                        finish={ fn }
                    />
                </div>
            )
        },
        deleteItemEvent (row, column, ref) {
            const grid = this.$refs[ref]
            grid.remove(row)
        },
        getData () {
            this.confirmLoading = true
            const url = '/bidding/purchaseBiddingEvaResult/queryByBiddingId'
            const { id = '' } = this.currentEditRow || {}
            const params = { id }
            getAction(url, params)
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    let { biddingRegulationList = [] } = res.result || {}
                    biddingRegulationList = biddingRegulationList.map(item => {
                        let obj = {}
                        const { supplierEvaScoreList = [], ...others } = item
                        if (!this.supplierEvaScoreList.length) {
                            this.supplierEvaScoreList = supplierEvaScoreList
                            this.setColumns()
                        }
                        supplierEvaScoreList.forEach(sub  => {
                            obj[sub.toElsAccount] = sub.score
                        })

                        return { supplierEvaScoreList, ...others, ...obj }
                    })
                    this.$refs.biddingRegulationList.loadData(biddingRegulationList)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        setColumns () {
            const supColumns = this.supplierEvaScoreList.map((item, i) => {
                return {
                    title: item.supplierName || `supplierName_${i}`,
                    field: item.toElsAccount,
                    width: 150,
                    editRender: {
                        name: '$input',
                        events: {
                            change: ({ row, column })=> {
                                const property = column.property
                                const val = row[property]
                                const supplierEvaScoreList = row.supplierEvaScoreList
                                const obj = supplierEvaScoreList.find(n => n.toElsAccount === property)
                                if (obj) {
                                    obj.score = val
                                }
                                console.log('row', row)
                            }
                        }
                    }
                }
            })
            this.columns = this.columns.concat(supColumns)
        },
        handleSave () {
            const callback = () => {
                const accounts = this.supplierEvaScoreList.map(n => n.toElsAccount)
                console.log('accounts', accounts)

                let biddingRegulationList = this.$refs.biddingRegulationList.getTableData().fullData
                biddingRegulationList = biddingRegulationList.map(item => {
                    accounts.forEach(prop => {
                        if (item[prop]) {
                            delete item[prop]
                        }
                    })
                    return item
                })

                const params = {
                    id: this.currentEditRow.id,
                    biddingRegulationList
                }
                
                const url = '/bidding/purchaseBiddingEvaResult/saveEvaResult'
                
                this.confirmLoading = true
                postAction(url, params)
                    .then(res => {
                        const type = res.success ? 'success' : 'error'
                        this.$message[type](res.message)
                    })
                    .finally(() => {
                        this.confirmLoading = false
                        this.init()
                    })
            }
            this.$confirm({
                title: '评标录入',
                content: '是否确认当前录入结果?',
                onOk () {
                    callback && callback()
                },
                onCancel () {
                    console.log('Cancel')
                }
            })
        },
        init () {
            this.height = document.documentElement.clientHeight
            this.getData()
        }
    },
    created () {
        this.init()
    }
}
</script>

<style lang="less" scoped>
.BidResultList {
    .posA {
        & +.container {
            margin-top: 44px;
        }
    }
    .container {
        background: #fff;
        padding: 12px;
    }
    .itemBox {
        + .itemBox {
        margin-top: 12px;
        }
    }
	.title {
		padding: 0 7px;
		border: 1px solid #ededed;
		height: 34px;
		line-height: 34px;
		&.dark {
			background: #f2f2f2;
		}
	}
	.table,
	.description {
		margin-top: 10px;
	}
}
</style>

