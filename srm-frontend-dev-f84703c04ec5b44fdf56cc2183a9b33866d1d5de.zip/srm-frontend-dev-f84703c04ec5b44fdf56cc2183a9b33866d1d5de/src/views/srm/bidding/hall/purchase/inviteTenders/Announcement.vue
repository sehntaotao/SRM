<template>
  <div class="announcement">
    <!-- <content-header
      v-if="showHeader"
      class="posA"
      :btns="btns"
      @content-header-back="goBack"
    /> -->

    <div
      class="container"
      :style="style">

      <remote-js
        v-if="currentEditRow.templateNumber"
        :src="fileSrc"
        @load="loadSuccess"
        @error="loadError" />

      <detail-layout
        ref="detailPage" 
        mode="tiled"
        :page-data="pageData"
        :url="url" />
      
    </div>
  </div>
</template>

<script>
// import ContentHeader from '@/views/srm/bidding/hall/components/content-header'
import { DetailMixin } from '@comp/template/hallDetail/DetailMixin'
export default {
    mixins: [
        DetailMixin
    ],
    components: {
        // 'content-header': ContentHeader
    },
    data () {
        return {
            btns: [],
            showHeader: false,
            height: 0,
            pageData: {
                groups: [
                    {
                        groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_subjectInfo`, '标的信息'),
                        groupType: 'item',
                        groupCode: 'itemInfo',
                        type: 'grid',
                        custom: {
                            ref: 'purchaseBiddingItemList',
                            columns: []
                        }
                    },
                    {
                        groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingDocuments`, '招标文件'),
                        groupCode: 'fileDemandInfo',
                        type: 'grid',
                        custom: {
                            ref: 'purchaseAttachmentDemandList',
                            columns: [{
                                type: 'checkbox',
                                width: 40
                            },
                            {
                                type: 'seq',
                                width: 60,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            {
                                field: 'fileType_dictText',
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileType`, '文件类型'),
                                width: 120
                            },
                            {
                                field: 'required_dictText',
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ifRequired`, '是否必填'),
                                width: 120
                            },
                            {
                                field: 'remark',
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_remark`, '备注'),
                                width: 220
                            }
                            ]
                        }
                    }
                ]
            },
            url: {
                detail: '/bidding/purchaseBiddingHead/queryById',
                submit: '/elsUflo/audit/submit'
            }
        }
    },
    inject: [
        'currentEditRow'
    ],
    computed: {
        style () {
            const offset = this.showHeader ? 120 : 66
            return { minHeight: `${this.height - offset}px` }
        },
        fileSrc () {
            const { templateNumber = '', templateVersion = '' } = this.currentEditRow || {}
            let account = this.currentEditRow.templateAccount ? this.currentEditRow.templateAccount :  this.currentEditRow.busAccount
            const configFiles = this.$variateConfig['configFiles']
            const time = +new Date()
            const url = `${configFiles}/${account}/purchase_bidding_${templateNumber}_${templateVersion}.js?t=`+time
            return url
        }
    },
    methods: {
        goBack () {
            console.log('back')
        }
    },
    created () {
        this.height = document.documentElement.clientHeight
    }
}
</script>

<style lang="less" scoped>
.announcement {
    .posA {
        & +.container {
            margin-top: 44px;
        }
    }
    .container {
        background: #fff;
        padding: 12px;
    }
}
</style>
