<template>
  <div>
    <change-tenders
      v-if="viewChangeTender"
      @create-tender="handleCreateTender"
      @edit-tender="handleEditTender"></change-tenders>
    <new-and-edit-tender 
      v-else
      :id="tenderId"
      :relationId="relationId"
      :tender-type="tenderType"
      @go-back="goBack"
      @save-tender="saveTender"
      @approval-tender="approvalTender"
    ></new-and-edit-tender>
  </div>
</template>
<script>
import changeTenders from '@/views/srm/bidding/hall/modules/ChangeTenders'
import newAndEditTender from '@/views/srm/bidding/hall/modules/NewAndEditTender'
import { postAction } from '@/api/manage'
export default {
    components: {
        changeTenders,
        newAndEditTender
    },
    data () {
        return {
            viewChangeTender: true,
            tenderId: null,
            tenderType: null,
            relationId: null
        }
    },
    methods: {
        handleCreateTender (data) {
            this.tenderId = ''
            this.tenderType = 'new'
            this.relationId = data.id
            this.viewChangeTender= false
        },
        handleEditTender (data) {
            let {rcurrentEditRow, row} = data
            this.tenderId = row.id
            this.tenderType = 'edit'
            this.relationId = rcurrentEditRow.id
            this.viewChangeTender= false
        },
        goBack () {
            this.viewChangeTender= true
        },
        // 审批
        approvalTender (tenderForm) {
            if(tenderForm.id == ''){
                this.$message.warning('请先保存再提交审批！')
                return
            }
            let url = 'elsUflo/audit/submit'
            let param = {}
            tenderForm['relationId'] = this.relationId
            param['businessId'] = tenderForm.id
            param['businessType'] = 'changeBidding'
            param['auditSubject'] = '招标变更单' + tenderForm.changeNumber
            param['params'] = JSON.stringify(tenderForm)
            postAction(url, param).then((res) => {
                if (res.success) {
                    this.$message.success(res.message)
                    this.goBack()
                } else {
                    this.$message.warning(res.message)
                }
            })
        },
        saveTender () {
            
        }
    }
  
}
</script>