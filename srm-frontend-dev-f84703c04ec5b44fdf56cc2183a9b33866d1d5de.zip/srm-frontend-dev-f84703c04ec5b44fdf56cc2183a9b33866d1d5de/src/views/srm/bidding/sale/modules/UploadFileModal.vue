<template>
  <div>
    <tile-edit-page
      ref="editPage"
      :pageData="pageData"
      :url="url"
      @goBack="goBack" />
  </div>
</template>

<script>
import { tileEditPageMixin } from '@comp/template/tileStyle/tileEditPageMixin'
import { getAction, postAction } from '@/api/manage'
export default {
    mixins: [tileEditPageMixin],
    name: 'UploadFileModal',
    components: {
    },
    data () {
        return {
            editRowModal: false,
            editItemRow: {},
            currentItemContent: '',
            pageData: {
                title: '',
                form: {
                },
                panels: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachedDemandList`, '附件需求清单'),
                        content: {
                            type: 'table',
                            ref: 'saleAttachmentDemandList',
                            height: 200,
                            columns: [
                                { type: 'seq', width: 60, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')},
                                { field: 'fileType_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileType`, '文件类型'), width: 120},
                                { field: 'stageType_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_phaseType`, '阶段类型'), width: 120},
                                { field: 'required_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ifRequired`, '是否必填'), width: 120 },
                                { field: 'remark', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_remark`, '备注'), width: 220 }
                            ]
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentList`, '附件列表'),
                        content: {
                            type: 'table',
                            ref: 'saleAttachmentList',
                            columns: [
                                { type: 'checkbox', width: 40 },
                                { type: 'seq', width: 60, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')},
                                { field: 'fileType_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileType`, '文件类型'), width: 120 },
                                { field: 'fileName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileName`, '文件名称'), width: 320 },
                                { field: 'uploadTime', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadTime`, '上传时间'), width: 140 },
                                { field: 'uploadElsAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploader`, '上传方'), width: 120 },
                                { field: 'sendStatus_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_comfigSend`, '是否发送'), width: 120 },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'),
                                    width: 100,
                                    align: 'center',
                                    slots: {
                                        default: ({row}) => {
                                            let resultArray = []
                                            resultArray.push(<a title="下载" style="margin-left:8px" onClick={() => this.downloadFile(row)}>下载</a>)
                                            if(row.sendStatus == '0'){
                                                resultArray.push(<a title="删除" style="margin-left:8px" onClick={() => this.deleteRow(row)}>删除</a>)
                                            }
                                            return resultArray
                                        }
                                    }
                                }
                            ],
                            toolbarButton: [
                                {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'), type: 'upload', businessType: 'bidding', callBack: this.uploadCallBack}
                            ]
                        }
                        
                    }
                ],
                publicBtn: [
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_release`, '发布'), type: 'primary', clickFn: this.publishEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'), clickFn: this.goBack }
                ]
            },
            url: {
                detail: '/bidding/saleBiddingHead/queryById',
                upload: '/attachment/saleAttachment/upload',
                delete: '/attachment/saleAttachment/delete',
                publish: '/attachment/saleAttachment/send'
            }
          
        }
    },
    methods: {
        downloadFile (row){
            let fromData = this.pageData.form
            let supplier = fromData.biddingSupplierList[0]
            let elsAccount = this.$ls.get('Login_elsAccount')
            if(row.fileType == '2' && row.uploadElsAccount != elsAccount){
                if(supplier.bidCheck != '1'){
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bidNotDownload`, '暂无标书下载权限！'))
                    return 
                }
            }
            this.downloadEvent(row)
        },
        publishEvent () {
            let params = {elsAccount: this.currentEditRow.elsAccount, headId: this.currentEditRow.id}
            let key = this.currentEditRow.relationId
            let toSend = {}
            toSend[key]=this.currentEditRow.toElsAccount
            params['toSend'] = toSend
            postAction(this.url.publish, params).then(res => {
                if(res.success) {
                    this.$message.success(res.message)
                    this.goBack()
                }else {
                    this.$message.warning(res.message)
                }
            })
        },
        uploadCallBack (result) {
            let fileGrid = this.$refs.editPage.$refs.saleAttachmentList[0]
            fileGrid.insertAt(result, -1)
        },
        deleteRow (row) {
            let params = {id: row.id}
            let that = this
            getAction(this.url.delete, params).then(res => {
                console.log(res)
                that.init()
            })
            
        }
    }
}
</script>