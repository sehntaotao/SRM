<template> 
  <div style="height:100%">
    <!-- 列表界面 -->
    <list-layout
      v-show="!showDetailPage && !showUploadFilePage"
      ref="listPage"
      :pageData="pageData"
      :url="url" />
    <sale-bidding-detail
      v-if="showDetailPage" 
      ref="detailPage" 
      :current-edit-row="currentEditRow" 
      @hide="hideEditPage" />
    <upload-file-modal
      v-if="showUploadFilePage" 
      ref="detailPage" 
      :current-edit-row="currentEditRow" 
      @hide="hideUploadFilePage" />

  </div>
</template>
<script>
import { ListMixin } from '@comp/template/list/ListMixin'
import SaleBiddingDetail from './modules/SaleBiddingDetail'
import layIM from '@/utils/im/layIM.js'
import UploadFileModal from './modules/UploadFileModal'
import { SET_HALL_CURRENTROW } from '@/store/mutation-types'

import {formatDate} from '@/utils/util.js'

export default {
    mixins: [ListMixin],
    components: {
        SaleBiddingDetail,
        UploadFileModal
    },
    data () {
        return {
            showUploadFilePage: false,
            pageData: {
                businessType: 'bidding',
                form: {
                    biddingNumber: ''
                },
                button: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_helpText`, '帮助说明'), icon: 'file-text', folded: true, clickFn: this.showHelpText},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentExplain`, '附件说明'), icon: 'file-pdf', folded: true, clickFn: this.showHelpPDF}
                ],
                formField: [
                    {
                        type: 'input',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tenderNumber`, '招标单号'),
                        fieldName: 'biddingNumber',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_enterTenderNumberTips`, '请输入招标单号')
                    }
                ],
                optColumnWidth: 200,
                optColumnList: [
                    {type: 'chat', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_communicate`, '沟通'), clickFn: this.handleChat, allow: this.allowChat},
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'), clickFn: this.handleView},
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileUpload`, '文件上传'), clickFn: this.uploadFile, allow: this.allowUploadFile},
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supBiddingHall`, '投标大厅'), clickFn: this.handleTender}
                ]
            },
            url: {
                add: '/bidding/saleBiddingHead/add',
                list: '/bidding/saleBiddingHead/list',
                columns: 'saleBiddingHead',
                excelCode: 'ebidding' 
            }
        }
    },
    created () {
        this.getUrlParam()
    },
    methods: {
        handleChat (row) {
            let { id } = row
            // 创建聊天
            layIM.createChat({id, type: 'SaleBidding', url: this.url || ''})
        }, 
        allowChat (row){
            return false
        },
        handleView (row) {
            this.currentEditRow = row
            this.showDetailPage = true
        },
        getUrlParam (){
            let templateNumber = this.$route.query.templateNumber
            let templateVersion = this.$route.query.templateVersion
            let busAccount = this.$route.query.busAccount
            let id = this.$route.query.id
            if(templateNumber && templateVersion && id ){
                let row = {}
                row['templateNumber']=templateNumber
                row['templateVersion']=templateVersion
                row['id']=id
                row['busAccount']=busAccount
                this.currentEditRow = row
                this.showDetailPage = true
            }
        },
        handleTender (row) {
            this.$ls.set(SET_HALL_CURRENTROW, row)
            let _t = +new Date()
            const routeUrl = this.$router.resolve({
                path: '/applyHall',
                query: {
                    _t,
                    type: 'tender' // 投标
                }
            })
            window.open(routeUrl.href, '_blank')
        },
        uploadFile (row){
            this.currentEditRow = row
            this.showUploadFilePage = true
        },
        allowUploadFile (row){
            let bidBeginTime = row.bidBeginTime
            let current = formatDate(new Date().getTime(), 'yyyy-MM-dd hh:mm:ss')
            if(bidBeginTime < current){
                return true
            }else{
                return false
            }
        },
        hideUploadFilePage (){
            this.showUploadFilePage = false
        }

        
    }
}
</script>
<style lang="less" scoped>
.radio-wrap {
    display: block;
    height: 30px;
}
</style>