<script>
export default {
    name: 'MenuPart',
    props: {
        menus: {
            type: Array,
            default () {
                return []
            }
        },
        mainSupplierInfo: {//主体供应商信息
            type: Object,
            default: ()=>{
                return {
                    enterpriseLogo: '',
                    name: ''
                }
            }
        }
    },
    data (){
        return {
            curMenuIndex: 0//当前menus
        }  
    },
    components: {
    },
    watch: {
    },
    methods: {
        //导航刷新
        handleResetClick (e, n){
            this.$emit(`content-reset-header-${e.type}`, n)
        },
        // 导航点击
        handleClick (e, n, index) {
            this.curMenuIndex=index 
            this.$emit(`content-header-${e.type}`, n)
        }
    },
    render () {
        let { menus } = this
        const menusEl = menus.map((n, index)=> (
            <a-col 
                span={6} 
                onClick={ (event) => this.handleClick(event, n, index) }>
                <a-card bordered={false}  class={this.curMenuIndex==index?'menus-active':''}>
                    <div class="content">
                        
                        <div class="content-icon">
                            <img src= {require(`./../img/venture-${index+1}.png`)} /> 
                        </div>
                        
                        <div class="content-txt">
                            <div class="title">{n.title}</div>
                            { true || <div class="desc">
                                <span class='txt'>{n.desc}</span>
                                <span class="red" > <b>{n.number}</b>条</span> 
                            </div>} 
                          
                            <a-button size='small'  vOn:click_stop={ (event) => this.handleResetClick(event, n, index) }>刷新 </a-button>
                        </div>

                    </div>
                </a-card>
            </a-col>
        ))

        const returnNameFrist=(val)=>{
            
            return val?val.charAt(0):''
        }

        return (
             

            <div class="menu-part">
                <div class="top-wrap">
                    <div class="warp-company">
                        <a-card bordered={false}>
                            <div class="content">
                                <div class="content-icon">
                                    {this.mainSupplierInfo.enterpriseLogo?<img src= {this.mainSupplierInfo.enterpriseLogo} /> : <span class="logo-name">{ returnNameFrist(this.mainSupplierInfo.name)}</span> }     
                                </div>
                        
                                <div class="content-txt">
                                    <div class="title" title={Object.keys(this.mainSupplierInfo).length>0?this.mainSupplierInfo.name:''}>{Object.keys(this.mainSupplierInfo).length>0?this.mainSupplierInfo.name:''}</div>
                                       
                                </div>
                                    
                            </div>
                        </a-card>
                    </div>
                    <div  class="warp-supplist">
                        <a-row gutter={16}>
                            {menusEl}
                        </a-row>
                    </div>
                </div>
            </div>
        )
    }
}
</script>

<style lang="less" scoped>
.menu-part{
    .logo-name{
        background-color: #1890ff;
        display: inline-block;
        width: 55px;
        height: 55px;
        border-radius: 5px;
        text-align:center;
        font-size: 20px;
        color: #fff;
        line-height: 55px;
    }
    .menus-active{
        box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.4); 
        transition: all 1s;
    }
    .top-wrap{
        display: flex;
        flex-direction: row;
        .warp-company{
            width: 23%;
        }
        .warp-supplist{
            flex: 1;
            margin-left: 16px;
        }
       /deep/ .ant-col {
           cursor: pointer;
       }
              .content{
        display: flex;
        align-items: center;
        .content-icon{
            width: 55px;
            height: 55px;
            img{
                width: 100%;
            }
        }
        .content-txt{
            flex: 1;
            margin-left: 15px;
            justify-content: flex-start;
            .title{
                font-size: 16px;
                font-weight: 600;
                color: #606060;
                margin-bottom: 8px;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 90%;
                white-space: nowrap
            }
            .desc{
                display: flex;
                justify-content: space-between;
                color: #A5ABB6;
                font-size: 12px;
                .red{
                   b{color: #F71515;
                }} 
            }
        }
    }
    }

}

</style>