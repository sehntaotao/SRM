<template>
  <div class="page-container">
    <edit-layout
      ref="editPage"
      :page-data="pageData"
      :currentEditRow="currentEditRow"
      :url="url" />
    <field-select-modal 
      ref="fieldSelectModal" />
    <!-- 加载配置文件 -->
    <!-- <remote-js
      :src="fileSrc"
      @load="loadSuccess"
      @error="loadError" /> -->
  </div>
</template>
<script>
import { EditMixin } from '@comp/template/saleEdit/EditMixin'
import fieldSelectModal from '@comp/template/fieldSelectModal'
import { getAction, postAction } from '@/api/manage'
import { USER_INFO } from '@/store/mutation-types'
import { ROWSELECTMODALCONST } from '@/utils/const'    
import REGEXP  from '@/utils/regexp'
import {srmI18n, getLangAccount} from '@/utils/util.js'

export default {
    name: 'ElsEnterpriseInfoEdit',
    mixins: [EditMixin],
    components: {
        fieldSelectModal
    },
    data () {
        return {
            pageData: {
                form: {},
                groups: [
                    {
                        groupName: '基本信息',
                        groupCode: 'enterpriseForm',
                        sortOrder: '1',
                        custom: {
                            ref: 'enterpriseForm',
                        formFields: [
                            {
                                fieldType: 'input',
                                fieldLabel: '企业全称',
                                fieldName: 'name'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业简称',
                                fieldName: 'alias'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '集团代码',
                                fieldName: 'fbk1'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '境内外关系',
                                fieldLabelI18nKey: 'i18n_field_area',
                                fieldName: 'area',
                                dictCode: 'srmAreaType'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: 'D-U-N-S',
                                fieldName: 'fbk2'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '公司属性',
                                fieldName: 'fbk3',
                                dictCode: 'companyAttributes'
                            },
                            {
                                fieldType: 'date',
                                fieldLabel: '成立日期',
                                fieldLabelI18nKey: 'i18n_field_establishTime',
                                fieldName: 'establishTime',
                                dataFormat: 'YYYY-MM-DD'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '注册资金（万）',
                                fieldName: 'regCapital'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '员工人数（人）',
                                fieldName: 'staffNumRange'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '营业执照是否永续',
                                fieldName: 'fbk4',
                                dictCode: 'yn',
                                bindFunction: function (parentRef, pageData, groupData, realValue) {
                                    if(realValue == '1'){
                                        groupData.custom.validateRules.fbk5[0].required = false
                                    }else{
                                        groupData.custom.validateRules.fbk5[0].required = true
                                    }
                                }
                            },
                            {
                                fieldType: 'date',
                                fieldLabel: '营业期限',
                                fieldName: 'fbk5',
                                dataFormat: 'YYYY-MM-DD'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '营业范围',
                                fieldName: 'businessScope'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '代理品牌',
                                fieldName: 'fbk6'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '主要客户',
                                fieldName: 'fbk7'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '注册地（国家）',
                                fieldName: 'country'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '注册地（地区）',
                                fieldName: 'fbk8'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '与营业执照登记证一致',
                                fieldLabelI18nKey: 'i18n_field_regLocation',
                                fieldName: 'regLocation'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '法人',
                                fieldLabelI18nKey: 'i18n_field_legalPersonName',
                                fieldName: 'legalPersonName'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '法人电话',
                                fieldName: 'fbk9'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '法人邮箱',
                                fieldName: 'fbk10'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业联系信息-邮编',
                                fieldName: 'fbk11'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业联系信息-区号',
                                fieldName: 'fbk12'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业联系信息-公司网站',
                                fieldName: 'websiteList'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业联系信息-办公固定电话',
                                fieldName: 'fbk13'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业联系信息-客服电话',
                                fieldName: 'fbk27'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业联系信息-企业备注',
                                fieldName: 'fbk28'
                            },
                            {
                                fieldType: 'textArea',
                                fieldLabel: '企业简介',
                                fieldName: 'fbk14'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '供应商信息状态',
                                fieldName: 'fbk15',
                                dictCode: 'srmInformationStatus'
                            },
                            {
                                fieldType: 'selectModal',
                                fieldLabel: '物料类别',
                                fieldName: 'fbk16',
                                bindFunction: function (Vue, data) {
                                    Vue.form.fbk16 = data[0].cateCode
                                },
                                extend: { 
                                    modalColumns: [
                                        {field: 'cateCode', title: '物料类别编码', with: 150},
                                        {field: 'cateName', title: '物料类别名称', with: 150}
                                    ], 
                                    modalUrl: '/material/purchaseMaterialCode/getMaterialGrade', 
                                    modalParams: {}
                                }
                            },
                            {
                                fieldType: 'image',
                                fieldLabel: '营业执照/登记证',
                                fieldName: 'businessLicense'
                            }
                        ],
                        validateRules: {
                            name: [{required: true, message: '企业全称不能为空'}],
                            alias: [{required: true, message: '企业简称不能为空'}],
                            area: [{required: true, message: '境内外关系不能为空'}],
                            fbk3: [{required: true, message: '公司属性不能为空'}],
                            establishTime: [{required: true, message: '成立日期不能为空'}],
                            regCapital: [{required: true, message: '注册资金不能为空'}],
                            staffNumRange: [{required: true, message: '员工人数不能为空'}],
                            fbk4: [{required: true, message: '[营业执照是否永续]不能为空'}],
                            fbk5: [{required: false, message: '营业期限不能为空'}],
                            businessLicense: [{required: true, message: '营业执照/登记证不能为空'}],
                            businessScope: [{required: true, message: '营业范围不能为空'}],
                            country: [{required: true, message: '注册地（国家）不能为空'}],
                            fbk8: [{required: true, message: '注册地（地区）不能为空'}],
                            regLocation: [{required: true, message: '注册地址不能为空'}]
                        }
                    }},
                    {
                        groupName: '业务信息',
                        groupCode: 'businesssForm',
                        groupType: 'head',
                        sortOrder: '5',
                        custom: {
                            ref: 'businesssForm',
                            formFields: [
                            {
                                fieldType: 'multiple',
                                fieldLabel: '主要业务方向',
                                fieldName: 'fbk17',
                                dictCode: 'srmMainBusinessDirection'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '商业模式',
                                fieldName: 'fbk18',
                                dictCode: 'srmBusinessModel'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '行业类型',
                                fieldName: 'fbk19',
                                dictCode: 'srmIndustryType'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '主营品类',
                                fieldName: 'fbk20'
                            },
                            {
                                fieldType: 'select',
                                fieldLabel: '厂房性质',
                                fieldName: 'fbk21',
                                dictCode: 'srmPlantNature'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '厂房面积(m²)',
                                fieldName: 'fbk22'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '企业运营ERP',
                                fieldName: 'fbk23'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '近三年营业额',
                                fieldName: 'fbk24'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '物流方式',
                                fieldName: 'fbk25'
                            },
                            {
                                fieldType: 'input',
                                fieldLabel: '取消订单提前通知(天)',
                                fieldName: 'fbk26'
                            }
                        ],
                        validateRules: {
                            fbk18: [{required: true, message: '商业模式不能为空'}],
                            fbk19: [{required: true, message: '行业类型不能为空'}],
                            fbk20: [{required: true, message: '主营品类不能为空'}],
                            fbk21: [{required: true, message: '厂房性质不能为空'}],
                            fbk22: [{required: true, message: '厂房面积不能为空'}],
                            fbk23: [{required: true, message: '企业运营ERP不能为空'}],
                            fbk25: [{required: true, message: '物流方式不能为空'}],
                            fbk26: [{required: true, message: '取消订单提前通知(天)不能为空'}]
                        }
                    }},
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contactInfo`, '联系人信息'), groupCode: 'contactsInfo', type: 'grid', custom: {
                        ref: 'supplierContactsInfoList',
                        columns: [
                            { type: 'checkbox', width: 40 },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            { 
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressType`, '类型'),
                                field: 'fbk1',
                                width: 150,
                                dictCode: 'contactType',
                                editRender: {name: '$select'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_names`, '姓名'),
                                field: 'name',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_telphones`, '手机号码'),
                                field: 'telphone',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_email`, '邮箱'),
                                field: 'email',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_sex`, '性别'),
                                field: 'fbk2',
                                dictCode: 'sex',
                                editRender: {name: '$select'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_position`, '职位'),
                                field: 'position',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_certificateType`, '证件类型'),
                                field: 'fbk3',
                                dictCode: 'srmCertificateType',
                                editRender: {name: '$select'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_licenseNumber`, '证件号'),
                                field: 'fbk4',
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_remark`, '备注'),
                                field: 'remark',
                                editRender: {name: '$input'}
                            }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addContactsItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteContactsEvent}
                        ],
                        rules: {
                            name: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_theNameCannotBeEmpty`, '姓名不能为空')}],
                            fbk1: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contactTypeCannotBeEmpty`, '联系人类型不能为空')}],
                            telphone: [{
                                pattern: /^((13|14|15|16|17|18|19)[0-9]{1}\d{8})$/, 
                                message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_phoneError`, '手机号不正确')
                            }],
                            email: [{
                                pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/, 
                                message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_emailError`, '邮箱格式不正确')
                            }]
                        }
                    }},
                    { groupName: '地址信息', groupCode: 'addressInfo', type: 'grid', custom: {
                        ref: 'supplierAddressInfoList',
                        columns: [
                            { 
                                type: 'checkbox', width: 40 
                            },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            { 
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressType`, '地址类型'),
                                field: 'fbk1',
                                width: 100,
                                dictCode: 'addressType',
                                editRender: {name: '$select'}
                            },
                            { 
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ynRegisteredAddress`, '是否是注册地址'),
                                field: 'fbk2',
                                width: 100,
                                required: '1',
                                dictCode: 'yn',
                                editRender: {
                                    name: '$select', 
                                    option: [], 
                                    events: {
                                        change: (currentRow, currentValue)=> {
                                            this.changeRegisteredAddress(currentRow, currentValue)
                                        } 
                                    }
                                }
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_country`, '国家'),
                                field: 'country',
                                width: 150,
                                required: '1',
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_area`, '地区'),
                                field: 'province',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_area`, '地区'),
                                field: 'city',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_address`, '详细地址'),
                                field: 'address',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressAbbreviation`, '地址简称'),
                                field: 'fbk3',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_zipCode`, '邮编'),
                                field: 'fax',
                                width: 150,
                                editRender: {name: '$input', props: {type: 'number'}}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressIntroduction`, '地址备注'),
                                field: 'remark',
                                width: 150,
                                editRender: {name: '$input'}
                            }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addAddressItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteAddressEvent}
                        ],
                        rules: {
                            fbk2: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ynRegisteredAddressCannotBeEmpty`, '[是否是注册地址]不能为空')}],
                            country: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_countryCannotBeEmpty`, '国家不能为空')}],
                            province: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_provinceCannotBeEmpty`, '省份不能为空')}],
                            city: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cityCannotBeEmpty`, '城市不能为空')}],
                            fbk3: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressAbbreviationCannotBeEmpty`, '地址简称不能为空')}]
                        }
                    } },
                    { groupName: '财务信息', groupCode: 'bankInfo', type: 'grid', custom: {
                        ref: 'supplierBankInfoList',
                        columns: [
                            { 
                                    type: 'checkbox', width: 40 
                                },
                                { 
                                    type: 'seq', width: 50,
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankName`, '开户银行'),
                                    field: 'bankBranchName',
                                    dictCode: 'bankType',
                                    width: 150,
                                    editRender: {name: '$select'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_accountOpeningBranch`, '开户支行'),
                                    field: 'fbk1',
                                    width: 150,
                                    editRender: {name: '$input'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccount`, '银行账号'),
                                    field: 'bankAccount',
                                    required: '1',
                                    width: 150,
                                    editRender: {name: '$input'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCooperativeNumber`, '银行联行号'),
                                    field: 'fbk2',
                                    required: '1',
                                    width: 150,
                                    editRender: {name: '$input'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccountNames`, '账号名称'),
                                    field: 'bankAccountName',
                                    required: '1',
                                    width: 150,
                                    editRender: {name: '$input'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_settlementMethod`, '结算方式'),
                                    field: 'fbk3',
                                    required: '1',
                                    dictCode: 'paymentMethod',
                                    width: 150,
                                    editRender: {name: '$select'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_paymentTerms`, '付款条件'),
                                    field: 'fbk4',
                                    required: '1',
                                    dictCode: 'paymentTerm',
                                    width: 150,
                                    editRender: {name: '$select'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_settlementCurrency`, '结算币种'),
                                    field: 'fbk5',
                                    dictCode: 'srmCurrency',
                                    width: 150,
                                    editRender: {name: '$select'}
                                },
                                {
                                    ...ROWSELECTMODALCONST,
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tariff`, '税率'),
                                    field: 'fbk6',
                                    width: 150,
                                    bindFunction: function (row, data){    
                                        row.fbk6 = data[0].taxRate
                                    }, 
                                    extend: {
                                        modalColumns: [
                                            {field: 'taxCode', title: '税码', with: 150}, 
                                            {field: 'taxRate', title: '税率', with: 150}
                                        ], 
                                        modalUrl: '/base/tax/list', modalParams: {}
                                    }
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_copyName`, '银行盖章复印件'),
                                    field: 'fbk8',
                                    required: '1',
                                    width: 150
                                },
                                { field: 'grid_opration', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), width: 120, align: 'center', slots: { default: 'grid_opration' } },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_mainAccount`, '是否主账号'),
                                    field: 'fbk7',
                                    required: '1',
                                    width: 150,
                                    dictCode: 'yn',
                                    editRender: {name: '$select'}
                                }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addBankItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteBankEvent},
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'),
                                type: 'upload',
                                businessType: 'supplierMasterData',
                                beforeChecked: true, 
                                beforeCheckedCallBack: this.bankFileUploadCallBack,
                                single: true,
                                modalVisible: false,
                                callBack: this.uploadCallBack
                            }
                        ],
                        rules: {
                            bankBranchName: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankNameCannotBeEmpty`, '开户银行不能为空')}],
                            fbk1: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_accountOpeningBranchCannotBeEmpty`, '开户支行不能为空')}],
                            bankAccount: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccountCannotBeEmpty`, '银行账号不能为空')}],
                            fbk2: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCooperativeNumberCannotBeEmpty`, '银行联行号不能为空')}],
                            bankAccountName: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccountNameCannotBeEmpty`, '账号名称不能为空')}],
                            fbk3: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_settlementMethodCannotBeEmpty`, '结算方式不能为空')}],
                            fbk4: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_paymentTermsCannotBeEmpty`, '付款条件不能为空')}],
                            fbk8: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileNameCannotBeEmpty`, '银行盖章复印件不能为空')}]
                        },
                        showOptColumn: true,
                        optColumnList: [
                            { type: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), clickFn: this.bankFileDownloadEvent }
                        ]
                    } },
                    { 
                        groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_certificationInfo`, '认证信息'), 
                        groupCode: 'certificationInfo', 
                        type: 'grid', 
                        custom: {
                            ref: 'supplierCertificatedInfoList',
                            columns: [
                                { 
                                    type: 'checkbox', width: 40 
                                },
                                { 
                                    type: 'seq', width: 50,
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_certificateType`, '证书类型'),
                                    field: 'certificationType',
                                    dictCode: 'certificateType',
                                    width: 150,
                                    editRender: {name: '$select'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_effectiveDate`, '生效日期'),
                                    field: 'effectiveDate',
                                    width: 150,
                                    editRender: {name: 'mDatePicker'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_expiryDate`, '失效日期'),
                                    field: 'expiryDate',
                                    width: 150,
                                    editRender: {name: 'mDatePicker'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_isFail`, '是否失效'),
                                    field: 'isFail',
                                    width: 150,
                                    dictCode: 'yn',
                                    editRender: {name: '$select'}
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileName`, '附件名称'),
                                    field: 'fileName',
                                    width: 150
                                },
                                { 
                                    field: 'grid_opration', 
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), 
                                    width: 120, 
                                    align: 'center', 
                                    slots: { default: 'grid_opration' } 
                                },
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_remark`, '备注'),
                                    field: 'remark',
                                    width: 150,
                                    editRender: {name: '$input'}
                                }
                            ],
                            buttons: [
                                {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addCertificationItem},
                                {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteCertificationEvent},
                                {
                                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'),
                                    type: 'upload',
                                    businessType: 'supplierMasterData',
                                    beforeChecked: true, 
                                    beforeCheckedCallBack: this.certificateFileUploadCallBack,
                                    single: true,
                                    modalVisible: false,
                                    callBack: this.uploadCallBack
                                }
                            ],
                            rules: {
                                certificateType: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_certificateTypeCannotBeEmpty`, '证书类型不能为空')}]
                            },
                            showOptColumn: true,
                            optColumnList: [
                                { type: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), clickFn: this.bankFileDownloadEvent }
                            ]
                        }
                    }
                ],
                formFields: [],
                itemColumns: [],
                publicBtn: [
                    // { title: '上一步', click: this.prevEvent },
                    // { title: '下一步', type: 'primary', click: this.nextEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', click: this.saveEvent }
                ]
            },
            url: {
                edit: '/enterprise/elsEnterpriseInfo/editEnterpriseInfo',
                detail: '/supplier/supplierMaster/queryCurrentEnterprise',
                upload: '/attachment/purchaseAttachment/upload'
            }
        }
    },
    computed: {
        fileSrc () {
            let time = new Date().getTime()
            return `${this.$variateConfig['configFiles']}/100000/purchase_enterprise_TC2021092601_1.js?t=`+time
        }
    },
    mounted () {
        this.init()
        this.load()
    },
    methods: {
        init () {
            this.$refs.editPage.queryDetail()
        },
        load () {
            this.$refs.editPage.queryDictData()
        },
        bankFileDownloadEvent (row) {
            row.fileName = row.fbk8
            this.downloadFile (row)
        },
        certificateFileDownloadEvent (row) {
            this.downloadFile (row)
        },
        downloadFile (row){
            if(!row.fileName){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_lineNotDownload`, '该行没有可下载的附件'))
                return
            }
            const [id, fileName] = row.fileName.split('-')
            const params = {
                id
            }
            getAction('/attachment/purchaseAttachment/download', params, {
                responseType: 'blob'
            }).then(res => {
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        bankFileUploadCallBack (data){
            return new Promise((resolve)=> {
                // 验证的规则
                if (data && data.length) {
                    if (data.length===1) {
                        resolve(true)
                    } else{
                        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_onlySelectOne`, '只能选择一条'))
                        resolve(false)
                    }
                }else{
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSelectDataoPerated`, '请选择需要操作的数据'))
                    resolve(false)
                }
                
            })
        },
        certificateFileUploadCallBack (data){
            return new Promise((resolve)=> {
                // 验证的规则
                if (data && data.length) {
                    if (data.length===1) {
                        resolve(true)
                    } else{
                        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_onlySelectOne`, '只能选择一条'))
                        resolve(false)
                    }
                }else{
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSelectDataoPerated`, '请选择需要操作的数据'))
                    resolve(false)
                }
                
            })
        },
        uploadCallBack (result, refName) {
            console.log(result)
            const { id = '', fileName = '', filePath = '' } = result[0] || {}
            const fileGrid = this.$refs.editPage.$refs[refName][0].getCheckboxRecords()
            fileGrid[0].filePath = `${filePath}`
            fileGrid[0].fileName = `${id}-${fileName}`
            fileGrid[0].fbk8 = `${id}-${fileName}`
        },
        // 增加联系人信息
        addContactsItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierContactsInfoList[0]
            let itemData = {}
            this.pageData.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
            this.$refs.editPage.queryDictData()
        },
        // 删除联系人信息
        deleteContactsEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierContactsInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        // 增加地址信息
        addAddressItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierAddressInfoList[0]
            let itemData = {}
            this.pageData.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
            this.$refs.editPage.queryDictData()
        },
        // 删除地址信息
        deleteAddressEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierAddressInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        // 添加财务信息
        addBankItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierBankInfoList[0]
            let itemData = {}
            this.pageData.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
            this.$refs.editPage.queryDictData()
        },
        // 删除财务信息
        deleteBankEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierBankInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        // 添加认证信息
        addCertificationItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierCertificatedInfoList[0]
            let itemData = {}
            this.pageData.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
            this.$refs.editPage.queryDictData()
        },
        // 删除认证信息
        deleteCertificationEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierCertificatedInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        // 是否是注册地址
        changeRegisteredAddress (currentRow, currentValue) {
            if(currentValue.value == '1'){
                currentRow.row.country = this.pageData.form.country
                currentRow.row.province = this.pageData.form.fbk8
                currentRow.row.address = this.pageData.form.regLocation
            }else{
                currentRow.row.country = ''
                currentRow.row.province = ''
                currentRow.row.address = ''
            }
        },
        fieldSelectOk (data) {
            let supplierGrid = this.$refs.editPage.$refs.supplierOrgInfoList[0]
            let { fullData } = supplierGrid.getTableData()
            let supplierList = fullData.map(item => {
                return item.elsAccount
            })
            // 过滤已有数据
            let insertData = data.filter(item => {
                return !supplierList.includes(item.elsAccount)
            })
            insertData = insertData.map(item => {
                return {
                    toElsAccount: item.elsAccount
                }
            })
            supplierGrid.insertAt(insertData, -1)
        },
        saveEvent () {
            const params = this.$refs.editPage.getPageData()
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.$refs.editPage.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                // 校验规则
                const errorIndex = result.findIndex(n => n.status === 'error')
                if (errorIndex !== -1) {
                    this.$refs.editPage.currentStep = errorIndex
                    return
                }
                // this.updateLogoSrc(params)
                // if (flag) {
                let url = this.url.edit
                this.confirmLoading = true
                postAction(url, params).then(res => {

                    if(res.success) {
                        this.$message.success(res.message)
                        this.init()
                        this.confirmLoading = false
                    }else {
                        this.$message.warning(res.message)
                    }
                })
                // }
            }).catch(err => {
                console.log(err)
            })
        },
        updateLogoSrc (params) {
            let oldUserInfo = this.$ls.get(USER_INFO)
            oldUserInfo.enterpriseLogo = params.enterpriseLogo || ''
            // 更新logosrc
            this.$ls.set(USER_INFO, oldUserInfo, 7 * 24 * 60 * 60 * 1000)
        },
        publishEvent () {
            this.$refs.editPage.handleSend()
        }
        
    }
}
</script>