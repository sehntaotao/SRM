<template>
  <div style="height:100%">
    <list-layout
      ref="listPage"
      v-show="!showDetailPage && ! showEditPage"
      :pageData="pageData"
      :url="url" />
    <!-- 编辑界面 -->
    <EnterpriseEdit
      v-if="showEditPage"
      ref="editPage"
      :current-edit-row="currentEditRow"
      @hide="hideEditPage"/> 
    <!-- 详情界面 -->
    <EnterpriseDetail 
      v-if="showDetailPage"
      ref="detailPage" 
      :current-edit-row="currentEditRow" 
      @hide="hideEditPage" />
  </div>
</template>
<script>
import EnterpriseDetail from './modules/EnterpriseDetail'
import EnterpriseEdit from './modules/EnterpriseEdit'
import {ListMixin} from '@comp/template/list/ListMixin'
export default {
    mixins: [ListMixin],
    components: {
        EnterpriseDetail,
        EnterpriseEdit
    },
    data () {
        return {
            showEditPage: false,
            pageData: {
                formField: [
                    // {
                    //     type: 'input',
                    //     label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_keyword`, '关键字'),
                    //     fieldName: 'keyWord',
                    //     placeholder: '请输入关键字(采购方)'
                    // }
                ],
                form: {
                    keyWord: '',
                    name: ''
                },
                button: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_helpText`, '帮助说明'), icon: 'file-text', folded: true, clickFn: this.showHelpText},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentExplain`, '附件说明'), icon: 'file-pdf', folded: true, clickFn: this.showHelpPDF}
                ],
                showOptColumn: true,
                optColumnList: [
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'), clickFn: this.handleView},
                    {type: 'edit', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'), clickFn: this.handleEdit}
                ]
            },
            url: {
                list: '/supplier/supplierMaster/supplierlist',
                columns: 'EnterpriseMasterList'
            }
        }
    },
    methods: {
        handleExportXls () {
            this.$refs.listPage.handleExportXls(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supplierMasterData`, '供应商主数据'))
        }
    }
}
</script>