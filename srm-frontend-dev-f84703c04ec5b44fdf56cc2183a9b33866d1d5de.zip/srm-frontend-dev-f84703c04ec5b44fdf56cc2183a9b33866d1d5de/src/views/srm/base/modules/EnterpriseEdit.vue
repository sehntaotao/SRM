<template>
  <div class="page-container">
    <edit-layout
      ref="editPage"
      :page-data="pageData"
      :url="url" />
    <field-select-modal 
      ref="fieldSelectModal" />
    <!-- 加载配置文件 -->
    <remote-js
      :src="fileSrc"
      @load="loadSuccess"
      @error="loadError" />
  </div>
</template>
<script>
import { EditMixin } from '@comp/template/saleEdit/EditMixin'
import fieldSelectModal from '@comp/template/fieldSelectModal'
import { getAction, postAction } from '@/api/manage'
import { ROWSELECTMODALCONST } from '@/utils/const'
import {srmI18n, getLangAccount} from '@/utils/util.js'

export default {
    name: 'ElsEnterpriseInfoEdit',
    mixins: [EditMixin],
    components: {
        fieldSelectModal
    },
    data () {
        return {
            pageData: {
                form: {},
                groups: [
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tableRowControl`, '表格行控制'), groupCode: 'gridEditConfig', groupType: 'gridEditConfig',  extend: {
                        editConfig: {
                            showStatus: true,
                            mode: 'row',
                            activeMethod: function (gridData, row) {
                                // let elsAccount = this.$ls.get('Login_elsAccount')
                                if (row.elsAccount && !row.toElsAccount) {
                                    return false
                                }
                                return true
                            }
                        }
                    }, custom: {}},
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contactInfo`, '联系人信息'), groupCode: 'contactsInfo', type: 'grid', custom: {
                        ref: 'supplierContactsInfoList',
                        columns: [
                            { 
                                type: 'checkbox', width: 40 
                            },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ELSAccount`, 'ELS账号'),
                                field: 'elsAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_toElsAccount`, '采购维护账号'),
                                field: 'toElsAccount',
                                width: 150
                            },
                            {
                                ...ROWSELECTMODALCONST,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_subAccount`, '子账号'),
                                field: 'subAccount',
                                required: '1',
                                width: 150,
                                bindFunction: function (row, data) {
                                    row.subAccount = data[0].subAccount,
                                    row.name = data[0].realname,
                                    row.telphone = data[0].phone,
                                    row.email = data[0].email
                                }, extend: { modalColumns: [
                                    {field: 'subAccount', title: srmI18n(`${getLangAccount()}#i18n_field_subAccount`, '子账号'), with: 150},
                                    {field: 'realname', title: srmI18n(`${getLangAccount()}#i18n_title_name`, '姓名'), with: 150}, 
                                    {field: 'phone', title: srmI18n(`${getLangAccount()}#i18n_title_telphone`, '电话号码'), with: 150}, 
                                    {field: 'email', title: srmI18n(`${getLangAccount()}#i18n_field_email`, '邮箱'), with: 150}], 
                                modalUrl: '/account/elsSubAccount/list', modalParams: {}, beforeCheckedCallBack: function (Vue, row) {
                                    return new Promise((resolve, rejec) => {
                                        let toElsAccount = row.toElsAccount || ''
                                        return toElsAccount === '' ? rejec(srmI18n(`${getLangAccount()}#i18n_title_publicInformationOnlyMaintainedSupplierBasicInformationEnterprise`, '公共信息只能供方在企业基本信息中维护')) :resolve('success') 
                                    })
                                }}
                            },
                            {
                                required: '0',
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_function`, '职能'),
                                field: 'functionName',
                                width: 150,
                                dictCode: 'JobFunction',
                                editRender: {name: 'ASelect'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_position`, '职位'),
                                required: '1',
                                field: 'position',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_name`, '姓名'),
                                field: 'name',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_telphone`, '电话号码'),
                                field: 'telphone',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_email`, '邮箱'),
                                required: '1',
                                field: 'email',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: 'QQ',
                                field: 'qqNo',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_weChat`, '微信'),
                                field: 'wxNo',
                                width: 150,
                                editRender: {name: '$input'}
                            }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addContactsItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteContactsEvent}
                        ],
                        rules: {
                            subAccount: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_theSubaccountCannotBeEmpty`, '子账号不能为空')}],
                            functionName: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_functionCannotBeEmpty`, '职能不能为空')}],
                            position: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_positionBeEmpty`, '职位不能为空')}],
                            name: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_theNameCannotBeEmpty`, '姓名不能为空')}],
                            telphone: [{
                                pattern: /^((13|14|15|16|17|18|19)[0-9]{1}\d{8})$/, 
                                message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_phoneError`, '手机号不正确')
                            }],
                            email: [{
                                pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/, 
                                message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_emailError`, '邮箱格式不正确')
                            }]
                        }
                    } },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressInfo`, '地址信息'), groupCode: 'addressInfo', type: 'grid', custom: {
                        ref: 'supplierAddressInfoList',
                        columns: [
                            { 
                                type: 'checkbox', width: 40 
                            },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ELSAccount`, 'ELS账号'),
                                field: 'elsAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_toElsAccount`, '采购维护账号'),
                                field: 'toElsAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_country`, '国家'),
                                field: 'country',
                                width: 150,
                                required: '1',
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_province`, '省份'),
                                field: 'province',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_city`, '城市'),
                                field: 'city',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_address`, '详细地址'),
                                field: 'address',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_telphone`, '电话'),
                                field: 'telphone',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_zipCode`, '邮编'),
                                field: 'fax',
                                width: 150,
                                editRender: {name: '$input', props: {type: 'number'}}
                            }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addAddressItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteAddressEvent}
                        ],
                        rules: {
                            country: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_countryCannotBeEmpty`, '国家不能为空')}],
                            province: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_provinceCannotBeEmpty`, '省份不能为空')}],
                            city: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cityCannotBeEmpty`, '城市不能为空')}],
                            address: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_addressCannotBeEmpty`, '地址不能为空')}],
                            telphone: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_phoneCannotBeEmpty`, '电话不能为空')}],
                            fax: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_zipcodeCannotBeEmpty`, '邮编不能为空')}]
                        }
                    } },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankInfo`, '银行信息'), groupCode: 'bankInfo', type: 'grid', custom: {
                        ref: 'supplierBankInfoList',
                        columns: [
                            { 
                                type: 'checkbox', width: 40 
                            },
                            { 
                                type: 'seq', width: 50,
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_ELSAccount`, 'ELS账号'),
                                field: 'elsAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_purchaseElsAccount`, '采购ELS账号'),
                                field: 'toElsAccount',
                                width: 150
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCountry`, '银行国家'),
                                field: 'bankCountry',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankProvince`, '银行省份'),
                                field: 'bankProvince',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCity`, '银行城市'),
                                field: 'bankCity',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankBranchName`, '开户行全称'),
                                field: 'bankBranchName',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccount`, '银行账号'),
                                field: 'bankAccount',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccountName`, '银行账号名称'),
                                field: 'bankAccountName',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cooperationBankType`, '合作银行类型'),
                                field: 'cooperationBankType',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCode`, '银行代码'),
                                field: 'bankCode',
                                required: '1',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCodeIBAN`, 'IBAN（国际银行帐户号码）'),
                                field: 'iban',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_swiftCode`, 'SWIFT CODE（银行国际代码）'),
                                field: 'swiftCode',
                                width: 150,
                                editRender: {name: '$input'}
                            }
                            ,
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_openAccountScannedName`, '开户资料扫描件名称'),
                                field: 'fileName',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_openAccountScannedPath`, '开户资料扫描件地址'),
                                field: 'filePath',
                                width: 150,
                                editRender: {name: '$input'}
                            },
                            { field: 'grid_opration', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), width: 120, align: 'center', slots: { default: 'grid_opration' } }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '添加'), type: 'primary', click: this.addBankItem},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteBankEvent},
                            {
                                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'),
                                type: 'upload',
                                businessType: 'supplierMasterData',
                                beforeChecked: true, 
                                beforeCheckedCallBack: this.bankFileUploadCallBack,
                                single: true,
                                modalVisible: false,
                                callBack: this.uploadCallBack
                            }
                        ],
                        rules: {
                            bankCountry: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCountryCannotBeEmpty`, '银行国家不能为空')}],
                            bankProvince: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankProvinceCannotBeEmpty`, '银行省份不能为空')}],
                            bankCity: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCityCannotBeEmpty`, '银行城市不能为空')}],
                            bankBranchName: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankBranchNameCannotBeEmpty`, '开户行全称不能为空')}],
                            bankAccount: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankAccountCannotBeEmpty`, '银行账号不能为空')}],
                            bankAccountName: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankNameCannotBeEmpty`, '银行名称不能为空')}],
                            bankCode: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bankCodeCannotBeEmpty`, '银行代码不能为空')}]
                        },
                        showOptColumn: true,
                        optColumnList: [
                            { type: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), clickFn: this.bankFileDownloadEvent }
                        ]
                    } }
                ],
                formFields: [],
                publicBtn: [
                    // { title: '上一步', click: this.prevEvent },
                    // { title: '下一步', type: 'primary', click: this.nextEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', click: this.saveEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'), click: this.goBack }
                ]
            },
            url: {
                edit: '/supplier/supplierMaster/edit',
                detail: '/supplier/supplierMaster/queryById',
                upload: '/attachment/purchaseAttachment/upload'
            }
        }
    },
    computed: {
        fileSrc () {
            let templateNumber = this.currentEditRow.templateNumber
            let templateVersion = this.currentEditRow.templateVersion
            let elsAccount = this.currentEditRow.templateAccount
            if(!elsAccount || elsAccount==''){
                elsAccount = this.currentEditRow.elsAccount
            }
            let time = new Date().getTime()
            return `${this.$variateConfig['configFiles']}/${elsAccount}/sale_supplierMasterData_${templateNumber}_${templateVersion}.js?t=`+time
        }
    },
    methods: {
        bankFileDownloadEvent (row) {
            this.downloadFile (row)
        },
        certificateFileDownloadEvent (row) {
            this.downloadFile (row)
        },
        downloadFile (row){
            if(!row.fileName){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_lineNotDownload`, '该行没有可下载的附件'))
                return
            }
            const [id, fileName] = row.fileName.split('-')
            const params = {
                id
            }
            getAction('/attachment/purchaseAttachment/download', params, {
                responseType: 'blob'
            }).then(res => {
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        bankFileUploadCallBack (data){
            return new Promise((resolve)=> {
                // 验证的规则
                if (data && data.length) {
                    if (data.length===1) {
                        if(data[0].elsAccount && !data[0].toElsAccount){
                            this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_changeToPublicTips`, '改数据为公共信息，修改需要进入企业基本信息中修改'))
                            resolve(false)
                        }
                        resolve(true)
                    } else{
                        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_onlySelectOne`, '只能选择一条'))
                        resolve(false)
                    }
                }else{
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSelectDataoPerated`, '请选择需要操作的数据'))
                    resolve(false)
                }
                
            })
        },
        certificateFileUploadCallBack (data){
            return new Promise((resolve)=> {
                // 验证的规则
                if (data && data.length) {
                    if (data.length===1) {
                        if(data[0].elsAccount && !data[0].toElsAccount){
                            this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_changeToPublicTips`, '改数据为公共信息，修改需要进入企业基本信息中修改'))
                            resolve(false)
                        }
                        resolve(true)
                    } else{
                        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_onlySelectOne`, '只能选择一条'))
                        resolve(false)
                    }
                }else{
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSelectDataoPerated`, '请选择需要操作的数据'))
                    resolve(false)
                }
                
            })
        },
        uploadCallBack (result, refName) {
            console.log(result)
            const { id = '', fileName = '', filePath = '' } = result[0] || {}
            const fileGrid = this.$refs.editPage.$refs[refName][0].getCheckboxRecords()
            fileGrid[0].filePath = `${filePath}`
            fileGrid[0].fileName = `${id}-${fileName}`
        },
        addContactsItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierContactsInfoList[0]
            let itemData = {}
            this.pageConfig.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.toElsAccount
            itemData['toElsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
        },
        deleteContactsEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierContactsInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        addAddressItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierAddressInfoList[0]
            let itemData = {}
            this.pageConfig.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.toElsAccount
            itemData['toElsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
        },
        deleteAddressEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierAddressInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warningthis.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！')
                return
            }
            itemGrid.removeCheckboxRow()
        },
        addBankItem () {
            let itemGrid = this.$refs.editPage.$refs.supplierBankInfoList[0]
            let itemData = {}
            this.pageConfig.itemColumns.forEach(item => {
                if(item.defaultValue) {
                    itemData[item.field] = item.defaultValue
                }
            })
            const form =  this.$refs.editPage.getPageData()
            itemData['elsAccount'] = form.toElsAccount
            itemData['toElsAccount'] = form.elsAccount
            itemGrid.insert([itemData])
        },
        deleteBankEvent () {
            let itemGrid = this.$refs.editPage.$refs.supplierBankInfoList[0]
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        fieldSelectOk (data) {
            let supplierGrid = this.$refs.editPage.$refs.supplierOrgInfoList[0]
            let { fullData } = supplierGrid.getTableData()
            let supplierList = fullData.map(item => {
                return item.elsAccount
            })
            // 过滤已有数据
            let insertData = data.filter(item => {
                return !supplierList.includes(item.elsAccount)
            })
            insertData = insertData.map(item => {
                return {
                    toElsAccount: item.elsAccount
                }
            })
            supplierGrid.insertAt(insertData, -1)
        },
        saveEvent () {
            const params = this.$refs.editPage.getPageData()
            //判断是否可以随意修改
            // if(params.supplierStatus==='2'){
            //     this.$message.warning('合格供应商不允许数据修改，只能进行数据变更，所以无法进行保存')
            //     return
            // }
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.$refs.editPage.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                // 校验规则
                const errorIndex = result.findIndex(n => n.status === 'error')
                if (errorIndex !== -1) {
                    this.$refs.editPage.currentStep = errorIndex
                    return
                }
                // if (flag) {
                    
                //校验手机号和邮箱格式
                // let contractList = params.supplierContactsInfoList
                // if(contractList && contractList.length>0){
                //     let i = 1
                //     for(let item of contractList){
                //         const regTelephone = /^((13|14|15|16|17|18)[0-9]{1}\d{8})$/
                //         if(item.telphone && !regTelephone.test(item.telphone)){
                //             this.$message.warning('联系人信息中第'+i+'手机号格式不正确')
                //             return
                //         }
                //         const regEmail = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
                //         if(item.email && !regEmail.test(item.email)){
                //             this.$message.warning('联系人信息中第'+i+'邮箱格式不正确')
                //             return
                //         }
                //         i++
                //     }
                // }
                let url = this.url.edit
                this.confirmLoading = true
                postAction(url, params).then(res => {
                    if(res.success) {
                        this.$message.success(res.message)
                        this.init()
                    }else {
                        this.$message.warning(res.message)
                    }
                    this.confirmLoading = false
                })
                // }
            }).catch(err => {
                console.log(err)
            })
        },
        publishEvent () {
            this.$refs.editPage.handleSend()
        }
        
    }
}
</script>