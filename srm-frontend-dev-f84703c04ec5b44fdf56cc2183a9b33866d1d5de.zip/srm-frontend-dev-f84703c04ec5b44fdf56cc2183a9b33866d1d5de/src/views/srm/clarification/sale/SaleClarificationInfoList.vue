<template>
  <div style="height:100%">
    <!-- 列表界面 -->
    <list-layout
      v-show="!showDetailPage"
      ref="listPage"
      :pageData="pageData"
      :url="url" />
    <!-- 详情界面 -->
    <SaleClarificationInfoDetail 
      v-if="showDetailPage" 
      ref="detailPage" 
      :current-edit-row="currentEditRow" 
      @hide="hideEditPage" /> 
  </div>

</template>
<script>
import { ListMixin } from '@comp/template/list/ListMixin'
import SaleClarificationInfoDetail from './modules/SaleClarificationInfoDetail'
import { postAction } from '@/api/manage'
export default {
    mixins: [ListMixin],
    components: {
        SaleClarificationInfoDetail
    },
    data () {
        return {
            showAddPage: false,
            showNewRoundPage: false,
            pageData: {
                businessType: 'purchase_clarification',
                form: {
                    keyWord: '',
                    regulationType: ''
                },
                button: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_helpText`, '帮助说明'), icon: 'file-text', folded: true, clickFn: this.showHelpText},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_attachmentExplain`, '附件说明'), icon: 'file-pdf', folded: true, clickFn: this.showHelpPDF}
                ],
                formField: [
                    {
                        type: 'input',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationNo`, '澄清单号'),
                        fieldName: 'clarificationNumber',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationNo`, '澄清单号')
                    },
                    {
                        type: 'select',
                        label: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_businessType`, '业务类型'),
                        fieldName: 'businessType',
                        placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_businessType`, '业务类型'),
                        dictCode: 'srmClarificationBusinessType'
                    }
                ],
                optColumnWidth: 170,
                optColumnList: [
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'), clickFn: this.handleView}
                ]
            },
            url: {
                list: '/bidding/saleClarificationInfo/list',
                edit: '/bidding/saleClarificationInfo/edit',
                columns: 'SaleClarificationInfo' 
            }
        }
    },
    methods: {
        handleView (row) {
            this.currentEditRow = row
            if(row.viewStatus==='0'){
                //触发查询按钮时，将“查看状态”置为“已阅读”
                row.viewStatus = '1'
                postAction(this.url.edit, row).then(res => {
                    const type = res.success ? 'success' : 'error'
                    this.$message[type](res.message)
                    if(res.success){
                        this.showDetailPage = true
                        this.$store.dispatch('SetTabConfirm', true)
                    }
                }).finally(() => {
                    this.confirmLoading = false
                })
            }else{
                this.showDetailPage = true
                this.$store.dispatch('SetTabConfirm', true)
            }
            
        }
    }
}
</script>