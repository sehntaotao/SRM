<template>
  <div class="page-container">
    <edit-layout
      ref="editPage"
      :page-data="pageData"
      :currentEditRow="currentEditRow"
      :url="url" />
  </div>
</template>

<script>
import { EditMixin } from '@comp/template/edit/EditMixin'
import fieldSelectModal from '@comp/template/fieldSelectModal'
import { getAction, postAction } from '@/api/manage'
export default {
    name: 'PurchaseClarificationInfoAdd',
    mixins: [EditMixin],
    components: {
        fieldSelectModal
    },
    props: {
        currentEditRow: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    data () {
        const _self = this
        return {
            selectType: 'clarification',
            pageData: {
                form: {
                },
                groups: [
                    {
                        groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_basicData`, '基础信息'),
                        groupCode: 'baseForm',
                        sortOrder: '1',
                        custom: {
                            formFields: [
                                {
                                    fieldType: 'input',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationNo`, '澄清编号'),
                                    fieldName: 'clarificationNumber',
                                    disabled: true,
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationNo`, '澄清编号')
                                },
                                {
                                    fieldType: 'select',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_businessType`, '业务类型'),
                                    fieldName: 'businessType',
                                    dictCode: 'srmClarificationBusinessType',
                                    disabled: false,
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_businessType`, '业务类型'),
                                    bindFunction: function (parentRef, pageData, groupData, realValue){     
                                        _self.updateBusinessNumberExtendModel(realValue)
                                    }
                                },
                                {
                                    fieldType: 'selectModal',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessOrderNo`, '业务单号'),
                                    fieldName: 'businessNumber',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessOrderNo`, '业务单号'),
                                    extend: {
                                        beforeCheckedCallBack: function (Vue, pageData, groupData, form) {
                                            return new Promise((resolve, reject) => {
                                                let businessType = form.businessType || ''
                                                return businessType !== '' ? resolve('success') : reject('先选择业务类型')
                                            })
                                        }
                                    },
                                    bindFunction: function (Vue, data){     
                                        // 竞价        
                                        if(Vue.form.businessType==='1'){
                                            Vue.form.businessNumber = data[0].ebiddingNumber
                                            Vue.form.businessName = data[0].ebiddingDesc
                                            Vue.form.businessId = data[0].id
                                        }     
                                        //询价                           
                                        if(Vue.form.businessType==='2'){
                                            Vue.form.businessNumber = data[0].enquiryNumber
                                            Vue.form.businessName = data[0].enquiryDesc
                                            Vue.form.businessId = data[0].id
                                        }  
                                        //招标
                                        if(Vue.form.businessType==='3'){
                                            Vue.form.businessNumber = data[0].biddingNumber
                                            Vue.form.businessName = data[0].biddingDesc
                                            Vue.form.businessId = data[0].id
                                        }  
                                    }
                                },
                                {
                                    fieldType: 'input',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessOrderDesc`, '业务描述'),
                                    fieldName: 'businessName',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessOrderDesc`, '业务描述')
                                },
                                {
                                    fieldType: 'input',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessId`, '业务单据id'),
                                    fieldName: 'businessId',
                                    disabled: true,
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessId`, '业务单据id')
                                },
                                {
                                    fieldType: 'input',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_matterTitel`, '事项标题'),
                                    fieldName: 'matterTitel'
                                },
                                {
                                    fieldType: 'richEditorModel',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationMatter`, '澄清事项'),
                                    fieldName: 'clarificationMatter',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationMatter`, '澄清事项')
                                },
                                {
                                    fieldType: 'select',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_publishStatus`, '发布状态'),
                                    fieldName: 'sendStatus',
                                    disabled: true,
                                    dictCode: 'srmSendStatus'
                                },
                                {
                                    fieldType: 'input',
                                    fieldLabel: this.$srmI18n(`${this.$getLangAccount()}#i18n_saleBarcodeInfoHeadList_remark`, '备注'),
                                    fieldName: 'remark',
                                    placeholder: this.$srmI18n(`${this.$getLangAccount()}#i18n_saleBarcodeInfoHeadList_remark`, '备注')
                                }
                            ],
                            validateRules: {
                                businessType: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessOrderTypeCantEmpty`, '业务类型不能为空')}],
                                businessNumber: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_businessOrderNoCantEmpty`, '业务单号不能为空'), trigger: 'change'}],
                                matterTitel: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_matterTitelCantEmpty`, '事项标题不能为空')}],
                                clarificationMatter: [{required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_clarificationMatterCantEmpty`, '澄清事项不能为空')}]
                            }
                        }
                        
                    },
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_accessory`, '附件'), groupCode: 'fileInfo', type: 'grid', custom: {
                        ref: 'attachments',
                        columns: [
                            { type: 'checkbox', width: 40 },
                            { type: 'seq', width: 60, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')},
                            { field: 'fileName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileName`, '文件名称'), width: 200 },
                            { field: 'uploadTime', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadTime`, '上传时间'), width: 180 },
                            { field: 'uploadElsAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadBigB`, '上传大B'), width: 120 },
                            { field: 'uploadSubAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadSubAccount`, '上传子账号'), width: 120 },
                            { field: 'grid_opration', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), width: 120, align: 'center', slots: { default: 'grid_opration' } }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'), type: 'upload', businessType: 'clarification', callBack: this.uploadCallBack},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: this.deleteFilesEvent}
                        ],
                        showOptColumn: true,
                        optColumnList: [
                            { type: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), clickFn: this.downloadEvent }
                        ]
                    } }
                ],
                formFields: [],
                publicBtn: [
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', click: this.saveEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_savePublish`, '保存并发布'), type: 'primary', click: this.publishEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'), click: this.goBack }
                ]
            },
            url: {
                add: '/bidding/purchaseClarificationInfo/add',
                edit: '/bidding/purchaseClarificationInfo/edit',
                publish: '/bidding/purchaseClarificationInfo/publish',
                detail: '/bidding/purchaseClarificationInfo/queryById',
                upload: '/attachment/purchaseAttachment/upload'
            },
            businessNumberExtendArray: [
                {    
                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bidDocument`, '竞价单'),   
                    modalColumns: [         
                        {field: 'ebiddingNumber', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bidDocumentNo`, '竞价单号'), with: 150},         
                        {field: 'ebiddingDesc', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_documentCheck`, '单据检查'), with: 150},         
                        {field: 'ebiddingStatus_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_bidDocumentStatus`, '竞价单状态'), with: 150}     
                    ],     
                    modalUrl: '/ebidding/purchaseEbiddingHead/list?superQueryParams=%5B%7B%22fieldCode%22:%22ebiddingStatus%22,%22fieldType%22:%22select%22,%22dictCode%22:%22srmEbiddingStatus%22,%22fieldValue%22:%220%22,%22logicSymbol%22:%22ne%22,%22joiner%22:%22AND%22%7D%5D',     
                    modalParams: {}
                },
                { 
                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_inquirySheet`, '询价单'),      
                    modalColumns: [         
                        {field: 'enquiryNumber', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_inquirySheetNo`, '询价单号'), with: 150},         
                        {field: 'enquiryDesc', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_enquiryDesc`, '询价描述'), with: 150},         
                        {field: 'enquiryStatus_dictText', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_inquirySheetStatus`, '询价单状态'), with: 150}     
                    ],     
                    modalUrl: '/enquiry/purchaseEnquiryHead/list?superQueryParams=%5B%7B%22fieldCode%22:%22enquiryStatus%22,%22fieldType%22:%22input%22,%22dictCode%22:%22srmEnquiryStatus%22,%22fieldValue%22:%220%22,%22logicSymbol%22:%22ne%22,%22joiner%22:%22AND%22%7D%5D',     
                    modalParams: {}
                },
                {   
                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tenderFrom`, '招标单'),  
                    modalColumns: [         
                        {field: 'biddingNumber', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tenderNumber`, '招标单号'), with: 150},         
                        {field: 'biddingDesc', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_biddingDesc`, '单据简称'), with: 150},
                        {field: 'biddingStatus_dictText', title: '询价单状态', with: 150}      
                    ],     
                    modalUrl: '/bidding/purchaseBiddingHead/list?superQueryParams=%5B%7B%22fieldCode%22:%22biddingStatus%22,%22fieldType%22:%22input%22,%22fieldValue%22:%220%22,%22logicSymbol%22:%22ne%22,%22joiner%22:%22AND%22%7D%5D',     
                    modalParams: {}
                }
            ]
        }
    },
    computed: {
    },
    mounted () {
        this.init()
    },
    methods: {
        // 更新业务单据号
        updateBusinessNumberExtendModel (type) {
            let selectIndex = type?parseInt(type)-1: 0
            this.pageData.groups[0].custom.formFields[2].extend= Object.assign({}, this.pageData.groups[0].custom.formFields[2], this.businessNumberExtendArray[selectIndex])
        },
        init () {
            if(this.currentEditRow && this.currentEditRow.id) {
                this.$refs.editPage.queryDetail(this.currentEditRow.id)
            }
        },
        uploadCallBack (result) {
            let fileGrid = this.$refs.editPage.$refs.attachments[0]
            fileGrid.insertAt(result, -1)
        },
        deleteFilesEvent () {
            const fileGrid = this.$refs.editPage.$refs.attachments[0]
            const checkboxRecords = fileGrid.getCheckboxRecords()
            if (!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            const ids = checkboxRecords.map(n => (n.id)).join(',')
            const params = {
                ids
            }
            getAction('/attachment/purchaseAttachment/deleteBatch', params).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success) fileGrid.removeCheckboxRow()
            })
        },
        prevEvent () {
            this.$refs.editPage.prevStep()
        },
        nextEvent () {
            this.$refs.editPage.nextStep()
        },
        saveEvent () {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.$refs.editPage.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.$refs.editPage.currentStep = i
                        return
                    }
                }
                if (flag) {
                    const params = this.$refs.editPage.getPageData()
                    let url = this.currentEditRow.id? this.url.edit: this.url.add
                    postAction(url, params).then(res => {
                        const type = res.success ? 'success' : 'error'
                        this.$message[type](res.message)
                        if(res.success){
                            if (!this.currentEditRow.id) {
                                this.currentEditRow.id = res.result.id
                            }
                            this.goBack()
                        }
                    }).finally(() => {
                        this.confirmLoading = false
                    })
                }
            }).catch(err => {
                console.log(err)
            })
        },
        publishEvent () {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.$refs.editPage.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.$refs.editPage.currentStep = i
                        return
                    }
                }
                if (flag) {
                    const params = this.$refs.editPage.getPageData()
                    let url = this.url.publish
                    postAction(url, params).then(res => {
                        const type = res.success ? 'success' : 'error'
                        this.$message[type](res.message)
                        if(res.success){
                            this.goBack()
                        }
                    }).finally(() => {
                        this.confirmLoading = false
                    })
                }
            }).catch(err => {
                console.log(err)
            })
        }
    }
}
</script>
<style lang="less" scoped>
.page-container{
    /deep/ .edit-form-box{
        width: 100%;
    }
}
    
</style>