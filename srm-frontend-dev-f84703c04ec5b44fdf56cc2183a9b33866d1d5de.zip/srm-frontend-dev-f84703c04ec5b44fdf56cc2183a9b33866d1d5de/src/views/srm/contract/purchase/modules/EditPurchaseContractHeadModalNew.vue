<template>
  <div class="PurchaseEightDisciplinesHeadEdit">
    <a-spin :spinning="confirmLoading">
      <business-layout
        :ref="businessRefName"
        :currentEditRow="currentEditRow"
        :remoteJsFilePath="remoteJsFilePath"
        :requestData="requestData"
        :externalToolBar="externalToolBar"
        :pageHeaderButtons="pageHeaderButtons"
        :collapseHeadCode="['baseForm','busRule','personFrom']"
        modelLayout="masterSlave"
        pageStatus="edit"
        :handleAfterDealSource="handleAfterDealSource"
        :handleBeforeRemoteConfigData="handleBeforeRemoteConfigData"
        v-on="businessHandler"
      >
      </business-layout>
      <a-modal
        centered
        :width="960"
        :maskClosable="false"
        :visible="flowView"
        @ok="closeFlowView"
        @cancel="closeFlowView">
        <iframe
          style="width:100%;height:560px"
          title=""
          :src="currentBasePath + '/uflo/diagram?processInstanceId='+flowId"
          frameborder="0"></iframe>
      </a-modal>
      <a-modal
        forceRender
        :visible="editRowModal"
        :title="$srmI18n(`${$getLangAccount()}#i18n_title_edit`, '编辑')"
        :width="800"
        @ok="confirmEdit"
        @cancel="closeEditModal">
        <j-editor
          v-if="editRowModal"
          v-model="currentItemContent"></j-editor>
      </a-modal>
      <a-modal
        v-model="previewModal"
        :title="$srmI18n(`${$getLangAccount()}#i18n_title_preview`, '预览')"
        :footer="null"
        :width="1000">
        <div
          style="width:210mm;margin:0 auto;padding:2.54mm 3.18mm;border:1px solid #ccc"
          v-html="previewContent"></div>
      </a-modal>
      <field-select-modal
        ref="fieldSelectModal"
        isEmit
        @ok="fieldSelectOk" />
      <view-item-diff-modal ref="viewDiffModal" />
      <His-Contract-Item-Modal ref="hisContractItemModal"/>
      <select-Data-Modal
        ref="selectDataModal"
        @ok="selectDataOk"/>
    </a-spin>
  </div>
</template>

<script>

import BusinessLayout from '@comp/template/business/BusinessLayout'
import fieldSelectModal from '@comp/template/fieldSelectModal'
import {businessUtilMixin} from '@comp/template/business/businessUtilMixin.js'
import selectDataModal from './selectDataModal'
import ViewItemDiffModal from './ViewItemDiffModal'
import HisContractItemModal from './HisContractItemModal'
import {getAction, postAction} from '@/api/manage'
import JEditor from '@comp/els/JEditor'

export default {
    name: 'PurchaseContractHeadModal',
    mixins: [businessUtilMixin],
    components: {
        BusinessLayout,
        fieldSelectModal,
        selectDataModal,
        ViewItemDiffModal,
        HisContractItemModal,
        JEditor
    },
    props: {
        currentEditRow: {
            required: true,
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    data () {
        return {
            labelCol: { span: 4 },
            wrapperCol: { span: 15 },
            refresh: true,
            showHelpTip: false,
            editRowModal: false,
            previewModal: false,
            notShowTableSeq: true,
            editItemRow: {},
            currentItemContent: '',
            previewContent: '',
            confirmLoading: false,
            currentBasePath: this.$variateConfig['domianURL'],
            flowView: false,
            flowId: 0,
            requestData: {
                detail: { url: '/contract/purchaseContractHead/queryById', args: (that) => { return {id: that.currentEditRow.id}}}
            },
            externalToolBar: {
                purchaseContractItemList: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.insertGridItem,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.deleteGridItem
                    }
                ],
                purchaseContractContentItemList: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.addContentItemRow,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.deleteContentGridItem
                    }
                ],
                purchaseContractPromiseList: [],
                contractItemCustom1List: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.businessGridAdd,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.businessGridDelete
                    }
                ],
                contractItemCustom2List: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.businessGridAdd,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.businessGridDelete
                    }
                ],
                contractItemCustom3List: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.businessGridAdd,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.businessGridDelete
                    }
                ],
                contractItemCustom4List: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.businessGridAdd,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.businessGridDelete
                    }
                ],
                contractItemCustom5List: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'),
                        key: 'gridAdd',
                        click: this.businessGridAdd,
                        attrs: {
                            type: 'primary'
                        }
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.businessGridDelete
                    }
                ],
                purchaseAttachmentList: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'),
                        key: 'upload',
                        args: {
                            property: 'label', // 可省略
                            itemInfo: [], // 必传
                            action: '/attachment/purchaseAttachment/upload', // 必传
                            businessType: 'contract', // 必传,
                            itemNumberKey: 'materialNumber',
                            itemNumbeValueProp: 'value',
                            itemNumberLabel: '关联tab',
                            headId: '', // 必传
                            modalVisible: false // 必传
                        },
                        callBack: this.uploadCallBack
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'),
                        key: 'gridDelete',
                        click: this.businessGridDelete
                    }
                ]
            },
            pageHeaderButtons: [
                {
                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'),
                    args: {
                        url: '/contract/purchaseContractHead/edit'
                    },
                    // show: this.syncShow, // 同步校验显示方法
                    attrs: {
                        type: 'primary'
                    },
                    key: 'save',
                    showMessage: true,
                    handleBefore: this.handleSaveBefore
                },
                {
                    title: '审批',
                    args: {
                        url: '/elsUflo/audit/submit'
                    },
                    attrs: {
                        type: 'primary'
                    },
                    key: 'submit',
                    showMessage: true,
                    handleBefore: this.handleSubmitBefore
                },
                {
                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'),
                    key: 'goBack'
                }
            ],
            url: {
                save: '/contract/purchaseContractHead/edit',
                audit: '/elsUflo/audit/submit',
                download: '/attachment/purchaseAttachment/download',
                detail: '/contract/purchaseContractHead/queryById'
            }
        }
    },
    computed: {
        remoteJsFilePath () {
            let templateNumber = this.currentEditRow.templateNumber
            let templateVersion = this.currentEditRow.templateVersion
            let account = this.currentEditRow.templateAccount || this.currentEditRow.busAccount
            return `${account}/purchase_contract_${templateNumber}_${templateVersion}`
        }
    },
    beforeDestroy () {
        if (this.sortable) {
            this.sortable.destroy()
        }
    },
    methods: {
        handleBeforeRemoteConfigData (){
            return {
                groups: [
                    {
                        groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_accessory`, '附件'),
                        groupNameI18nKey: '',
                        groupCode: 'purchaseAttachmentList',
                        groupType: 'item',
                        sortOrder: '10',
                        extend: {
                            optColumnList: [
                                { key: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), click: this.downloadEvent }
                            ]
                        }
                    },
                    {
                        groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_purchaseContractLibrary`, '合同条款库'),
                        groupNameI18nKey: '',
                        groupCode: 'purchaseContractContentItemList',
                        groupType: 'item',
                        sortOrder: '4',
                        show: true,
                        extend: {
                            optColumnList: []
                        }
                    },
                    {
                        groupName: '关联订单',
                        groupNameI18nKey: '',
                        groupCode: 'orderItemList',
                        groupType: 'item',
                        sortOrder: '5',
                        show: true,
                        extend: {
                            optColumnList: []
                        }
                    }
                ],
                itemColumns: [
                    {
                        title: '订单号',
                        groupCode: 'orderItemList',
                        field: 'orderNumber',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '订单行号',
                        groupCode: 'orderItemList',
                        field: 'itemNumber',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '行类型',
                        field: 'itemType_dictText',
                        groupCode: 'orderItemList',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '订单行状态',
                        field: 'itemStatus_dictText',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '工厂',
                        groupCode: 'orderItemList',
                        field: 'factoryCode_dictText',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '库存地点代码',
                        groupCode: 'orderItemList',
                        field: 'storageLocationCode_dictText',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '物料编码',
                        groupCode: 'orderItemList',
                        field: 'materialNumber',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '物料描述',
                        groupCode: 'orderItemList',
                        field: 'materialDesc',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '物料规格',
                        groupCode: 'orderItemList',
                        field: 'materialSpec',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '物料组',
                        groupCode: 'orderItemList',
                        field: 'materialGroupCode',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '物料组名称',
                        groupCode: 'orderItemList',
                        field: 'materialGroupName',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '采购周期',
                        groupCode: 'orderItemList',
                        field: 'purchaseCycle',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '采购类型',
                        groupCode: 'orderItemList',
                        field: 'purchaseType_dictText',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '要求交期',
                        groupCode: 'orderItemList',
                        field: 'requireDate',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '订单数量',
                        groupCode: 'orderItemList',
                        field: 'quantity',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '数量单位',
                        groupCode: 'orderItemList',
                        field: 'quantityUnit',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        title: '来源合同行号',
                        groupCode: 'orderItemList',
                        field: 'sourceItemNumber',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        dictCode: '',
                        required: '0',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '项目编号',
                        fieldLabelI18nKey: 'i18n_title_projectNumber',
                        field: 'itemId',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        dictCode: '',
                        width: '150',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '项目名称',
                        fieldLabelI18nKey: 'i18n_title_projectName',
                        field: 'itemName',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '项目类型',
                        fieldLabelI18nKey: 'i18n_title_itemType',
                        field: 'itemType_dictText',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '项目版本',
                        fieldLabelI18nKey: 'i18n_title_projectVersion',
                        field: 'itemVersion',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '变更标识',
                        fieldLabelI18nKey: 'i18n_title_changeIdentification',
                        field: 'changeFlag',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        cellRender: {name: '$switch', type: 'visible', props: {closeValue: '0', openValue: '1', disabled: true}},
                        width: '150',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '来源类型',
                        fieldLabelI18nKey: 'i18n_title_sourceType',
                        field: 'sourceType_dictText',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        disabled: true
                    },
                    {
                        groupCode: 'purchaseContractContentItemList',
                        title: '操作',
                        fieldLabelI18nKey: 'i18n_title_operation',
                        field: 'sourceType_dictText',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        align: 'left',
                        slots: {
                            default: ({row}) => {
                                let resultArray = []
                                resultArray.push(<a title={this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看')} onClick={() => this.viewDetail(row)}>查看</a>)
                                resultArray.push(<a style="margin-left:8px" title="编辑" onClick={() => this.editRow(row)}>修改</a>)
                                if(row.changeFlag == '1'){
                                    resultArray.push(<a title="比对" style="margin-left:8px" onClick={() => this.viewDiff(row)}>比对</a>)
                                }
                                return resultArray
                            }
                        }
                    },
                    {
                        groupCode: 'purchaseAttachmentList',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_documentName`, '文件名'),
                        fieldLabelI18nKey: '',
                        field: 'fileName',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150'
                    },
                    {
                        groupCode: 'purchaseAttachmentList',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadTime`, '上传时间'),
                        fieldLabelI18nKey: '',
                        field: 'uploadTime',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150'
                    },
                    {
                        groupCode: 'purchaseAttachmentList',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploader`, '上传方'),
                        fieldLabelI18nKey: '',
                        field: 'uploadElsAccount',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150'
                    },
                    {
                        groupCode: 'purchaseAttachmentList',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'),
                        fieldLabelI18nKey: '',
                        field: 'grid_opration',
                        align: 'center',
                        headerAlign: 'center',
                        defaultValue: '',
                        width: '150',
                        slots: { default: 'grid_opration' }
                    }
                ]
            }
        },
        handleAfterDealSource (pageConfig, resultData){
            let formModel = pageConfig.groups[0].formModel
            if (resultData.id) {
                for(let key in resultData){
                    formModel[key] = resultData[key]
                }
                this.externalToolBar['purchaseAttachmentList'][0].args.headId = resultData.id || ''
            }
            let itemInfo = pageConfig.groups.map(n => ({ label: n.groupName, value: n.groupCode }))
            this.externalToolBar['purchaseAttachmentList'][0].args.itemInfo = itemInfo
            if (formModel.showCustom1 == '0') {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom1List', true)
            }else {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom1List', false)
            }
            if (formModel.showCustom2 == '0') {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom2List', true)
            }else {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom2List', false)
            }
            if (formModel.showCustom3 == '0') {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom3List', true)
            }else {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom3List', false)
            }
            if (formModel.showCustom4 == '0') {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom4List', true)
            }else {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom4List', false)
            }
            if (formModel.showCustom5 == '0') {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom5List', true)
            }else {
                this.hideSingleGroup(this.businessRefName, 'contractItemCustom5List', false)
            }
            if (formModel.showItem == '1') {
                this.hideSingleGroup(this.businessRefName, 'purchaseContractItemList', false)
            }else {
                this.hideSingleGroup(this.businessRefName, 'purchaseContractItemList', true)
            }
            if ((formModel.contractStatus == '3'||formModel.contractStatus == '8'||formModel.contractStatus == '6')&&(formModel.promiseType == 'promiseSale'||formModel.promiseType == 'promisePurchase')) {
                this.hideSingleGroup(this.businessRefName, 'purchaseContractPromiseList', false)
            }else {
                this.hideSingleGroup(this.businessRefName, 'purchaseContractPromiseList', true)
            }
            if (formModel.promisePurchase == 'order'&&(formModel.contractStatus == '3'||formModel.contractStatus == '8'||formModel.contractStatus == '6')) {
                this.hideSingleGroup(this.businessRefName, 'orderItemList', false)
            }else {
                this.hideSingleGroup(this.businessRefName, 'orderItemList', true)
            }
        },
        viewDiff (row) {
            this.$refs.viewDiffModal.open(row)
        },
        viewDetail (row) {
            this.$refs.hisContractItemModal.open(row)
        },
        handleSaveAfter (obj) {
            return new Promise(resolve => {
                return resolve(obj)
            })
        },
        filterObj (code, tar) {
            const localPageConfig = getPageConfig() // eslint-disable-line
            const arr = localPageConfig.formFields.filter(rs => rs.groupCode == code)
            console.log(arr)
            let result = {}
            arr.forEach(rs => {
                const name = tar[rs.fieldName]
                if (name != 'undefined') {
                    result[rs.fieldName] = name
                }
            })
            return result
        },
        handleSaveBefore (args) {
            let {Vue, pageConfig, btn, pageData} = args 
            let obj = pageData && JSON.parse(JSON.stringify(pageData))
            const localBusRule = this.filterObj('busRule', obj.busRule)
            const localPersonFrom = this.filterObj('personFrom', obj.personFrom)
            obj = Object.assign({}, obj, localBusRule, localPersonFrom)
            let params = {
                Vue, pageConfig, btn, pageData: obj
            }
            delete obj.busRule
            delete obj.personFrom
            return new Promise((resolve) => {
                return resolve(params)
            })
        },
        paramIntegrate () {
            let pageData = this.getAllData() || {}
            let { busRule = {}, personFrom = {} } = pageData || {}
            // pageData = { ...pageData, ...busRule, ...personFrom}
            delete pageData.busRule
            delete pageData.personFrom
            pageData = Object.assign({}, pageData, busRule, personFrom )
            return pageData
        },
        preview () {
            let contentGrid= this.getItemGridRef('purchaseContractContentItemList')
            if (!contentGrid.getTableData().tableData.length){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_noLineInfo`, '无条款行信息'))
                return
            }
            this.$refs.editPage.confirmLoading = true
            getAction('/contract/purchaseContractHead/getPreviewData', {id: this.currentEditRow.id}).then((res) => {
                if (res.success) {
                    this.previewModal = true
                    this.previewContent = res.result
                }else {
                    this.$message.warning(res.message)
                }
            }).finally(() => {
                this.$refs.editPage.confirmLoading = false
            })
        },
        //新增行
        insertGridItem () {
            let pageData = this.getAllData()
            if (!pageData.personFrom.toElsAccount) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectSupplierFirst`, '请先选择供应商！'))
                return
            }
            let params = {toElsAccount: pageData.personFrom.toElsAccount}
            this.$refs.selectDataModal.open(params)
        },
        selectDataOk (data){
            let detailGrid = this.getItemGridRef('purchaseContractItemList')
            let tableData =  detailGrid.getTableData().fullData
            let addTableData = []
            data.forEach((item, i) => {
                let lineNum = tableData.length + (i + 1)
                addTableData.push({
                    itemNumber: lineNum,
                    sourceType: item.sourceType,
                    sourceType_dictText: item.sourceType_dictText,
                    sourceNumber: item.sourceNumber,
                    sourceItemNumber: item.sourceItemNumber,
                    taxAmount: item.taxAmount,
                    netAmount: item.netAmount||0,
                    currency: item.currency,
                    price: item.price,
                    quantityUnit: item.quantityUnit,
                    quantity: item.quantity,
                    materialSpec: item.materialSpec,
                    materialDesc: item.materialDesc,
                    materialGroup: item.materialGroup,
                    taxCode: item.taxCode,
                    taxRate: item.taxRate,
                    materialNumber: item.materialNumber
                })
            })
            detailGrid.insertAt(addTableData, -1)
            this.calculateAmount()
        },
        calculateAmount (){
            let detailGrid = this.getItemGridRef('purchaseContractItemList').getTableData().tableData
            let totalTaxAmount = 0
            let totalNetAmount = 0
            detailGrid.forEach(item =>{
                if(item.taxAmount){
                    totalTaxAmount +=Number(item.taxAmount)
                }
                if(item.netAmount){
                    totalNetAmount +=Number(item.netAmount)
                }
            })
            let allData = this.$refs[`${this.businessRefName}`].extendAllData()
            allData.pageConfig.groups[1].formModel.totalTaxAmount = totalTaxAmount
            allData.pageConfig.groups[1].formModel.totalNetAmount = totalNetAmount
        },
        //删除复选框选定行
        deleteGridItem () {
            let itemGrid = this.getItemGridRef('purchaseContractItemList')
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
            this.calculateAmount()
        },
        addContentItemRow () {
            let item = {
                selectModel: 'multiple',
                sourceUrl: '/contract/purchaseContractLibrary/list',
                params: {
                    order: 'desc',
                    column: 'id'
                },
                columns: [
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_itemType`, '项目类型'),
                        field: 'itemType_dictText',
                        width: 100
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_SaleMassProdHeadList_projectName`, '项目名称'),
                        field: 'itemName',
                        width: 250
                    },
                    {
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_projectVersion`, '项目版本'),
                        field: 'itemVersion',
                        width: 100
                    }
                ]
            }
            this.$refs.fieldSelectModal.open(item.sourceUrl, item.params, item.columns, item.selectModel)
        },
        fieldSelectOk (data) {
            let detailGrid = this.getItemGridRef('purchaseContractContentItemList')
            let tableData =  detailGrid.getTableData().fullData
            let addTableData = []
            data.forEach((item, i) => {
                let lineNum = tableData.length + (i + 1)
                addTableData.push({
                    itemNumber: lineNum,
                    itemName: item.itemName,
                    itemVersion: item.itemVersion,
                    itemType: item.itemType,
                    itemType_dictText: item.itemType_dictText,
                    itemContent: item.itemContent,
                    originalContent: item.itemContent,
                    itemId: item.id,
                    changeFlag: '0',
                    sourceType: '2',
                    sourceType_dictText: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contractLibrary`, '合同库')
                })
            })
            let conent = ''
            conent = data.map(item => {
                return item.itemContent
            })
            this.businessTemplate = conent.join('')
            detailGrid.insertAt(addTableData, -1)
        },
        addSelectModel (id) {
            getAction('/contract/purchaseContractTemplateHead/queryById', {id: id}).then(res => {
                if(res.success) {
                    let detailGrid = this.getItemGridRef('purchaseContractContentItemList')
                    detailGrid.remove()
                    let tableData =  detailGrid.getTableData().fullData

                    let addTableData = []
                    res.result.purchaseContractTemplateItemList.forEach((item, i) => {
                        let lineNum = tableData.length + (i + 1)
                        addTableData.push({
                            itemNumber: lineNum,
                            itemName: item.itemName,
                            itemVersion: item.itemVersion,
                            itemType: item.itemType,
                            itemType_dictText: item.itemType_dictText,
                            itemContent: item.itemContent,
                            originalContent: item.itemContent,
                            itemId: item.id,
                            changeFlag: '0',
                            sourceType: '1',
                            sourceType_dictText: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contractTemplate`, '合同模板')
                        })
                    })
                    let conent = ''
                    conent = res.result.purchaseContractTemplateItemList.map(item => {
                        return item.itemContent
                    })
                    this.businessTemplate = conent.join('')
                    detailGrid.insertAt(addTableData, -1)
                }
            })
        },
        //删除复选框选定行
        deleteContentGridItem () {
            let itemGrid = this.getItemGridRef('purchaseContractContentItemList')
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        // 修改
        editRow (row) {
            this.editItemRow = row
            this.currentItemContent = row.itemContent
            this.editRowModal = true
        },
        closeEditModal () {
            this.editRowModal = false
        },
        confirmEdit () {
            this.editItemRow.itemContent = this.currentItemContent
            let changeFlag = '0'
            if(this.editItemRow.itemContent != this.editItemRow.originalContent){
                changeFlag = '1'
            }
            this.editItemRow.changeFlag = changeFlag
            this.editRowModal = false
        },
        /*rowDrop () {
            this.$nextTick(() => {
                let contractBuyContentItemList = this.getItemGridRef("purchaseContractContentItemList")
                this.sortable = Sortable.create(contractBuyContentItemList.$el.querySelector('.body--wrapper>.vxe-table--body tbody'), {
                    handle: '.drag-btn',
                    onEnd: ({ newIndex, oldIndex }) => {
                        let { fullData } = contractBuyContentItemList.getTableData()
                        let tableData = [...fullData]
                        let currRow = tableData.splice(oldIndex, 1)[0]
                        tableData.splice(newIndex, 0, currRow)
                        tableData = tableData.map((item, index) => {
                            item.itemNumber = index + 1
                            return item
                        })
                        contractBuyContentItemList.loadData(tableData)
                        contractBuyContentItemList.syncData()
                    }
                })
            })
        },*/
        uploadCallBack (result) {
            let fileGrid = this.getItemGridRef('purchaseAttachmentList')
            fileGrid.insertAt(result, -1)
        },
        deleteFilesEvent () {
            const fileGrid = this.getItemGridRef('purchaseAttachmentList')
            const checkboxRecords = fileGrid.getCheckboxRecords()
            if (!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                return
            }
            const ids = checkboxRecords.map(n => (n.id)).join(',')
            const params = {
                ids
            }
            getAction('/attachment/purchaseAttachment/deleteBatch', params).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success) fileGrid.removeCheckboxRow()
            })
        },
        goBack () {
            this.$emit('hide')
        },
        saveEvent () {
            this.$refs.editPage.postData()
        },
        handleSubmitBefore (args) {
            let thisData = this.getItemGridRef('purchaseContractContentItemList').getTableData().fullData
            let param = this.paramIntegrate()
            if (param.contractLevels == 'subsidiary'&&param.masterContractNumber=='') {
                this.$message.warning('合同层级为从合同时,主合同号必填!')
                return
            }
            if (!(param && param.id!='')) {
                this.$message.warning('先保存,再提交审批')
                return
            }
            if(!thisData || thisData.length===0){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contractTermLibraryInformationNeedsConfigured`, '需配置合同条款库信息!'))
                return
            }
            return new Promise((resolve) => {
                let { pageData = {} } = args || {}
                let { busRule = {}, personFrom = {} } = pageData || {}

                // pageData = { ...pageData, ...busRule, ...personFrom}
                delete pageData.busRule
                delete pageData.personFrom

                pageData = Object.assign({}, pageData, busRule, personFrom )
                let params = {
                    businessId: pageData.id,
                    businessType: 'contract',
                    auditSubject: `${this.$srmI18n(`${this.$getLangAccount()}#i18n_title_contractNoCode`, '合同编号')}：${pageData.contractNumber}`,
                    params: JSON.stringify(pageData)
                }
                args = Object.assign({}, args, {
                    pageData: params
                })
                resolve(args)
            })
        },

        showcAuditConditionBtn (){
            let params = this.getAllData()
            let auditStatus = params.auditStatus
            if(auditStatus!='0'){
                return false
            }else{
                return true
            }
        },
        auditPostData (invokeUrl){
            this.$refs.editPage.confirmLoading = true
            let formData = this.getAllData()
            let param = {}
            param['businessId'] = formData.id
            param['rootProcessInstanceId'] = formData.flowId
            param['businessType'] = 'contract'
            param['auditSubject'] = '合同编号：'+formData.contractNumber
            param['params'] = JSON.stringify(formData)
            postAction(invokeUrl, param, 'post').then((res) => {
                if (res.success) {
                    this.$message.success(res.message)
                    this.$parent.submitCallBack(formData)
                } else {
                    this.$message.warning(res.message)
                }
            }).finally(() => {
                this.$refs.editPage.confirmLoading = false
            })
        },

        showFlow () {
            let params = this.getAllData()
            this.flowId = params.flowId
            this.flowView = true
        },
        closeFlowView () {
            this.flowView = false
        },
        handleCancel () {
            this.visible = false
        },
        downloadEvent (Vue, row) {
            if(!row.fileName){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_lineNotDownload`, '该行没有可下载的附件'))
                return
            }
            const id = row.id
            const fileName = row.fileName
            const params = {
                id
            }
            getAction(this.url.download, params, {
                responseType: 'blob'
            }).then(res => {
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        }
    }
}
</script>