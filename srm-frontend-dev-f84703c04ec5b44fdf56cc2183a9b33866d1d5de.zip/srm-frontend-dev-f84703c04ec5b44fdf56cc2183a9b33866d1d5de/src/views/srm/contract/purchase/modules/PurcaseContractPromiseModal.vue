<template>
  <div class="page-container">
    <edit-layout
      ref="editPage"
      :current-edit-row="currentEditRow"
      refresh
      :page-data="pageData"
      :url="url" />
    <!-- 行明细弹出选择框 -->
    <field-select-modal
      ref="fieldSelectModal" />
    <a-modal
      centered
      :width="960"
      :maskClosable="false"
      :visible="flowView"
      @ok="closeFlowView"
      @cancel="closeFlowView">
      <iframe
        style="width:100%;height:560px"
        title=""
        :src="currentBasePath + '/uflo/diagram?processInstanceId='+flowId"
        frameborder="0"></iframe>
    </a-modal>
    <!-- 加载配置文件 -->
    <remote-js
      :src="fileSrc"
      @load="loadSuccess"
      @error="loadError" />
  </div>
</template>

<script>
import fieldSelectModal from '@comp/template/fieldSelectModal'
import { httpAction, postAction, getAction, downFile } from '@/api/manage'
import { EditMixin } from '@comp/template/edit/EditMixin'

export default {
    name: 'PurcaseContractPromiseModal',
    components: {
        fieldSelectModal
    },
    mixins: [EditMixin],
    data () {
        return {
            currentBasePath: this.$variateConfig['domianURL'],
            flowView: false,
            confirmLoading: false,
            flowId: 0,
            pageData: {
                form: {},
                groups: [
                    { groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_IZcVH_519d8b79`, '履约行信息'),  groupType: 'item', groupCode: 'purchasePromiseItemList', type: 'grid', custom: {
                            ref: 'purchasePromiseItemList',
                            columns: []
                        } },
                    /*{ groupName: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_accessory`, '附件'), groupCode: 'fileInfo', type: 'grid', custom: {
                        ref: 'purchaseAttachmentList',
                        columns: [
                            { type: 'checkbox', width: 40 },
                            { type: 'seq', width: 60, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号')},
                            { field: 'fileName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileName`, '文件名称'), width: 120 },
                            { field: 'uploadTime', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadTime`, '上传时间'), width: 180 },
                            { field: 'uploadElsAccount', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploaderPerson`, '上传人'), width: 120 },
                            { field: 'grid_opration', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), width: 120, align: 'center', slots: { default: 'grid_opration' } }
                        ],
                        buttons: [
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadAttachment`, '上传附件'), type: 'upload', businessType: 'purchaseRequest', callBack: this.uploadCallBack}
                        ],
                        showOptColumn: true,
                        optColumnList: [
                            { type: 'download', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_colunmDownload`, '下载'), clickFn: this.downloadEvent },
                            { type: 'delete', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), clickFn: this.deleteFilesEvent }
                        ]
                    } }*/

                ],
                formFields: [],
                publicBtn: [
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', click: this.saveEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitApproval`, '提交审批'), type: 'primary', click: this.submitAudit, showCondition: this.showAuditConditionBtn },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_release`, '发布'), type: 'primary', click: this.publishEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'), click: this.goBack }
                ]
            },
            url: {
                add: '/contract/purchaseContractPromise/add',
                edit: '/contract/purchaseContractPromise/edit',
                detail: '/contract/purchaseContractPromise/queryById',
                public: '/contract/purchaseContractPromise/publishEvent',
                upload: '/attachment/purchaseAttachment/upload',
                import: '/els/system/excelByConfig/importExcel',
                submitAudit: '/elsUflo/audit/submit',
                cancelAudit: '/elsUflo/audit/cancel'
            }
        }
    },
    computed: {
        fileSrc () {
            let templateNumber = this.currentEditRow.templateNumber
            let templateVersion = this.currentEditRow.templateVersion
            let elsAccount = this.currentEditRow.templateAccount || this.$ls.get('Login_elsAccount')
            let time = new Date().getTime()
            return `${this.$variateConfig['configFiles']}/${elsAccount}/purchase_contractPromise_${templateNumber}_${templateVersion}.js?t=`+time
        }
    },
    methods: {
        goBack () {
            this.$emit('hide')
        },
        loadSuccess () {
            this.pageConfig = getPageConfig() // eslint-disable-line
            if (this.currentEditRow.sourceType!='item') {
                this.pageConfig.groups.splice(1, 1)
            }
            this.handlePageData(this.pageConfig)
            this.init()
        },
        afterHandleData (data) {
            if (this.currentEditRow.sourceType=='item') {
                data.groups.forEach(rs => {
                    if (rs.groupCode == 'purchasePromiseItemList') {
                        rs.custom.buttons = []
                    }
                })
            }
            this.init()
        },
        uploadCallBack (result) {
            let fileGrid = this.$refs.editPage.$refs.purchaseAttachmentList[0]
            fileGrid.insertAt(result, -1)
        },
        deleteFilesEvent (row) {
            const fileGrid = this.$refs.editPage.$refs.purchaseAttachmentList[0]
            getAction('/attachment/purchaseAttachment/delete', {id: row.id}).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success) fileGrid.remove(row)
            })
        },

        showAuditConditionBtn () {
            let params = this.$refs.editPage ? this.$refs.editPage.form : {}
            let auditStatus = params.auditStatus
            let audit = params.audit
            if(((audit=='1')&&(auditStatus=='1'||auditStatus=='2'))||audit=='0'){
                return false
            }else{
                return true
            }
        },
        saveEvent (){
            this.$refs.editPage.postData()
        },
        showFlow (){
            this.flowId = this.$refs.editPage.form.flowId
            if(!this.flowId){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_noeStatusCantView`, '当前状态不能查看流程！'))
                return
            }
            this.flowView = true
        },
        closeFlowView (){
            this.flowView = false
        },
        getDataInfo (id){
            return new Promise((resolve, reject) => {
                let data = {
                    id: id
                }
                getAction('/contract/purchaseContractPromise/queryById', data).then(res => {
                    if (res.success) {
                        resolve(res.result)
                    }else{
                        this.$message.error(res.message)
                        this.$refs.editPage.confirmLoading = false
                    }
                })
            })
        },
        handleApproval (formData){
            let that = this
            let auditSubject = '履约单号'+'：'+formData.promiseNumber
            that.$refs.editPage.confirmLoading = true
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitApproval`, '提交审批'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterSubmittingApprovalItcannotIsurSubmitApproval?`, '提交审批后将不能修改，是否确认提交审批?'),
                onCancel: ()=> {
                    that.$refs.editPage.confirmLoading = false
                },
                onOk: function () {
                    let param = {}
                    param['businessId'] = formData.id
                    param['rootProcessInstanceId'] = formData.flowId
                    param['businessType'] = 'contractPromise'
                    param['auditSubject'] =  auditSubject
                    param['params'] = JSON.stringify(formData)
                    httpAction(that.url.submitAudit, param, 'post').then((res) => {
                        if (res.success) {
                            that.$message.success(res.message)
                            that.$parent.submitCallBack(formData)
                            that.init()
                        } else {
                            that.$message.warning(res.message)
                        }
                    }).finally(() => {
                        that.$refs.editPage.confirmLoading = false
                    })
                }
            })
        },
        submitAudit () {
            let formData = this.$refs.editPage ? this.$refs.editPage.form : {}
            let params = this.$refs.editPage.getPageData()
            postAction(this.url.edit, params ).then(res =>  {
                if (res.success) {
                    this.getDataInfo(params.id).then((res)=>{
                        this.handleApproval(res)
                    })
                }
            })
            
        },
        publishEvent () {
            let params = this.$refs.editPage.getPageData()
            if (params.audit == '1') {
                this.$message.warning('当前单据需要审批通过后发布')
                return
            } else {
                this.$refs.editPage.handleSend()
            }
        }
    }
}
</script>
