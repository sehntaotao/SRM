<template>
  <div class="calendar_set">
    <div class="factory">
      <span class="label">{{ $srmI18n(`${$getLangAccount()}#i18n_title_currentFactory`, '当前工厂') }}</span>
      <a-select 
        v-model="curFac"
        style="width: 300px;margin-right: 10px;"
        @change="handleChange">
        <a-select-option
          v-for="el of factoryArr"
          :key="el.orgCode"
          :value="el.orgCode">
          {{ el.orgName }}
        </a-select-option>
      </a-select>

      <a-button 
        class="master_plan"
        @click="goOverview"
        type="primary">{{ $srmI18n(`${$getLangAccount()}#i18n_title_annualOverview`, '年总览图') }}</a-button>
    </div>
    <FullCalendar
      ref="calendar"
      :options="calendarOptions" />
    
    <div class="btns">
      <a-button 
        class=""
        @click="setting"
        type="primary">{{ $srmI18n(`${$getLangAccount()}#i18n_title_setup`, '设置') }}</a-button>
    </div>
    <setDialog
      :factoryArr="factoryArr"
      @addCalendar="addCalendar"
      ref="setDialog" />
  </div>
</template>
<script>
import FullCalendar from '@fullcalendar/vue'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'
import setDialog from './modules/setDialog'
import dateTrans from '@/utils/dateTransform'
import { getAction, postAction } from '@api/manage'
import { DEFAULT_LANG } from '@/store/mutation-types'

export default {
    components: {
        FullCalendar,
        setDialog
    },
    data () {
        return {
            calendarOptions: {
                plugins: [ dayGridPlugin, interactionPlugin ],
                initialView: 'dayGridMonth',
                dateClick: this.handleDateClick,
                events: [
                    // { title: 'event 1', date: '2021-04-30', color: 'yellow', textColor: 'red' },
                    // { title: 'event 2', date: '2021-04-31' },
                    // { title: 'event 3', date: '2021-05-06', allDay: false  }
                ],
                weekends: true,
                firstDay: 1, // 设置一周中显示的第一天是哪天，周日是0，周一是1，类推
                locale: this.$ls.get(DEFAULT_LANG)==='en' ? 'en-us' : 'zh-cn', // 切换语言，当前为中文
                // locale: 'zh-cn', // 切换语言，当前为中文
                eventColor: '#3BB2E3', // 全部日历日程背景色
                // themeSystem: 'bootstrap', // 主题色(本地测试未能生效)
                //initialDate: moment().format('YYYY-MM-DD'), // 自定义设置背景颜色时一定要初始化日期时间
                timeGridEventMinHeight: '20', // 设置事件的最小高度
                height: '80%', // 当前日历高度
                aspectRatio: 1.3, // 设置日历单元格宽度与高度的比例。
                // displayEventTime: false, // 是否显示时间
                // allDaySlot: false, // 周，日视图时，all-day 不显示
                eventLimit: true, // 设置月日程，与all-day slot的最大显示数量，超过的通过弹窗显示
                // headerToolbar: { // 日历头部按钮位置
                //     left: '',
                //     center: 'prevYear,prev title next,nextYear',
                //     right: 'today dayGridMonth,timeGridWeek,timeGridDay'
                // },
                // buttonText: {
                //     today: this.$srmI18n(`${this.$getLangAccount()}#i18n_btn_HS_9e39f`, '今天'),
                //     month: '月',
                //     week: '周',
                //     day: '日'
                // }
            },
            curDayInfo: '',
            yearStart: '2021-01-01',
            yearEnd: '2021-12-30',
            factoryArr: [],
            curFac: ''
        }
    },
    methods: {
        init () {
            this.getFactory()
        },
        handleChange () {
            // 更新工厂后获取对应的
            this.getFactory()
        },
        goOverview () {
            this.$router.push({path: '/calendar/overview'})
        },
        getCalendar () {
            let url = 'calendar/purchaseFactoryCalendar/getCalendar'
            return getAction(url, {elsAccount: this.$ls.get('Login_elsAccount'), factory: this.curFac})
        },
        async getFactory () {
            const account = this.$getLangAccount()
            const {$srmI18n} = this

            let url = 'calendar/purchaseFactoryCalendar/getFactory'
            await getAction(url, {elsAccount: this.$ls.get('Login_elsAccount')}).then((res) => {
                if(res.success) {
                    this.factoryArr = res.result
                    if (!this.curFac) { // 默认首次如果工厂没有选为第一个工厂
                        this.curFac = this.factoryArr.length ? this.factoryArr[0].orgCode : ''
                    }
                } else {
                    this.$message.warning(res.message)
                }
            })
            let { success, result, message } = await this.getCalendar()
            if (success) {
                // let day = result.find(rs => rs.id == this.curFac)
                if (result.length>0) {
                    this.calendarOptions.events = result[0].dayOffList.map(s => (
                        {
                            date: s,
                            title: $srmI18n(`${account}#i18n_title_restday`, '休息日'),
                            textColor: '#ffffff',
                            // display: 'background',
                            eventColor: '#3788d8',
                            color: '#3788d8'
                        }
                    )
                    )
                } else {
                    this.calendarOptions.events = []
                }
            } else {
                this.$message.warning(message)
            }
        },
        addCalendar (data) {
            const account = this.$getLangAccount()
            const {$srmI18n} = this
            
            console.log(data)
            let holiday = this.holiday(data)
            let url = 'calendar/purchaseFactoryCalendar/addCalendar'
            let params = {
                purchaseFactoryCalendarHeadList: data.factory,
                dayOffList: holiday || []
            }
            postAction(url, params).then((res) => {
                if(res.success) {
                    let hd = holiday.map( rs => ({ title: $srmI18n(`${account}#i18n_title_restday`, '休息日'), date: rs }))
                    // 更新界面
                    this.calendarOptions.events = hd
                } else {
                    this.$message.warning(res.message)
                }
            })
        },
        setting () {
            this.$refs.setDialog.open()
        },

        holiday (data) {
            let ws = []
            let ds = []
            let years = data.yearSelect.sort((a, b) => a-b)
            console.log(years)
            let yearStart = `${years[0]}-01-01`
            let yearEnd = `${years.length > 1 ? years[years.length-1]: years}-12-31`
            console.log(yearStart)
            console.log(yearEnd)
            if (data.daySelect.length > 0) { // 日
                ws = dateTrans.getDayOrweek(yearStart, yearEnd, data.daySelect, 'day')
            }
            if (data.weekSelect.length > 0) { // 周
                ds = dateTrans.getDayOrweek(yearStart, yearEnd, data.weekSelect, 'week')
            }
            let hd = [...new Set([...ws, ...ds])]
            console.log(hd)
            return hd
        },
        handleDateClick (info) {
            console.log(info)
            console.log('date click! ' + info.dateStr)
            console.log('Clicked on: ' + info.dateStr)
            console.log('Coordinates: ' + info.jsEvent.pageX + ',' + info.jsEvent.pageY)
            console.log('Current view: ' + info.view.type)
            // change the day's background color just for fun
            // if (this.curDayInfo.includes(info.dateStr)) {
            //     info.dayEl.style.backgroundColor = ''
            //     let idx = this.curDayInfo.findIndex(rs => rs == info.dateStr)
            //     this.curDayInfo.splice(idx, 1)
            // } else {
            //     info.dayEl.style.backgroundColor = 'red'
            // }
            // this.curDayInfo.push(info.dateStr)
        },
        toggleWeekends () {
            this.calendarOptions.weekends = !this.calendarOptions.weekends // toggle the boolean!
        }
    },
    mounted () {
        this.init()
        console.log(this.$refs.calendar)
        console.log(this.$refs.toggleWeekends)
        console.log(this.$refs.calendar.getApi())
        // 前端获取周六日 具体日期
        // console.log(dateTrans.getWeek('2021-01-01', '2021-12-30', [6, 0]))
    }
}
</script>
<style lang="less" scoped>
    .calendar_set{
        padding: 20px;
        background: white;
        height: 100%;
        .factory{
            .label{
                margin-right: 10px;
            }
        }
        .btns{
            margin-top: 20px;
        }
    }
</style>