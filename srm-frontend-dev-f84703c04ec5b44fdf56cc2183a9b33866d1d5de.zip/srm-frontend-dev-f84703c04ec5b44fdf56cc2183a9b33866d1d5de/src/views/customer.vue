<template>
  <div style="height: 100%;">
    <iframe
      v-if="showChat"
      id="customerBackIframe"
      style="width:100%;height:100%"
      :src="url"
      scrolling="no"
      frameborder="0"></iframe>
  </div>
</template>

<script>
import { getAction } from '@/api/manage'
import { iframeUrl } from '@/utils/im/tools.js'
export default {
    data () {
        return {
            showChat: false
        }
    },
    created () {
        this.checkUserIsCustomerRole()
    },
    computed: {
        // 获取iframe url
        url () {
            const obj = {
                token: this.$ls.get('Access-Token'),
                id: this.$ls.get('Login_Userinfo').id
                // wsUrl: 'ws://localhost:9326/els/imChat', // 本地调试
                // baseUrl: 'http://localhost:8888/els/im' // 本地调试
            } 
            const url = iframeUrl(obj, '/customer')
            return url
        }
    },
    methods: {
        checkUserIsCustomerRole () {
            getAction('/account/elsSubAccount/checkUserIsCustomerRole', {}).then(res=>{
                if(res.success){
                    if (res.result) {
                        this.showChat =  true
                    } else {
                        this.$message.error('没有客服权限!')
                    }
                }
            })
        }
    }
}
</script>

<style>

</style>