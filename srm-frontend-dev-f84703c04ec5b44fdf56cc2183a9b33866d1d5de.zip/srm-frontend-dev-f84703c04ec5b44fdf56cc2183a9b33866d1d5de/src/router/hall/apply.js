import Tender from './supply/tender'
import bidEvaluation from './supply/bidEvaluation'
import { HallLayout} from '@/components/layouts'
const HallRouter = {
    path: '/applyHall',
    redirect: () =>{
        return { name: 'applyAnnouncement' }
    },
    name: 'applyHall',
    meta: {
        title: '投标大厅',
        titleI18nKey: 'i18n_title_supBiddingHall',
        icon: 'sliders',
        keepAlive: false
    },
    component: HallLayout,
    children: [
        bidEvaluation,
        Tender
    ]
}
export default HallRouter