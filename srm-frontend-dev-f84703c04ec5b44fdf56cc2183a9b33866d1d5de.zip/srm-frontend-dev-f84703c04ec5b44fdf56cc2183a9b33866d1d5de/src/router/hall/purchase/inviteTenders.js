import { RouteView } from '@/components/layouts'

const inviteTendersRouter = {
    path: '/hall/inviteTenders',
    name: 'inviteTenders',
    meta: {
        type: 'purchase',
        title: '招标',
        titleI18nKey: 'i18n_menu_YB_c608c',
        icon: 'icon-111-03',
        keepAlive: false
    },
    component: RouteView,
    children: [
        {
            path: '/hall/inviteTenders/announcement',
            name: 'announcement',
            meta: {
                title: '项目公告',
                titleI18nKey: 'i18n_menu_dIRx_47180cb3',
                keepAlive: false
            },
            component: () => import(/* webpackChunkName: 'announcement' */ '@/views/srm/bidding/hall/purchase/inviteTenders/Announcement.vue')
        },
        {
            path: '/hall/inviteTenders/registrationStatus',
            name: 'registrationStatus',
            meta: {
                title: '供应商列表',
                titleI18nKey: 'i18n_title_supplierList',
                keepAlive: false
            },
            component: () => import(/* webpackChunkName: 'registrationStatus' */ '@/views/srm/bidding/hall/purchase/inviteTenders/RegistrationStatus.vue')
        },
        // {
        //     path: '/hall/inviteTenders/qualificationExamination',
        //     name: 'QualificationExamination',
        //     meta: {
        //         title: '资格审查',
        //         keepAlive: false
        //     },
        //     component: () => import(/* webpackChunkName: 'qualificationExamination' */ '@/views/srm/bidding/hall/purchase/inviteTenders/qualificationExamination.vue')
        // },
        {
            path: '/hall/inviteTenders/openingAuthority',
            name: 'openingAuthority',
            meta: {
                title: '开通权限',
                titleI18nKey: 'i18n_menu_vebW_2d594a07',
                keepAlive: false
            },
            component: () => import(/* webpackChunkName: 'openingAuthority' */ '@/views/srm/bidding/hall/purchase/inviteTenders/OpeningAuthority.vue')
        },
        {
            path: '/hall/inviteTenders/selectParticipants',
            name: 'selectParticipants',
            meta: {
                title: '设置参与人员',
                titleI18nKey: 'i18n_menu_GRsULj_a0d00fda',
                keepAlive: false
            },
            component: () => import(/* webpackChunkName: 'selectParticipants' */ '@/views/srm/bidding/hall/purchase/inviteTenders/SelectParticipants.vue')
        },
        {
            path: '/hall/inviteTenders/viewChangeTenders',
            name: 'viewChangeTenders',
            meta: {
                title: '招标单变更',
                titleI18nKey: 'i18n_menu_YBtAH_a19aa425',
                keepAlive: false
            },
            component: () => import(/* webpackChunkName: 'selectParticipants' */ '@/views/srm/bidding/hall/purchase/inviteTenders/ViewChangeTenders.vue')
        }
    ]
}

export default inviteTendersRouter