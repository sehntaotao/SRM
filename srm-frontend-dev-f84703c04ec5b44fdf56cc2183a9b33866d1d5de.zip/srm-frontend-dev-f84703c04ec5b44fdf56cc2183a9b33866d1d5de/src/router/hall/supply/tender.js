
const BidEvaluationRouter = {
    path: '/applyHall/tenderStatus',
    name: 'tenderStatus',
    meta: {
        title: '投标',
        icon: 'icon-111-05',
        keepAlive: false
    },
    component: () => import(/* webpackChunkName: 'tender-status' */ '@/views/srm/tender/status/tenderStatus.vue')
}

export default BidEvaluationRouter
