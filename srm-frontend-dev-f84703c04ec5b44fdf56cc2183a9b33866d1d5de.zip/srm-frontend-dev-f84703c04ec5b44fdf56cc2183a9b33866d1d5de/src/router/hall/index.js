import inviteTendersRouter from './purchase/inviteTenders'
import bidEvaluationRouter from './purchase/bidEvaluation'
import openTenderRouter from './purchase/openTender'
import calibrationRouter from './purchase/calibration'
import { HallLayout} from '@/components/layouts'

const HallRouter = {
    path: '/hall',
    redirect: () =>{
        return { name: 'announcement' }
    },
    name: 'hall',
    meta: {
        title: '招标大厅',
        titleI18nKey: 'i18n_title_biddingHall',
        icon: 'sliders',
        keepAlive: false
    },
    component: HallLayout,
    children: [
        inviteTendersRouter,
        openTenderRouter,
        bidEvaluationRouter,
        calibrationRouter
    ]
}

export default HallRouter