import HallRouter from './hall'
import ApplyRouter from './hall/apply'
import supplierPictureRouter from './supplierPicture.js'
import helpCenterRouter from './helpCenter.js'
import MallRouter from './mall'
import { getLangAccount, srmI18n } from '@/utils/util'

import { UserLayout, TabLayout } from '@/components/layouts'
// import {RouteView, PageView} from '@/components/layouts'
/**
 * 走菜单，走权限控制
 * @type {[null,null]}
 */
export const asyncRouterMap = [

    {
        path: '/',
        name: 'dashboard-srm',
        component: TabLayout,
        meta: { title: '首页' },
        redirect: '/dashboard/workplace'
    },
    {
        path: '*', redirect: '/404', hidden: true
    }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
    {
        path: '/user',
        component: UserLayout,
        redirect: '/user/login',
        hidden: true,
        children: [
            {
                path: 'login',
                name: 'login',
                component: () => import(/* webpackChunkName: "userLogin" */ '@/views/user/LoginNew')
            },
            {
                path: 'supplierRegister',
                name: 'supplierRegister',
                component: () => import(/* webpackChunkName: "userSupplierRegister" */ '@/views/srm/supplier/SupplierRegister')
            },
            {
                path: 'register',
                name: 'register',
                component: () => import(/* webpackChunkName: "userRegister" */ '@/views/user/Register')
            },
            {
                path: 'register-result',
                name: 'registerResult',
                component: () => import(/* webpackChunkName: "userRegisterResult" */ '@/views/user/RegisterResult')
            },
            {
                path: 'alteration',
                name: 'alteration',
                component: () => import(/* webpackChunkName: "userAlteration" */ '@/views/user/Alteration')
            },
            {
                path: 'noticeList',
                name: 'noticeList',
                component: () => import(/* webpackChunkName: "userNoticeList" */ '@/views/user/noticeList')
            },
            {
                path: 'noticeDetail',
                name: 'noticeDetail',
                component: () => import(/* webpackChunkName: "userNoticeDetail" */ '@/views/user/noticeDetail')
            },
            {
                path: 'service',
                name: 'service',
                component: () => import(/* webpackChunkName: "userService" */ '@/views/user/service')
            },
            {
                path: 'suggestion',
                name: 'suggestion',
                component: () => import(/* webpackChunkName: "userSuggestion" */ '@/views/user/suggestion')
            },
            {
                path: 'noticeDetailTemplate',
                name: 'noticeDetailTemplate',
                component: () => import('@/views/user/NoticeDetailTemplate')
            },
            {
                path: 'qclogin',
                name: 'qclogin',
                component: () => import('@/views/user/QcCodeLogin')
            },
            {
                path: 'QcCodeBinding',
                name: 'QcCodeBinding',
                component: () => import('@/views/user/QcCodeBinding')
            },
            {
                path: 'addedApplicationRecharge',
                name: 'addedApplicationRecharge',
                component: () => import('@/views/user/addApplicationSeviceRecharge')
            }
            
        ]
    },
    // 忘记密码
    {
        path: '/user/forgetPassword',
        name: 'forgetPassword',
        component: () => import('@/views/user/forgetPassword')
    },
    // 调查问卷展示页面
    {
        path: '/questionnaire/observe',
        name: 'observe',
        meta: {
            keepAlive: false,
            title: srmI18n(`${getLangAccount()}#i18n_btn_QUDm_4572294b`, '问卷调查', true)
        },
        component: () => import('@/views/questionnaire/view')
    },
    // 调查问卷展示页面
    {
        path: '/questionnaire/result',
        name: 'questionnaireResult',
        meta: {
            keepAlive: false,
            title: srmI18n(`${getLangAccount()}#i18n_btn_QUDm_4572294b`, '问卷调查', true)
        },
        component: () => import('@/views/questionnaire/result')
    },
    {
        path: '/oauth2/authorize',
        name: 'authorize',
        component: () => import('@/views/user/thirdPartyLogin')
    },
    {
        path: '/personalSettingsIndex',
        component: TabLayout,
        hidden: true,
        children: [
            {
                path: '/personalSettingsIndex',
                name: 'personalSettingsIndex',
                meta: {
                    keepAlive: false,
                    title: '个人设置',
                    titleI18nKey: 'i18n_title_personalSettings'
                },
                component: () => import('@/views/sys/personalSettings/personalSettingsIndex')
            }
        ]
    },
    {
        path: '/registrationGuidePage',
        name: 'registrationGuidePage',
        component: () => import('@/views/sys/registrationGuide/registrationGuidePage')
    },
    {
        path: '/calendar',
        component: TabLayout,
        children: [
            {
                path: 'set',
                name: 'calendarSet',
                meta: {
                    keepAlive: false,
                    title: '设置日历',
                    titleI18nKey: 'i18n_btn_GRBv_4170f9b1'
                },
                component: () => import('@/views/calendar/set')
            },
            {
                path: 'overview',
                name: 'overview',
                meta: {
                    keepAlive: false,
                    title: '年总览图',
                    titleI18nKey: 'i18n_title_annualOverview'
                },
                component: () => import('@/views/calendar/overview')
            }
        ]
    },
    {
        path: '/questionnaire',
        component: TabLayout,
        children: [
            {
                path: 'designer',
                name: 'designer',
                meta: {
                    keepAlive: false,
                    title: '问卷设计',
                    titleI18nKey: 'i18n_title_questionnaireDesign'
                },
                component: () => import('@/views/questionnaire/index')
            }
        ]
    },
    {
        path: '/thirdPartyEmail',
        name: 'thirdPartyEmail',
        component: () => import('@/views/user/thirdPartyEmail')
    },
    {
        path: '/pageNotice',
        name: 'pageNotice',
        component: TabLayout,
        children: [
            {
                path: 'list',
                name: 'pageNoticeList',
                meta: {
                    keepAlive: false,
                    title: '公告列表',
                    titleI18nKey: 'i18n_field_RxAB_264a0a0f'
                },
                component: () => import(/* webpackChunkName: "pageNoticeList" */ '@/views/pageNotice/List')
            },
            {
                path: 'detail',
                name: 'pageNoticeDetail',
                meta: {
                    keepAlive: false,
                    title: '公告详情',
                    titleI18nKey: 'i18n_field_RxdV_2650e27d'
                },
                component: () => import(/* webpackChunkName: "pageNoticeDetail" */ '@/views/pageNotice/Detail')
            }
        ]
    },
    {
        path: '/404',
        component: () => import(/* webpackChunkName: "fail" */ '@/views/exception/404')
    },
    {
        path: '/print',
        name: 'print',
        component: TabLayout,
        children: [
            {
                path: 'preview',
                name: 'PrintPreview',
                meta: {
                    url: '/els/ureport/preview?_t=1,9&_i=1',
                    title: '预览打印',
                    titleI18nKey: 'i18n_field_UBfW_4765dc41'
                },
                component: () => import('@/components/layouts/IframePageView')
            }
        ]
    },
    {
        path: '/enquiry',
        name: 'enquiry',
        component: TabLayout,
        children: [
            {
                path: 'purchaseHall',
                name: 'purchaseHall',
                meta: {
                    keepAlive: false,
                    title: '询价大厅',
                    titleI18nKey: 'i18n_title_inquiryHall'
                },
                component: () => import('@/views/srm/enquiry/purchase/modules/PurchaseEnquiryHall')
            },
            {
                path: 'purchaseEnquiryHisList',
                name: 'purchaseEnquiryHisList',
                meta: {
                    keepAlive: false,
                    title: '询价报价历史',
                    titleI18nKey: 'i18n_field_husuvK_3a11ca73'
                },
                component: () => import('@/views/srm/enquiry/purchase/PurchaseEnquiryHisList')
            }
        ]
    },
    {
        path: '/ebidding',
        name: 'ebidding',
        component: TabLayout,
        children: [
            {
                path: 'purchaseEbiddingHisList',
                name: 'PurchaseEbiddingHisList',
                meta: {
                    keepAlive: false,
                    title: '竞价报价历史',
                    titleI18nKey: 'i18n_field_OusuvK_30dbd8f7'
                },
                component: () => import('@/views/srm/ebidding/PurchaseEbiddingHisList')
            },
            {
                path: 'buyLobbyNew',
                name: 'BuyBidLobbyNew',
                meta: {
                    keepAlive: false,
                    title: '竞价大厅',
                    titleI18nKey: 'i18n_btn_OufY_390dbcd7'
                },
                component: () => import('@/views/srm/ebidding/modules/BuyBidLobbyNew')
            },
            {
                path: 'saleLobbyNew',
                name: 'SaleBidLobbyNew',
                meta: {
                    keepAlive: false,
                    title: '竞价大厅',
                    titleI18nKey: 'i18n_btn_OufY_390dbcd7'
                },
                component: () => import('@/views/srm/ebidding/sale/modules/SaleBidLobbyNew')
            }
        ]
    },
    {
        path: '/vmi',
        name: 'vmi',
        component: TabLayout,
        children: [
            {
                path: 'VMIWaterLineHistoryList',
                name: 'VMIWaterLineHistoryList',
                meta: {
                    keepAlive: false,
                    title: 'vmi历史水位线',
                    titleI18nKey: 'i18n_field_WWWvKfLW_dbc6fa48'
                },
                component: () => import('@/views/srm/vmi/VMIWaterLineHistoryList')
            }
        ]
    },
    {
        path: '/demand',
        name: 'demand',
        component: TabLayout,
        children: [
            {
                path: 'ElsBusinessTransferHisList',
                name: 'ElsBusinessTransferHisList',
                meta: {
                    keepAlive: false,
                    title: '操作历史',
                    titleI18nKey: 'i18n_field_tkvK_2f06a59b'
                },
                component: () => import('@views/srm/demand/ElsBusinessTransferHisList')
            }
        ]
    },
    {
        path: '/srm/base/',
        component: TabLayout,
        children: [
            {
                path: 'SupplierVenture',
                name: 'SupplierVenture',
                meta: {
                    keepAlive: false,
                    title: '供应商风险',
                    titleI18nKey: 'i18n_title_suppliersRisk'
                },
                component: () => import('@/views/srm/base/venture/SupplierVenture')
            }
        ]
    },
    HallRouter,
    ApplyRouter,
    supplierPictureRouter,
    helpCenterRouter,
    MallRouter
]
