import { MallLayout } from '@/components/layouts'

const MallRouter = {
    path: '/mall',
    name: 'mall',
    meta: {
        title: '商城',
        titleI18nKey: 'i18n_menu_XL_aab48',
        icon: 'sliders',
        keepAlive: false
    },
    component: MallLayout,
    children: [
        {
            path: 'productList',
            name: 'productList',
            meta: {
                keepAlive: false,
                title: '商城',
                titleI18nKey: 'i18n_menu_XL_aab48'
            },
            component: () => import('@views/srm/mall/product/mall')
        },
        {
            path: 'myFav',
            name: 'myFav',
            meta: {
                keepAlive: false,
                title: '我的收藏',
                titleI18nKey: 'i18n_title_myFav'
            },
            component: () => import('@views/srm/mall/product/myFav')
        },
        {
            path: 'comparisonDetail',
            name: 'comparisonDetail',
            meta: {
                keepAlive: false,
                title: '比价',
                titleI18nKey: 'i18n_menu_lu_d5da3'
            },
            component: () => import('@views/srm/mall/product/comparisonDetail')
        },
        {
            path: 'goodsDetail',
            name: 'goodsDetail',
            meta: {
                keepAlive: false,
                title: '商品详情',
                titleI18nKey: 'i18n_field_XNdV_2812d71a'
            },
            component: () => import('@views/srm/mall/product/goodsDetail')
        },
        {
            path: 'cart',
            name: 'cart',
            meta: {
                keepAlive: false,
                title: '购物车',
                titleI18nKey: 'i18n_title_shoppingCart'
            },
            component: () => import('@views/srm/mall/product/cart')
        }
    ]
}

export default MallRouter