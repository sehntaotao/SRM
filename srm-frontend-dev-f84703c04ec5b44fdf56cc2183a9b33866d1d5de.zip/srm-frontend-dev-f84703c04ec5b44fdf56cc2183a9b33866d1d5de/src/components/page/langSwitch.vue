<template>
  <div class="lang-wrap">
    <a-select
      class="select-wrap"
      v-model="lang"
      size="small"
      @change="changeLangHandle">
      <a-select-option
        v-for="el in langs"
        :key="el.value">
        {{ el.label }}
      </a-select-option> 
    </a-select>
  </div>
</template>

<script>
import {  DEFAULT_LANG } from '@/store/mutation-types'
export default {
    name: 'Langswitch',


    data () {
        return {
            lang: this.$ls.get(DEFAULT_LANG) || 'zh',
            langs: [
                { label: '中文', value: 'zh' },
                { label: 'En', value: 'en' },
                { label: '德语', value: 'de' },
                { label: '越南语', value: 'vie' },
                { label: '繁体中文', value: 'cht' },
                { label: '法语', value: 'fra' }
            ]
        }
    },

    mounted () {
        
    },

    methods: {
        // 改变语种处理
        changeLangHandle () {
            this.$store.commit('TOGGLE_LANG', this.lang)
            this.$emit('change-lang', this.lang)
            window.location.reload()
        }
    }
}
</script>

<style lang="scss" scoped>
.lang-wrap {
  min-width: 60px;
  .select-wrap {
    width: 100%;
  }
}
</style>