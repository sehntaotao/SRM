<template>
  <div class="tinymce-editor">
    <editor
      :id="id"
      v-model="myValue"
      :init="init"
      :disabled="disabled"
      @onClick="onClick"
    />
  </div>
</template>

<script>
import tinymce from 'tinymce/tinymce'
import Editor from '@tinymce/tinymce-vue'
import 'tinymce/themes/silver/theme'
import 'tinymce/plugins/image'
import 'tinymce/plugins/media'
import 'tinymce/plugins/table'
import 'tinymce/plugins/lists'
import 'tinymce/plugins/code'
// import 'tinymce/plugins/contextmenu'
import 'tinymce/plugins/wordcount'
import 'tinymce/plugins/colorpicker'
// import 'tinymce/plugins/textcolor'
import 'tinymce/plugins/fullscreen'
import 'tinymce/icons/default/icons'
import 'tinymce/plugins/paste'
export default {
    components: {
        Editor
    },
    props: {
        id: {
            type: String,
            default: 'myEditor'
        },
        value: {
            type: String,
            required: false
        },
        triggerChange: {
            type: Boolean,
            default: false,
            required: false
        },
        disabled: {
            type: Boolean,
            default: false
        },
        plugins: {
            type: [String, Array],
            default: 'lists image media table wordcount fullscreen code'
        },
        toolbar: {
            type: [String, Array],
            default:
                'bold italic underline strikethrough wordcount print image table forecolor backcolor| styleselect formatselect fontselect fontsizeselect' +
                'numlist bullist outdent indent blockquote | subscript superscript | alignleft aligncenter alignright alignjustify  | undo redo removeformat preview fullscreen '
        },
        coustomInit: {//自定义配置
            type: Object,
            default: ()=>{}
        }
    },
    data () {
        return {
        //初始化配置
            init: {
                language_url: '/tinymce/langs/zh_CN.js',
                language: 'zh_CN',
                skin_url: '/tinymce/skins/lightgray',
                height: 480,
                plugins: this.plugins,
                toolbar: this.toolbar,
                branding: false,
                menubar: false,
                toolbar_drawer: false,
                auto_reset_designmode: true,
                paste_retain_style_properties: 'color font-size text-align line-height width height font-weight',
                images_upload_handler: (blobInfo, success) => {
                    const img = 'data:image/jpeg;base64,' + blobInfo.base64()
                    success(img)
                }
                
            },
            myValue: this.value
        }
    },
    created (){//合并自定义的配置
        this.init={...this.init, ...this.coustomInit}   
    },
    mounted () {
        this.initEditor()
    },
    destroyed () {
        this.removeEditor()
    },
    methods: {
        initEditor () {
               
  
            
            tinymce.init({})
        },
        // 销毁实例
        removeEditor () {
            tinymce.execCommand('mceRemoveControl', true, this.id) 
        },
        onClick (e) {
            this.$emit('onClick', e, tinymce)
        },
        //可以添加一些自己的自定义事件，如清空内容
        clear () {
            this.myValue = ''
        }
    },
    watch: {
        value (newValue) {
            this.myValue = (newValue == null ? '' : newValue)
        },
        myValue (newValue) {
            if(this.triggerChange){
                this.$emit('change', newValue)
            }else{
                this.$emit('input', newValue)
            }
        }
    }
}

</script>
<style scoped>
</style>