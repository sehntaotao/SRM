import MSelectModal from './src/main.vue'

MSelectModal.install = function (Vue) {
    Vue.component('MSelectModal', MSelectModal)
}

export default MSelectModal