<template>
  <div class="MSelectModal">
    <div class="content">
      <slot :openFunc="openSelectModal">
        <a-input
          readOnly
          :disabled="config.disabled"
          :value="value"
          :placeholder="config.placeholder"
          @click="openSelectModal">
          <a-icon
            v-if="!config.disabled"
            slot="suffix"
            type="close-circle"
            @click="clearInputValue"></a-icon>
        </a-input>
      </slot>
    </div>
    
    <field-select-modal
      isEmit
      :isTree="isTree"
      :treeConfig="treeConfig"
      ref="fieldSelectModal"
      v-on="$listeners" />
  </div>
</template>

<script>
/**
 * MSelectModal
 * @description 弹窗选择组件
 * @property {Object} config 当前字段配置
 * @property {Object} pageData 父级所有数据
 * @property {Object} form 父级表头数据
 * @property {Boolean} isRow 是否为表行弹窗类型
 * @property {Object} row 表行配置，当前行数据
 * @property {Object} column 表行配置，当前列数据
 * @property {Boolean} config.extend.isTree 是否配置为表格树
 * @property {Object} config.extend.treeConfig 树节点配置项
 * @property {Array} config.extend.modalConfigs 多套弹窗参数配置
 * 
 * @event {Function} config.extend.beforeCheckedCallBack 打开弹窗前回调，须返回一个 promise (表单调用时，可选回调参数为: this, 
 * this.pageData, this.groupData, this.form, 表格行调用时, 可选回调参数为: this, this.row, this.column)
 * 
 * e.g 表单使用
 * beforeCheckedCallBack: function (Vue, pageData, groupData, form) {
 *      return new Promise((resolve, reject) => {
 *          let orderStatus = form.orderStatus || '';
 *          return orderStatus === '0' ? resolve('success') : reject('只允许操作新建状态单据');
 *      })
 * }
 * 
 * e.g 表格使用
 * beforeCheckedCallBack: function (Vue, row, column) {
 *      return new Promise((resolve, reject) => {
 *          let price = row.price || '';
 *          return price ? resolve('success') : reject('须输入含税单价');
 *      })
 * }
 * 
 * @event {Function} config.extend.afterClearCallBack 点击取消按钮事件回调 (为表头时，返回两个参数: form 与 pageData； 为表行时，
 * 返回4个参数:row, column, rowIndex, columnIndex)
 * 
 */

import fieldSelectModal from '@comp/template/fieldSelectModal'
export default {
    name: 'MSelectModal',
    components: {
        fieldSelectModal
    },
    model: {
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: String,
            default: ''
        },
        config: {
            type: Object,
            default () {
                return {}
            }
        },
        pageData: {
            type: Object,
            default () {
                return {
                    groups: [{
                        custom: {
                            form: {},
                            formFields: [],
                            validateRules: {}
                        },
                        extend: null,
                        groupCode: null,
                        groupName: null,
                        sortOrder: null
                    }]
                }
            }
        },
        form: {
            type: Object,
            default () {
                return {}
            }
        },
        currentStep: {
            type: Number,
            default: 0
        },
        isRow: {
            type: Boolean,
            default: false
        },
        row: {
            type: Object,
            default () {
                return {}
            }
        },
        column: {
            type: Object,
            default () {
                return {}
            }
        },
        visible: {
            type: Boolean,
            default: false
        },
        isFromTileEditPage: {
            type: Boolean,
            default: false
        }
    },
    data () {
        return {}
    },
    computed: {
        // 配置下标，当弹窗配置为数组时
        current () {
            return this.config && this.config.extend && this.config.extend.current || 0
        },
        // 当前配置项
        curConfig () {
            let extend = this.config && this.config.extend || {}
            if (extend.modalConfigs && Array.isArray(extend.modalConfigs)) {
                return extend.modalConfigs[this.current]
            }
            return extend
        },
        groupData () {
            if (this.isFromTileEditPage) {
                return this.pageData.panels[this.currentStep] || {}
            }
            return this.pageData.groups[this.currentStep] || {}
        },
        isTree () {
            return this.curConfig && this.curConfig.isTree || false
        },
        treeConfig () {
            return this.curConfig && this.curConfig.treeConfig || {}
        }
    },
    watch: {
        visible (flag) {
            if (flag) {
                this.openSelectModal()
            }
        }
    },
    methods: {
        //打开选择弹窗
        openSelectModal () {
            if (!this.curConfig || !Object.keys(this.curConfig).length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_configurationParameter`, '请配置参数'))
                return
            }
            let modalParams = this.curConfig.modalParams
            let beforeCheckedCallBack = this.curConfig.beforeCheckedCallBack || (() => window.Promise.resolve())
            let url = this.curConfig.modalUrl
            console.log('url', url)
            let columns = this.curConfig.modalColumns
            let model = this.curConfig.selectModel
            let params = {}
            if (typeof(modalParams) === 'function') {
                params = modalParams(this, this.form, this.row)
            } else {
                params = modalParams
            }
            this.changeSelectModalValue(beforeCheckedCallBack).then(() => {
                this.$refs.fieldSelectModal.open(url, params, columns, model)
            }).catch((errTxt) => {
                this.$message.error(errTxt)
                if (this.isRow) {
                    this.$emit('error', errTxt)
                }
            })
        },
        clearInputValue () {
            let beforeCheckedCallBack = this.curConfig.beforeCheckedCallBack || (() => window.Promise.resolve())
            let afterClearCallBack = this.curConfig.afterClearCallBack || (f => f)
            this.changeSelectModalValue(beforeCheckedCallBack).then(() => {
                this.$emit('change', '')
                this.$emit('afterClearCallBack', afterClearCallBack)
            }).catch((errTxt) => {
                this.$message.error(errTxt)
                if (this.isRow) {
                    this.$emit('error', errTxt)
                }
            })
        },
        // 统一表头、表行回调参数
        changeSelectModalValue (cb) {
            if (this.isRow) {
                return cb && cb(this, this.row, this.column, this.form)
            } else {
                return cb && cb(this, this.pageData, this.groupData, this.form)
            }
        }
    }
}
</script>
