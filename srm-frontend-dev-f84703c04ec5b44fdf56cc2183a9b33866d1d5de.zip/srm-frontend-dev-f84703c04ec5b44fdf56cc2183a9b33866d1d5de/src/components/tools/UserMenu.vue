<template>
  <div
    class="user-wrapper nav-right-part"
    :class="{'dark':setDarkThemeDefaulColor}"
  >
    <!-- <span
      class="action top-icon"
      title="搜索菜单"
      @click="showClick">
      <a-icon type="search"></a-icon>
    </span> -->
    <!-- <component
      :is="searchMenuComp"
      v-show="searchMenuVisible"
      class="search-box"
      :visible="searchMenuVisible"
      title="搜索菜单"
      :footer="null"
      @cancel="searchMenuVisible=false"> -->
    
    <span
      class="toWebBidding header-notice action top-icon"
      @click="toWebBidding"
    >
      <img src="~@/assets/img/common/qqt_logo_3.png" />
      <!-- <span>采购网</span> -->
    </span>
    <div class="search-box">
      <div class="inner">
        <span class="search-button">
          <a-icon type="search" />
        </span>
        <a-select
          class="search-input"
          showSearch
          :showArrow="false"
          v-model="selectedMenu"
          :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_searchMenu`, '系统设置')"
          optionFilterProp="children"
          :filterOption="filterOption"
          :open="isMobile()?true:null"
          :getPopupContainer="(node) => node.parentNode"
          :style="isMobile()?{width: '100%',marginBottom:'50px'}:{}"
          @change="searchMethods"
          @blur="hiddenClick"
        >
          <a-select-option
            v-for="(site,index) in searchMenuOptions"
            :key="index"
            :value="site.id">{{ site.meta.title }}</a-select-option>
        </a-select>
      </div>
    </div>
    <!-- </component> -->
    <!-- 聊天入口 -->
    <span
      @click="openChat"
      class="header-notice action top-icon"
    >
      <icon-font
        style="font-size: 20px; padding: 0px"
        class="icon"
        type="icon-4444-02">
      </icon-font>
    </span>
    <!-- 客服入口 -->
    <span
      @click="fetchCustomer"
      class="header-notice action top-icon"
    >
      <icon-font
        style="font-size: 16px; padding: 4px"
        class="icon"
        type="icon-icon1">
      </icon-font>
    </span>
    <header-notice class="action" />
    <!-- 语言切换 -->
    <div class="user-menu-lang action">
      <lang-switch/>
    </div>
    <a-dropdown>
      <span class="action action-full ant-dropdown-link user-dropdown-menu">
        <a-avatar
          class="avatar"
          size="small"
          :src="getAvatar()"
        />
        <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_welcome`, '欢迎您') }}，{{ nickname() }}</span>
      </span>
      <a-menu
        slot="overlay"
        class="user-dropdown-menu-wrapper"
      >
        <a-menu-item
          key="2"
          @click="systemSetting"
        >
          <a-icon type="tool" />
          <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_systemSettings`, '系统设置') }}</span>
        </a-menu-item>
        <a-menu-item
          key="3"
          @click="personalSettings"
        >
          <a-icon type="setting" />
          <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_personalSettings`, '个人设置') }}</span>
        </a-menu-item>
        <!-- <a-menu-item
          key="4"
          @click="updatePassword"
        >
          <a-icon type="setting" />
          <span>密码修改</span>
        </a-menu-item> -->
        <a-menu-item key="5">
          <a
            href="javascript:;"
            @click="handleLogout">
            <a-icon type="logout"/>
            <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_layOutLogin`, '退出登录') }}</span>
          </a>
        </a-menu-item>
      </a-menu>
    </a-dropdown>
    <user-password ref="userPassword" />
    <setting-drawer
      ref="settingDrawer"
      :closable="true"
      :title="$srmI18n(`${$getLangAccount()}#i18n_title_systemSettings`, '系统设置')"
    />
  </div>
</template>

<script>
import UserPassword from './UserPassword'
import SettingDrawer from '@/components/setting/SettingDrawer'
import layIM from '@/utils/im/layIM.js'
import HeaderNotice from './HeaderNoticeNew'
import { mapActions, mapGetters, mapState } from 'vuex'
import {mixin, mixinDevice } from '@/utils/mixin.js'
import { getAction } from '@/api/manage'
import LangSwitch from '@comp/page/langSwitch'
import { ACCESS_TOKEN } from '@/store/mutation-types'
export default {
    name: 'UserMenu',
    mixins: [mixinDevice, mixin],
    components: {
        HeaderNotice,
        UserPassword,
        SettingDrawer,
        LangSwitch
    },
    props: {
        theme: {
            type: String,
            required: false,
            default: 'dark'
        }
    },
    data (){
        return{
            searchMenuOptions: [],
            searchMenuComp: 'span',
            searchMenuVisible: true,
            selectedMenuUrl: null,
            selectedMenu: ''
        }
    },
    computed: {
        ...mapState({
        // 后台菜单
            permissionMenuList: state => state.user.permissionList

        })
    },
    created () {
        let lists = []
        this.searchMenus(lists, this.permissionMenuList)
        this.searchMenuOptions=[...lists]
    },
    methods: {
        toWebBidding () {
            const url = '/enterprise/elsEnterpriseInfo/getLoginB2BUrl'
            getAction(url, {})
                .then(res => {
                    if (!res.success) {
                        this.$message.error(res.message)
                        return
                    }
                    window.open(res.message)
                })
        },
        fetchCustomer () {
            this.$emit('customerTap')
        },
        // 打开聊天
        openChat () {
            let LayimMain = layIM.im.LAYIM &&layIM.im.LAYIM.getLayimMain && layIM.im.LAYIM.getLayimMain() || null
            if (!LayimMain) { // chat相关组件没有加载完
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_chatComponentLoading`, '聊天组件在拼命加载中~'))
                return
            }
            let chatSign = LayimMain.css('display')
            if (chatSign == 'none') {
                LayimMain.show()
            } else{
                LayimMain.hide()
            }
        },
        filterOption (input, option) {
            return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
        },
        showClick () {
            this.searchMenuVisible = !this.searchMenuVisible
        },
        hiddenClick (){
            this.shows = false
        },
        // update_begin author:sunjianlei date:20191230 for: 解决外部链接打开失败的问题
        searchMethods (value) {
            let route = this.searchMenuOptions.filter(item => item.id === value)[0]
            this.selectedMenuUrl = route.path || ''
            this.selectedMenu = value
            if (route.meta.internalOrExternal === true || route.component.includes('layouts/IframePageView')) {
                let token = this.$ls.get(ACCESS_TOKEN)
                window.open(route.meta.url+ `?token=${token}`, '_blank')
            } else {
                this.$router.push({ path: route.path })
            }
            // this.searchMenuVisible = false
        },
        /* update_begin author:zhaoxin date:20191129 for: 做头部菜单栏导航*/
        searchMenus (arr, menus){
            for(let i of menus){
                if(!i.hidden && 'layouts/RouteView'!==i.component){
                    arr.push(i)
                }
                if(i.children&& i.children.length>0){
                    this.searchMenus(arr, i.children)
                }
            }
        },
        ...mapActions(['Logout']),
        ...mapGetters(['nickname', 'avatar', 'userInfo']),
        getAvatar (){
            const {origin} = window.location ||{}
            return `${origin}${this.avatar()}`
        },
        handleLogout () {
            const that = this

            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_tips`, '提示'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_areYouSureYouWantLogOff`, '真的要注销登录吗 ?'),
                onOk () {
                    return that.Logout({}).then(() => {
                        window.location.href='/'
                        //window.location.reload()
                    }).catch(err => {
                        that.$message.error({
                            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_errors`, '错误'),
                            description: err.message
                        })
                    })
                },
                onCancel () {
                }
            })
        },
        updatePassword (){
            let elsAccount = this.userInfo().elsAccount
            let subAccount = this.userInfo().subAccount
            this.$refs.userPassword.show(elsAccount, subAccount)
        },
        systemSetting (){
            this.$refs.settingDrawer.showDrawer()
        },
        personalSettings (){
            this.$router.push({path: '/personalSettingsIndex'})
        }
    },
    watch: {
        '$route': function (newRoute) {
            // 处理菜单查找问题
            if (this.selectedMenu) {
                this.selectedMenu = newRoute.path && newRoute.path == this.selectedMenuUrl ? this.selectedMenu : ''
            }
        }
    }
}
</script>
<style lang="less" scoped>
  .user-wrapper .search-input {
    // width: 180px;
    // color: inherit;

    /deep/ .ant-select-selection {
      background-color: inherit;
      border: 0;
      border-bottom: 1px solid white;
      &__placeholder, &__field__placeholder {
        color: inherit;
      }
    }
  }
  .user-wrapper .search-box{
    color: #858ebd;
    display: inline-flex;
    align-items: center;
    height: 45px;
    // padding-left: 42px;
    .inner{
      padding-right: 14px;
      border-radius: 20px;
      background: #f5f5fa;
      height: 28px;
      display: inline-flex;
      justify-content: center;
       /deep/ .ant-select-dropdown-menu-item{
         font-size: 13px;
       }
    }
    .search-input{
      width: 110px;
      height: 28px;
      opacity: 1;
      background: #f5f5fa;
      border-radius: 16px;
    }
    .search-button{
      font-size: 20px;
      color: #858ebd;
      width: 42px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    /deep/ .ant-select {
      .ant-select-selection__rendered{
        height: 28px;
        margin-left: 0;
        margin-right: 0;
        font-size: 13px;
      }
      .ant-select-selection--single{
        height: 28px;
      }
      .ant-select-selection{
        box-shadow: none;
      }
      .ant-select-selection-selected-value{
        line-height: 28px;
      }
    }
  }
  
  .user-wrapper .toWebBidding {
      >span {
        vertical-align: middle;
      }
      >img {
        height: 20px;
        width: 20px;
        // margin-right: 10px;
      }
  }
  .user-menu-lang{
     /deep/ .ant-select-selection {
       width: 62px;
     }
  }
</style>
<style scoped>
  .logout_title {
    color: inherit;
    text-decoration: none;
  }
</style>