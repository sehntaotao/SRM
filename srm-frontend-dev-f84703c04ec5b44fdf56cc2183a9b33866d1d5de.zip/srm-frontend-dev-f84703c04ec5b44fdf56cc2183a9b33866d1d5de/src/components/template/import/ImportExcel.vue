<template>
  <a-modal 
    centered
    title="导入数据"
    :width="720"
    :visible="visible"
    :maskClosable="false"
    @ok="ok"
    :footer="null"
    @cancel="close">
    <a-steps
      v-if="!isLoading"
      v-model="current"
      @change="onChange">
      <a-step
        disabled
        key="step-1"
        title="导入">
        <a-icon
          slot="icon"
          type="import" />
      </a-step>
      <a-step
        v-if="isPreview === 1"
        disabled
        key="step-preview"
        title="数据预览">
        <a-icon
          slot="icon"
          type="container" />
      </a-step>
      <a-step
        disabled
        key="step-2"
        title="完成">
        <a-icon
          slot="icon"
          type="smile-o" />
      </a-step>
    </a-steps>
    <a-spin :spinning="confirmLoading">
      <div
        style="margin-top:12px"
        class="steps-content">
        <div
          v-if="current === 0"
          v-show="!isLoading"
          class="step-2">
          <div class="import-desc">
            <h3>导入说明：</h3>
            <ul>
              <li>文件大小不能超过 10M；</li>
              <li>仅支持 *.xls、*.xlsx 格式文件；</li>
              <li>可以点击这里，<a
                href="#"
                @click="downloadFile">下载模板!</a>
              </li></ul>
          </div>
          <a-upload-dragger
            name="file"
            :headers="uploadHeader"
            :accept="accept"
            :action="importUrl"
            @change="imortChangeEvent"
            :beforeUpload="beforeUpload"
          >
            <p class="ant-upload-drag-icon">
              <a-icon type="inbox" />
            </p>
            <p class="ant-upload-text">
              点击或把文件拖拽到这个区域上传
            </p>
          </a-upload-dragger>
        </div>
        <div v-if="isPreview === 1 && current === 1 && !isLoading">
          <vxe-grid
            border
            auto-resize 
            resizable
            column-key
            row-id="id"
            highlight-hover-row
            show-overflow
            ref="previewGrid"
            height="220"
            size="mini"
            :columns="tableColumns"
            :data="tableData"
            header-align="center">
          </vxe-grid>
          <div style="text-align:right;margin-top:6px">
            <a-button
              type="primary"
              @click="importPreviewData">导入</a-button>
          </div>
        </div>
        <div
          v-if="isLoading"
          class="progress">
          <a-progress
            type="circle"
            :stroke-color="{
              '0%': '#108ee9',
              '100%': '#87d068',
            }"
            :percent="percent"
          />
        </div>
        <div
          v-if="current === lastStepIndex && !isLoading"
          class="step-3">
          <a-result
            status="success"
            title="导入成功啦！"></a-result>
        </div>
      </div>
    </a-spin>
  </a-modal>
</template>
<script>
import { Steps, Result } from 'ant-design-vue'
import { downFile, postAction } from '@api/manage'
export default {
    name: 'ImportExcel',
    props: {
        excelCode: String
    },
    components: {
        ASteps: Steps,
        AStep: Steps.Step,
        AResult: Result
    },
    data () {
        return {
            visible: false,
            current: 0,
            confirmLoading: false,
            uploadHeader: {'X-Access-Token': this.$ls.get('Access-Token')},
            accept: '.xls, .xlsx',
            isPreview: 0,
            tableColumns: [],
            tableData: [],
            dataKey: '',
            fileName: '模板文件',
            isLoading: false,
            percent: 0
        }
    },
    computed: {
        importUrl () {
            let url = this.isPreview === 1 ?  '/els/base/excelHeader/previewExcelData/' : '/els/base/excelHeader/importExcelData/'
            url += this.excelCode
            return  url 
        },
        lastStepIndex () {
            let current = this.isPreview === 1 ? 2 : 1
            return current
        }
    },
    methods: {
        open (preview, columns, fileName) {
            this.current = 0
            this.tableData = []
            this.isPreview = 0
            this.isPreview = preview
            this.tableColumns = columns
            this.fileName = fileName
            this.visible = true
        },
        ok () {
            this.visible = false
        },
        close () {
            this.visible = false
        },
        onChange (current) {
            this.current = current
        },
        //下载模板
        downloadFile (){
            downFile('/base/excelHeader/downloadTemplate', {excelCode: this.excelCode}).then((data)=>{
                if (!data) {
                    this.$message.warning('未找到对应模板！')
                    return
                }
                if (typeof window.navigator.msSaveBlob !== 'undefined') {
                    window.navigator.msSaveBlob(new Blob([data]), this.fileName + '.xlsx')
                }else{
                    let url = window.URL.createObjectURL(new Blob([data]))
                    let link = document.createElement('a')
                    link.style.display = 'none'
                    link.href = url
                    link.setAttribute('download', this.fileName+'.xlsx')
                    document.body.appendChild(link)
                    link.click()
                    document.body.removeChild(link) //下载完成移除元素
                    window.URL.revokeObjectURL(url) //释放掉blob对象
                }
            })
        },
        //导入
        imortChangeEvent (info) {
            // 导入时loading
            if (info.event && info.file.status === 'uploading') {
                this.isLoading = true
                try {
                    this.percent = Math.floor(info.event.loaded/info.event.total*100)
                } catch (error) {
                    throw new Error(error)
                }
            }
            if (info.file.status === 'done') {
                let res = info.file.response
                if(res.success){
                    if(this.isPreview === 1) {
                        this.dataKey = res.result.dataKey
                        this.tableData = res.result.dataList
                    }else {
                        window.setTimeout(() => {
                            this.visible = false
                        }, 3000)
                        this.$parent.loadData()
                    }
                    this.current += 1
                    this.percent = 0
                }else{
                    this.$message.warning(res.message)
                }
                this.isLoading = false
            }
            if (info.file.status === 'error') {
                this.isLoading = false
            }
        },
        beforeUpload (file) {
            if(file.size > 10 * 1024 * 1024) {
                this.$message.warning('超过最大文件限制！')
                return false
            }
        },
        importPreviewData () {
            let that = this
            that.confirmLoading = true
            let url = '/base/excelHeader/importPreviewExcelData/' + this.excelCode + '/' + this.dataKey
            postAction(url, {}).then(res => {
                if(res.success) {
                    this.$parent.loadData()
                    this.current += 1
                    window.setTimeout(() => {
                        that.visible = false
                    }, 3000)
                }else {
                    this.$message.warning(res.message)
                }
            }).finally(() => {
                that.confirmLoading = false
            })
        }
    }
}
</script>
<style lang="less" scoped>
    .progress{
      text-align: center;
    }
</style>