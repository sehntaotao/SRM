import DetailLayout from './DetailLayout.vue'
export const DetailMixin = {
    components: {
        DetailLayout,
        remoteJs: {
            render (createElement) {
                var self = this
                return createElement('script', {
                    attrs: { type: 'text/javascript', src: this.src, async: true },
                    on: {
                        load: function (event) {
                            self.$emit('load', event)
                        },
                        error: function (event) {
                            self.$message.warning('获取模板失败, 请检查:' + event)
                            self.$emit('error', event)
                        }
                    }
                })
            },
            props: {
                src: { type: String, required: true }
            }
        }
    },
    props: {
        currentEditRow: {
            type: Object,
            default: () => {
                return {}
            }
        }
    },
    data () {
        return {
            pageConfig: {}
        }
    },
    mounted () {
        // this.init()
    },
    methods: {
        init () {
            if(this.currentEditRow && this.currentEditRow.id) {
                this.$refs.detailPage.queryDetail(this.currentEditRow.id)
            }
        },
        //配置加载成功执行
        loadSuccess () {
            this.pageConfig = getPageConfig() // eslint-disable-line
            console.log(this.pageConfig)
            this.handlePageData(this.pageConfig)
            this.init()
        },
        //配置加载异常执行
        loadError (err) {
            console.log(err)
        },
        // 提取表格编辑配置
        // extractGridEditConfig (groups) {
        //     const that = this
        //     let editConfig = null
        //     groups.forEach((groupItem)=> {
        //         // 表格编辑规则判断字段是配置项的值为gridEditConfig唯一，groupCode可任意取值，方便扩展gridEditConfig
        //         if (groupItem.groupType==='gridEditConfig' && groupItem.groupCode==='gridEditConfig') {
        //             if (groupItem.extend) {
        //                 editConfig= {}
        //                 editConfig.trigger= groupItem.extend.editConfig.trigger || 'click'
        //                 editConfig.mode= groupItem.extend.editConfig.mode || 'cell'
        //                 editConfig.showStatus= groupItem.extend.editConfig.showStatus || true
        //                 if (groupItem.extend.editConfig.activeMethod) {
        //                     editConfig.activeMethod= (gridData)=> { return that.gridActiveMethod(gridData, groupItem.extend.editConfig.activeMethod) }
        //                 }
        //             }
        //         }
        //     })
        //     return editConfig
        // },
        // 处理当前pageData数据和配置数据
        handlePageData (data) {
            // let that = this
            let fields = []
            this.beforeHandleData(data)
            if (!this.isLocal) {
                this.pageData.groups = data.groups.concat(this.pageData.groups)
                this.pageData.formFields = data.formFields
                // 区分表格行的编辑规则和表头分组
                // let gridLineRule = this.pageData.groups.filter((groupItem)=> {
                //     if (groupItem.groupType==='gridEditConfig') {
                //         return true
                //     }
                // })
                this.pageData.groups = this.pageData.groups.filter((groupItem)=> {
                    if (groupItem.groupType!=='gridEditConfig') {
                        return true
                    }
                })
            }
            this.pageData.groups.forEach(item => {
                // 行表列信息，目前固定为itemInfo
                if (item.groupCode === 'itemInfo') {
                    if(!item.custom.notShowTableSeq){
                        item.custom.columns = [{ type: 'checkbox', width: 40 }, { type: 'seq', width: 60, title: '序号'}].concat(data.itemColumns)
                    }else {
                        item.custom.columns = [{ type: 'checkbox', width: 40 }].concat(data.itemColumns)
                    }
                }
                if (item.type && item.type === 'grid') 
                {                    
                    // item.custom.editConfig= that.extractGridEditConfig(gridLineRule)
                    // 表格列字典值
                    item.custom.columns.forEach(sub => {
                        if (sub.dictCode) {
                            sub.field += '_dictText'
                        }
                        sub.slots = {
                            header: ({ column }) => {
                                const flag = !!(sub.helpText)
                                const dom = flag
                                    ? (<vxe-tooltip content={ sub.helpText }>
                                        <span style="display: flex; alignItems: center;">
                                            <i class="vxe-icon--question"></i>
                                            <span style="marginLeft: 6px;">{ column.title }</span>
                                        </span>
                                    </vxe-tooltip>)
                                    : (<span>{ column.title }</span>)
                                return [
                                    dom
                                ]
                            }
                        }
                        // 修复阶梯价格json显示的bug
                        if (sub.fieldType === 'ladderPriceJson') {
                            sub.slots= {default: 'ladder_price_json_render'}
                            sub.showOverflow= false
                        }
                    })
                } else {
                    // 表单信息根据分组编码分类
                    fields = data.formFields.filter(item2 => {
                        return item.groupCode === item2.groupCode
                    })
                    item.custom = {
                        formFields: fields
                    }
                }
            })
            this.afterHandleData(this.pageData)
        },
        goBack () {
            this.$emit('hide')
        },
        prevEvent () {
            this.$refs.detailPage.prevStep()
        },
        nextEvent () {
            this.$refs.detailPage.nextStep()
        },
        downloadEvent (row) {
            this.$refs.detailPage.handleDownload(row)
        },
        beforeHandleData (data) {
            console.log('beforeHandleData', data)
        },
        afterHandleData (data) {
            console.log('afterHandleData', data)
        }
    }
}