<template>
  <div class="detailPage">
    <a-spin :spinning="confirmLoading">
      <div class="container">
        <div class="content">
          <div class="tabs">
            <div
              v-for="tab in pageData.groups" 
              :key="tab.groupCode" 
              forceRender
              class="itemBox">
              <div class="title dark">
                {{ tab.groupName }}
              </div>
              <div
                v-if="tab.type && tab.type === 'grid'"
                class="table">
                <vxe-grid
                  :ref="tab.custom.ref"
                  v-bind="defaultGridOption"
                  header-align="center"
                  :columns="tab.custom.columns">
                  <template #toolbar_buttons>
                    <a-button
                      v-for="(btn, index3) in tab.custom.buttons"
                      :key="'btn_' + index3"
                      :type="btn.type"
                      v-show="btn.showCondition ? btn.showCondition() : true"
                      @click="btn.click">
                      {{ btn.title }}
                    </a-button>
                  </template>
                  <template #grid_opration="{ row, column }">
                    <a
                      v-for="(item, i) in tab.custom.optColumnList"
                      :key="'opt_'+ row.id + '_' + i"
                      :title="item.title"
                      style="margin:0 4px"
                      :disabled="item.allow ? item.allow(row) : false"
                      v-show="item.showCondition ? item.showCondition(row) : true"
                      @click="item.clickFn(row, column)">{{ item.title }}</a>
                  </template>
                  <!-- 阶梯价格 -->
                  <template #ladder_price_json_render="{ row, column}">
                    <a-tooltip
                      placement="top"
                      v-if="row[column.property]"
                      overlayClassName="tip-overlay-class">
                      <template slot="title">
                        <vxe-table
                          auto-resize
                          border
                          size="mini"
                          :data="initRowLadderJson(row[column.property])">
                          <vxe-table-column
                            type="seq"
                            :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_seq`, '序号')}`"
                            width="80"></vxe-table-column>
                          <vxe-table-column
                            field="ladderQuantity"
                            :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_ladderQuantity`, '阶梯数量')}`"
                            width="140"></vxe-table-column>
                          <vxe-table-column
                            field="price"
                            :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_price`, '含税价')}`"
                            width="140"></vxe-table-column>
                          <vxe-table-column
                            field="netPrice"
                            :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_netPrice`, '不含税价')}`"
                            width="140"></vxe-table-column>
                        </vxe-table>
                      </template>
                      <div class="json-box"><a href="javascript: void(0)">{{ defaultRowLadderJson(row[column.property]) }}</a></div>
                    </a-tooltip>
                  </template>
                </vxe-grid>
              </div>
              <div
                v-else
                bordered
                class="description">
                <template v-if="tab.custom.formFields && tab.custom.formFields.length">
                  <a-descriptions
                    bordered
                    size="small">
                    <a-descriptions-item 
                      v-for="field in tab.custom.formFields"
                      :key="field.fieldName"> 
                      <span slot="label">
                        {{ field.fieldLabel }}
                        <a-tooltip
                          v-if="field.helpText"
                          :title="field.helpText">
                          <a-icon type="question-circle-o" />
                        </a-tooltip>
                      </span>
                      <template>
                        <span v-if="!tab.custom.parentObj">
                          <span v-if="field.fieldType == 'switch'">
                            {{
                              ['1', 'Y'].includes(form[field.fieldName])
                                ? `${$srmI18n(`${$getLangAccount()}#i18n_title_yes`, '是')}`
                                : `${$srmI18n(`${$getLangAccount()}#i18n_title_no`, '否')}`
                            }}
                          </span>
                          <span v-else>
                            {{ field.fieldType == 'select' || field.fieldType == 'multiple' ? form[field.fieldName + '_dictText'] : form[field.fieldName] }}
                          </span>
                        </span>
                        <span v-else-if="tab.custom.parentObj && form[tab.custom.parentObj]">
                          <span v-if="field.fieldType == 'switch'">
                            {{
                              ['1', 'Y'].includes(form[panel.custom.parentObj][field.fieldName])
                                ? `${$srmI18n(`${$getLangAccount()}#i18n_title_yes`, '是')}`
                                : `${$srmI18n(`${$getLangAccount()}#i18n_title_no`, '否')}`
                            }}
                          </span>
                          <span v-else>
                            {{ field.fieldType == 'select' || field.fieldType == 'multiple' ? form[panel.custom.parentObj][field.fieldName + '_dictText'] : form[panel.custom.parentObj][field.fieldName] }}
                          </span>
                        </span>
                      </template>
                    </a-descriptions-item>
                  </a-descriptions>
                </template>
              </div>
            </div>
          </div>
        </div>
      </div>
    </a-spin>
  </div>
</template>

<script>
import { PURCHASEATTACHMENTDOWNLOADAPI } from '@/utils/const'
import { getAction, postAction } from '@/api/manage'
// import Breadcrumb from '@/components/tools/Breadcrumb.vue'

export default {
    name: 'DetailLayout',
    components: {
        // Breadcrumb
    },
    props: {
        title: {
            type: String,
            default: '详情'
        },
        pageData: {
            type: Object,
            default: () => {}
        },
        url: {
            type: Object,
            default: () => {}
        },
        mode: {
            type: String,
            default: 'tabs'
        }
    },
    data () {
        return {
            minHeight: 0,
            activeKey: '',
            confirmLoading: false,
            text: 'text',
            form: {},
            //默认表格配置
            defaultGridOption: {
                border: true,
                resizable: true,
                autoResize: true,
                showOverflow: true,
                columnKey: true,
                highlightHoverRow: true,
                size: 'mini',
                align: 'center',
                headerAlign: 'center',
                columns: [],
                data: [],
                checkboxConfig: { highlight: true, trigger: 'row' },
                editConfig: { trigger: 'dblclick', mode: 'cell' }
                // toolbarConfig: { slots: {buttons: 'toolbar_buttons'} }
            }
        }
    },
    computed: {
        // 是否为平铺模板, 默认取否
        isTabs () {
            return this.mode === 'tabs'
        }
    },
    methods: {
        handleDownload ({ id, fileName }, url = '') {
            const params = {
                id
            }
            let downloadUrl = url || PURCHASEATTACHMENTDOWNLOADAPI
            if(this.url.download){
                downloadUrl = this.url.download
            }
            getAction(downloadUrl, params, {
                responseType: 'blob'
            }).then(res => {
                console.log(res)
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        queryDetail (id) {
            let that = this
            this.confirmLoading = true
            getAction(this.url.detail, {id: id}).then(res => {
                that.activeKey = that.pageData.groups[0].groupCode
                if(res.success) {
                    that.form = res.result
                    that.pageData.groups.forEach(group => {
                        if(group.type == 'grid') {
                            let ref = group.custom.ref
                            that.$refs[ref][0].loadData(res.result[ref])
                            if(group.custom.expandColumnsMethod) {
                                let expandColumns = group.custom.expandColumnsMethod()
                                group.custom.columns = group.custom.columns.concat(expandColumns)
                            }
                        }
                    })
                }else {
                    that.$message.warning(res.message)
                }
            }).finally(() => {
                that.confirmLoading = false
            })
        },
        getPageData () {
            const that = this
            let params = {...this.form}
            this.pageData.groups.forEach(group => {
                if(group.type == 'grid') {
                    let ref = group.custom.ref
                    params[ref] = that.$refs[ref][0].getTableData().fullData
                }
            })
            return params
        },
        setPromise () {
            let that = this
            let promise = this.pageData.groups.map(group => {
                if(group.type == 'grid') {
                    return that.$refs[group.custom.ref][0].validate(true)
                }else {
                    return that.$refs[group.groupCode][0].validate()
                }
            })
            return promise
        },
        handValidate (url, params, callback){
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) return callback && callback(url, params, this)
            }).catch(err => {
                console.log(err)
            })
        },
        handleSend (type = 'public', callback) {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) this.postData(type, callback)
            }).catch(err => {
                console.log(err)
            })
        },
        postData (type, callback) {
            let params = this.getPageData()
            let url =  type === 'public'
                ? this.url.public
                : this.voucherId
                    ? this.url.edit
                    : this.url.add
            this.confirmLoading = true
            postAction(url, params).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success && this.refresh) {
                    this.queryDetail()
                }
                if (res.success && type === 'public') {
                    this.$parent.goBack()
                } else {
                    // 自定义回调
                    return callback && callback(params, this)
                }
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        showLoading () {
            this.confirmLoading = true
        },
        hideLoading () {
            this.confirmLoading = false
        },
        // 阶梯报价json数据组装
        initRowLadderJson (jsonData) {
            let arr = []
            if (jsonData) {
                arr = JSON.parse(jsonData)
            }
            return arr
        },
        // 阶梯报价默认显示
        defaultRowLadderJson (jsonData) {
            let arrString = ''
            if (jsonData) {
                let arr = JSON.parse(jsonData)
                arr.forEach((item)=> {
                    let ladderQuantity = item.ladderQuantity
                    let price = item.price
                    let netPrice= item.netPrice
                    let str = `${ladderQuantity} ${price} ${netPrice} `
                    arrString +=str+ ','
                })
            }
            return arrString
        }
    },
    created () {
        const clientHeight = document.documentElement.clientHeight
        this.minHeight = clientHeight - 260
    }
}
</script>

<style lang="less" scoped>
.detailPage {
	.top {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 1px 0 0 1px;
		padding: 8px 40px;
		background: #fff;
		.btnGroups {
			text-align: right;
			.ant-btn {
				& + .ant-btn {
					margin-left: 10px;
				}
			}
		}
	}
	.content {
		margin: 0 1px;
		padding: 8px;
		background: #fff;
	}
    .itemBox {
        + .itemBox {
        margin-top: 12px;
        }
    }
	.title {
		padding: 0 7px;
		border: 1px solid #ededed;
		height: 34px;
		line-height: 34px;
		&.dark {
			background: #f2f2f2;
		}
	}
	.table,
	.description {
		margin-top: 10px;
	}
    .json-box {
        width: 100%;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
/deep/ .detailPage .ant-descriptions-bordered .ant-descriptions-item-label {
	background: #f2f6ff;
}
/deep/ .detailPage .ant-descriptions-item-content {
	width: 16.66%;
	max-width: 16.66%;
}
</style>
