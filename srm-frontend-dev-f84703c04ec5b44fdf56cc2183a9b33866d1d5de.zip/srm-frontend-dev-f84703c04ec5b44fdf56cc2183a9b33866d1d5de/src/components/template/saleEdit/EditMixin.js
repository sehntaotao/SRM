import Vue from 'vue'
import EditLayout from './EditLayout.vue'
import { USER_ELS_ACCOUNT } from '@/store/mutation-types'
export const EditMixin = {
    components: {
        EditLayout,
        remoteJs: {
            render (createElement) {
                var self = this
                return createElement('script', {
                    attrs: { type: 'text/javascript', src: this.src, async: true },
                    on: {
                        load: function (event) {
                            self.$emit('load', event)
                        },
                        error: function (event) {
                            self.$emit('error', event)
                        }
                    }
                })
            },
            props: {
                src: { type: String, required: true }
            }
        }
    },
    props: {
        currentEditRow: {
            type: Object,
            default: () => {
                return {
                    busAccount: Vue.ls.get(USER_ELS_ACCOUNT)
                }
            }
        }
    },
    data () {
        return {
            pageConfig: {}
        }
    },
    mounted () {
        // this.init()
    },
    methods: {
        // busAccount 国际化
        i18nBusAccount () {
            let account = this.$ls.get(USER_ELS_ACCOUNT)
            if (this.currentEditRow && this.currentEditRow.busAccount) {
                account = this.currentEditRow.busAccount || this.currentEditRow.elsAccount || this.$el.get(USER_ELS_ACCOUNT)
            }
            return account
        },
        init () {
            if(this.currentEditRow && this.currentEditRow.id) {
                this.$refs.editPage.queryDetail(this.currentEditRow.id)
            }
        },
        //配置加载成功执行
        loadSuccess () {
            this.pageConfig = getPageConfig() // eslint-disable-line
            this.handlePageData(this.pageConfig)
            this.init()
        },
        //配置加载异常执行
        loadError (err) {
            console.log(err)
        },
        beforeHandleData (data) {
            console.log('beforeHandleData', data)
        },
        afterHandleData (data) {
            console.log('afterHandleData', data)
        },
        // 提取表格编辑配置
        extractGridEditConfig (groups) {
            const that = this
            let editConfig = null
            groups.forEach((groupItem)=> {
                // 表格编辑规则判断字段是配置项的值为gridEditConfig唯一，groupCode可任意取值，方便扩展gridEditConfig
                if (groupItem.groupType==='gridEditConfig' && groupItem.groupCode==='gridEditConfig') {
                    if (groupItem.extend) {
                        editConfig= {}
                        editConfig.trigger= groupItem.extend.editConfig.trigger || 'click'
                        editConfig.mode= groupItem.extend.editConfig.mode || 'cell'
                        editConfig.showStatus= groupItem.extend.editConfig.showStatus || true
                        if (groupItem.extend.editConfig.activeMethod) {
                            editConfig.activeMethod= (gridData)=> { return that.gridActiveMethod(gridData, groupItem.extend.editConfig.activeMethod) }
                        }
                    }
                }
            })
            return editConfig
        },
        //处理当前pageData数据和配置数据
        handlePageData (data) {
            const that = this
            this.beforeHandleData(data)
            this.pageData.groups = data.groups.concat(this.pageData.groups)
            // 区分表格行的编辑规则和表头分组
            let gridLineRule = this.pageData.groups.filter((groupItem)=> {
                if (groupItem.groupType==='gridEditConfig') {
                    return true
                }
            })
            this.pageData.groups = this.pageData.groups.filter((groupItem)=> {
                if (groupItem.groupType!=='gridEditConfig') {
                    return true
                }
            })
            this.pageData.formFields = data.formFields
            let fields = []
            this.pageData.groups.forEach(item => {
                //行表列信息，目前固定为itemInfo
                if(item.groupType == 'item') {
                    let rules = {}
                    if(!item.custom) item.custom = {}
                    item.type = 'grid'
                    let columns = data.itemColumns.filter(column => {
                        if(item.groupCode == 'itemInfo') {
                            return !column.groupCode
                        }
                        return column.groupCode == item.groupCode
                    })
                    columns.forEach(sub => {
                        if (sub.required === '1') {
                            let msg = that.$srmI18n(`${that.i18nBusAccount()}#${sub.fieldLabelI18nKey}`, sub.title)
                            let ruleRequired = that.$srmI18n(`${that.$getLangAccount()}#i18n_title_required`, '必填')
                            rules[sub.field] = [{ required: true, message: `${msg}${ruleRequired}!` }]
                        }
                        if (sub.regex) {
                            console.log('sub.regex', sub.regex)
                            const prop = sub.field
                            rules[prop] = rules[prop] || []
                            let patternMsg = that.$srmI18n(`${that.i18nBusAccount()}#${sub.alertMsgI18nKey}`, sub.alertMsg)
                            rules[prop].push({
                                pattern: sub.regex, message: patternMsg
                            })
                        }
                        // 隐藏有sub.slots，配置项与vxe-table的slots的配置参数一样
                        switch(sub.fieldType) {
                        case 'input':
                            sub.editRender = { name: '$input', events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'textArea':
                            sub.editRender = { name: 'srmTextArea', events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'select':
                            sub.editRender = { name: '$select', options: [], events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'switch':
                            sub.cellRender = { name: '$switch', props: { openValue: '1', closeValue: '0' }, events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'date':
                            sub.editRender = { name: 'mDatePicker', events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'number':
                            sub.editRender = { name: '$input', props: {type: 'number'}, events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'float':
                            sub.editRender = { name: '$input', props: {type: 'float', digits: 4}, events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, sub.bindFunction)} } }
                            break
                        case 'selectModal':
                            sub.slots = Object.assign({}, sub.slots, {
                                default: ({row, rowIndex, column, columnIndex}, h) => {
    
                                    const scopedSlots = {
                                        default: ({ openFunc }) => {
                                            return (
                                                <div style="position: relative;min-height: 30px;padding-right: 20px;">
                                                    {row[column.property]}
                                                    <a style="position: absolute;display: inline-block;font-size: 16px;right: 0px; top: 3px;z-index: 10;">
                                                        <a-icon type="file-search" onClick={() => { openFunc && openFunc() }} />
                                                    </a>
                                                </div>
                                            )
                                        }
                                    }
    
                                    const props = {
                                        config: sub,
                                        row: row,
                                        isRow: true
                                    }
                                    const on = {
                                        afterClearCallBack: (cb) => cb && cb(row, column, rowIndex, columnIndex ),
                                        ok: (data) => { sub.bindFunction && sub.bindFunction(row, data, that) }
                                    }
                                            
                                    return [
                                        (<m-select-modal scopedSlots={ scopedSlots } { ...{ props, on } } />)
                                    ]
                                }
                            })
                            // 需要手动配置可编辑状态，才能显示必填项红点
                            // sub.editRender = Object.assign({}, sub.editRender, {
                            //     enabled: true
                            // })
                            break
                        }
                    })
                    if(!item.custom.ref) {
                        item.custom.ref = item.groupCode
                    }
                    item.custom.rules = rules
                    if(!item.custom.notShowTableSeq){
                        item.custom.columns = [{ type: 'checkbox', width: 40 }, { type: 'seq', width: 60, title: '序号'}].concat(columns)
                    }else {
                        item.custom.columns = [{ type: 'checkbox', width: 40 }].concat(columns)
                    }
                    // 增加表行默认按钮，默认增加添加和删除
                    if (!item.custom.buttons) {
                        item.custom.buttons= [
                            {title: '添加', type: 'primary', click: ()=> {that.addItemMixin(item.custom.ref)}},
                            {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), click: ()=>{that.deleteItemMixin(item.custom.ref)}}
                        ]
                    }
                }
                //表单信息根据分组编码分类
                if(item.type != 'grid'){
                    fields = data.formFields.filter(item2 => {
                        return item.groupCode == item2.groupCode
                    })
                    // 过滤配置为图片类型的字段，并塞在数组最后面
                    let imageFields = fields.filter(n => n.fieldType === 'image')
                    let otherFields = fields.filter(n => n.fieldType !== 'image')
                    fields = otherFields.concat(imageFields)
                    
                    item.custom = {
                        formFields: fields,
                        form: {},
                        validateRules: {}
                    }
                    fields.forEach(item3 => {
                        if (item.fieldType === 'treeSelect') {
                            item.multiple = item.multiple || false
                        }
                        // 防止switch类型字段没有默认值
                        if (item3.fieldType === 'switch') {
                            item3.defaultValue = item3.defaultValue? item3.defaultValue: '0'
                        }
                        item.custom.form[item3.fieldName] = item3.defaultValue
                        if (item3.required === '1') {
                            let msg = that.$srmI18n(`${that.i18nBusAccount()}#${item3.fieldLabelI18nKey}`, item3.fieldLabel)
                            let ruleRequired = that.$srmI18n(`${that.$getLangAccount()}#i18n_title_required`, '必填')
                            item.custom.validateRules[item3.fieldName] = [{ required: true, message: `${msg}${ruleRequired}!` }]
                        }
                        if (item3.regex) {
                            console.log('item3.regex', item3.regex)
                            const prop = item3.fieldName
                            item.custom.validateRules[prop] = item.custom.validateRules[prop] || []
                            let patternMsg = that.$srmI18n(`${that.i18nBusAccount()}#${item3.alertMsgI18nKey}`, item3.alertMsg)
                            item.custom.validateRules[prop].push({
                                pattern: item3.regex, message: patternMsg
                            })
                        }
                    })
                } else {
                    item.custom.editConfig= that.extractGridEditConfig(gridLineRule)
                    item.custom.columns.forEach(sub => {
                        if (sub.slots) {
                            sub.slots.header = ({ column }) => {
                                const flag = !!(sub.helpText)
                                const dom = flag
                                    ? (<vxe-tooltip content={ sub.helpText }>
                                        <span style="display: flex; alignItems: center;">
                                            <i class="vxe-icon--question"></i>
                                            <span style="marginLeft: 6px;">{ column.title }</span>
                                        </span>
                                    </vxe-tooltip>)
                                    : (<span>{ column.title }</span>)
                                return [
                                    dom
                                ]
                            }
                        }
                    })
                }
            })
            this.afterHandleData(this.pageData)
        },
        goBack () {
            this.$emit('hide')
        },
        prevEvent () {
            this.$refs.editPage.prevStep()
        },
        nextEvent () {
            this.$refs.editPage.nextStep()
        },
        downloadEvent (row) {
            this.$refs.editPage.handleDownload(row)
        },
        // 默认表行增加
        addItemMixin (refName) {
            if (refName) {
                let itemGrid = this.$refs.editPage.$refs[refName][0]
                let itemData = {}
                this.pageConfig.itemColumns.forEach(item => {
                    if(item.defaultValue) {
                        itemData[item.field] = item.defaultValue
                    }
                })
                itemGrid.insert([itemData])
            }
        },
        // 默认表行删除
        deleteItemMixin (refName) {
            if (refName) {
                let itemGrid = this.$refs.editPage.$refs[refName][0]
                let checkboxRecords = itemGrid.getCheckboxRecords()
                if(!checkboxRecords.length) {
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                    return
                }
                itemGrid.removeCheckboxRow()
            }
        },
        // 表行编辑change事件
        changeGridItem (currentRow, currentValue, cb) {
            cb && cb(currentRow.row, currentRow.column, currentValue.value, this)
        },
        // 表格编辑控制，切记不要写成循环
        gridActiveMethod (gridData, cb) {
            let that = this
            let {row, _rowIndex, column, _columnIndex} = gridData
            return cb(that, row, _rowIndex, column, _columnIndex)
        }
    }
}