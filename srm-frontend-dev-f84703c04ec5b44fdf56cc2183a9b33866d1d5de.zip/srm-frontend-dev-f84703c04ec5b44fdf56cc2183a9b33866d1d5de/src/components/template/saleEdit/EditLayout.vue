<template>
  <div class="subEditPage">
    <a-spin :spinning="confirmLoading">
      <div class="container">
        <div class="top">
          <div class="breadcrumb">
            <!-- <breadcrumb></breadcrumb> -->
          </div>
          <div class="btnGroups">
            <a-button
              v-for="(btn, i) in pageData.publicBtn"
              :key="`pub_btn_${i}`"
              :type="btn.type"
              v-show="btn.showCondition ? btn.showCondition() : true"
              @click="btn.click"
            >
              {{ btn.title }}
            </a-button>
          </div>
        </div>
        <div class="content">

          <div class="tabs">
            <a-tabs
              v-model="currentStep"
            >
              <a-tab-pane 
                v-for="(tab, i) in pageData.groups" 
                :key="i" 
                forceRender
              >
                <span slot="tab">
                  <a-badge :dot="tab.showDadgeDot">
                    {{ $srmI18n(`${busAccount}#${tab.groupNameI18nKey}`, tab.groupName) }} 
                  </a-badge> 
                  
                </span>
                <div
                  v-if="tab.type && tab.type === 'grid'"
                  class="table"
                  :style="{ minHeight: `${minHeight}px` }">
                  <vxe-grid
                    :ref="tab.custom.ref"
                    v-bind="gridConfig"
                    :edit-config="tab.custom.editConfig||gridCustomEditConfig"
                    :edit-rules="tab.custom.rules"
                    :columns="tab.custom.columns">
                    <template #renderDictLabel="{ row, column }">
                      <span>
                        {{ getDictLabel(row[column.property], column) }}
                      </span>
                    </template>
                    <template #toolbar_buttons>
                      <span
                        v-for="(btn, i) in tab.custom.buttons" 
                        class="tools-btn"
                        :key="'btn_' + i">
                        <a-button
                          v-if="btn.type != 'upload' && btn.type !== 'import'"
                          :type="btn.type"
                          v-show="btn.showCondition ? btn.showCondition() : true"
                          @click="btn.click">
                          {{ btn.title }}
                        </a-button>
                        <a-upload
                          v-else-if="btn.type === 'import'"
                          :show-upload-list="false"
                          :multiple="false"
                          :headers="tokenHeader"
                          :data="btn.params"
                          :action="url.import"
                          @change="(info) => handleUploadChange(info, btn, tab.custom.ref)"
                        >
                          <a-button type="primary">{{ btn.title }}</a-button>
                        </a-upload>
                        <custom-upload
                          v-else
                          :single="btn.single"
                          :disabledItemNumber="btn.disabledItemNumber"
                          :requiredFileType="btn.requiredFileType"
                          :property="btn.property"
                          :visible.sync="btn.modalVisible"
                          :title="btn.title"
                          :itemInfo="itemInfo"
                          :action="url.upload"
                          :accept="accept"
                          :headers="tokenHeader"
                          :data="{businessType: btn.businessType, headId: form.id}"
                          @change="(info) => handleUploadChange(info, btn, tab.custom.ref)"
                        >
                          <a-button
                            v-if="btn.beforeChecked"
                            type="primary"
                            icon="cloud-upload"
                            @click="checkedGridSelect(btn, tab.custom.ref, btn.beforeCheckedCallBack)">{{ btn.title }}</a-button>
                        </custom-upload>
                      </span>
                    </template>
                    <template #grid_opration="{ row, column, $rowIndex }">
                      <span
                        style="margin:0 4px"
                        v-for="(item, i) in tab.custom.optColumnList"
                        :key="'opt_'+ row.id + '_' + i">
                        <a
                          v-if="item.type != 'rowImport'"
                          :title="item.title"
                          :disabled="item.allow ? item.allow(row) : false"
                          v-show="item.showCondition ? item.showCondition(row) : true"
                          @click="item.clickFn(row, column, $rowIndex )">{{ item.title }}</a>
                        <a-upload
                          v-else-if="item.type === 'rowImport'"
                          :show-upload-list="false"
                          :multiple="false"
                          :headers="tokenHeader"
                          :data="item.params"
                          :accept="item.accept"
                          :action="url.rowImport"
                          v-show="item.showCondition ? item.showCondition(row) : true"
                          @change="(info) => handleUploadChange(info, item, tab.custom.ref, row)"
                        >
                          <a
                            style="font-size:12px"
                            :title="item.title"
                            :disabled="item.allow ? item.allow(row) : false"
                          >{{ item.title }}</a>
                        </a-upload>
                      </span>
                      
                    </template>
                  </vxe-grid>
                </div>
                <div
                  v-else
                  class="form"
                  :style="{ minHeight: `${minHeight}px` }">
                  <a-form-model
                    :ref="tab.groupCode" 
                    :model="form" 
                    :rules="tab.custom.validateRules"
                    class="ant-advanced-rule-form"
                    v-bind="layout">
                    <a-row :getterr="12">
                      <a-col
                        v-for="(item, i) in tab.custom.formFields"
                        :key="`col_${tab.groupCode}_${i}`"
                        :span="8">
                        <a-form-model-item
                          v-if="item.fieldType === 'input' || item.fieldType === 'password' || item.fieldType === 'textArea'"
                          :prop="item.fieldName">
                          
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <a-input
                            class="clickinput"
                            v-if="item.click"
                            :readOnly="item.readOnly"
                            :disabled="item.disabled"
                            :type="item.fieldType === 'input'?'text': item.fieldType === 'password'?'password':'textarea'"
                            @click="clickInputValue(form[item.fieldName], item)"
                            v-model="form[item.fieldName]"
                          />
                          <a-input
                            v-else
                            :readOnly="item.readOnly"
                            :disabled="item.disabled"
                            :type="item.fieldType === 'input'?'text': item.fieldType === 'password'?'password':'textarea'"
                            @change="changeInputValue(form[item.fieldName], item)"
                            v-model="form[item.fieldName]"
                            :placeholder="'请输入'+item.fieldLabel" />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType == 'select'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-select
                            :disabled="item.disabled"
                            :configData="item"
                            :getPopupContainer="triggerNode => {
                              return triggerNode.parentNode || document.body;
                            }"
                            @change="changeSelectValue"
                            v-model="form[item.fieldName]"
                            :current-edit-row="currentEditRow"
                            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                            :dict-code="item.dictCode" />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType == 'multiple'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-select
                            :disabled="item.disabled"
                            mode="multiple"
                            :configData="item"
                            @change="changeSelectValue"
                            :maxTagCount="item.extend && item.extend.maxTagCount || 1"
                            v-model="form[item.fieldName]"
                            :current-edit-row="currentEditRow"
                            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                            :dict-code="item.dictCode" />
                        </a-form-model-item>
                        <a-form-model-item
                          v-if="item.fieldType == 'cascader'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-cascader
                            change-on-select
                            v-model="form[item.fieldName]"
                            :mode="item.dictCode"
                            :disabled="item.disabled"
                            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                          />
                        </a-form-model-item>
                        <a-form-model-item
                          v-if="item.fieldType == 'number'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <a-input-number
                            style="width:100%"
                            :disabled="item.disabled"
                            @change="changeInputValue(form[item.fieldName], item)"
                            v-model="form[item.fieldName]"
                            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                          />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType == 'date'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <a-date-picker
                            style="width:100%"
                            :disabled="item.disabled"
                            @change="changeInputValue(form[item.fieldName], item)"
                            :show-time="item.dataFormat && item.dataFormat.length > 10 ? true : false"
                            :valueFormat="(item.dataFormat || 'YYYY-MM-DD')"
                            v-model="form[item.fieldName]"
                            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                          />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType == 'switch'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-switch
                            :disabled="item.disabled"
                            :configData="item"
                            @change="changeSelectValue"
                            v-model="form[item.fieldName]" />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType == 'treeSelect'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-tree-select 
                            v-model="form[item.fieldName]"
                            allowClear
                            :disabled="item.disabled"
                            :multiple="item.extend && item.extend.multiple || false"
                            :maxTagCount="item.extend && item.extend.maxTagCount || 1"
                            :sourceUrl="item.dictCode"
                            :sourceMap="item.sourceMap"
                            :showEmptyNode="item.showEmptyNode"
                            :placeholder="item.placeholder" />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType=='selectModal'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-select-modal
                            v-model="form[item.fieldName]"
                            :config="item"
                            :pageData="pageData"
                            :form="form"
                            :currentStep="currentStep"
                            @afterClearCallBack="handleSelectModalAfterClear"
                            @ok="(rows) => handleSelectModalAfterSelect(item, rows)"
                          />
                        </a-form-model-item>
                        <a-form-model-item
                          v-else-if="item.fieldType === 'image'"
                          :prop="item.fieldName">
                          <span slot="label">
                            <a-tooltip
                              :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                              {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                            </a-tooltip>
                            <a-tooltip
                              v-if="item.helpText"
                              :title="item.helpText">
                              <a-icon type="question-circle-o" />
                            </a-tooltip>
                          </span>
                          <m-upload
                            :disabled="item.disabled"
                            :value.sync="form[item.fieldName]"
                            :accept="accept2"
                            :headers="tokenHeader"
                            :data="{ businessType: item.dictCode, headId: form.id}"
                          > 
                          </m-upload>
                        </a-form-model-item>
                      </a-col>
                    </a-row>
                  </a-form-model>
                </div>
              </a-tab-pane>
            </a-tabs>
          </div>
        </div>
      </div>
    </a-spin>
    
  </div>
</template>
<script>
import { ajaxFindDictItems } from '@/api/api'
import { getAction, postAction } from '@/api/manage'
import { filterObj } from '@/utils/util.js'
import { EditConfig } from '@/plugins/table/gridConfig'
import MUpload from '@comp/mUpload'
import MTreeSelect from '@comp/treeSelect/mTreeSelect'
import CustomUpload from '@comp/template/CustomUpload'
import { USER_ELS_ACCOUNT } from '@/store/mutation-types'
import { SALEATTACHMENTDOWNLOADAPI } from '@/utils/const'
import { Badge } from 'ant-design-vue'
import { setTimeout } from 'timers'

export default {
    name: 'EditLayout',
    props: {
        pageData: {
            type: Object,
            default: () => {
              return {
                    groups: [{
                        custom: {
                            form: {},
                            formFields: [],
                            validateRules: {}
                        },
                        extend: null,
                        groupCode: null,
                        groupName: null,
                        sortOrder: null
                    }]
                }
            }
        },
        url: {
            type: Object,
            default: () => {}
        },
        refresh: {
            type: Boolean,
            default: false
        },
        currentEditRow: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    components: {
        MTreeSelect,
        CustomUpload,
        MUpload,
        ABadge: Badge
    },
    data () {
        return {
            minHeight: 0,
            needEcho: null,
            mustMaterialNumber: null,
            setStartPrice: null,
            ebiddingWay: null,
            delayRule: null,
            currentStep: 0,
            confirmLoading: false,
            layout: {
                labelCol: { span: 9 },
                wrapperCol: { span: 15 }
            },
            voucherId: '',
            form: this.pageData.form || {},
            //附件上传配置
            tokenHeader: {'X-Access-Token': this.$ls.get('Access-Token')},
            accept: '.doc, .docx, .xls, .xlsx, .ppt, .png, .jpg, .jpeg, .gif, .pptx, .pdf',
            accept2: '.png, .jpg, .jpeg, .gif',
            //默认表格配置
            gridConfig: EditConfig,
            currentSelectModal: null,
            currentObject: null,
            gridCustomEditConfig: {
                trigger: 'click',
                mode: 'row',
                showStatus: true
            }
        }
    },
    computed: {
        busAccount () {
            let account = this.$ls.get(USER_ELS_ACCOUNT)
            if (this.currentEditRow && this.currentEditRow.busAccount) {
                account = this.currentEditRow.busAccount || this.currentEditRow.elsAccount
            }
            return account
        },
        groups () {
            return this.pageData.groups
        },
        itemColumns () {
            const groups = this.pageData.groups || []
            let itemInfo = groups.filter(item => item.groupCode == 'itemInfo')
            if (itemInfo.length) {
                return itemInfo[0].custom.columns
            }
            return []
        },
        itemInfo () {
            let itemInfo = []
            const groups = this.pageData.groups || []
            const group = groups.find(n => n.groupCode === 'itemInfo')
            if (group) {
                const refName = group.custom.ref
                itemInfo = this.$refs[refName][0].getTableData().fullData || []
            }
            return itemInfo
        }
    },
    watch: {
        groups () {
            this.initFormDefaultValue()
        },
        itemColumns () {
            this.queryDictData()
        }
    },
    methods: {
        handleSelectModalAfterClear (cb) {
            cb && cb(this.form, this.pageData)
        },
        handleSelectModalAfterSelect (item, rows) {
            item.bindFunction && item.bindFunction.call(null, this, rows)
        },
        // 文件下载
        handleDownload ({ id, fileName }, url = '') {
            const params = {
                id
            }
            let downloadUrl = url || SALEATTACHMENTDOWNLOADAPI
            if(this.url.download){
                downloadUrl = this.url.download
            }
            getAction(downloadUrl, params, {
                responseType: 'blob'
            }).then(res => {
                console.log(res)
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        // 初始化默认值
        initFormDefaultValue () {
            const that = this
            this.pageData.groups.forEach(item => {
                if(!item.type) {
                    let fields = item.custom.formFields
                    fields.forEach(item2 => {
                        if(item2.defaultValue) {
                            that.$set(that.form, item2.fieldName, item2.defaultValue)
                        }
                    })
                }
            })
        },
        // 获取表格下拉字典
        queryDictData () {
            let that = this
            this.pageData.groups.forEach(item => {
                if(item.type == 'grid') {
                    item.custom.columns.forEach(item2 => {
                        if(item2.dictCode) {
                            let postData = {
                                busAccount: that.busAccount || that.$ls.get(USER_ELS_ACCOUNT),
                                dictCode: item2.dictCode
                            }
                            ajaxFindDictItems(postData).then(res => {
                                if(res.success) {
                                    let options = res.result.map(item3 => {
                                        return {
                                            value: item3.value,
                                            label: item3.text,
                                            title: item3.title
                                        }
                                    })
                                    if (item2.editRender) {
                                        item2.editRender.options = options
                                    }
                                    item2.dictOptions= options
                                    that.$forceUpdate()
                                }
                            })
                        }
                        // else if(item2.dictCode && !item2.editRender) {
                        //     item2.field = item2.field + '_dictText'
                        // }
                    })
                }
            })
        },
        prevStep () {
            this.currentStep > 0 && this.currentStep--
        },
        nextStep () {
            if(this.currentStep < this.pageData.groups.length - 1) {
                this.currentStep++
            } 
        },
        goBack () {
            this.$parent.goBack()
        },
        setFormPropDefaultData () {
            const { formFields = [] }  = this.pageData || {}
            formFields.forEach(({ fieldName, defaultValue }) => {
                this.form[fieldName] = defaultValue || ''
            })
        },
        queryDetail (id, cb, currentGroupCode) {
            if (!this.voucherId) this.voucherId = id
            this.confirmLoading = true
            getAction(this.url.detail, {id: id || this.voucherId}).then(res => {
                this.currentStep = currentGroupCode || 0
                if (!res.success) {
                    this.$message.error(res.message)
                    return
                }
                this.setFormPropDefaultData()
                this.form = Object.assign({}, this.form, filterObj(res.result))
                this.pageData.groups.forEach(group => {
                    if (group.type && group.type === 'grid') {
                        const ref = group.custom.ref
                        this.$refs[ref][0].loadData(res.result[ref])
                        if(Object.keys(group).includes('showDadgeDot')){//判断tab是否需要加红点
                            group.showDadgeDot=res.result[ref].length>0
                        }
                    }
                })
                this.pageData.groups.forEach(group => {
                    if (!group.type || !group.type === 'grid') {
                        this.$nextTick(() => {
                            const formFields = group.custom.formFields || []
                            formFields.forEach(item => {
                                const { bindFunction, fieldName, fieldType, groupCode, defaultValue } = item
    
                                if (bindFunction && typeof bindFunction === 'function') {
                                    const parentRef = this.$refs[groupCode]
                                    const groupData = this.pageData.groups[this.currentStep]
                                    const value = this.form[fieldName] || defaultValue
                                    if (fieldType !== 'selectModal') {
                                        if (fieldType === 'input') {
                                            bindFunction.call(null, parentRef, this.pageData, groupData, value, item, this.form )
                                        } else {
                                            bindFunction.call(null, parentRef, this.pageData, groupData, value, [], '', this.form)
                                        }
                                    }
                                }
                            })
                        })

                    }
                })

                cb && cb()
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        getPageData () {
            const that = this
            let params = {...this.form}
            this.pageData.groups.forEach(group => {
                if(group.type == 'grid') {
                    let ref = group.custom.ref
                    params[ref] = that.$refs[ref][0].getTableData().fullData
                }
            })
            return params
        },
        setPromise () {
            let that = this
            let promise = this.pageData.groups.map(group => {
                if(group.type == 'grid') {
                    return that.$refs[group.custom.ref][0].validate(true)
                }else {
                    return that.$refs[group.groupCode][0].validate()
                }
            })
            return promise
        },
        handValidate (url, params, callback){
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) return callback && callback(url, params, this)
            }).catch(err => {
                console.log(err)
            })
        },
        handleSend (type = 'public', callback) {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) this.postData(type, callback)
            }).catch(err => {
                console.log(err)
            })
        },
        postData (type, callback) {
            let params = this.getPageData()
            let url =  type === 'public'
                ? this.url.public
                : this.voucherId
                    ? this.url.edit
                    : this.url.add
            this.confirmLoading = true
            postAction(url, params).then(res => {
                const msgType = res.success ? 'success' : 'error'
                this.$message[msgType](res.message)
                if (res.success && this.refresh) {
                    this.queryDetail()
                }
                if (res.success && type === 'public') {
                    this.$parent.goBack()
                } else {
                    // 自定input义回调
                    return callback && callback(params, this)
                }
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        //附件上传
        handleUploadChange (info, btn, refName, row) {
            btn.callBack && btn.callBack(info, refName, row)
        },
        // input 改变事件,value-当前值
        changeInputValue (value, item) {
            let parentRef = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let parentRefName = this.pageData.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageData.groups[this.currentStep]
            }
            // let test = value?true: false
            // groupData.custom.validateRules= Object.assign({}, groupData.custom.validateRules, {enquiryType: {required: test, message: '123455'}})
            if (item && item.bindFunction &&  typeof item.bindFunction === 'function') {
                item.bindFunction(parentRef, this.pageData, groupData, value, item, this.form)
            }
        },
        clickInputValue (value, item) {
            let parentRef = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let parentRefName = this.pageData.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageData.groups[this.currentStep]
            }
            if (item && item.bindClickFunction &&  typeof item.bindClickFunction === 'function') {
                item.bindClickFunction(parentRef, this.pageData, groupData, value, item, this.form)
            }
        },
        // select 改变事件
        changeSelectValue (realValue, opt, oldVal, configData) {
            let parentRef = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let parentRefName = this.pageData.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageData.groups[this.currentStep]
            }
            if (configData && configData.bindFunction && typeof configData.bindFunction==='function') {
                configData.bindFunction(parentRef, this.pageData, groupData, realValue, opt, oldVal, this.form)
            }
        },
        // 通过value显示label
        getDictLabel (value, column) {
            if (typeof value === 'string' || typeof value === 'number') {
                let valString = value + '' 
                if (column._own && column._own.dictOptions && column._own.dictOptions.length) {
                    let dictItem = column._own.dictOptions.filter((opt)=> {
                        return opt.value === valString
                    })
                    return dictItem.length? dictItem[0].label: valString
                } else {
                    return valString
                }
            } else {
                return value
            }
        },
        // 检查表格是否有被选中, cb返回promise,true打开上传，false不打开上传，如果没有cb,直接打开上传
        /**
         * cb(selectData) {
         *     return new Promise((resolve, reject)=> {
         *     // 自定义验证的规则
         *     let flag = true
         *     if (flag) {
         *          resolve(true)
         *      } else {
         *          resolve(false)
         *      }
         *     })
         * }
         */
        checkedGridSelect (btn, refName, cb) {
            let selectData = null
            if (this.$refs[refName]) {
                if (this.$refs[refName][0]) {
                    selectData = this.$refs[refName][0].getCheckboxRecords() || this.$refs[refName][0].getRadioRecord()
                }
            }
            if (selectData && selectData.length) {
                if (cb && typeof cb === 'function') {
                    cb(selectData).then(res=> {
                        if (res) {
                            btn.modalVisible = true
                            // this.$refs[refName+'_upload'][0].$el.click()
                        }
                    })
                } else {
                    this.modalVisible = true
                    // this.$refs[refName+'_upload'][0].$el.click()
                }
                
            } else {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterChoose`, '请先选择'))
            }
        },
        // 手动更新表单,暴露给外部使用，newFields传对象{key: value}
        manualUpdate (newFields) {
            this.form = Object.assign({}, this.form, filterObj(newFields))
        }
    },
    created () {
        const clientHeight = document.documentElement.clientHeight
        this.minHeight = clientHeight - 260
    }
}
</script>

<style lang="less" scoped>
.subEditPage {
    .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: -3px -3px 0 -3px;
        padding: 6px 40px;
        background: #fff;
        .btnGroups {
            text-align: right;
            .ant-btn {
                & +.ant-btn {
                    margin-left: 10px;
                }
            }
        }
    }
    .content {
        margin: 8px 5px;
        padding: 15px;
        background: #fff;
        flex: 1;
    }
    // .table {
    //     min-height: 400px;
    // }
    .tools-btn {
        margin-left: 10px;
    }

    /deep/ .ant-badge-dot {
        width: 10px;
        height: 10px;
    }
}
</style>
