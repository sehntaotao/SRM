<template>
  <div class="edit-page">
    <a-spin :spinning="confirmLoading">
      <div class="page-header">
        <a-steps
          :current="currentStep"
          size="small">
          <a-step
            v-for="group in pageData.groups"
            :key="group.groupCode"
            :title="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)" />
        </a-steps>
      </div>
      <div class="page-content">
        <div
          v-for="(group, index) in pageData.groups"
          :key="group.groupCode"
          v-show="currentStep === index"
          :class="group.type == 'grid' ? 'edit-grid-box' : 'edit-form-box'">
          <div v-if="!group.type">
            <span
              v-for="(btn, info) in group.custom.buttons"
              :key="info"
              style="margin-right: 10px">
              <a-button
                v-if="btn.type !== 'upload' && btn.type !== 'import' && btn.type !== 'select'"
                :type="btn.type"
                :disabled="btn.disabled && btn.disabled(btn) || false"
                @click="btn.click">
                {{ btn.title }}
              </a-button>
              <custom-upload
                v-if="btn.type == 'upload'"
                :single="btn.single"
                :disabledItemNumber="btn.disabledItemNumber"
                :requiredFileType="btn.requiredFileType"
                :property="btn.property"
                :visible.sync="btn.modalVisible"
                :dictCodeType="btn.dictCodeType"
                :title="btn.title"
                :itemInfo="itemInfo"
                :action="url.upload"
                :accept="accept"
                :headers="tokenHeader"
                :data="{businessType: btn.businessType, headId: form.id}"
                @change="(info) => handleUploadChange(info, btn, group.custom.ref)"
              >
                <a-button
                  v-if="btn.beforeChecked"
                  :disabled="btn.disabled && btn.disabled(btn) || false"
                  type="primary"
                  icon="cloud-upload"
                  @click="checkedGridSelect(btn, group.custom.ref, btn.beforeCheckedCallBack)">{{ btn.title }}</a-button>
              </custom-upload>
            </span>
          </div>
          <a-form-model 
            v-if="!group.type"
            :ref="group.groupCode" 
            :model="form" 
            :rules="group.custom.validateRules"
            class="ant-advanced-rule-form"
            layout="inline"
            v-bind="layout">
            <a-row :getterr="12">
              <a-col
                v-for="(item, index2) in group.custom.formFields"
                :key="'col_' + group.groupCode + '_' + index2"
                :span="8">
                <a-form-model-item
                  v-if="item.fieldType === 'input' || item.fieldType === 'password' || item.fieldType === 'textArea'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <a-input
                    class="clickinput"
                    v-if="item.click"
                    :readOnly="item.readOnly"
                    :disabled="item.disabled"
                    :type="item.fieldType === 'input'?'text': item.fieldType === 'password'?'password':'textarea'"
                    @click="clickInputValue(form[item.fieldName], item)"
                    v-model="form[item.fieldName]"
                  />
                  <a-input
                    v-else
                    :readOnly="item.readOnly"
                    :disabled="item.disabled"
                    :type="item.fieldType === 'input'?'text': item.fieldType === 'password'?'password':'textarea'"
                    @change="changeInputValue(form[item.fieldName], item)"
                    v-model="form[item.fieldName]"
                    :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                  />
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType == 'select'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-select
                    :disabled="item.disabled"
                    :configData="item"
                    :getPopupContainer="triggerNode => {
                      return triggerNode.parentNode || document.body;
                    }"
                    @change="changeSelectValue"
                    v-model="form[item.fieldName]"
                    returnTitle
                    :current-edit-row="currentEditRow"
                    :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                    :dict-code="item.dictCode" />
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType == 'multiple'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-select
                    :disabled="item.disabled"
                    mode="multiple"
                    :configData="item"
                    :maxTagCount="item.extend && item.extend.maxTagCount || 1"
                    v-model="form[item.fieldName]"
                    :current-edit-row="currentEditRow"
                    :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                    :dict-code="item.dictCode"
                    @change="changeSelectValue"
                  />
                </a-form-model-item>
                <a-form-model-item
                  v-if="item.fieldType == 'cascader'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-cascader
                    change-on-select
                    v-model="form[item.fieldName]"
                    :mode="item.dictCode"
                    :disabled="item.disabled"
                    :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                  />
                </a-form-model-item>
                <a-form-model-item
                  v-if="item.fieldType == 'number'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <a-input-number
                    style="width:100%"
                    :disabled="item.disabled"
                    @change="changeInputValue(form[item.fieldName], item)"
                    v-model="form[item.fieldName]"
                    :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`"
                  />
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType == 'date'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <div v-if="item.dataFormat=='YYYY-MM'">
                    <a-month-picker
                      style="width:100%"
                      :disabled="item.disabled"
                      @change="changeInputValue(form[item.fieldName], item)"
                      :valueFormat="item.dataFormat"
                      v-model="form[item.fieldName]"
                      :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseInput`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`" />
                  </div>
                  <div v-else>
                    <a-date-picker
                      style="width:100%"
                      :disabled="item.disabled"
                      @change="changeInputValue(form[item.fieldName], item)"
                      :show-time="item.dataFormat && item.dataFormat.length > 10 ? true : false"
                      :valueFormat="(item.dataFormat || 'YYYY-MM-DD')"
                      v-model="form[item.fieldName]"
                      :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseInput`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)}`" />
                  </div>
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType == 'switch'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-switch
                    :disabled="item.disabled"
                    :configData="item"
                    @change="changeSelectValue"
                    v-model="form[item.fieldName]" />
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType == 'treeSelect'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-tree-select 
                    v-model="form[item.fieldName]"
                    allowClear
                    :disabled="item.disabled"
                    :multiple="item.extend && item.extend.multiple || false"
                    :maxTagCount="item.extend && item.extend.maxTagCount || 1"
                    :sourceUrl="item.dictCode"
                    :sourceMap="item.sourceMap"
                    :showEmptyNode="item.showEmptyNode"
                    :parentNodeSelectable="item.extend && (item.extend.parentNodeSelectable || true)"                    
                    :placeholder="item.placeholder" />
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType=='selectModal'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-select-modal
                    v-model="form[item.fieldName]"
                    :config="item"
                    :pageData="pageData"
                    :form="form"
                    :currentStep="currentStep"
                    @afterClearCallBack="handleSelectModalAfterClear"
                    @ok="(rows) => handleSelectModalAfterSelect(item, rows)"
                  />
                  <!-- <a-input
                    readOnly
                    :disabled="item.disabled"
                    v-model="form[item.fieldName]"
                    :placeholder="item.placeholder"
                    @click="() => openSelectModal(item)">
                    <a-icon
                      slot="suffix"
                      type="close-circle"
                      @click="() => clearInputValue(item)"></a-icon>
                  </a-input> -->
                </a-form-model-item>
                <a-form-model-item v-else-if="item.fieldType === 'ladderPrice'">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <ladder-price
                    v-model="form[item.fieldName]"
                    :config="item"
                    :pageData="pageData"
                    :form="form"
                    @afterClearCallBack="handleLadderPriceAfterClear"
                    @ok="(rows) => handleLadderPriceAfterSelect(item, rows)"
                  ></ladder-price>
                </a-form-model-item>
                <!-- 新增准入方式弹窗 -->
                <a-form-model-item
                  v-else-if="item.fieldType === 'accessMethod'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <access-method
                    v-model="form[item.fieldName]"
                    :config="item"
                    :pageData="pageData"
                    :form="form"
                    @afterClearCallBack="handleAccessMethodAfterClear"
                    @ok="(rows) => handleAccessMethodAfterSelect(item, rows)"
                  ></access-method>
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType === 'richEditorModel'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <rich-editor-model
                    :value="form[item.fieldName]"
                    :disabled="item.disabled"
                    @handleSureClick="(content)=> {form[item.fieldName] = content}"></rich-editor-model>
                </a-form-model-item>
                <a-form-model-item
                  v-else-if="item.fieldType === 'image'"
                  :prop="item.fieldName">
                  <span slot="label">
                    <a-tooltip
                      :title="$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel)">
                      {{ $srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, item.fieldLabel) }}
                    </a-tooltip>
                    <a-tooltip
                      v-if="item.helpText"
                      :title="item.helpText">
                      <a-icon type="question-circle-o" />
                    </a-tooltip>
                  </span>
                  <m-upload
                    :disabled="item.disabled"
                    :value.sync="form[item.fieldName]"
                    :accept="accept2"
                    :headers="tokenHeader"
                    :data="{ businessType: item.dictCode, headId: form.id}"
                  > 
                  </m-upload>
                </a-form-model-item>
              </a-col>
            </a-row>
          </a-form-model>
          <vxe-grid
            v-else-if="group.type == 'grid'"
            :ref="group.custom.ref"
            v-bind="gridConfig"
            :edit-config="group.custom.editConfig || gridCustomEditConfig"
            :edit-rules="group.custom.rules"
            :columns="group.custom.columns"
            @cell-dblclick="dblclickHander"
          >
            <!-- 2021-10-09 新增一个插槽，通过options数组来渲染a标签，相比原来的grid_opration，不需要额外配置optColumnList，且只能限制使用1个 -->
            <template #showBtn="{ row, column }">
              <!-- 判断字段中的指定字段是否等于指定值，相等才显示 -->
              <template v-if="column._own.isShow.default || row[column._own.isShow.key] === column._own.isShow.value">
                <template v-for="(item, i) in column._own.options">
                  <!-- 上传 -->
                  <a-upload
                    v-if="item.type==='upload'"
                    :key="'opt_' + row.id + '_' + i"
                    :show-upload-list="false"
                    :multiple="false"
                    :headers="tokenHeader"
                    :data="{businessType: item.params.businessType, headId: row.headId || item.params.headId, uploadElsAccount: item.params.businessType}"
                    :action="item.url"
                    @change="(info) => item.clickFn(info, row, column)"
                  >
                    <span
                      v-if="item.isConfirm"
                      :ref="'upload' + row._XID"
                      style="margin:0 4px;color: #1890ff;cursor:pointer;"
                      @click="item.confirm($event, row, column, 'upload' + row._XID)">{{ item.title }}</span>
                    <span
                      v-else
                      style="margin:0 4px;color: #1890ff;cursor:pointer;">{{ item.title }}</span>
                  </a-upload>
                  <!-- 弹出窗 -->
                  <div
                    v-else-if="item.type==='selectModal'"
                    :key="'opt_' + row.id + '_' + i"
                    style="position: relative;min-height: 30px;padding-right: 20px;">
                    {{ row[item.field] }}
                    <a style="position: absolute;display: inline-block;font-size: 16px;right: 0px; top: 3px;z-index: 10; background: #fff;">
                      <a-icon
                        type="file-search"
                        @click="item.clickFn(row, column)" />
                    </a>
                  </div>
                  <!-- a标签 -->
                  <a
                    v-else-if="row[item.disable.key]"
                    :key="'opt_' + row.id + '_' + i"
                    :title="item.title"
                    style="margin:0 4px"
                    @click="item.clickFn(row, column)"
                  >
                    {{ item.title }}
                  </a>
                  <span
                    v-else
                    :key="'opt_' + row.id + '_' + i"
                    style="margin:0 4px"
                  >
                    {{ item.title }}
                  </span>
                </template>
              </template>
            </template>
            <!-- 表格代码编辑器 -->
            <template #code_editor_col_render="{row,column}">
              <code-editor-model
                :value="row[column.property]"
                @handleSureClick="(content)=> {row[column.property] = content}"></code-editor-model>
            </template>
            <!-- 表格富文本编辑器 -->
            <template #rich_editor_col_render="{row,column}">
              <rich-editor-model
                :value="row[column.property]"
                @handleSureClick="(content)=> {row[column.property] = content}"></rich-editor-model>
            </template>
            <template #renderDictLabel="{ row, column }">
              <span>
                {{ getDictLabel(row[column.property], column) }}
              </span>
            </template>
            <template #toolbar_buttons>
              <span 
                v-for="(btn, index3) in group.custom.buttons" 
                class="tools-btn"
                :key="'btn_' + index3">
                <a-button
                  v-if="btn.type !== 'upload' && btn.type !== 'import' && btn.type !== 'select'"
                  :type="btn.type"
                  :disabled="btn.disabled && btn.disabled(btn) || false"
                  @click="btn.click">
                  {{ btn.title }}
                </a-button>
                <a-upload
                  v-else-if="btn.type === 'import'"
                  :show-upload-list="false"
                  :multiple="false"
                  :headers="tokenHeader"
                  :data="btn.params"
                  :action="url.import"
                  @change="(info) => handleUploadChange(info, btn, group.custom.ref)"
                >
                  <a-button
                    @click="btn.beforeImport && btn.beforeImport($event)"
                    :disabled="btn.disabled && btn.disabled(btn) || false"
                    type="primary">{{ btn.title }}</a-button>
                </a-upload>
                <a-select
                  v-else-if="btn.type === 'select'"
                  :default-value="btn.defaultValue || ''"
                  :style="btn.style ? btn.style : 'width: 120px'"
                  @change="btn.change">
                  <a-select-option
                    :value="bt.value"
                    v-for="(bt, idx) of btn.options"
                    :key="idx">
                    {{ bt.name }}
                  </a-select-option>
                </a-select>
                <custom-upload
                  v-else
                  :single="btn.single"
                  :disabledItemNumber="btn.disabledItemNumber"
                  :disabledHead="btn.disabledHead"
                  :attrCheck="btn.attrCheck"
                  :requiredFileType="btn.requiredFileType"
                  :dictCodeType="btn.dictCodeType"
                  :property="btn.property"
                  :visible.sync="btn.modalVisible"
                  :title="btn.title"
                  :itemInfo="itemInfo"
                  :action="url.upload"
                  :accept="accept"
                  :headers="tokenHeader"
                  :data="{businessType: btn.businessType, headId: form.id, hasFileType: btn.hasFileType}"
                  @change="(info) => handleUploadChange(info, btn, group.custom.ref)"
                >
                  <a-button
                    v-if="btn.beforeChecked"
                    :disabled="btn.disabled && btn.disabled(btn) || false"
                    type="primary"
                    icon="cloud-upload"
                    @click="checkedGridSelect(btn, group.custom.ref, btn.beforeCheckedCallBack)">{{ btn.title }}</a-button>
                </custom-upload>
              </span>
            </template>
            <!-- 10.29新增行上传文件 -->
            <template #grid_opration="{ row, column }">
              <span
                style="margin:0 4px"
                v-for="(item, i) in group.custom.optColumnList"
                :key="'opt_'+ row.id + '_' + i">
                <!-- 表格行上传-无文件类型选择 -->
                <a-upload
                  v-if="item.type === 'rowImport'"
                  :show-upload-list="false"
                  :multiple="false"
                  :headers="tokenHeader"
                  :data="typeof item.params === 'function' ? item.params(row) : item.params"
                  :accept="accept || item.accept"
                  :action="item.action || url.rowImport || url.upload"
                  v-show="item.showCondition ? item.showCondition(row) : true"
                  @change="(info) => handleUploadChange(info, item, group.custom.ref, row)"
                >
                  <a
                    style="font-size:12px"
                    :title="item.title"
                    :disabled="item.allow ? item.allow(row) : false"
                    @click="item.clickFn && item.clickFn(row, column)"
                  >{{ item.title }}</a>
                </a-upload>

                <a
                  v-else
                  :title="item.title"
                  :disabled="item.allow ? item.allow(row) : false"
                  v-show="item.showCondition ? item.showCondition(row) : true"
                  @click="item.clickFn(row, column )">{{ item.title }}</a>
              </span>
            </template>
          </vxe-grid>
        </div>
      </div>
      <div class="page-footer">
        <a-button
          :type="customPageFooterPreBtn.type"
          v-if="currentStep"
          @click="customPageFooterPreBtn.click">{{ customPageFooterPreBtn.title }}</a-button>
        <a-button
          :type="customPageFooterNextBtn.type"
          v-if="currentStep<(pageData.groups.length-1)"
          @click="customPageFooterNextBtn.click">{{ customPageFooterNextBtn.title }}</a-button>
        <a-button
          v-for="(btn,index) in pageData.publicBtn"
          :key="'pub_btn_' + index"
          :type="btn.type"
          v-show="btn.showCondition ? btn.showCondition() : true"
          @click="btn.click">{{ btn.title }}</a-button>
      </div>
    </a-spin>

  </div>
</template>

<script>
import {ajaxFindDictItems} from '@/api/api'
import { getAction, postAction } from '@/api/manage'
import { filterObj } from '@/utils/util.js'
import { EditConfig } from '@/plugins/table/gridConfig'
import MUpload from '@comp/mUpload'
import MTreeSelect from '@comp/treeSelect/mTreeSelect'
import { USER_ELS_ACCOUNT } from '@/store/mutation-types'
import CustomUpload from '@comp/template/CustomUpload'
import LadderPrice from '@comp/LadderPrice'
import AccessMethod from '@comp/AccessMethod'
import RichEditorModel from '@comp/richEditorModel/RichEditorModel'
import { PURCHASEATTACHMENTDOWNLOADAPI } from '@/utils/const'
export default {
    name: 'EditLayout',
    props: {
        pageData: {
            type: Object,
            default: () => {
                return {
                    groups: [{
                        custom: {
                            form: {},
                            formFields: [],
                            validateRules: {}
                        },
                        extend: null,
                        groupCode: null,
                        groupName: null,
                        sortOrder: null
                    }]
                }
            }
        },
        url: {
            type: Object,
            default: () => {}
        },
        refresh: {
            type: Boolean,
            default: false
        },
        currentEditRow: {
            type: Object,
            default: ()=> {
                return {}
            }
        },
        acceptParent: {
           type: String,
           default: ()=>{
              return ''
           }
        }
    },
    components: {
        MTreeSelect,
        CustomUpload,
        MUpload,
        RichEditorModel,
        LadderPrice,
        AccessMethod
    },
    data () {
        return {
            needEcho: null,
            mustMaterialNumber: null,
            setStartPrice: null,
            ebiddingWay: null,
            delayRule: null,
            currentStep: 0,
            confirmLoading: false,
            layout: {
                labelCol: { span: 9 },
                wrapperCol: { span: 15 }
            },
            voucherId: '',
            form: this.pageData.form || {},
            //附件上传配置
            tokenHeader: {'X-Access-Token': this.$ls.get('Access-Token')},
            accept: '.doc, .docx, .xls, .xlsx, .ppt, .png, .jpg, .jpeg, .gif, .pptx, .pdf, .txt',
            accept2: '.png, .jpg, .jpeg, .gif',
            //默认表格配置
            gridConfig: EditConfig,
            currentSelectModal: null,
            currentObject: null,
            gridCustomEditConfig: {
                trigger: 'dblclick',
                mode: 'cell',
                showStatus: true
            },
            customPageFooterPreBtn: {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_prevStep`, '上一步'),  type: 'primary', belong: 'preStep', click: this.prevStep },
            customPageFooterNextBtn: { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_nextStep`, '下一步'), type: 'primary', belong: 'nextStep', click: this.nextStep }
        }
    },
    computed: {
        busAccount () {
            let account = this.$ls.get(USER_ELS_ACCOUNT)
            if (this.currentEditRow && this.currentEditRow.busAccount) {
                account = this.currentEditRow.busAccount || this.currentEditRow.elsAccount || this.$el.get(USER_ELS_ACCOUNT)
            }
            return account
        },
        groups () {
            return this.pageData.groups
        },
        itemColumns () {
            const groups = this.pageData.groups || []
            let itemInfo = groups.filter(item => item.groupCode == 'itemInfo')
            if (itemInfo.length) {
                return itemInfo[0].custom.columns
            }
            return []
        },
        itemInfo () {
            let itemInfo = []
            const groups = this.pageData.groups || []
            const group = groups.find(n => n.groupCode === 'itemInfo')
            if (group) {
                const refName = group.custom.ref
                itemInfo = this.$refs[refName][0].getTableData().fullData || []
            }
            return itemInfo
        },
        getLangAccount () {
            return this.$getLangAccount(this.busAccount)
        }
        
    },
    watch: {
        groups () {
            this.initFormDefaultValue()
        },
        itemColumns () {
            this.queryDictData()
        },
        acceptParent: {
          handler: function (value) {
              if(value) {
                  this.accept = value
              }
          },
          immediate: true
        }
    },
    mounted () {
        // form表单默认字段
        if (this.currentEditRow && this.currentEditRow.templateNumber) {
            this.form['templateNumber']=this.currentEditRow.templateNumber
            this.form['templateName']=this.currentEditRow.templateName
            this.form['templateVersion']=this.currentEditRow.templateVersion
        }
        this.$store.dispatch('modifyBusAccountLangData', { busAccount: this.busAccount})
    },
    methods: {
        handleSelectModalAfterClear (cb) {
          // 2021-10-25,入参增加this，使用this才能调用实例的方法
            cb && cb(this.form, this.pageData, this)
        },
        handleLadderPriceAfterClear (cb) {
            cb && cb(this.form, this.pageData)
        },
        handleAccessMethodAfterClear (cb) {
            cb && cb(this.form, this.pageData)
        },
        handleSelectModalAfterSelect (item, rows) {
            item.bindFunction && item.bindFunction.call(null, this, rows)
        },
        handleLadderPriceAfterSelect (item, rows) {
            item.bindFunction && item.bindFunction.call(null, this, rows) 
        },
        handleAccessMethodAfterSelect (item, rows) {
            item.bindFunction && item.bindFunction.call(null, this, rows) 
        },
        handleDownload ({ id, fileName }, url = '') {
            const params = {
                id
            }
            let downloadUrl = url || PURCHASEATTACHMENTDOWNLOADAPI
            if(this.url.download){
                downloadUrl = this.url.download
            }
            getAction(downloadUrl, params, {
                responseType: 'blob'
            }).then(res => {
                console.log(res)
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        // 初始化默认值
        initFormDefaultValue () {
            const that = this
            this.pageData.groups.forEach(item => {
                if(!item.type) {
                    let fields = item.custom.formFields
                    fields.forEach(item2 => {
                        if(item2.defaultValue) {
                            that.$set(that.form, item2.fieldName, item2.defaultValue)
                        }
                    })
                }
            })
        },
        // 获取表格下拉字典
        queryDictData () {
            let that = this
            this.pageData.groups.forEach(item => {
                if(item.type == 'grid') {
                    item.custom.columns.forEach(item2 => {
                        if(item2.dictCode) {
                          let postData = {
                              busAccount: that.busAccount || that.$ls.get(USER_ELS_ACCOUNT),
                              dictCode: item2.dictCode
                          }
                          ajaxFindDictItems(postData).then(res => {
                              if(res.success) {
                                  let options = res.result.map(item3 => {
                                      return {
                                          value: item3.value,
                                          label: item3.text,
                                          title: item3.title
                                      }
                                  })
                                  if (item2.editRender) {
                                      item2.editRender.options = options
                                  }
                                  item2.dictOptions= options
                                  that.$forceUpdate()
                              }
                          })
                        }
                        
                        // else if(item2.dictCode && !item2.editRender) {
                        //     item2.field = item2.field + '_dictText'
                        // }
                    })
                }
            })
        },
        prevStep () {
            this.currentStep > 0 && this.currentStep--
            this.preOrNextStepHandle('pre')
        },
        nextStep () {
            if(this.currentStep < this.pageData.groups.length - 1) {
                this.currentStep++
            }
            this.preOrNextStepHandle('next')
        },
        // 上一步和下一步的处理逻辑外部使用
        preOrNextStepHandle (type) {
            let formCompnent = null
            let gridCompnent = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let formRefName = this.pageData.groups[this.currentStep].groupCode
                let gridRefName = this.pageData.groups[this.currentStep].custom?this.pageData.groups[this.currentStep].custom.ref: ''
                formCompnent = formRefName? this.$refs[formRefName] : ''
                gridCompnent = gridRefName? this.$refs[gridRefName][0] : ''
                groupData = this.pageData.groups[this.currentStep]
            }
            let emitData ={ formCompnent: formCompnent, gridCompnent: gridCompnent, pageData: this.pageData, groupData: groupData, form: this.form}
            if (type === 'next') {
                this.$emit('nextStepHandle', emitData)
            } else {
                this.$emit('preStepHandle', emitData)
            }
        },
        goBack () {
            this.$parent.goBack()
        },
        setFormPropDefaultData () {
            const { formFields = [] }  = this.pageData || {}
            formFields.forEach(({ fieldName, defaultValue }) => {
                this.form[fieldName] = defaultValue || ''
            })
        },
        queryDetail (id, cb) {
            if (!this.voucherId) this.voucherId = id
            this.confirmLoading = true
            getAction(this.url.detail, {id: id || this.voucherId}).then(res => {
                if (!res.success) {
                    this.$message.error(res.message)
                    return
                }
                this.setFormPropDefaultData()
                this.form = Object.assign({}, this.form, filterObj(res.result))
                this.pageData.groups.forEach(group => {
                    if (group.type && group.type === 'grid') {
                        const ref = group.custom.ref
                        this.$refs[ref][0].loadData(res.result[ref])
                    }
                })
                this.pageData.groups.forEach(group => {
                    if (!group.type || !group.type === 'grid') {
                        this.$nextTick(() => {
                            const formFields = group.custom.formFields || []
                            formFields.forEach(item => {
                                const { bindFunction, fieldName, fieldType, groupCode, defaultValue } = item
    
                                if (bindFunction && typeof bindFunction === 'function') {
                                    const parentRef = this.$refs[groupCode]
                                    const groupData = this.pageData.groups[this.currentStep]
                                    const value = this.form[fieldName] || defaultValue
                                    if (fieldType !== 'selectModal') {
                                        if (fieldType === 'input') {
                                            bindFunction.call(null, parentRef, this.pageData, groupData, value, item, this.form )
                                        } else {
                                            bindFunction.call(null, parentRef, this.pageData, groupData, value, [], '', this.form)
                                        }
                                    }
                                }
                            })
                        })

                    }
                })

                cb && cb(res.result)
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        getPageData () {
            const that = this
            let params = {...this.form}
            // 没有模板时，赋值默认参数
            if (!this.voucherId) {
                params = Object.assign(params, this.currentEditRow)
            }
            this.pageData.groups.forEach(group => {
                if(group.type == 'grid') {
                    let ref = group.custom.ref
                    params[ref] = that.$refs[ref][0].getTableData().fullData
                }
            })
            return params
        },
        setPromise () {
            let that = this
            let promise = this.pageData.groups.map(group => {
                if(group.type == 'grid') {
                    return that.$refs[group.custom.ref][0].validate(true)
                }else {
                    return that.$refs[group.groupCode][0].validate()
                }
            })
            return promise
        },
        resetFields() {
             let that = this
             this.pageData.groups.forEach(group => {
                if (group.type != 'grid') {
                  return that.$refs[group.groupCode][0].resetFields()
                }
             })
        },
        handValidate (url, params, callback){
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) return callback && callback(url, params, this)
            }).catch(err => {
                console.log(err)
            })
        },
        handleSend (type = 'public', callback) {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) this.postData(type, callback)
            }).catch(err => {
                console.error(err)
            })
        },
        postData (type, callback) {
            let params = this.getPageData()
            let url = type === 'public'
                ? this.url.public
                : this.voucherId
                    ? this.url.edit
                    : this.url.add
            this.confirmLoading = true
            postAction(url, params).then(res => {
                if (res.success) {
                    const msgType = res.success ? 'success' : 'error'
                    this.$message[msgType](res.message)
                    if (res.result && res.result.id) {
                        this.voucherId = res.result.id
                    }
                    if (res.success && this.refresh) {
                        this.queryDetail()
                    }
                    if (res.success && type === 'public') {
                        this.$parent.goBack()
                    } else {
                    // 自定义回调
                        return callback && callback(params, this)
                    }
                } else {
                    const msgType = res.success ? 'success' : 'error'
                    this.$message[msgType](res.message)
                }
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        //附件上传
        handleUploadChange (info, btn, refName, row) {
            btn.callBack && btn.callBack(info, refName, row)
        },
        // input 改变事件,value-当前值
        changeInputValue (value, item) {
            let parentRef = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let parentRefName = this.pageData.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageData.groups[this.currentStep]
            }
            // let test = value?true: false
            // groupData.custom.validateRules= Object.assign({}, groupData.custom.validateRules, {enquiryType: {required: test, message: '123455'}})
            if (item && item.bindFunction &&  typeof item.bindFunction === 'function') {
                item.bindFunction(parentRef, this.pageData, groupData, value, item, this.form)
            }
        },
        clickInputValue (value, item) {
            let parentRef = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let parentRefName = this.pageData.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageData.groups[this.currentStep]
            }
            if (item && item.bindClickFunction &&  typeof item.bindClickFunction === 'function') {
                item.bindClickFunction(parentRef, this.pageData, groupData, value, item, this.form)
            }
        },
        // select 改变事件
        changeSelectValue (realValue, opt, oldVal, configData) {
            let parentRef = null
            let groupData = null
            if (this.pageData.groups[this.currentStep]) {
                let parentRefName = this.pageData.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageData.groups[this.currentStep]
            }
            if (configData && configData.bindFunction && typeof configData.bindFunction==='function') {
                configData.bindFunction(parentRef, this.pageData, groupData, realValue, opt, oldVal, this.form)
            }
        },
        // 通过value显示label
        getDictLabel (value, column) {
            if (typeof value === 'string' || typeof value === 'number') {
                let valString = value + '' 
                if (column._own && column._own.dictOptions && column._own.dictOptions.length) {
                    let dictItem = column._own.dictOptions.filter((opt)=> {
                        return opt.value === valString
                    })
                    return dictItem.length? dictItem[0].label: valString
                } else {
                    return valString
                }
            } else {
                return value
            }
        },
        // 检查表格是否有被选中, cb返回promise,true打开上传，false不打开上传，如果没有cb,直接打开上传
        /**
         * cb(selectData) {
         *     return new Promise((resolve, reject)=> {
         *     // 自定义验证的规则
         *     let flag = true
         *     if (flag) {
         *          resolve(true)
         *      } else {
         *          resolve(false)
         *      }
         *     })
         * }
         */
        checkedGridSelect (btn, refName, cb) {
            // if (!this.voucherId) {
            //     this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSaveDocumentFirst`, '请先保存单据！'))
            //     return
            // }
            let selectData = null
            if (this.$refs[refName]) {
                if (this.$refs[refName][0]) {
                    selectData = this.$refs[refName][0].getCheckboxRecords() || this.$refs[refName][0].getRadioRecord()
                }
            }
            if (selectData && selectData.length) {
                if (cb && typeof cb === 'function') {
                    cb(selectData).then(res=> {
                        if (res) {
                            btn.modalVisible = true
                            // this.$refs[refName+'_upload'][0].$el.click()
                        }
                    })
                } else {
                    this.modalVisible = true
                    // this.$refs[refName+'_upload'][0].$el.click()
                }
                
            } else {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterChoose`, '请先选择'))
            }
        },
        /***
         * 2021-10-20新增，双击事件，如果配置中有clickFn，就触发该事件
         * 
         */
        dblclickHander (table) {
          table.column._own.clickFn && table.column._own.clickFn(table)
        }
    }
}
</script>