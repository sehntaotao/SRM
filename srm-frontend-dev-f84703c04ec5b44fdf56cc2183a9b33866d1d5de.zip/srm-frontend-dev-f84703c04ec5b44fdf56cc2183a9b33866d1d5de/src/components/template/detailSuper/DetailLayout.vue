<template>
  <div class="detailPage">
    <a-spin :spinning="confirmLoading">
      <div class="container">
        <div class="top">
          <div class="breadcrumb">
            <!-- <breadcrumb></breadcrumb> -->
          </div>
          <div class="btnGroups">
            <a-button
              v-for="(btn,index) in pageData.publicBtn"
              :key="'pub_btn_' + index"
              :type="btn.type"
              v-show="btn.showCondition ? btn.showCondition() : true"
              @click="btn.click"
              :disabled="btn.disabled ? btn.disabled() : false"
            >
              {{ btn.title }}
            </a-button>
          </div>
        </div>
        <div class="content">
          <div class="tabs">
            <a-tabs v-model="activeKey">
              <a-tab-pane 
                v-for="tab in pageData.groups" 
                :key="tab.groupCode" 
                forceRender
                :tab="tab.groupName">
                <div
                  v-if="tab.type && tab.type === 'grid'"
                  class="table"
                  :style="{ minHeight: `${minHeight}px` }">
                  <vxe-grid
                    :ref="tab.custom.ref"
                    :rowStyle="rowStyle"
                    v-bind="defaultGridOption"
                    header-align="center"
                    :columns="tab.custom.columns"
                    :tree-config="treeConfig"
                    @checkbox-change="toggleCheckedSelect"
                    @checkbox-all="toggleAllCheckedSelect">
                    <template #toolbar_buttons>
                      <!-- <a-button
                        v-for="(btn, index3) in tab.custom.buttons"
                        :key="'btn_' + index3"
                        :type="btn.type"
                        v-show="btn.showCondition ? btn.showCondition() : true"
                        @click="btn.click">
                        {{ btn.title }}
                      </a-button> -->
                      <span 
                        v-for="(btn, index3) in tab.custom.buttons" 
                        class="tools-btn"
                        :key="'btn_' + index3"> 
                        <custom-upload
                          v-if="btn.type == 'upload'"
                          :single="btn.single"
                          :disabledItemNumber="btn.disabledItemNumber"
                          :requiredFileType="btn.requiredFileType"
                          :property="btn.property"
                          :visible.sync="btn.modalVisible"
                          :title="btn.title"
                          :itemInfo="itemInfo"
                          :action="url.upload"
                          :accept="accept"
                          :headers="tokenHeader"
                          :data="{businessType: btn.businessType, headId: form.id}"
                          @change="(info) => handleUploadChange(info, btn, tab.custom.ref)"
                        >
                          <a-button
                            v-if="btn.beforeChecked"
                            type="primary"
                            icon="cloud-upload"
                            @click="checkedGridSelect(btn, tab.custom.ref, btn.beforeCheckedCallBack)">{{ btn.title }}</a-button>
                        </custom-upload>
                        <a-button
                          v-else
                          :type="btn.type"
                          v-show="btn.showCondition ? btn.showCondition() : true"
                          @click="btn.click || ''">
                          {{ btn.title }}
                        </a-button> 
                      </span>
                    </template>
                    <template #grid_opration="{ row, column }">
                      <a
                        v-for="(item, i) in tab.custom.optColumnList"
                        :key="'opt_'+ row.id + '_' + i"
                        :title="item.title"
                        style="margin:0 4px"
                        :disabled="item.allow ? item.allow(row) : false"
                        v-show="item.showCondition ? item.showCondition(row) : true"
                        @click="item.clickFn(row, column)">{{ item.title }}</a>
                    </template>
                  </vxe-grid>
                </div>
                <div
                  v-else
                  bordered
                  class="description"
                  :style="{ minHeight: `${minHeight}px` }">
                  <template v-if="tab.custom.formFields && tab.custom.formFields.length">
                    <a-descriptions
                      bordered
                      size="small">
                      <a-descriptions-item
                        v-for="field in tab.custom.formFields"
                        :key="field.fieldName"> 
                        <span slot="label">
                          {{ field.fieldLabel }}
                          <a-tooltip
                            v-if="field.helpText"
                            :title="field.helpText">
                            <a-icon type="question-circle-o" />
                          </a-tooltip>
                        </span>
                        <template>
                          <span v-if="!tab.custom.parentObj">
                            <span v-if="field.fieldType == 'switch'">
                              {{ ['1', 'Y'].includes(form[field.fieldName]) ? '是' : '否' }}
                            </span>
                            <a
                              :href="form[field.fieldName]"
                              target="_blank"
                              v-else-if="field.fieldType == 'link'">
                              <span>认证链接</span>
                            </a>

                            <!-- <a-input 
                              v-else-if="field.change == 'input'" 
                              v-model="changeInput"
                              :disabled="currentEditRow && !currentEditRow.fbk5"
                              @change="changeInputValue"
                            />    -->
                            <a-input 
                              v-else-if="field.change == 'input'" 
                              v-model="changeInput"
                              :disabled="btnDisable()"
                              placeholder="最多输入两位小数"
                              oninput="value=value.match(/^\d+(?:\.\d{0,2})?/)"
                              @change="changeInputValue"
                            />   
                                        
                            <span v-else>
                              {{ field.fieldType == 'select' || field.fieldType == 'multiple' ? form[field.fieldName + '_dictText'] : form[field.fieldName] }}
                            </span>
                          </span>
                          <span v-else-if="tab.custom.parentObj && form[tab.custom.parentObj]">
                            <span v-if="field.fieldType == 'switch'">
                              {{ ['1', 'Y'].includes(form[panel.custom.parentObj][field.fieldName]) ? '是' : '否' }}
                            </span>
                            <a
                              :href="form[field.fieldName]"
                              target="_blank"
                              v-else-if="field.fieldType == 'link'">
                              <span>认证链接</span>
                            </a>
                            <span v-else>
                              {{ field.fieldType == 'select' || field.fieldType == 'multiple' ? form[panel.custom.parentObj][field.fieldName + '_dictText'] : form[panel.custom.parentObj][field.fieldName] }}
                            </span>
                          </span>
                        </template>
                      </a-descriptions-item>
                    </a-descriptions>
                  </template>
                </div>
              </a-tab-pane>
            </a-tabs>
          </div>
        </div>
      </div>
    </a-spin>
  </div>
</template>

<script>
import { PURCHASEATTACHMENTDOWNLOADAPI } from '@/utils/const'
import { getAction, postAction } from '@/api/manage'
import CustomUpload from '@comp/template/CustomUpload'

// import Breadcrumb from '@/components/tools/Breadcrumb.vue'

export default {
    name: 'DetailLayout',
    components: {
        // Breadcrumb
        CustomUpload
    },
    props: {
        title: {
            type: String,
            default: '详情'
        },
        pageData: {
            type: Object,
            default: () => {}
        },
        url: {
            type: Object,
            default: () => {}
        },
        currentEditRow: {
            type: Object,
            default: () => {}
        },
        typeData: {
            type: String,
            default: undefined
        }
    },
    data () {
        return {
            checkedId: new Set(),
            minHeight: 0,
            activeKey: '',
            confirmLoading: false,
            changeInput: undefined,
            text: 'text',
            tokenHeader: {'X-Access-Token': this.$ls.get('Access-Token')},
            accept: '.doc, .docx, .xls, .xlsx, .ppt, .png, .jpg, .jpeg, .gif, .pptx, .pdf',
            form: {},
            //默认表格配置
            defaultGridOption: {
                border: true,
                resizable: true,
                autoResize: true,
                height: 'auto',
                showOverflow: true,
                columnKey: true,
                highlightHoverRow: true,
                size: 'mini',
                align: 'center',
                headerAlign: 'center',
                columns: [],
                data: [],
                checkboxConfig: { highlight: true, trigger: 'row' },
                editConfig: { trigger: 'dblclick', mode: 'cell' },
                toolbarConfig: { slots: {buttons: 'toolbar_buttons'} }
            }
        }
    },
    // watch: {
    //     //正确给 cData 赋值的 方法
    //     currentEditRow: {
    //         handlerFn: function (newval){
    //             console.log(newval,'watchchchchchchchchchcch')
    //             this.changeInput = newval 
    //         },
    //         deep: true
           
    //     }
    // },
    computed: {
    // 配置
        treeConfig (){
            return {
                lazy: true, 
                children: 'purchaseDeliverySplitItemList', 
                hasChild: 'hasChild'
            }
        },
        itemInfo () {
            let itemInfo = []
            const groups = this.pageData.groups || []
            const group = groups.find(n => n.groupCode === 'itemInfo')
            if (group) {
                const refName = group.custom.ref
                itemInfo = this.$refs[refName][0].getTableData().fullData || []
            }
            return itemInfo
        }
    },
    methods: {
        toggleCheckedSelect ({ row, checked }) {
          if (checked) {
              this.checkedId.add(row.id)
          } else {
              this.checkedId.delete(row.id)
          }
          return Array.from(this.checkedId)
        },
        toggleAllCheckedSelect ({records, checked}) {
          if (checked) {
            records.forEach(item => this.checkedId.add(item.id))
          } else {
            // 注意取消全选时需要遍历当前表格数据来删除，records不管用
            this.checkedId.forEach(item => this.checkedId.delete(item))
          }
          return Array.from(this.checkedId)
        },
        // 文件下载
        handleDownload ({ id, fileName }, url = '') {
            const params = {
                id
            }
            let downloadUrl = url || PURCHASEATTACHMENTDOWNLOADAPI
            if(this.url.download){
                downloadUrl = this.url.download
            }
            getAction(downloadUrl, params, {
                responseType: 'blob'
            }).then(res => {
                console.log(res)
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        //附件上传
        handleUploadChange (info, btn, refName) {
            btn.callBack && btn.callBack(info, refName)
        },
        queryDetail (id, cb) {
            let that = this
            this.confirmLoading = true
            getAction(this.url.detail, {id: id}).then(res => {
                that.activeKey = that.pageData.groups[0].groupCode
                if(res.success) {
                    that.form = res.result
                    that.pageData.groups.forEach(group => {
                        if(group.type == 'grid') {
                            let ref = group.custom.ref
                            that.$refs[ref][0].loadData(res.result[ref])
                            if(group.custom.expandColumnsMethod) {
                                let expandColumns = group.custom.expandColumnsMethod()
                                group.custom.columns = group.custom.columns.concat(expandColumns)
                            }
                        }
                    })
                }else {
                    that.$message.warning(res.message)
                }
                cb && cb(res.result)
            }).finally(() => {
                that.confirmLoading = false
            })
        },
        getPageData () {
            const that = this
            let params = {...this.form}
            this.pageData.groups.forEach(group => {
                if(group.type == 'grid') {
                    let ref = group.custom.ref
                    params[ref] = that.$refs[ref][0].getTableData().fullData
                }
            })
            return params
        },
        setPromise () {
            let that = this
            let promise = this.pageData.groups.map(group => {
                if(group.type == 'grid') {
                    return that.$refs[group.custom.ref][0].validate(true)
                }else {
                    return that.$refs[group.groupCode]&&that.$refs[group.groupCode][0].validate() || Promise.resolve()
                }
            })
            return promise
        },
        handValidate (url, params, callback){
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) return callback && callback(url, params, this)
            }).catch(err => {
                console.log(err)
            })
        },
        handleSend (type = 'public', callback) {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) this.postData(type, callback)
            }).catch(err => {
                console.log(err)
            })
        },
        postData (type, callback) {
            let params = this.getPageData()
            let url =  type === 'public'
                ? this.url.public
                : this.voucherId
                    ? this.url.edit
                    : this.url.add
            this.confirmLoading = true
            postAction(url, params).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success && this.refresh) {
                    this.queryDetail()
                }
                if (res.success && type === 'public') {
                    this.$parent.goBack()
                } else {
                    // 自定义回调
                    return callback && callback(params, this)
                }
            }).finally(() => {
                // this.$parent.goBack()
                this.confirmLoading = false
            })
        },
        showLoading () {
            this.confirmLoading = true
        },
        hideLoading () {
            this.confirmLoading = false
        },
        rowStyle ({row}){
            if(this.typeData){
                if(this.typeData === 'enquiry' && this.pageData.groups[1].groupName === '询价行信息'){
                    let {fullData} = this.$refs.purchaseEnquiryItemList[0].getTableData()
                    if(fullData.length > 1){
                        if(row.itemNumber % 2 != 0){
                            return `
                            background-color: rgba(3, 223, 252,.3) ;
                            `
                        }
                    }
                }
            }
        },
        changeInputValue () {
            this.$emit('changeInputValue', this.changeInput)
        },
        btnDisable () {
            if(this.currentEditRow) {
                switch (this.currentEditRow.purchaseInvoiceAffirmStatus) {
                case '0' :
                case '1' :
                    return true
                default : return false
                }
            }
        }
    },
    created () {
        const clientHeight = document.documentElement.clientHeight
        this.minHeight = clientHeight - 260
    },
    
    mounted (){
        this.changeInput = this.currentEditRow ? this.currentEditRow.fbk5 ? this.currentEditRow.fbk5 : undefined : undefined
    }
    
}
</script>

<style lang="less" scoped>
.detailPage {
    .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 1px 0px 0 1px;
        padding: 8px 40px;
        background: #fff;
        .btnGroups {
            text-align: right;
            .ant-btn {
                & +.ant-btn {
                    margin-left: 10px;
                }
            }
        }
    }
    .content {
        margin: 0px 1px;
        padding: 8px;
        background: #fff;
    }

    /deep/ .ant-descriptions-bordered .ant-descriptions-item-label {
      background: #f8feff;
    }
    
    /deep/ .ant-descriptions-item-content {
      width: 16.66%;
      max-width: 16.66%;
    }
    /deep/ .row--checked {
      background-color: #fff3e0!important;
    }
}
</style>

