/*
 * @Author: fzb
 * @Date: 2021-07-29 09:57:40
 * @LastEditTime: 2021-10-09 15:15:37
 * @FilePath: \srm-frontend_v4.5\src\components\template\business\businessUtilMixin.js
 */
import { USER_INFO } from '@/store/mutation-types'

import { handValidate, composePromise, downloadTemplate } from '@/utils/util.js'
import { httpAction } from '@/api/manage'

export const businessUtilMixin= {
    data () {
        return {
            refresh: false,
            confirmLoading: false,
            businessRefName: 'businessRef',
            curGroupCode: '',
            fieldSelectType: '',
            businessHandler: {
                handleFooterSave: this.composeBusinessSave,
                handleFooterPublish: this.composeBusinessPublish,
                handleFooterSubmit: this.composeBusinessSubmit,
                handleFooterReject: this.composeBusinessReject,
                handleGoBack: this.businessHide,
                handleToolbarGridDelete: this.businessGridDelete,
                handleToolbarGridExportExcel: this.businessGridExportExcel
            }
        }
    },
    provide () {
        return {
            tplRootRef: this
        }
    },
    methods: {
        /**
         * 校验
         */
        handValidate,
        /**
         * 获取业务模板的所有数据和配置, 传入组件ref名称
         * @param {*} extendRef 
         * @returns 
         */
        getBusinessExtendData (extendRef) {
            if (this.$refs[extendRef]) {
                return this.$refs.businessRef.extendAllData()
            } else {
                return null
            }
        },
        /**
         * 单个分组-隐藏与显示
         * @param {*} extendRef 
         * @param {*} groupCode 
         * @param {*} flag 
         */
        hideSingleGroup (extendRef, groupCode, flag) {
            if (this.getBusinessExtendData(extendRef)) {
                let data = this.getBusinessExtendData(extendRef).pageConfig
                let groups = data.groups
                if (groups && groups.length) {
                    groups.forEach(item=> {
                        if (item.groupCode=== groupCode) {
                            item.show= !flag
                        }
                    })
                }
            }
        },
        /**
         * 设置表单单个field是否可编辑,可用于bindFuntion
         * @param {*} fieldName 
         * @param {*} flag 
         */
        setDisableByField (fieldName, formFields, flag) {
            for (let sub of formFields) {
                if (sub.fieldName === fieldName) {
                    sub.disabled = flag
                    break
                }
            }
        },
        
        /**
         * 设置所有的表单的字段不可编辑
         * @param {*} formFields
         */
        setAllFieldsDisable (formFields) {
            for (let sub of formFields) {
                sub.disabled = true
            }
        },
        /**
         * 设置表单单个field的值,可用于bindFuntion
         * @param {*} fieldName 
         * @param {*} flag 
         */
        setValueByField (groupCode, field, value) {
            let pageData = this.$refs[this.businessRefName].pageConfig.groups
            for (let rs of pageData) {
                if (rs.groupCode == groupCode && rs.formModel[field] != 'undefined') {
                    rs.formModel[field] = value
                    break
                }
            }
        },
        /**
         * 获取当前用户信息
         */
        getUserInfo () {
            return this.$ls.get(USER_INFO)
        },
        /**
         * 返回
         */
        businessHide () {
            this.$emit('hide')
        },
        // 规范功能按钮 配置
        normalizeBtnConfig (key) {
            let pageHeaderButtons = this.pageHeaderButtons || []
            let pageFooterButtons = this.pageFooterButtons || []
            let btns = [ ...pageHeaderButtons, ...pageFooterButtons ]
            let {
                args = {},
                method = 'post',
                showMessage = true,
                handleBefore = (args => window.Promise.resolve(args)),
                handleAfter = (args => window.Promise.resolve(args))
            } = btns.find(n => n.key === key) || {}
            const { url = '' } = args
            if (!url) {
                this.$message.error('须配置请求API')
                return false
            }

            return { url, method, showMessage, handleBefore, handleAfter }
        },
        // 获取页面所有数据
        getAllData () {
            const { allData = {} } = this.getBusinessExtendData(this.businessRefName)
            return Object.assign({}, allData)
        },
        // 规范功能按钮 功能
        normalizeStepPromiseMethod (type = 'save') {
            const {
                url,
                method,
                showMessage,
                handleBefore,
                handleAfter
            } = this.normalizeBtnConfig(type)
            if (!url) return
            
            const requestAction = (args) => {
                // 每次重新获取页面所有数据
                return new Promise((resolve, reject) => {
                    httpAction(url, args.pageData, method).then(res => {
                        if (res.success) {
                            if (showMessage) {
                                const message = this.$message[`${res.success ? 'success' : 'error'}`]
                                message(res.message)
                            }
                            // 保存成功，赋值id进行查询
                            if (type === 'save' && !this.currentEditRow.id) {
                                this.currentEditRow.id = res.result.id
                            }
                            resolve(args)
                        } else {
                            this.$message.error(res.message)
                            reject(args)
                        }
                    }, () => {
                        reject(args)
                    })
                })
            }
            const steps = [handleAfter, requestAction, handleBefore]
            
            return composePromise(...steps)
        },
        handleValidateFail ({ message = '', currentStep = 0  }) {
            this.$message.error(message)
            this.$refs[this.businessRefName].currentStep = currentStep
        },
        // 组合驳回流程
        composeBusinessReject (args) {
            const pageData = this.getAllData()
            
            let steps = [
                this.stepBusinessReject
            ]
            if (this.refresh) {
                steps.unshift(this.stepBusinessRefresh)
            }
            const handleCompose = composePromise(...steps)
            this.confirmLoading = true
            handleCompose({ ...args, pageData })
                .then(res => {
                    console.log('all reject success', res)
                }, err => {
                    console.log('all reject error', err)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        // 组合保存流程
        composeBusinessSave (args) {
            const pageData = this.getAllData()
            
            let steps = [
                this.stepBusinessSave,
                this.changeRequestUrl
            ]
        
            if (this.refresh) {
                steps.unshift(this.stepBusinessRefresh)
            }
            const handleCompose = composePromise(...steps)
            this.confirmLoading = true
            handleCompose({ ...args, pageData })
                .then(res => {
                    console.log('all save success', res)
                }, err => {
                    console.log('all save error', err)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        // 组合发布流程（自定义校验 + 保存 + 发布）
        composeBusinessPublish (args) {
            const pageData = this.getAllData()
            
            const steps = [
                this.stepBusinessPublish,
                this.setShowMessageTrue, // 恢复按钮配置的 showMessage
                this.stepBusinessSave,
                this.setShowMessageFalse, // 隐藏按钮配置的 showMessage
                this.stepValidate
            ]
            const handleCompose = composePromise(...steps)
            this.confirmLoading = true
            handleCompose({ ...args, pageData })
                .then(res => {
                    console.log('all publish success', res)
                    this.businessHide()
                }, err => {
                    console.log('all publish error', err)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        // 组合提交审批流程（自定义校验 + 保存 + 发布）
        composeBusinessSubmit (args) {
            const pageData = this.getAllData()
            
            const steps = [
                this.stepBusinessSubmit,
                this.confirmSubmit,
                this.setShowMessageTrue, // 恢复按钮配置的 showMessage
                this.stepBusinessSave,
                this.setShowMessageFalse, // 隐藏按钮配置的 showMessage
                this.stepValidate
            ]
            const handleCompose = composePromise(...steps)
            this.confirmLoading = true
            handleCompose({ ...args, pageData })
                .then(res => {
                    console.log('all submit success', res)
                    this.businessHide()
                }, err => {
                    console.log('all submit error', err)
                })
                .finally(() => {
                    this.confirmLoading = false
                })
        },
        // 校验步骤
        stepValidate (args) {
            const Ref = this.$refs[this.businessRefName]
            // 校验
            return new Promise((resolve, reject) => {
                this.handValidate(Ref, args.pageConfig).then(res => {
                    console.log('res', res)
                    if (res.validStatus) {
                        resolve(args)
                    } else {
                        this.handleValidateFail(res)
                        reject(args)
                    }
                }, err => {
                    reject(err)
                })
            })
        },
        setShowMessageTrue (args) {
            return new Promise((resolve) => {
                const pageFooterButtons = args.pageConfig.pageFooterButtons
                const btn = pageFooterButtons.find(n => n.key === 'save')
                btn && (btn.showMessage = true)
                resolve(args)
            })
        },
        setShowMessageFalse (args) {
            return new Promise((resolve) => {
                const pageFooterButtons = args.pageConfig.pageFooterButtons
                const btn = pageFooterButtons.find(n => n.key === 'save')
                btn && (btn.showMessage = false)
                resolve(args)
            })
        },
        changeRequestUrl (args) {
            return new Promise((resolve, reject) => {
                if (args.btn.args.url) {
                    let lastLen = args.btn.args.url.lastIndexOf('/')
                    // 没有id新增，有id编辑
                    if (this.currentEditRow && this.currentEditRow.id) {
                        args.btn.args.url =  args.btn.args.url.substring(0, lastLen) + '/edit'
                    } else {
                        this.refresh = true
                        args.btn.args.url =  args.btn.args.url.substring(0, lastLen) + '/add'
                    }
                    resolve(args)
                } else {
                    reject(args)
                }
            })

        },
        // 保存步骤
        // 保存前操作 handleBefore
        // 保存后操作 handleAfter
        stepBusinessSave (args) {
            const handleCompose = this.normalizeStepPromiseMethod('save')
            return handleCompose(args)
        },
        stepBusinessRefresh (args) {
            return new Promise((resolve) => {
                this.$refs[this.businessRefName].queryDetail()
                resolve(args)
            })
        },
        confirmSubmit (args) {
            return new Promise((resolve, reject) => {
                this.$confirm({
                    title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_submitApproval`, '提交审批'),
                    content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmSubmitApprovalTips`, '是否确认提交审批'),
                    onOk () {
                        resolve(args)
                    },
                    onCancel () {
                        reject(args)
                    }
                })
            })
        },
        // 提交审批步骤
        // 交审批 handleBefore
        // 交审批 handleAfter
        stepBusinessSubmit (args) {
            const handleCompose = this.normalizeStepPromiseMethod('submit')
            return handleCompose(args)
        },
        // 发布步骤
        // 发布前操作 handleBefore
        // 发布后操作 handleAfter
        stepBusinessPublish (args) {
            const handleCompose = this.normalizeStepPromiseMethod('publish')
            return handleCompose(args)
        },
        // 驳回步骤
        stepBusinessReject (args) {
            const handleCompose = this.normalizeStepPromiseMethod('reject')
            return handleCompose(args)
        },
        getItemGridRef (groupCode) {
            let gridRef = `${groupCode}grid`
            return this.$refs[this.businessRefName].$refs[gridRef][0].$refs[groupCode]
        },
        // 表格通用删除
        businessGridDelete ({ groupCode }) {
            let itemGrid = this.getItemGridRef(groupCode)
            let checkboxRecords = itemGrid.getCheckboxRecords()
            if(!checkboxRecords.length) {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据'))
                return
            }
            itemGrid.removeCheckboxRow()
        },
        // 表格通用 导出 excel
        // @example
        // {
        //     title: '导出 Excel',
        //     key: 'gridExportExcel',
        //     args: {
        //         url: '/system/excelByConfig/exportExcel', // 必传
        //         handlerName: 'saleEnquiryItemExcelHandler', // 必传
        //         roelCode: 'sale' // 必传
        //     }
        // }
        businessGridExportExcel ({ btn }) {
            const { allData = {} } = this.getBusinessExtendData(this.businessRefName)
            const {  groupCode = '', handlerName = '', roelCode = '', url = '', id = '', data = '' } = btn.args || {}
            const options = {
                url,
                groupCode,
                handlerName,
                roelCode,
                id: id || allData.id,
                data // 成本报价this.currentEditRow.itemId + '_' + groupCode
            }
            return downloadTemplate(options)
        },
        // 表格通用新增
        businessGridAdd ({ pageConfig, groupCode }) {
            let itemGrid = this.getItemGridRef(groupCode)
            let { columns = [] } = pageConfig.groups.find(n => n.groupCode === groupCode)
            
            let row = columns
                .filter(n => n.field)
                .reduce((acc, obj) => {

                    acc[obj.field] = obj.defaultValue || ''
                    return acc
                }, {})
            
            itemGrid.insertAt([row], -1)
        },
        uploadCallBack (result, ref) {
            let fileGrid = this.getItemGridRef(ref)
            fileGrid.insertAt(result, -1)
        }
    }  
}
