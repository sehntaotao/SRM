<!--
 * @Author: your name
 * @Date: 2021-05-31 14:36:16
 * @LastEditTime: 2021-08-18 16:31:29
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \srm-frontend_v4.5\src\components\template\container\DetailFormLayout.vue
-->
<template>
  <div
    class="description"
    :style="{'min-height': minHeight + 'px'}">
    <template v-if="group.formFields && group.formFields.length">
      <a-descriptions v-bind="descriptionsConfig">
        <a-descriptions-item 
          v-for="field in group.formFields"
          :key="field.fieldName"> 
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <template>
            <!-- 阶梯价格 -->
            <template v-if="field.fieldName === 'ladderPriceJson'">
              <a-tooltip
                placement="top"
                v-if="group.formModel['ladderPriceJson']"
                overlayClassName="tip-overlay-class">
                <template slot="title">
                  <vxe-table
                    auto-resize
                    border
                    size="mini"
                    :data="initRowLadderJson(group.formModel['ladderPriceJson'])">
                    <vxe-table-column
                      type="seq"
                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_details`, '序号')}`"
                      width="80"></vxe-table-column>
                    <vxe-table-column
                      field="ladderQuantity"
                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_ladderQuantity`, '阶梯数量')}`"
                      width="140"></vxe-table-column>
                    <vxe-table-column
                      field="price"
                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_price`, '含税价')}`"
                      width="140"></vxe-table-column>
                    <vxe-table-column
                      field="netPrice"
                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_netPrice`, '不含税价')}`"
                      width="140"></vxe-table-column>
                  </vxe-table>
                </template>
                <div class="json-box"><a href="javascript: void(0)">{{ defaultRowLadderJson(group.formModel['ladderPriceJson']) }}</a></div>
              </a-tooltip>
            </template>
            <template v-else>
              <span v-if="field.fieldType == 'link'">
                <a
                  :href="group.formModel[field.fieldName]"
                  target="_blank">
                  <span>{{ $srmI18n(`${$getLangAccount()}#i18n_title_authenticationLink`, '认证链接') }}</span>
                </a>
              </span>
              <span v-else>
                <span v-if="field.fieldType == 'switch' || field.fieldType === 'select' || field.fieldType === 'multiple'">
                  {{ group.formModel[field.fieldName + '_dictText'] }}
                </span>
                <span
                  :style="{'display': 'inline-block', 'min-height': group.formFields.length===1? '100px': 'auto'}"
                  v-else>
                  {{ group.formModel[field.fieldName] }}
                </span>
              </span>
            </template>
          </template>
        </a-descriptions-item>
        <a-descriptions-item
          v-if="group.total.totalValue">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }} {{ $srmI18n(`${$getLangAccount()}#${group.i18n_title_generalSummary}`, '总汇总') }}
          </span>
          <template>
            <div class="summary-message">
              <span class="summary-message-content">
                <span class="total-num">{{ group.total.totalValue }}</span></span>
            </div>
          </template>
        </a-descriptions-item>
      </a-descriptions>
    </template>
  </div>
</template>
<script>
export default {
    name: 'DetailFormLayout',
    props: {
        // 传入归属方busAccount
        busAccount: {
            required: true,
            type: String,
            default: null
        },
        group: {
            type: Object,
            required: true,
            default: ()=> {
                return {}
            }
        },
        pageConfig: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    data () {
        return {
        }
    },
    computed: {
        // 最小高度，防止tab页面高度自动
        minHeight () {
            let minHeight = 0
            const clientHeight = document.documentElement.clientHeight
            minHeight = clientHeight - 260
            return minHeight
        },
        descriptionsConfig () {
            let config = {
                layout: 'horizontal',
                column: 2,
                size: 'small',
                bordered: true
            }
            if (this.group.formFields && this.group.formFields.length && this.group.formFields.length===1) {
                config.layout= 'vertical'
                config.column = 1
                config.size = 'middle'
            }
            return config
        }
    },
    methods: {
        // 阶梯报价json数据组装
        initRowLadderJson (jsonData) {
            let arr = []
            if (jsonData) {
                arr = JSON.parse(jsonData)
            }
            return arr
        },
        // 阶梯报价默认显示
        defaultRowLadderJson (jsonData) {
            let arrString = ''
            if (jsonData) {
                let arr = JSON.parse(jsonData)
                arr.forEach((item, index)=> {
                    let ladderQuantity = item.ladderQuantity
                    let price = item.price
                    let netPrice= item.netPrice
                    let str = `${ladderQuantity} ${price} ${netPrice} `
                    let separator = index===arr.length-1? '': ','
                    arrString +=str+ separator
                })
            }
            return arrString
        },
        // 初始化传过来默认方法
        initDetaultFunc () {
            let that = this
            that.$nextTick(() => {
                const formFields = that.group.formFields || []
                formFields.forEach((field) => {
                    const { bindFunction, fieldName, fieldType, groupCode, defaultValue } = field
                    if (bindFunction && typeof bindFunction === 'function') {
                        const parentRef = that.$refs[groupCode]
                        const groupData = that.group
                        const value = that.group.formModel[fieldName] || defaultValue
                        if (fieldType === 'input') {
                            bindFunction.call(null, parentRef, that.pageConfig, groupData, value, field, that.group.formModel )
                        } else {
                            bindFunction.call(null, parentRef, that.pageConfig, groupData, value, [], '', that.group.formModel)
                        }
                    }
                })
            })
        }
    }
}
</script>
<style lang="less" scoped>
.summary-message {
  height: 14px;
  display: flex;
  align-items: center;
  margin: 10px 0;
}
.summary-message-content {
  flex-grow: 1;
  font-weight: bolder;
  .total-num {
    font-size: 16px;
    color: red;
  }
}
/deep/ .description .ant-descriptions-bordered .ant-descriptions-item-label {
  background: #f8feff;
}
/deep/ .description .ant-descriptions-bordered .ant-descriptions-item-label {
  width: 20%;
	max-width: 20%;
}
/deep/ .description .ant-descriptions-bordered .ant-descriptions-item-content {
	width: 30%;
	max-width: 30%;
}
</style>