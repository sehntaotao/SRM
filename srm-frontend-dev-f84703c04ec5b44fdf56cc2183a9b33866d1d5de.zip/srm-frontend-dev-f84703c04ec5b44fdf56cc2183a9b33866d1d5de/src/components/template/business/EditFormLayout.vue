<!--
 * @Author: fzb
 * @Date: 2021-07-26 11:12:08
 * @LastEditTime: 2021-10-09 11:44:02
 * @FilePath: \srm-frontend_v4.5\src\components\template\container\EditFormLayout.vue
-->
<template>
  <a-form-model 
    v-if="group.groupType==='head'"
    :ref="group.groupCode"
    :model="group.formModel" 
    :rules="group.validateRules"
    class="ant-advanced-rule-form"
    :layout="layout"
    v-bind="formModelConfig">
    <template v-for="(field, fieldIndex) in group.formFields">
      <a-form-model-item
        style="min-height: 300px;"
        :key="'col_' + group.groupCode + '_' + fieldIndex"
        v-if="group.formFields.length===1 && (field.fieldType === 'input' || field.fieldType === 'password' || field.fieldType === 'textArea')"
        :prop="field.fieldName">
        <span slot="label">
          {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
          <a-tooltip
            v-if="field.helpText"
            :title="field.helpText">
            <a-icon type="question-circle-o" />
          </a-tooltip>
        </span>
        <a-input
          v-bind="field.extend"
          :disabled="field.disabled"
          :type="field.fieldType === 'input'?'text': field.fieldType === 'password'?'password':'textarea'"
          @change="changeInputValue(group.formModel[field.fieldName], field)"
          v-model="group.formModel[field.fieldName]"
          :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)}`" />
      </a-form-model-item>
    </template>
    <a-row
      :getterr="12"
      v-if="group.formFields.length>1">
      <a-col
        v-for="(field, fieldIndex) in group.formFields"
        :key="'col_' + group.groupCode + '_' + fieldIndex"
        :span="8">
        <a-form-model-item
          v-if="field.fieldType === 'input' || field.fieldType === 'password' || field.fieldType === 'textArea'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <a-input
            v-bind="field.extend"
            :disabled="field.disabled"
            :type="field.fieldType === 'input'?'text': field.fieldType === 'password'?'password':'textarea'"
            @change="changeInputValue(group.formModel[field.fieldName], field)"
            v-model="group.formModel[field.fieldName]"
            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)}`" />
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType == 'select'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-select
            :disabled="field.disabled"
            :configData="field"
            :getPopupContainer="triggerNode => {
              return triggerNode.parentNode || document.body;
            }"
            @change="changeSelectValue"
            v-model="group.formModel[field.fieldName]"
            :current-edit-row="currentEditRow"
            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)}`"
            :dict-code="field.dictCode" />
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType == 'multiple'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-select
            :disabled="field.disabled"
            mode="multiple"
            :configData="field"
            :maxTagCount="field.extend && field.extend.maxTagCount || 1"
            v-model="group.formModel[field.fieldName]"
            :current-edit-row="currentEditRow"
            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)}`"
            :dict-code="field.dictCode"
            @change="changeSelectValue"
          />
        </a-form-model-item>
        <a-form-model-item
          v-if="field.fieldType == 'cascader'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-cascader
            change-on-select
            v-model="group.formModel[field.fieldName]"
            :mode="field.dictCode"
            :disabled="field.disabled"
            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${item.fieldLabelI18nKey}`, field.fieldLabel)}`"
          />
        </a-form-model-item>
        <a-form-model-item
          v-if="field.fieldType == 'number'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <a-input-number
            style="width:100%"
            :disabled="field.disabled"
            @change="changeInputValue(group.formModel[field.fieldName], field)"
            v-model="group.formModel[field.fieldName]"
            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)}`" />
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType == 'date'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <a-date-picker
            style="width:100%"
            :disabled="field.disabled"
            @change="changeInputValue(group.formModel[field.fieldName], field)"
            :show-time="field.dataFormat && field.dataFormat.length > 10 ? true : false"
            :valueFormat="(field.dataFormat || 'YYYY-MM-DD')"
            v-model="group.formModel[field.fieldName]"
            :placeholder="`${$srmI18n(`${$getLangAccount()}#i18n_title_pleaseEnter`, '请输入')}${$srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)}`" />
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType == 'switch'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-switch
            :disabled="field.disabled"
            :configData="field"
            @change="changeSelectValue"
            v-model="group.formModel[field.fieldName]" />
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType == 'treeSelect'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-tree-select 
            v-model="group.formModel[field.fieldName]"
            allowClear
            :disabled="field.disabled"
            :multiple="field.extend && field.extend.multiple || false"
            :maxTagCount="field.extend && field.extend.maxTagCount || 1"
            :sourceUrl="field.dictCode"
            :sourceMap="field.sourceMap"
            :showEmptyNode="field.showEmptyNode"
            :placeholder="field.placeholder" />
        </a-form-model-item>
        <a-form-model-item
          v-if="field.type==='datepicker'"
          :prop="field.fieldName"
          :label="field.label">
          <a-date-picker
            v-model="pageData.form[field.fieldName]"
            :placeholder="field.placeholder"
            :valueFormat="(field.dataFormat || 'YYYY-MM-DD')">
          </a-date-picker>
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType=='selectModal'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-select-modal
            v-model="group.formModel[field.fieldName]"
            :config="field"
            :pageData="pageConfig"
            :form="group.formModel"
            :currentStep="currentStep"
            @afterClearCallBack="(cb)=> { handleSelectModalAfterClear(group.formModel, pageConfig, cb)}"
            @ok="(rows) => handleSelectModalAfterSelect(field, rows)"
          />
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType === 'richEditorModel'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <rich-editor-model
            :value="group.formModel[field.fieldName]"
            :disabled="field.disabled"
            @handleSureClick="(content)=> {group.formModel[field.fieldName] = content}"></rich-editor-model>
        </a-form-model-item>
        <a-form-model-item
          v-else-if="field.fieldType === 'image'"
          :prop="field.fieldName">
          <span slot="label">
            {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
            <a-tooltip
              v-if="field.helpText"
              :title="field.helpText">
              <a-icon type="question-circle-o" />
            </a-tooltip>
          </span>
          <m-upload
            :value.sync="group.formModel[field.fieldName]"
            :accept="accept2"
            :headers="tokenHeader"
            :data="{ businessType: field.dictCode, headId: group.formModel.id}"
          > 
          </m-upload>
        </a-form-model-item>
      </a-col>
    </a-row>
    <a-row
      :getterr="12"
      v-if="group.total.totalValue">
      <div class="summary-message">
        <span class="summary-message-content">
          {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }} {{ $srmI18n(`${$getLangAccount()}#${group.i18n_title_generalSummary}`, '总汇总') }}：<span class="total-num">{{ group.total.totalValue }}</span></span>
      </div>
    </a-row>
  </a-form-model>
</template>
<script>
import RichEditorModel from '@comp/richEditorModel/RichEditorModel'
export default {
    name: 'EditFormLayout',
    components: {
        RichEditorModel
    },
    inject: ['tplRootRef'],
    props: {
        // 传入归属方busAccount
        busAccount: {
            required: true,
            type: String,
            default: ''
        },
        currentStep: {
            type: [String, Number]
        },
        currentEditRow: {
            type: Object,
            default: () => {
                return {}
            }
        },
        group: {
            type: Object,
            required: true,
            default: ()=> {
                return {}
            }
        },
        pageConfig: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    data () {
        return {
           
        }
    },
    computed: {
        // form 表单布局
        layout () {
            if (this.group.formFields.length && this.group.formFields.length > 1) {
                return 'inline'
            } else {
                return 'vertical'
            }
        },
        // form表单默认配置
        formModelConfig () {
            if (this.group.formFields.length && this.group.formFields.length > 1) {
                return {
                    labelCol: { span: 9 },
                    wrapperCol: { span: 15 }
                }
            } else {
                return {
                    labelCol: { span: 3 },
                    wrapperCol: { span: 24 }
                }
            }
        }
    },
    // mounted () {
    //     this.initDetaultFunc()
    // },
    methods: {
        // 初始化传过来默认方法
        initDetaultFunc () {
            let that = this
            that.$nextTick(() => {
                const formFields = that.group.formFields || []
                formFields.forEach((field) => {
                    const { bindFunction, fieldName, fieldType, groupCode, defaultValue } = field
                    if (bindFunction && typeof bindFunction === 'function') {
                        const parentRef = that.$refs[groupCode]
                        const groupData = that.group
                        const value = that.group.formModel[fieldName] || defaultValue
                        if (fieldType !== 'selectModal') {
                            if (fieldType === 'input') {
                                bindFunction.call(null, this.$parent, parentRef, that.pageConfig, groupData, value, field, that.group.formModel, '', that.tplRootRef)
                            } else {
                                bindFunction.call(null, this.$parent.$parent.$parent, parentRef, that.pageConfig, groupData, value, [], '', that.group.formModel, that.tplRootRef)
                            }
                        }
                    }
                })
            })
        },
        // selectModal 清除
        handleSelectModalAfterClear (formModel, pageConfig, cb) {
            cb && cb(this, formModel, pageConfig)
        },
        // selectModal 确认时
        handleSelectModalAfterSelect (item, rows) {
            item.bindFunction && item.bindFunction.call(null, this, rows, this.tplRootRef)
        },
        // input 改变事件,value-当前值
        changeInputValue (value, item) {
            let parentRef = null
            let groupData = null
            if (this.pageConfig.groups[this.currentStep]) {
                let parentRefName = this.pageConfig.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageConfig.groups[this.currentStep]
            }
            // let test = value?true: false
            // groupData.custom.validateRules= Object.assign({}, groupData.custom.validateRules, {enquiryType: {required: test, message: '123455'}})
            if (item && item.bindFunction &&  typeof item.bindFunction === 'function') {
                item.bindFunction(this.$parent.$parent.$parent, parentRef, this.pageConfig, groupData, value, item, this.group.formModel, '', this.tplRootRef)
            }
        },
        // select 改变事件
        changeSelectValue (realValue, opt, oldVal, configData) {
            let parentRef = null
            let groupData = null
            if (this.pageConfig.groups[this.currentStep]) {
                let parentRefName = this.pageConfig.groups[this.currentStep].groupCode
                parentRef = this.$refs[parentRefName]
                groupData = this.pageConfig.groups[this.currentStep]
            }
            if (configData && configData.bindFunction && typeof configData.bindFunction==='function') {
                configData.bindFunction(this.$parent.$parent.$parent, parentRef, this.pageConfig, groupData, realValue, opt, oldVal, this.group.formModel, this.tplRootRef)
            }
        }
    }
}
</script>
<style lang="less" scoped>
.summary-message {
  height: 14px;
  display: flex;
  align-items: center;
  margin: 10px 0;
}
.summary-message-content {
  flex-grow: 1;
  font-weight: bolder;
  .total-num {
    font-size: 16px;
    color: red;
  }
}
/deep/ .description .ant-descriptions-bordered .ant-descriptions-item-label {
  background: #f8feff;
}
/deep/ .description .ant-descriptions-bordered .ant-descriptions-item-label {
  width: 20%;
	max-width: 20%;
}
/deep/ .description .ant-descriptions-bordered .ant-descriptions-item-content {
	width: 30%;
	max-width: 30%;
}
</style>