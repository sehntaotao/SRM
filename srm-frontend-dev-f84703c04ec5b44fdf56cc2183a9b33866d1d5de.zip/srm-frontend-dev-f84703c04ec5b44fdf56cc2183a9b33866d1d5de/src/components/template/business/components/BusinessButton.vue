<template>
  <div class="BusinessButton">
    <template v-for="(btn, i) in localButtons">
      <template v-if="btn.key === 'upload'">
        <custom-upload
          :key="'btn_' + i"
          :single="btn.args && btn.args.single"
          :disabledItemNumber="btn.args && btn.args.disabledItemNumber"
          :requiredFileType="btn.args && btn.args.requiredFileType"
          :property="btn.args && btn.args.property || 'materialName'"
          :visible.sync="btn.args && btn.args.modalVisible"
          :title="btn.args && btn.args.title || '附件上传'"
          :action="btn.args && btn.args.action || ACTION"
          :itemNumberKey="btn.args && btn.args.itemNumberKey || 'itemNumber'"
          :itemNumberLabel="btn.args && btn.args.itemNumberLabel || '行项目'"
          :itemNumbeValueProp="btn.args && btn.args.itemNumbeValueProp || ''"
          :itemInfo="btn.args && btn.args.itemInfo"
          :accept="accept"
          :headers="tokenHeader"
          :data="{
            businessType: btn.args && btn.args.businessType,
            headId: btn.args && btn.args.headId
          }"
          @change="(info) => handleUploadChange(info, btn)"
        >
          <a-button
            v-if="btn.beforeChecked"
            :disabled="btn.disabled && btn.disabled(btn) || false"
            type="primary"
            icon="cloud-upload"
            @click="checkedGridSelect(btn, btn.beforeCheckedCallBack)">{{ btn.args && btn.args.title || '附件上传' }}</a-button>
        </custom-upload>
      </template>
      <template v-else-if="btn.key === 'gridImportExcel'">
        <a-upload
          class="custom-mport"
          :key="'btn_' + i"
          :showUploadList="false"
          :multiple="false"
          :headers="tokenHeader"
          :data="()=> {return handleBeforeUploadData(btn)}"
          :action="btn.args && btn.args.url || IMPORTEXCELACTION"
          @change="(info) => handleUploadChange(info, btn)"
        >
          <a-button
            class="btn"
            v-bind="btn.attrs || {}">
            <a-icon type="upload" />
            {{ btn.title }}
          </a-button>
        </a-upload>
      </template>
      <template v-else>
        <a-button
          v-if="btn._show"
          :key="'btn_' + i"
          class="btn"
          @click="() => handleClick(btn)"
          v-bind="btn.attrs || {}">
          {{ btn.title }}
        </a-button>
      </template>
    </template>
  </div>
</template>

<script>
const ACTION = '/attachment/purchaseAttachment/upload'
const IMPORTEXCELACTION = '/els/system/excelByConfig/importExcel'

import CustomUpload from '@comp/template/CustomUpload'
import { isObject, isPromise } from '@/utils/util.js'

export default {
    name: 'BusinessButtons',
    components: {
        CustomUpload
    },
    props: {
        buttons: {
            type: Array,
            default () {
                return []
            }
        },
        pageConfig: {
            type: Object,
            default () {
                return {}
            }
        },
        isToolbarButtons: {
            type: Boolean,
            default: false
        },
        groupCode: {
            type: String,
            default: ''
        },
        // resultData: {
        //     type: Object,
        //     default () {
        //         return {}
        //     }
        // },
        isAsync: {
            type: Boolean,
            default: true
        }
    },
    data () {
        return {
            ACTION,
            IMPORTEXCELACTION,
            pageData: {},
            localButtons: [],
            accept: '.doc, .docx, .xls, .xlsx, .ppt, .png, .jpg, .jpeg, .gif, .pptx, .pdf',
            //附件上传配置
            tokenHeader: {'X-Access-Token': this.$ls.get('Access-Token')}
        }
    },
    watch: {
        buttons: {
            immediate: true,
            handler (arr) {
                if (!Array.isArray(arr) || !arr.length) {
                    return
                }
                this.localButtons = arr.map(n => {
                    // 如果仅为本地配置按钮数据
                    // 无需异步接口返回数据作为判断条件时使用
                    if (!this.isAsync) {
                        this.handleButtonShow(n)
                    }
                    return { _show: true, ...n}
                })
            }
        },
        // resultData: {
        //     immediate: true,
        //     handler (obj) {
        //         if (!isObject(obj) || !Object.keys(obj).length) {
        //             return
        //         }
        //         debugger
        //         this.pageData = obj || {}
        //         this.localButtons.forEach(n => this.handleButtonShow(n))
        //     }
        // },
        '$attrs.resultData': {
            immediate: true,
            handler (obj) {
                if (!isObject(obj) || !Object.keys(obj).length) {
                    return
                }
                this.pageData = obj || {}
                this.localButtons.forEach(n => this.handleButtonShow(n))
            }
        }
    },
    methods: {
        handleButtonShow (btn = {}) {
            if (!btn._show) {
                btn._show = undefined
            }
            const show = btn.show
            let payload = {Vue: this, pageConfig: this.pageConfig, pageData: this.pageData, btn}
            if (this.isToolbarButtons) {
                payload.groupCode = this.groupCode
            }
            if (show && typeof(show) === 'function') {
                let response = show(payload)
                if (isPromise(response)) {
                    response.then(() => {
                        btn._show = true
                    }, () => {
                        btn._show = false
                    })
                } else {
                    btn._show = !!response
                }
            } else if (typeof(btn.show) !== 'undefined') {
                btn._show = !!btn.show
            } else {
                btn._show = true
            }
        },
        // 允许上传数据前数据组装
        handleBeforeUploadData (btn) {
            let data = {
                groupCode: btn.args && btn.args.groupCode,
                handlerName: btn.args && btn.args.handlerName,
                roelCode: btn.args && btn.args.roelCode,
                id: btn.args && btn.args.id
            }
            if (btn && btn.args && typeof btn.args === 'function') {
                let data = { Vue: this, pageConfig: this.pageConfig, btn }
                return btn.args && btn.args(data)
            }
            return data
        },
        //附件上传
        handleUploadChange (info, btn) {
            let groupCode = this.groupCode
            btn.callBack && btn.callBack(info, groupCode)
        },
        checkedGridSelect (btn, cb) {
            let parent = this.$parent
            let selectData = null
            if (parent) {
                selectData = parent.getCheckboxRecords() || parent.getRadioRecord()
            }
            if (selectData && selectData.length) {
                if (cb && typeof cb === 'function') {
                    cb(selectData).then(res=> {
                        if (res) {
                            btn.modalVisible = true
                        }
                    })
                } else {
                    this.modalVisible = true
                }
            } else {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterChoose`, '请先选择'))
            }
        },
        beforeClick () {
            return new Promise(resolve=> {
                resolve(true)
            })
        },
        afterClick () {
            return new Promise(resolve=> {
                resolve(true)
            })
        },
        handleClick (btn) {
            let key = btn.key || ''
            let data = {Vue: this, pageConfig: this.pageConfig, btn}
            let beforeFn = this.beforeClick
            if (btn.beforeClick) {
                beforeFn = btn.beforeClick
            }
            beforeFn(data).then((res)=> {
                if (res) {
                    key = key.charAt(0).toUpperCase() + key.slice(1)
                    // 本地方法
                    let fn = this[`handle${key}`]
                    if (btn.click && typeof(btn.click) === 'function') {
                        fn = btn.click
                    }
                    // 载荷
                    let payload = {Vue: this, pageConfig: this.pageConfig, btn}
                    if (this.isToolbarButtons) {
                        payload.groupCode = this.groupCode
                    }
                    fn && fn(payload)
                }
            })
        },
        // 底部返回
        handleGoBack ({ Vue, pageConfig, btn }) {
            this.$emit('handleGoBack', {Vue, pageConfig, btn})
        },
        // 底部提交 footerSave
        handlePublish ({ Vue, pageConfig, btn }) {
            this.$emit('handleFooterPublish', {Vue, pageConfig, btn})
        },
        // 底部提交审批 footerSave
        handleSubmit ({ Vue, pageConfig, btn }) {
            this.$emit('handleFooterSubmit', {Vue, pageConfig, btn})
        },
        // 底部保存
        handleSave ({ Vue, pageConfig, btn }) {
            this.$emit('handleFooterSave', {Vue, pageConfig, btn})
        },
        // 底部保存
        handleReject ({ Vue, pageConfig, btn }) {
            this.$emit('handleFooterReject', {Vue, pageConfig, btn})
        },
        handleGridDelete ({ Vue, pageConfig, btn }) {
            this.$emit('handleToolbarGridDelete', {Vue, pageConfig, btn, groupCode: this.groupCode})
        },
        // 导出 Excel
        handleGridExportExcel ({ Vue, pageConfig, btn }) {
            this.$emit('handleToolbarGridExportExcel', {Vue, pageConfig, btn, groupCode: this.groupCode})
        }
    }
}
</script>


<style lang="scss" scoped>
.BusinessButton {
    display: inline-block;
    margin-left: 10px;
    .custom-mport,.CustomUpload {
        & + .btn {
            margin-left: 6px;
        }
    }
    .btn {
        & + .btn {
            margin-left: 6px;
        }
    }
}
</style>
