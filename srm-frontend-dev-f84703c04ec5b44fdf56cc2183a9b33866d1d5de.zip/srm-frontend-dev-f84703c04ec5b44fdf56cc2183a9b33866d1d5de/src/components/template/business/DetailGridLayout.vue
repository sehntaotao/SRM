<!--
 * @Author: your name
 * @Date: 2021-05-31 14:35:50
 * @LastEditTime: 2021-09-18 11:40:45
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \srm-frontend_v4.5\src\components\template\container\DetailGridLayout.vue
-->
<template>
  <div>
    <vxe-grid
      v-bind="gridConfig"
      :ref="group.groupCode"
      :columns="group.columns"
      :data="gridData">
      <!-- 表格代码编辑器 -->
      <template #code_editor_col_render="{row,column}">
        <code-editor-model
          :value="row[column.property]"
          @handleSureClick="(content)=> {row[column.property] = content}"></code-editor-model>
      </template>
      <!-- 表格富文本编辑器 -->
      <template #rich_editor_col_render="{row,column}">
        <rich-editor-model
          :value="row[column.property]"
          @handleSureClick="(content)=> {row[column.property] = content}"></rich-editor-model>
      </template>
      <template #renderDictLabel="{ row, column }">
        <span>
          {{ getDictLabel(row, column) }}
        </span>
      </template>
      <template #toolbar_buttons>
        <!-- <span 
          v-for="(btn, btnIndex) in group.externalToolBar" 
          class="tools-btn"
          :key="'btn_' + btnIndex">
          <a-button
            v-if="btn.click && btn.type !== 'upload'"
            :type="btn.type"
            @click="btn.click">
            {{ btn.title }}
          </a-button>
          <custom-upload
            v-if="btn.type === 'upload'"
            :single="btn.single"
            :disabledItemNumber="btn.disabledItemNumber"
            :requiredFileType="btn.requiredFileType"
            :property="btn.property"
            :visible.sync="btn.modalVisible"
            :title="btn.title"
            :itemInfo="itemInfo"
            :action="url.upload"
            :accept="accept"
            :headers="tokenHeader"
            :data="{businessType: btn.businessType, headId: form.id}"
            @change="(info) => handleUploadChange(info, btn, group.custom.ref)"
          >
            <a-button
              v-if="btn.beforeChecked"
              type="primary"
              icon="cloud-upload"
              @click="checkedGridSelect(btn, group.custom.ref, btn.beforeCheckedCallBack)">{{ btn.title }}</a-button>
          </custom-upload>
        </span> -->
        <business-button
          :buttons="group.externalToolBar"
          :groupCode="group.groupCode"
          :pageConfig="pageConfig"
          isToolbarButtons
          v-bind="$attrs"
          v-on="$listeners"
        />
      </template>
      <template #grid_opration="{ row, column }">
        <div v-if="group.extend && group.extend.optColumnList">
          <span
            v-for="(opt, optIndex) in group.extend.optColumnList"
            :key="'opt_'+ row.id + '_' + optIndex">
            <a
              :title="opt.title"
              style="margin:0 4px"
              :disabled="opt.disabled"
              v-show="!opt.hide"
              @click="()=> { optColumnFuntion(opt, row, column) }">{{ opt.title }}</a>
          </span>
        </div>
      </template>
      <!--使用 bottom 插槽-->
      <template #bottom>
        <div
          class="summary-message"
          v-if="group.total.totalValue">
          <span class="summary-message-content">
            {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }} {{ $srmI18n(`${$getLangAccount()}#${group.i18n_title_generalSummary}`, '总汇总') }}：<span class="total-num">{{ group.total.totalValue }}</span></span>
        </div>
      </template>
    </vxe-grid>
  </div>
</template>
<script>
import { ListConfig } from '@/plugins/table/gridConfig'
import BusinessButton from './components/BusinessButton'
import RichEditorModel from '@comp/richEditorModel/RichEditorModel'
export default {
    name: 'DetailGridLayout',
    components: {
        RichEditorModel,
        BusinessButton
    },
    props: {
        // 传入归属方busAccount
        busAccount: {
            required: true,
            type: String,
            default: null
        },
        group: {
            type: Object,
            required: true,
            default: ()=> {
                return {}
            }
        },
        loadData: {
            type: Array,
            default: ()=> {
                return []
            }
        },
        pageConfig: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    data () {
        return {
            // gridConfig: {
            //     border: true,
            //     resizable: true,
            //     autoResize: true,
            //     keepSource: true,
            //     height: 'auto',
            //     showOverflow: true,
            //     showHeaderOverflow: true,
            //     columnKey: true,
            //     highlightHoverRow: true,
            //     size: 'mini',
            //     align: 'center',
            //     headerAlign: 'center',
            //     toolbarConfig: {
            //         slots: {buttons: 'toolbar_buttons'},
            //         perfect: true
            //     }
            // },
            //默认表格配置
            gridConfig: ListConfig,
            gridData: this.loadData || []
        }
    },
    computed: {
        // 最小高度，防止tab页面高度自动
        gridHeight () {
            let minHeight = 0
            let clientHeight = document.documentElement.clientHeight
            minHeight = clientHeight - 260
            return minHeight
        }
    },
    watch: {
        loadData: {
            immediate: true,
            handler: function (val) {
                this.gridData = val
                console.log(this.gridData)
                this.loadGridData()
            }
        }
    },
    methods: {
        // 操作列方法
        optColumnFuntion (opt, row, col) {
            opt.click && opt.click(this, row, col)
        },
        loadGridData () {
            let that = this
            this.$nextTick(()=> {
                if (that.$refs[that.group.groupCode]) {
                    that.$refs[that.group.groupCode].loadData(that.gridData)
                }
            })
        },
        // 通过value显示label
        getDictLabel (row, column) {
            // 如果没有配置数据字典则走返回的field key值
            return row[column.own.field + '_dictText'] || row[column.own.field] 
        }
    }
}
</script>
<style lang="less" scoped>
.summary-message {
  height: 14px;
  display: flex;
  align-items: center;
  margin: 10px 0;
}
.summary-message-content {
  flex-grow: 1;
  font-weight: bolder;
  .total-num {
    font-size: 16px;
    color: red;
  }
}
</style>