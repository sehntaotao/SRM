<template>
  <div class="page-container">
    <div :class="isEdit? 'edit-page':'detail-page'">
      <a-spin :spinning="confirmLoading">
        <div
          class="page-header"
          v-if="pageHeaderButtons && pageHeaderButtons.length">
          <a-row>
            <a-col
              class="desc-col"
              :style="getDefaultColor"
              :span="6">
              <span v-if="isEdit">{{ $srmI18n(`${$getLangAccount()}#i18n_title_edit`, '编辑') }}{{ currentPageName }}</span>
              <span v-else>{{ currentPageName }}{{ $srmI18n(`${$getLangAccount()}#i18n_title_details`, '详情') }}</span>
            </a-col>
            <a-col
              class="btn-col"
              :span="18">
              <template v-if="isEdit && displayModel==='tab'">
                <a-button
                  style="margin-right: 10px;"
                  :type="customPageFooterPreBtn.type"
                  v-if="currentStep && displayModel==='tab'"
                  @click="customPageFooterPreBtn.click">{{ customPageFooterPreBtn.title }}</a-button>
                <a-button
                  :type="customPageFooterNextBtn.type"
                  v-if="currentStep<(pageConfig.groups.length-1) && displayModel==='tab'"
                  @click="customPageFooterNextBtn.click">{{ customPageFooterNextBtn.title }}</a-button>
              </template>
              <business-button
                :buttons="pageHeaderButtons"
                :pageConfig="pageConfig"
                :resultData="resultData"
                v-on="$listeners">
              </business-button>
            </a-col>
          </a-row>
        </div>
        <div
          class="page-header"
          v-if="isEdit && displayModel==='tab'">
          <a-steps
            :current="currentStep"
            @change="(step)=> { this.currentStep= step}"
            size="small">
            <a-step
              v-for="group in pageConfig.groups"
              size="small"
              :key="group.groupCode">
              <template slot="title">
                <a-tooltip :title="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)">
                  {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }}
                </a-tooltip>
              </template>
            </a-step>
          </a-steps>
        </div>
        <div
          class="page-content"
          :style="{height: pageContentHeight + 'px' }">
          <template
            v-if="displayModel==='tab'">
            <template v-if="isEdit">
              <div
                v-for="(group, index) in pageConfig.groups"
                :key="group.groupCode"
                v-show="currentStep === index">
                <edit-form-layout 
                  v-if="group.groupType==='head' && group.show"
                  :ref="group.groupCode+ 'form'"
                  :busAccount="busAccount"
                  :currentStep="currentStep"
                  :currentEditRow="currentEditRow"
                  :group="group"
                  :pageConfig="pageConfig"
                  v-on="$listeners"
                ></edit-form-layout>
                <edit-grid-layout
                  :style="{height: gridHeight }"
                  v-if="group.groupType==='item' && group.show"
                  :ref="group.groupCode + 'grid'"
                  :busAccount="busAccount"
                  :resultData="resultData"
                  :currentStep="currentStep"
                  :currentEditRow="currentEditRow"
                  :gridLoading="gridLoading"
                  :group="group"
                  :loadData="group.loadData"
                  :pageConfig="pageConfig"
                  v-on="$listeners">
                </edit-grid-layout>
              </div>
            </template>
            <template v-else>
              <a-tabs>
                <a-tab-pane 
                  v-for="(group) in pageConfig.groups"
                  :key="group.groupCode" 
                  forceRender
                  :tab="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)">
                  <detail-form-layout
                    v-if="group.groupType==='head' && group.show"
                    :ref="group.groupCode+ 'form'"
                    :busAccount="busAccount"
                    :group="group"
                    :pageConfig="pageConfig"></detail-form-layout>
                  <detail-grid-layout
                    :style="{height: gridHeight }"
                    v-if="group.groupType==='item' && group.show"
                    :ref="group.groupCode + 'grid'"
                    :resultData="resultData"
                    :pageConfig="pageConfig"
                    :busAccount="busAccount"
                    :group="group"
                    :loadData="group.loadData"></detail-grid-layout>
                </a-tab-pane>
              </a-tabs>
            </template>
          </template>
          <template v-if="displayModel==='collapse'">
            <template v-if="isEdit">
              <a-collapse
                forceRender
                :default-active-key="pageConfig.groups[0].groupCode"
              >
                <template v-for="(group) in pageConfig.groups">
                  <a-collapse-panel
                    v-if="group.show"
                    :key="group.groupCode"
                    :header="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)"
                  >
                    <edit-form-layout 
                      v-if="group.groupType==='head'"
                      :ref="group.groupCode+ 'form'"
                      :busAccount="busAccount"
                      :currentStep="currentStep"
                      :currentEditRow="currentEditRow"
                      :group="group"
                      :pageConfig="pageConfig"
                      v-on="$listeners"
                    ></edit-form-layout>
                    <edit-grid-layout 
                      :style="{height: gridHeight }"
                      v-if="group.groupType==='item'"
                      :ref="group.groupCode + 'grid'"
                      :busAccount="busAccount"
                      :currentStep="currentStep"
                      :currentEditRow="currentEditRow"
                      :resultData="resultData"
                      :gridLoading="gridLoading"
                      :group="group"
                      :loadData="group.loadData"
                      :pageConfig="pageConfig"
                      v-on="$listeners">
                    </edit-grid-layout>
                  </a-collapse-panel>
                </template>
              </a-collapse>
            </template>
            <template v-else>
              <a-collapse
                :style="{height: gridHeight }"
                forceRender
                :default-active-key="pageConfig.groups[0].groupCode"
              >
                <template v-for="(group) in pageConfig.groups">
                  <a-collapse-panel
                    v-if="group.show"
                    :key="group.groupCode"
                    :header="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)"
                  >
                    <detail-form-layout
                      v-if="group.groupType==='head'"
                      :ref="group.groupCode+ 'form'"
                      :busAccount="busAccount"
                      :group="group"
                      :pageConfig="pageConfig"></detail-form-layout>
                    <detail-grid-layout 
                      :style="{height: gridHeight }"
                      v-if="group.groupType==='item'"
                      :ref="group.groupCode + 'grid'"
                      :resultData="resultData"
                      :pageConfig="pageConfig"
                      :busAccount="busAccount"
                      :group="group"
                      :loadData="group.loadData"></detail-grid-layout>
                  </a-collapse-panel>
                </template>
              </a-collapse>
            </template>
          </template>
          <template v-if="displayModel==='unCollapse'">
            <template v-if="isEdit">
              <div
                v-for="(group) in pageConfig.groups"
                :key="group.groupCode">
                <div
                  class="item-box-title dark"
                  v-if="group.show">
                  {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }}
                </div>
                <edit-form-layout 
                  v-if="group.groupType==='head' && group.show"
                  :ref="group.groupCode+ 'form'"
                  :busAccount="busAccount"
                  :currentStep="currentStep"
                  :currentEditRow="currentEditRow"
                  :group="group"
                  :pageConfig="pageConfig"
                  v-on="$listeners"
                ></edit-form-layout>
                <edit-grid-layout 
                  :style="{height: gridHeight }"
                  v-if="group.groupType==='item' && group.show"
                  :ref="group.groupCode + 'grid'"
                  :busAccount="busAccount"
                  :currentStep="currentStep"
                  :currentEditRow="currentEditRow"
                  :gridLoading="gridLoading"
                  :resultData="resultData"
                  :group="group"
                  :loadData="group.loadData"
                  :pageConfig="pageConfig"
                  v-on="$listeners">
                </edit-grid-layout>
              </div>
            </template>
            <template v-else>
              <div :style="{height: gridHeight }">
                <div
                  v-for="(group) in pageConfig.groups"
                  :key="group.groupCode" 
                  forceRender
                  :tab="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)">
                  <div
                    class="item-box-title dark"
                    v-if="group.show">
                    {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }}
                  </div>
                  <detail-form-layout
                    v-if="group.groupType==='head' && group.show"
                    :ref="group.groupCode+ 'form'"
                    :busAccount="busAccount"
                    :group="group"
                    :pageConfig="pageConfig"></detail-form-layout>
                  <detail-grid-layout 
                    v-if="group.groupType==='item' && group.show"
                    :ref="group.groupCode + 'grid'"
                    :busAccount="busAccount"
                    :resultData="resultData"
                    :pageConfig="pageConfig"
                    :group="group"
                    :loadData="group.loadData"></detail-grid-layout>
                </div>
              </div>
            </template>
          </template>
          <template v-if="displayModel==='masterSlave'">
            <template v-if="isEdit">
              <a-collapse
                forceRender
                v-if="collapseHeadCode.length"
                :activeKey="localCollapseKeys"
              >
                <template v-for="(group) in pageConfig.groups">
                  <a-collapse-panel
                    v-if="localCollapseHeadCode.includes(group.groupCode) && group.show"
                    :key="group.groupCode"
                    :header="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)"
                  >
                    <edit-form-layout 
                      v-if="group.groupType==='head' && group.show"
                      :ref="group.groupCode+ 'form'"
                      :busAccount="busAccount"
                      :currentStep="currentStep"
                      :currentEditRow="currentEditRow"
                      :group="group"
                      :pageConfig="pageConfig"
                      v-on="$listeners"
                    ></edit-form-layout>
                    <edit-grid-layout 
                      :style="{height: gridHeight }"
                      v-if="group.groupType==='item' && group.show"
                      :ref="group.groupCode + 'grid'"
                      :busAccount="busAccount"
                      :resultData="resultData"
                      :currentStep="currentStep"
                      :currentEditRow="currentEditRow"
                      :gridLoading="gridLoading"
                      :group="group"
                      :loadData="group.loadData"
                      :pageConfig="pageConfig"
                      v-on="$listeners">
                    </edit-grid-layout>
                  </a-collapse-panel>
                </template>
              </a-collapse>
              <div
                v-else
                v-for="(group, index) in pageConfig.groups"
                :key="group.groupCode">
                <div v-if="index===0 && group.show">
                  <div class="item-box-title dark">
                    {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }}
                  </div>
                  <edit-form-layout 
                    v-if="group.groupType==='head' && group.show"
                    :ref="group.groupCode+ 'form'"
                    :busAccount="busAccount"
                    :currentStep="currentStep"
                    :currentEditRow="currentEditRow"
                    :group="group"
                    :pageConfig="pageConfig"
                    v-on="$listeners"
                  ></edit-form-layout>
                </div>
              </div>
              <a-tabs>
                <template v-for="(group, index) in pageConfig.groups">
                  <template v-if="group.show">
                    <a-tab-pane
                      v-if="collapseHeadCode.length ? !localCollapseHeadCode.includes(group.groupCode) : index>0 "
                      :key="group.groupCode" 
                      forceRender
                      :tab="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)">
                      <template>
                        <edit-form-layout 
                          v-if="group.groupType==='head'"
                          :ref="group.groupCode+ 'form'"
                          :busAccount="busAccount"
                          :currentStep="currentStep"
                          :currentEditRow="currentEditRow"
                          :group="group"
                          :pageConfig="pageConfig"
                          v-on="$listeners"
                        ></edit-form-layout>
                        <edit-grid-layout 
                          :style="{height: gridHeight }"
                          v-if="group.groupType==='item'"
                          :ref="group.groupCode + 'grid'"
                          :busAccount="busAccount"
                          :currentStep="currentStep"
                          :resultData="resultData"
                          :currentEditRow="currentEditRow"
                          :gridLoading="gridLoading"
                          :group="group"
                          :loadData="group.loadData"
                          :pageConfig="pageConfig"
                          v-on="$listeners">
                        </edit-grid-layout>
                      </template>
                    </a-tab-pane>
                  </template>
                </template>
              </a-tabs>
            </template>
            <template v-else>
              <template
                :style="{height: gridHeight }">
                <a-collapse
                  forceRender
                  v-if="collapseHeadCode.length"
                  :activeKey="localCollapseKeys"
                >
                  <template v-for="(group) in pageConfig.groups">
                    <a-collapse-panel
                      v-if="localCollapseHeadCode.includes(group.groupCode) && group.show"
                      :key="group.groupCode"
                      :header="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)"
                    >
                      <detail-form-layout
                        v-if="group.groupType==='head' && group.show"
                        :ref="group.groupCode+ 'form'"
                        :busAccount="busAccount"
                        :group="group"
                        :pageConfig="pageConfig"></detail-form-layout>
                      <detail-grid-layout
                        :style="{height: gridHeight }"
                        v-if="group.groupType==='item' && group.show"
                        :ref="group.groupCode + 'grid'"
                        :resultData="resultData"
                        :pageConfig="pageConfig"
                        :busAccount="busAccount"
                        :group="group"
                        :loadData="group.loadData"></detail-grid-layout>
                    </a-collapse-panel>
                  </template>
                </a-collapse>
                <div
                  v-else
                  v-for="(group, index) in pageConfig.groups"
                  :key="group.groupCode">
                  <div v-if="index===0 && group.show">
                    <div class="item-box-title dark">
                      {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }}
                    </div>
                    <detail-form-layout
                      v-if="group.groupType==='head' && group.show"
                      :ref="group.groupCode+ 'form'"
                      :busAccount="busAccount"
                      :resultData="resultData"
                      :group="group"
                      :pageConfig="pageConfig"></detail-form-layout>
                  </div>
                </div>
                <a-tabs>
                  <template v-for="(group, index) in pageConfig.groups">
                    <template v-if="group.show">
                      <a-tab-pane
                        v-if="collapseHeadCode.length ? !localCollapseHeadCode.includes(group.groupCode) : index>0"
                        :key="group.groupCode" 
                        forceRender
                        :tab="$srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName)">
                        <template>
                          <detail-form-layout
                            v-if="group.groupType==='head'"
                            :ref="group.groupCode+ 'form'"
                            :busAccount="busAccount"
                            :group="group"
                            :pageConfig="pageConfig"></detail-form-layout>
                          <detail-grid-layout 
                            :style="{height: gridHeight }"
                            v-if="group.groupType==='item'"
                            :ref="group.groupCode + 'grid'"
                            :busAccount="busAccount"
                            :resultData="resultData"
                            :pageConfig="pageConfig"
                            :group="group"
                            :loadData="group.loadData"></detail-grid-layout>
                        </template>
                      </a-tab-pane>
                    </template>
                  </template>
                </a-tabs>
              </template>
            </template>
          </template>
        </div>
        <div
          class="page-footer"
          v-if="isEdit && pageConfig.pageFooterButtons && pageConfig.pageFooterButtons.length">
          <a-button
            :type="customPageFooterPreBtn.type"
            v-if="currentStep && displayModel==='tab'"
            @click="customPageFooterPreBtn.click">{{ customPageFooterPreBtn.title }}</a-button>
          <a-button
            :type="customPageFooterNextBtn.type"
            v-if="currentStep<(pageConfig.groups.length-1) && displayModel==='tab'"
            @click="customPageFooterNextBtn.click">{{ customPageFooterNextBtn.title }}</a-button>
            
          <business-button
            :buttons="pageFooterButtons"
            :pageConfig="pageConfig"
            :resultData="resultData"
            v-on="$listeners"
          />
        </div>
      </a-spin>
      <!-- 加载配置文件 -->
      <remote-js
        v-if="remoteJsFilePath"
        :remoteFileSrc="remoteJsFileSrc"
        @load="loadRemoteJsSuccess"
        @error="loadRemoteJsError"
      >
      </remote-js>
    </div>
  </div>
</template>
<script>
import {ajaxFindDictItems} from '@/api/api'
import { getAction, postAction } from '@/api/manage'
import { USER_ELS_ACCOUNT, DEFAULT_COLOR } from '@/store/mutation-types'
import { EditConfig } from '@/plugins/table/gridConfig'
import MUpload from '@comp/mUpload'
import MTreeSelect from '@comp/treeSelect/mTreeSelect'
import DetailFormLayout from '@comp/template/business/DetailFormLayout.vue'
import DetailGridLayout from '@comp/template/business/DetailGridLayout.vue'
import EditGridLayout from '@comp/template/business/EditGridLayout.vue'
import EditFormLayout from '@comp/template/business/EditFormLayout.vue'
import CustomUpload from '@comp/template/CustomUpload'
import RichEditorModel from '@comp/richEditorModel/RichEditorModel'
import {Collapse} from 'ant-design-vue'
import { isArray, mergeWith, cloneDeep, sortBy } from 'lodash'
import BusinessButton from './components/BusinessButton'

export default {
    name: 'BusinessLayout',
    inject: ['tplRootRef'],
    props: {
        // 当前编辑行的数据
        currentEditRow: {
            required: true,
            type: Object,
            default: () => {
                return {}
            }
        },
        // 获取自定义的模板路径
        remoteJsFilePath: {
            type: String,
            default: null
        },
        // 配置数据组装前，返回所有的的组装数据{}
        handleBeforeRemoteConfigData: {
            type: Function
        },
        // 处理完所有的数据，如有需要，暴露给外部处理最后的数据
        handleAfterDealSource: {
            type: Function
        },
        // 接口请求数据
        requestData: {
            type: Object,
            default: ()=> {
                return {
                    // url:string,method:get/post,args:function
                    detail: {}
                    // 模板下载:/system/excelByConfig/downloadTemplate
                    // export: {}
                    // Excel导入:/system/excelByConfig/importExcel
                    // import: {}
                }
            }
        },
        // 不用接口请求外部传入的数据
        fromSourceData: {
            type: Object,
            default: () => {
                return {}
            }
        },
        // 页面的状态
        pageStatus: {
            type: String,
            default: 'edit'
        },
        // 头部的工具栏 {groupCode: [] }
        externalToolBar: {
            type: Object,
            default: ()=> {
                return {}
            }
        },
        // 底部按钮
        pageFooterButtons: {
            type: Array
        },
        // 详情头部按钮
        pageHeaderButtons: {
            type: Array
        },
        // 模式布局方式： tab格式：tab，折叠格式：collapse，非折叠格式：unCollapse，单一主从格式：masterSlave
        modelLayout: {
            type: String,
            default: 'tab'
        },
        // modelLayout 是主从masterSlave可折叠的数组 [{code:'baseForm', expand: true}, {code:'eightDisciplinesTeamList', expand: true}]
        // 如果是一维数组折默认打开所有的折叠
        collapseHeadCode: {
            type: Array,
            default: ()=> {
                return []
            }
        }
    },
    inheritAttrs: false,
    components: {
        BusinessButton,
        MUpload,
        MTreeSelect,
        CustomUpload,
        DetailFormLayout,
        DetailGridLayout,
        EditFormLayout,
        EditGridLayout,
        RichEditorModel,
        ACollapse: Collapse,
        remoteJs: {
            render (createElement) {
                let self = this
                return createElement('script', {
                    attrs: { type: 'text/javascript', src: this.remoteFileSrc, async: true },
                    on: {
                        load: function (event) {
                            self.$emit('load', event)
                        },
                        error: function (event) {
                            self.$emit('error', event)
                        }
                    }
                })
            },
            props: {
                remoteFileSrc: { 
                    type: String, 
                    required: false 
                }
            }
        }
    },
    data () {
        return {
            resultData: {}, // 明细接口请求数据
            gridLoading: false,
            confirmLoading: false,
            currentStep: 0,
            currentPageName: null,
            // form表单默认配置
            formModelConfig: {
                labelCol: { span: 9 },
                wrapperCol: { span: 15 }
            },
            //默认表格配置
            gridConfig: EditConfig,
            pageConfig: {
                groups: [
                    {
                        groupCode: null, // 分组编码,可自定义,要求对应后端的字段ref
                        groupName: null, // 分组显示的名称
                        groupType: null, // head头分组-表单, item行分组-表格
                        // 表单专有,groupType为head时
                        // form表单的model对象
                        formModel: {
                            id: null// form表单id
                        }, 
                        validateRules: null, // form表单的验证规则对象
                        // form表单字段数组
                        formFields: [
                            {
                                fieldType: null, // 字段类型
                                fieldName: null, // 字段名
                                fieldLabel: null, // 字段显示名称
                                helpText: null, // 字段显示名称超出提示内容
                                disabled: null, // 字段是否可编辑
                                placeholder: null, // 字段类型的placeholder
                                dictCode: null, // 字段数据字典code，用于请求数据字典数据
                                extend: null, // 表单字段扩展，m-tree-select使用，暂时不清楚具体的配置
                                sourceMap: null, // 表单字段扩展，m-tree-select使用，暂时不清楚具体的配置
                                showEmptyNode: null // 表单字段扩展，m-tree-select使用，暂时不清楚具体的配置
                            }
                        ], 
                        // 表格专有的字段
                        editConfig: {}, // 表格编辑配置
                        editRules: {}, // 表格编辑验证规则
                        columns: [], // 表格列
                        toolbarButtons: [], // 表格工具栏 
                        gridOpration: [], // 表格操作栏
                        total: {culumnName: null, totalValue: null} // 单个表格汇总
                    }
                ],
                pageFooterButtons: [] // 底部按钮
            },
            editFormData: {},
            // 上一步配置
            customPageFooterPreBtn: {title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_prevStep`, '上一步'),  type: 'primary', belong: 'preStep', click: this.prevStep },
            // 下一步配置
            customPageFooterNextBtn: { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_nextStep`, '下一步'), type: 'primary', belong: 'nextStep', click: this.nextStep },
            localCollapseHeadCode: [], // modelLayout 是主从masterSlave可折叠的数组 ['baseForm', 'eightDisciplinesTeamList']
            localCollapseKeys: [] // 折叠打开数组
        }
    },
    computed: {
        pageContentHeight () {
            let contentHeight = '600'
            const clientHeight = document.documentElement.clientHeight
            if (this.displayModel==='tab') {
                contentHeight = clientHeight - 186
            } else {
                contentHeight = clientHeight - 146
            }
           
            return contentHeight
        },
        gridHeight () {
            let height = '100'
            if (this.displayModel === 'tab') {
                const clientHeight = document.documentElement.clientHeight
                height = clientHeight - 260
            } else if (this.displayModel === 'collapse') {
                height = 300
            }  else if (this.displayModel === 'unCollapse') {
                height = 300
            }  else if (this.displayModel === 'masterSlave') {
                height = 500
            }
            return height + 'px'
        },
        displayModel () {
            return this.modelLayout
        },
        // 远程模板地址路径
        remoteJsFileSrc () {
            let remoteJsPath = this.remoteJsFilePath
            let time = new Date().getTime()
            // ${this.$variateConfig['configFiles']}/${elsAccount}/purchase_delivery_${templateNumber}_${templateVersion}.js?t=`+time
            return `${this.$variateConfig['configFiles']}/${remoteJsPath}.js?t=`+time
        },
        // 判断页面是编辑态还是详情态
        isEdit () {
            let flag = this.pageStatus === 'edit'
            return flag
        },
        // busAccount
        busAccount () {
            let account = this.$ls.get(USER_ELS_ACCOUNT)
            if (this.currentEditRow) {
                if (this.currentEditRow.busAccount || this.currentEditRow.elsAccount) {
                    account = this.currentEditRow.busAccount || this.currentEditRow.elsAccount
                }
            }
            return account
        },
        // 获取默认主题色
        getDefaultColor () {
            return {
                color: this.$ls.get(DEFAULT_COLOR)
            }
        }
    },
    mounted () {
        // 自定义组装数据时通过调用传入的方法组装
        if (!this.remoteJsFilePath) {
            this.initRemoteConfigData({})
        }
        // 当前页面的名称
        this.currentPageName = this.$route.meta? this.$route.meta.title: ''
    },
    methods: {
        prevStep () {
            this.currentStep > 0 && this.currentStep--
            this.preOrNextStepHandle('pre')
        },
        nextStep () {
            if(this.currentStep < this.pageConfig.groups.length - 1) {
                this.currentStep++
            }
            this.preOrNextStepHandle('next')
        },
        // 上一步和下一步的处理逻辑外部使用
        preOrNextStepHandle (type) {
            let formCompnent = null
            let gridCompnent = null
            let groupData = null
            if (this.pageConfig.groups[this.currentStep]) {
                let formRefName = this.pageConfig.groups[this.currentStep].groupCode
                let gridRefName = this.pageConfig.groups[this.currentStep].custom?this.pageConfig.groups[this.currentStep].custom.ref: ''
                formCompnent = formRefName? this.$refs[formRefName] : ''
                gridCompnent = gridRefName? this.$refs[gridRefName][0] : ''
                groupData = this.pageConfig.groups[this.currentStep]
            }
            let emitData ={ formCompnent: formCompnent, gridCompnent: gridCompnent, pageConfig: this.pageConfig, groupData: groupData, form: this.form}
            if (type === 'next') {
                this.$emit('nextStepHandle', emitData)
            } else {
                this.$emit('preStepHandle', emitData)
            }
        },
        // 表行编辑change事件
        changeGridItem (currentRow, currentValue, cb) {
            cb && cb(currentRow.row, currentRow.column, currentValue.value, this.$parent, this.tplRootRef) 
        },
        //远程配置加载成功执行
        loadRemoteJsSuccess () {
            let tempConfigData = getPageConfig() // eslint-disable-line
            this.initRemoteConfigData(tempConfigData)
        },
        //远程配置加载异常执行
        loadRemoteJsError (err) {
            this.$message.warning('获取模板失败, 请检查：'+ err)
        },
        // 组装远程配置数据前,返回组装前的所有数据
        beforeRemoteConfigData (remoteData) {
            // 混合本地与接口返回配置数据
            if (this.handleBeforeRemoteConfigData && typeof this.handleBeforeRemoteConfigData === 'function') {
                // 本地配置
                let localData = this.handleBeforeRemoteConfigData() || {}
                let cloneLocalData = cloneDeep(localData)
                let configData = mergeWith(remoteData, cloneLocalData, function (objValue, srcValue) {
                    if (isArray(objValue)) {
                        return objValue.concat(srcValue)
                    }
                })
                return configData
            } else {
                return remoteData
            }
        },
        // 组装远程的配置数据
        initRemoteConfigData (remoteData) {
            let that = this
            let initConfigData = this.beforeRemoteConfigData(remoteData)
            // 组装所有分组
            if (initConfigData && initConfigData.groups && initConfigData.groups.length) {
                initConfigData.groups = sortBy(initConfigData.groups, function (item) { return parseInt(item.sortOrder)})
                let sourceGroups = []
                initConfigData.groups.forEach((item)=> {
                    let group = {}
                    group.groupCode= item.groupCode
                    group.groupName= item.groupName
                    group.groupNameI18nKey = item.groupNameI18nKey
                    group.groupType= item.groupType
                    group.show= item.show || true
                    group.extend= item.extend || {}
                    group.total= { culumnName: null, totalValue: null }
                    // 表格工具栏, 如果是页面初始化传过来，全部以页面为主，如果从配置传过来，读取配置项工具栏数据
                    if (item.groupType === 'item') {
                        let initExternalToolBar= (toolbars)=> {
                            if (toolbars) {
                                // 正常情况key等于各个分组groupCode,当不知道分组时，找不到groupCode,所以统一用all代替，所有的表格顶部按钮一样比如成本报价
                                for(let key of Object.keys(toolbars) ) {
                                    if (key === 'all') {
                                        group.externalToolBar = toolbars[key]
                                        return false
                                    } else {
                                        if (key === group.groupCode) {
                                            group.externalToolBar = toolbars[key]
                                        }
                                    }
                                }
                            }
                        }
                        if (that.externalToolBar) {
                            initExternalToolBar(that.externalToolBar)
                        } else {
                            if (item.extend && item.extend.externalToolBar) {
                                initExternalToolBar(item.extend.externalToolBar)
                            }
                        }
                    }
                    sourceGroups.push(group)
                })
                // 表单配置项组装
                if (initConfigData && initConfigData.formFields && initConfigData.formFields.length) {
                    sourceGroups.forEach((groupData)=> {
                        let formFields = initConfigData.formFields.filter((filterData)=> {return filterData.groupCode===groupData.groupCode})
                        let formModel = {}
                        let validateRules = {}
                        formFields.forEach((field)=> {
                            if (groupData.groupType === 'head' && groupData.groupCode === field.groupCode) {
                                if (field.fieldType === 'treeSelect') {
                                    field.multiple = groupData.multiple || false
                                }
                                formModel[field.fieldName] = field.defaultValue
                                if (field.required === '1') {
                                    let msg = that.$srmI18n(`${that.busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel)
                                    let ruleRequired = that.$srmI18n(`${that.$getLangAccount()}#i18n_title_required`, '必填')
                                    validateRules[field.fieldName] = [{ required: true, message: `${msg}${ruleRequired}!` }]
                                }
                                if (field.regex) {
                                    const prop = field.fieldName
                                    validateRules[prop] = validateRules[prop] || []
                                    validateRules[prop].push({
                                        pattern: field.regex, message: field.alertMsg
                                    })
                                }
                                // 单个表单只有一个总汇总
                                if (field.sum === '1') {
                                    groupData.total.culumnName= field.fieldName
                                }
                                if (!field.disabled) {
                                    field.disabled = false
                                }
                            }
                        })
                        groupData.formModel = Object.assign({}, groupData.formModel, formModel)
                        groupData.validateRules = validateRules
                        groupData.formFields = formFields
                    })
                }
                // 表格列组装
                if (initConfigData && initConfigData.itemColumns && initConfigData.itemColumns.length) {
                    sourceGroups.forEach((groupData)=> {
                        // 拖动列
                        let dropColumn = {
                            width: 60,
                            visible: !!(groupData.extend && groupData.extend.dragAndDrop),
                            slots: {
                                default: () => {
                                    return [
                                        <span class="drag-btn">
                                            <i class="vxe-icon--menu"></i>
                                        </span>
                                    ]
                                },
                                header: () => {
                                    return [
                                        <vxe-tooltip content={this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pressHoldDragUpDown`, '按住后可以上下拖动排序！')} enterable>
                                            <i class="vxe-icon--question"></i>
                                        </vxe-tooltip>
                                    ]
                                }
                            }
                        }
                        let defaultColumns = [dropColumn, { type: 'checkbox', width: 40 }, { type: 'seq', width: 60, title: that.$srmI18n(`${that.$getLangAccount()}#i18n_title_seq`, '序号')}]
                        groupData.columns = defaultColumns.concat(initConfigData.itemColumns.filter((filterData)=> {return filterData.groupCode==groupData.groupCode}))
                        let rules = {}
                        let gridEditConfig = {}
                        groupData.columns.forEach((col)=> {
                            if (groupData.groupType === 'item' && groupData.groupCode === col.groupCode) {
                                // 单个表格只有一个总汇总
                                if (col.sum === '1') {
                                    groupData.total.culumnName= col.field
                                }
                                // 是否必填
                                if (col.required === '1') {
                                    let msg = that.$srmI18n(`${that.busAccount}#${col.fieldLabelI18nKey}`, col.title)
                                    let ruleRequired = that.$srmI18n(`${that.$getLangAccount()}#i18n_title_required`, '必填')
                                    rules[col.field] = [{ required: true, message: `${msg}${ruleRequired}!` }]
                                }
                                // 是否正则表达式验证
                                if (col.regex) {
                                    const prop = col.field
                                    rules[prop] = rules[prop] || []
                                    rules[prop].push({
                                        pattern: col.regex, message: col.alertMsg
                                    })
                                }
                                // 编辑态的显示-隐藏有col.slots，配置项与vxe-table的slots的配置参数一样
                                switch(col.fieldType) {
                                case 'input':
                                    col.editRender = { name: '$input', events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'textArea':
                                    col.editRender = { name: 'srmTextArea', events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'select':
                                    col.editRender = { name: 'srmSelect', options: that.queryDictData(col), events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'switch':
                                    col.cellRender = { name: '$switch', props: { openValue: '1', closeValue: '0' }, events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'date':
                                    col.editRender = { name: 'mDatePicker', events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'number':
                                    col.editRender = { name: '$input', props: {type: 'number'}, events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'float':
                                    col.editRender = { name: '$input', props: {type: 'float', digits: 4}, events: {change: (currentRow, currentValue)=> {that.changeGridItem(currentRow, currentValue, col.bindFunction)} } }
                                    break
                                case 'computed':
                                    col.editRender = { name: '$input', events: {blur: (currentRow)=> {that.blurGridItem(currentRow, col, groupData)} } }
                                    break
                                case 'selectModal':
                                    col.slots = Object.assign({}, col.slots, {
                                        default: ({row, rowIndex, column, columnIndex}) => {
                                            const scopedSlots = {
                                                default: ({ openFunc }) => {
                                                    const tpl = (
                                                        <div style="position: relative;min-height: 30px;padding-right: 20px;">
                                                            {row[column.property]}
                                                            <a style="position: absolute;display: inline-block;font-size: 16px;right: 0px; top: 3px;z-index: 10;">
                                                                <a-icon type="file-search" onClick={() => { openFunc && openFunc() }} />
                                                            </a>
                                                        </div>
                                                    )
                                                    const detailTpl = (
                                                        <div style="position: relative;min-height: 30px;padding-right: 20px;">
                                                            {row[column.property]}
                                                        </div>
                                                    )
                                                    return that.pageStatus == 'edit' ? tpl : detailTpl
                                                }
                                            }
                                            const props = {
                                                config: col,
                                                row: row,
                                                form: that.editFormData,
                                                isRow: true
                                            }
                                            const on = {
                                                afterClearCallBack: (cb) => cb && cb(that, row, col, rowIndex, columnIndex ),
                                                ok: (data) => { col.bindFunction && col.bindFunction(row, data, that, that.tplRootRef) }
                                            }
                                            return [
                                                (<m-select-modal scopedSlots={ scopedSlots } { ...{ props, on } } />)
                                            ]
                                        }
                                    })
                                    break
                                case 'richEditorModel': 
                                    col.slots= Object.assign({}, col.slots, { default: 'rich_editor_col_render'})
                                    break
                                }
                                // 自定义渲染
                                if (col.slots) {
                                    // 头部slots
                                    col.slots.header = ({ column }) => {
                                        const flag = !!(column.helpText)
                                        const dom = flag
                                            ? (<vxe-tooltip content={ column.helpText }>
                                                <span style="display: flex; alignItems: center;">
                                                    <i class="vxe-icon--question"></i>
                                                    <span style="marginLeft: 6px;">{ column.title }</span>
                                                </span>
                                            </vxe-tooltip>)
                                            : (<span>{ column.title }</span>)
                                        return [
                                            dom
                                        ]
                                    }
                                }
                            }
                        })
                        groupData.editRules = rules
                        // 编辑规则
                        if (groupData.extend && groupData.extend.editConfig) {
                            gridEditConfig.trigger= groupData.extend.editConfig.trigger || 'click'
                            gridEditConfig.mode= groupData.extend.editConfig.mode || 'cell'
                            gridEditConfig.showStatus= groupData.extend.editConfig.showStatus || true
                            if (groupData.extend.editConfig.activeMethod) {
                                gridEditConfig.activeMethod= (gridData)=> { return that.gridActiveMethod(gridData, groupData.extend.editConfig.activeMethod) }
                            }
                            groupData.editConfig = gridEditConfig
                        } else {
                            groupData.editConfig= {
                                trigger: 'click',
                                mode: 'cell',
                                showStatus: true
                            }
                        }
                    })
                }
                // 分组模板
                that.$set(that.pageConfig, 'groups', sourceGroups)
                // 底部按钮组
                if (that.pageFooterButtons && that.pageFooterButtons.length) {
                    that.$set(that.pageConfig, 'pageFooterButtons', that.pageFooterButtons)
                }
                // 赋值-组装data
                if (that.requestData && that.requestData.detail && that.requestData.detail.url) {
                    that.queryDetail()
                } else if (that.fromSourceData && Object.keys(that.fromSourceData).length) {
                    that.initMockData(that.fromSourceData)
                }
            }
        },
        // 获取表格下拉字典
        queryDictData (column) {
            const that = this
            if (column && column.dictCode) {
                let postData = {
                    busAccount: that.busAccount || that.$ls.get(USER_ELS_ACCOUNT),
                    dictCode: column.dictCode
                }
                ajaxFindDictItems(postData).then(res => {
                    if(res.success) {
                        let options = res.result.map((dictItem) => {
                            return {
                                value: dictItem.value,
                                label: dictItem.text,
                                title: dictItem.title
                            }
                        })
                        if (column.editRender) {
                            column.editRender.options = options
                        }
                        // dictOptions初始化数据字典的字段会用到
                        column.dictOptions= options
                        that.$forceUpdate()
                    } else {
                        if (column.editRender) {
                            column.editRender.options = []
                        }
                        // dictOptions初始化数据字典的字段会用到
                        column.dictOptions= []
                        that.$forceUpdate()
                    }
                })
            } else {
                if (column.editRender) {
                    column.editRender.options = []
                }
                // dictOptions初始化数据字典的字段会用到
                column.dictOptions= []
                that.$forceUpdate()
            }
        },
        // 处理获取数据，将接口或者自定义的数据所有key赋值
        dealSource (resultData) {
            this.resultData = resultData
            // this.showBusinessButton = true
            const that = this
            that.pageConfig.groups.forEach((group)=> {
                const _show = group.show == false ? false : true
                if (group.groupType === 'head' && _show) {
                    // 循环匹配
                    let currentHeadTag = null
                    for (let resultDataKey in resultData) {
                        if (group.groupCode === resultDataKey) {
                            currentHeadTag = resultDataKey
                        }
                    }
                    if (group.formModel) {
                        if (currentHeadTag) {
                            // currentHeadTag内容可能为空
                            if (resultData[currentHeadTag]) {
                                group.formModel = Object.assign(group.formModel, resultData[currentHeadTag])
                            }
                        } else {
                            group.formModel = Object.assign(group.formModel, resultData)
                            // 删除不属于当前组里面formModel的值
                            for (let key in group.formModel) {
                                that.pageConfig.groups.forEach((groupItem)=> {
                                    if (groupItem.groupType === 'item' && key === groupItem.groupCode) {
                                        delete group.formModel[key]
                                    }
                                })
                            }
                        }
                    }
                    group.formModel = Object.assign({}, group.formModel)
                    that.$nextTick(()=> {
                        const formFields = group.formFields || []
                        formFields.forEach((field) => {
                            const { bindFunction, fieldName, fieldType, groupCode, defaultValue } = field
                            const Fdom = that.$refs[`${groupCode}form`]
                            if (bindFunction && typeof bindFunction === 'function' && Fdom) {
                                const formRef = Fdom[0]
                                const groupData = group
                                const value = group.formModel[fieldName] || defaultValue
                                if (fieldType !== 'selectModal') {
                                    if (fieldType === 'input') {
                                        bindFunction.call(null, that.$parent, formRef.$refs[groupCode], that.pageConfig, groupData, value, field, group.formModel, '', that.tplRootRef )
                                    } else {
                                        bindFunction.call(null, that.$parent, formRef.$refs[groupCode], that.pageConfig, groupData, value, [], '', group.formModel, that.tplRootRef)
                                    }
                                }
                            }
                        })
                    })
                }
                if (group.groupType === 'item' && _show) {
                    group.loadData=resultData[group.groupCode]
                    if(resultData[group.groupCode] && resultData[group.groupCode].length) {
                        that.countTotalValue(resultData, group)
                    }
                }
            })
            // 数据返回后，如有需要，暴露给外部使用
            if (this.handleAfterDealSource && typeof this.handleAfterDealSource === 'function') {
                return this.handleAfterDealSource(that.pageConfig, resultData)
            }
        },
        // 获取静态数据
        initMockData (data) {
            this.dealSource(data)
        },
        // 通过接口获取数据
        async queryDetail () {
            const that = this
            this.confirmLoading = true
            if (this.requestData.detail) {
                let url = this.requestData.detail.url
                if (url) {
                    let method = 'get'
                    let args = this.requestData.detail.args(that)
                    // 有id 才能请求,新建时是没有id的，不用请求查询接口
                    if (args && args.id) {
                        if (this.requestData.detail.method) {
                            method= this.requestData.detail.method.toLowerCase()
                        }
                        let query = method==='get'?await getAction(url, args): await postAction(url, args)
                        this.confirmLoading = false
                        if (query && query.success) {
                            that.editFormData = query.result
                            that.dealSource(query.result)
                        } else {
                            that.$message.error(query.message)
                        }
                    } else {
                        this.confirmLoading = false
                        this.$nextTick(()=> {
                            that.dealSource(this.currentEditRow)
                        })
                    }
                }
            }
        },
        // 表格编辑控制
        gridActiveMethod (gridData, cb) {
            let that = this
            let {row, _rowIndex, column, _columnIndex} = gridData
            return cb(that, row, _rowIndex, column, _columnIndex)
        },
        /** 
         * 特殊功能存放处
        */
        // 表格计算属性失去焦点时-成本报价
        blurGridItem (data, column, group) {
            const that = this
            let url = '/formula/compute'
            let postData = {
                templateNumber: this.currentEditRow.templateNumber,
                templateVersion: this.currentEditRow.templateVersion,
                busAccount: this.busAccount || this.$ls.get('Login_elsAccount'),
                field: column.field,
                row: data.row,
                ref: group.groupCode
            }
            postAction(url, postData).then((res) => {
                if(res.success){
                    if (res.result) {
                        for (let key in res.result.row) {
                            data.row[key] = res.result.row[key]
                        }
                        if (that.$refs[group.groupCode]) {
                            let countData = {}
                            let tableData = that.$refs[group.groupCode][0].getTableData().tableData
                            countData[group.groupCode] = tableData
                            that.countTotalValue(countData, group)
                        }
                    }
                }else{
                    this.$message.warning(res.message)
                }
            })
        },
        // 单表格汇总-成本报价
        countTotalValue (data, group) {
            let total = null
            data[group.groupCode].forEach((data)=> {
                if (data[group.total.culumnName]) {
                    if (data[group.total.culumnName]) {
                        total += Number(data[group.total.culumnName])
                    }
                }
            })
            group.total.totalValue = total
        },
        /**
         * 引用组件对象，对外暴露功能存放处
         */
        // 暴露所有数据的方法
        extendAllData () {
            const that = this
            let allData = {}
            this.pageConfig.groups.forEach((group)=> {
                let _show = group.show == false ? false : true
                let data = {}
                if (group.groupType === 'item' && _show) {
                    let parentRef = that.$refs[group.groupCode+'grid'][0]
                    let grid = parentRef.$refs[group.groupCode]
                    if (grid && grid.getTableData()) {
                        data[group.groupCode] = grid.getTableData().tableData
                        allData = Object.assign({}, allData, data)
                    }
                } else if (group.groupType === 'head' && _show) {
                    if (group.groupCode === 'baseForm') {
                        data = group.formModel
                    } else {
                        data[group.groupCode] = group.formModel
                    }
                    allData = Object.assign({}, allData, data)
                }
            })
            return {
                pageConfig: this.pageConfig,
                allData: allData
            }
        }
    },
    watch: {
        collapseHeadCode: {
            immediate: true,
            handler: function (val) {
                if (!val.length) {
                    return
                }
                this.localCollapseHeadCode = val.map(rs => rs.code ? rs.code : rs)
                this.localCollapseKeys = val.map(rs => rs.code ? (rs.expand == false ? '' : rs.code) : rs ) // 兼容一维数组，一维数组默认都展开，expand为false或者不填默认都不展开
            }
        }
    }
}
</script>
<style lang="less" scoped>
.summary-message {
  height: 14px;
  display: flex;
  align-items: center;
  margin: 10px 0;
}
.summary-message-content {
  flex-grow: 1;
  font-weight: bolder;
  .total-num {
    font-size: 16px;
    color: red;
  }
}
.update-z-index {
    z-index: 100000;
}
.item-box-title {
		padding: 0 7px;
		border: 1px solid #ededed;
		height: 34px;
		line-height: 34px;
        margin-bottom: 6px;
		&.dark {
			background: #f2f2f2;
		}
	}
</style>