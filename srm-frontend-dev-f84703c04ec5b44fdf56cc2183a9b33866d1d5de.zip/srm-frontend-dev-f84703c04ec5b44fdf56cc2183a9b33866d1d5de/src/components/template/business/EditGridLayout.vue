<!--
 * @Author: fzb
 * @Date: 2021-07-26 11:12:40
 * @LastEditTime: 2021-09-02 19:36:14
 * @FilePath: \srm-frontend_v4.5\src\components\template\container\editGridLayout.vue
-->
<template>
  <vxe-grid
    v-if="group.groupType==='item'"
    :ref="group.groupCode"
    v-bind="gridConfig"
    :loading="gridLoading"
    :edit-config="group.editConfig"
    :edit-rules="group.editRules"
    :columns="group.columns">
    <!-- 表格代码编辑器 -->
    <template #code_editor_col_render="{row,column}">
      <code-editor-model
        :value="row[column.property]"
        @handleSureClick="(content)=> {row[column.property] = content}"></code-editor-model>
    </template>
    <!-- 表格富文本编辑器 -->
    <template #rich_editor_col_render="{row,column}">
      <rich-editor-model
        :value="row[column.property]"
        @handleSureClick="(content)=> {row[column.property] = content}"></rich-editor-model>
    </template>
    <!-- 数据字典渲染 -->
    <template #renderDictLabel="{ row, column }">
      <span>
        {{ getDictLabel(row[column.property], column, row) }}
      </span>
    </template>
    <template
      #toolbar_buttons>
      <div>
        <business-button
          :buttons="group.externalToolBar"
          :groupCode="group.groupCode"
          :pageConfig="pageConfig"
          isToolbarButtons
          v-bind="$attrs"
          v-on="$listeners"
        />
        <!-- <template v-for="(btn, btnIndex) in group.externalToolBar">
          <a-button
            v-if="btn.key !=='gridImport'"
            :key="'grid_btn_' + btnIndex"
            class="btn-opt"
            @click="()=> { gridBtnMixin(group, group.groupCode, btn)}">{{ btn.title }}</a-button>
          <a-upload
            v-else-if="btn.key ==='gridImport'"
            :key="'grid_import_btn_' + btnIndex"
            class="btn-opt"
            name="file"
            :show-upload-list="false"
            :multiple="false"
            :headers="tokenHeader"
            :data="()=> {return importArgs(btn.args, group)}"
            :action="btn.args.url"
            @change="(fileData)=>{handleImport(fileData, group)}"
          >
            <a-button type="primary">{{ btn.title }}</a-button>
          </a-upload>

        </template> -->
        <!-- <a-button
          v-if="group.externalToolBar && group.externalToolBar.add"
          class="btn-opt"
          type="primary"
          @click="()=> { addItemMixin(group.groupCode)}">添加</a-button>
        <a-button
          v-if="group.externalToolBar && group.externalToolBar.delete"
          class="btn-opt"
          type="primary"
          @click="()=> { deleteItemMixin(group.groupCode)}">删除</a-button>
        <a-upload
          v-if="group.externalToolBar && group.externalToolBar.import"
          class="btn-opt"
          name="file"
          :show-upload-list="false"
          :multiple="false"
          :headers="tokenHeader"
          :data="()=> {return importArgs(requestData.import, group)}"
          :action="requestData.import.url"
          @change="(fileData)=>{handleImport(fileData, group)}"
        >
          <a-button type="primary">导入</a-button>
        </a-upload>
        <a-button
          v-if="group.externalToolBar && group.externalToolBar.export"
          class="btn-opt"
          type="primary"
          @click="()=> { handleExport(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_files`, '文件'), group)}">导出</a-button> -->
      </div>
    </template>
    <template #grid_opration="{ row, column }">
      <div v-if="group.extend && group.extend.optColumnList">
        <span
          v-for="(opt, optIndex) in group.extend.optColumnList"
          :key="'opt_'+ row.id + '_' + optIndex">
          <a
            :title="opt.title"
            style="margin:0 4px"
            :disabled="opt.disabled"
            v-show="!opt.hide"
            @click="()=> { optColumnFuntion(opt, row, column) }">{{ opt.title }}</a>
        </span>
      </div>
    </template>
    <!--使用 bottom 插槽-->
    <template #bottom>
      <div
        class="summary-message"
        v-if="group.total.totalValue">
        <span class="summary-message-content">
          {{ $srmI18n(`${busAccount}#${group.groupNameI18nKey}`, group.groupName) }} {{ $srmI18n(`${$getLangAccount()}#${group.i18n_title_generalSummary}`, '总汇总') }}：<span class="total-num">{{ group.total.totalValue }}</span></span>
      </div>
    </template>
  </vxe-grid>
</template>
<script>
import BusinessButton from './components/BusinessButton'
import { ACCESS_TOKEN } from '@/store/mutation-types'
import { EditConfig } from '@/plugins/table/gridConfig'
import { downFile } from '@/api/manage'
import RichEditorModel from '@comp/richEditorModel/RichEditorModel'
import Sortable from 'sortablejs'
export default {
    name: 'EditGridLayout',
    components: {
        RichEditorModel,
        BusinessButton
    },
    props: {
        // 传入归属方busAccount
        busAccount: {
            required: true,
            type: String,
            default: null
        },
        currentStep: {
            type: [String, Number]
        },
        currentEditRow: {
            type: Object,
            defaupageConfiglt: () => {
                return {}
            }
        },
        gridLoading: {
            type: Boolean,
            default: false
        },
        group: {
            type: Object,
            required: true,
            default: ()=> {
                return {}
            }
        },
        pageConfig: {
            type: Object,
            default: ()=> {
                return {}
            }
        },
        loadData: {
            type: Array,
            default: ()=> {
                return []
            }
        }
    },
    data () {
        return {
            //默认表格配置
            gridConfig: EditConfig,
            tokenHeader: {'X-Access-Token': this.$ls.get(ACCESS_TOKEN)},
            gridData: this.loadData || [],
            groupSortable: null
        }
    },
    watch: {
        loadData: {
            immediate: true,
            handler: function (val) {
                this.gridData = val
                this.loadGridData()
            }
        }
    },
    created () {
        if (!!this.group.extend && this.group.extend.dragAndDrop) {
            this.gridConfig.mouseConfig.area = false
            this.groupRowDrop()
        }
    },
    methods: {
        //拖拽分组行
        groupRowDrop () {
            this.$nextTick(() => {
                let groupGrid = this.$refs[this.group.groupCode]
                this.groupSortable = Sortable.create(groupGrid.$el.querySelector('.body--wrapper>.vxe-table--body tbody'), {
                    handle: '.drag-btn',
                    onEnd: ({ newIndex, oldIndex }) => {
                        let { fullData } = groupGrid.getTableData()
                        let tableData = [...fullData]
                        let currRow = tableData.splice(oldIndex, 1)[0]
                        tableData.splice(newIndex, 0, currRow)
                        tableData = tableData.map((item, index) => {
                            item.sortOrder = index + 1
                            return item
                        })
                        groupGrid.loadData(tableData)
                        groupGrid.syncData()
                    }
                })
            })
        },
        // 操作列方法
        optColumnFuntion (opt, row, col) {
            opt.click && opt.click(this, row, col)
        },
        loadGridData () {
            let that = this
            this.$nextTick(()=> {
                if (that.$refs[that.group.groupCode]) {
                    that.$refs[that.group.groupCode].loadData(that.gridData)
                }
            })
        },
        // 通过value显示label
        getDictLabel (value, column, row) {
            if (typeof value === 'string' || typeof value === 'number') {
                let valString = value + '' 
                if (column && column.dictOptions && column.dictOptions.length) {
                    let dictItem = column.own.dictOptions.filter((opt)=> {
                        return opt.value === valString
                    })
                    return dictItem.length? dictItem[0].label: valString
                } else {
                    return row[column.own.field + '_dictText'] || valString // 有数据字典则返回dictText，否则返回当前key
                }
            } else {
                return value
            }
        },
        gridBtnMixin (group, groupCode, btn) {
            if (btn.click && typeof btn.click === 'function') {
                let itemGrid = this.$refs[groupCode]
                btn.click(this, group, itemGrid)
            } else {
                if (btn.key === 'gridAdd') {
                    this.addItemMixin(groupCode)
                } else if (btn.key === 'gridDelete') {
                    this.deleteItemMixin(groupCode)
                } else if (btn.key === 'gridExport') {
                    this.handleExport(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_files`, '文件'), group)
                }
            }
        },
        //附件上传
        handleUploadChange (info, btn, refName) {
            btn.callBack && btn.callBack(info, refName)
        },
        // 检查表格是否有选中
        checkedGridSelect (btn, refName, cb) {
            let selectData = null
            if (this.$refs[refName]) {
                if (this.$refs[refName][0]) {
                    selectData = this.$refs[refName][0].getCheckboxRecords() || this.$refs[refName][0].getRadioRecord()
                }
            }
            if (selectData && selectData.length) {
                if (cb && typeof cb === 'function') {
                    cb(selectData).then(res=> {
                        if (res) {
                            btn.modalVisible = true
                        }
                    })
                } else {
                    this.modalVisible = true
                }
                
            } else {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterChoose`, '请先选择'))
            }
        },
        // 默认表行增加
        addItemMixin (refName) {
            if (refName) {
                let itemGrid = this.$refs[refName]
                let itemData = {}
                itemGrid.insert([itemData])
            }
        },
        // 默认表行删除
        deleteItemMixin (refName) {
            if (refName) {
                let itemGrid = this.$refs[refName]
                let checkboxRecords = itemGrid.getCheckboxRecords()
                if(!checkboxRecords.length) {
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据！'))
                    return
                }
                itemGrid.removeCheckboxRow()
            }
        },
        // 导出
        handleExport (fileName, group) {
            this.gridLoading = true
            fileName = fileName || this.$srmI18n(`${this.$getLangAccount()}#i18n_title_exportFile`, '导出文件')
            if (this.requestData.export) {
                // 传多ref给外部处理
                let gridRef = this.$refs[group.groupCode]
                group.gridRef = gridRef
                let data = this.requestData.export.args? this.requestData.export.args(group): {}
                downFile(this.requestData.export.url, data).then((data) => {
                    if (!data) {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileDownloadFailed`, '文件下载失败'))
                        return
                    }
                    if (typeof window.navigator.msSaveBlob !== 'undefined') {
                        window.navigator.msSaveBlob(new Blob([data]), fileName+'.xlsx')
                    } else {
                        let url = window.URL.createObjectURL(new Blob([data]))
                        let link = document.createElement('a')
                        link.style.display = 'none'
                        link.href = url
                        link.setAttribute('download', fileName+'.xlsx')
                        document.body.appendChild(link)
                        link.click()
                        document.body.removeChild(link) //下载完成移除元素
                        window.URL.revokeObjectURL(url) //释放掉blob对象
                    }
                }).finally(() => {
                    this.gridLoading = false
                })
            } else {
                this.$message.warn('请先配置导出的参数')
                this.gridLoading = false
            }
        },
        // 导入方法
        importMethod (data) {
            let name = 'get'
            if (data && data.method) {
                name = data.method.toLowerCase()==='post'? 'post': 'get'
            }
            return name
        },
        // 导入的参数
        importArgs (data, group) {
            let args = {}
            if (data && data.args) {
                // 传多ref给外部处理
                let gridRef = this.$refs[group.groupCode]
                group.gridRef = gridRef
                args = data.args(group)
            }
            return args
        },
        /* 导入 */
        handleImport (info, group) {
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList)
            }
            if (info.file.status === 'done') {
                if (info.file.response.success) {
                    if (info.file.response.code === 201) {
                        let { message, result: { msg, fileUrl, fileName } } = info.file.response
                        let href = this.$variateConfig['domianURL'] + fileUrl
                        this.$warning({
                            title: message,
                            content: (
                                <div>
                                    <span>{msg}</span><br/>
                                    <span>{this.$srmI18n(`${this.$getLangAccount()}#i18n_title_detailContent`, '具体详情请')} <a href={href} target="_blank" download={fileName}>点击下载</a> </span>
                                </div>
                            )
                        })
                    } else {
                        this.$message.success(info.file.response.message || `${info.file.name} 文件上传成功`)
                        this.$emit('handleImportSuccess', {response: info.file.response, group: group, ref: this.$refs[group.groupCode] })
                    }
                } else {
                    this.$message.error(`${info.file.name} ${info.file.response.message}.`)
                }
            } else if (info.file.status === 'error') {
                this.$message.error(`文件上传失败: ${info.file.msg} `)
            }
        }
    },
    beforeDestroy () {
        this.groupSortable && this.groupSortable.destroy()
    }
}
</script>
<style lang="less" scoped>
.drag-btn {
    cursor:move
}
.btn-opt {
    margin-left: 6px;
    margin-right: 6px;
}
.summary-message {
  height: 14px;
  display: flex;
  align-items: center;
  margin: 10px 0;
}
.summary-message-content {
  flex-grow: 1;
  font-weight: bolder;
  .total-num {
    font-size: 16px;
    color: red;
  }
}
</style>