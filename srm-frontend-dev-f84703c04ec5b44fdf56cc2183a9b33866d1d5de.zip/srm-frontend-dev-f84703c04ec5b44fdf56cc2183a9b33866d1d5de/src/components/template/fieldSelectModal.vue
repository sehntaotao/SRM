<template>
  <div>
    <a-modal
      centered
      :title="$srmI18n(`${$getLangAccount()}#i18n_title_SelectData`, '选择数据')"
      :width="960"
      :visible="visible"
      :maskClosable="false"
      :confirmLoading="confirmLoading"
      @ok="selectedOk"
      @cancel="close">
      <a-input-search
        :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_pleaseInputThekeyword`, '请输入关键字')"
        style="margin-bottom:8px"
        @search="onSearch"
        enterButton />
      <vxe-grid
        border
        resizable
        show-overflow
        highlight-hover-row
        max-height="350"
        row-id="id"
        size="small"
        :loading="loading"
        ref="selectGrid"
        :seq-config="{startIndex: (tablePage.currentPage - 1) * tablePage.pageSize}"
        :data="tableData"
        :pager-config="isTree ? null : tablePage"
        :radio-config="selectModel === 'single' ? checkedConfig : undefined"
        :checkbox-config="selectModel === 'multiple' ? checkedConfig : undefined"
        :tree-config="isTree ? treeConfig : null"
        :columns="columns"
        @page-change="handlePageChange"
        @checkbox-change="togglePaperSelect"
        @checkbox-all="toggleAllPaperSelect">
      </vxe-grid>
    </a-modal>
  </div>
</template>

<script>
import { getAction } from '@/api/manage'
export default {
    name: 'FieldSelectModal',
    props: {
        isEmit: {
            type: Boolean,
            default: false
        },
        isTree: {
            type: Boolean,
            default: false
        },
        treeConfig: {
            type: Object,
            default () {
                return {}
            }
        },
        pageConfigData: {
            type: Object,
            default () {
                return {}
            }
        }
    },
    data () {
        return {
            selectedPapers: new Set(),
            visible: false,
            loading: false,
            confirmLoading: false,
            columns: [],
            url: '',
            selectModel: 'single',
            checkedConfig: {highlight: true, reserve: true, trigger: 'row'},
            queryParams: {},
            tableData: [],
            tablePage: {
                total: 0,
                currentPage: 1,
                pageSize: 10,
                align: 'left',
                pageSizes: [10, 20, 50, 100, 200, 500],
                layouts: ['Sizes', 'PrevPage', 'Number', 'NextPage', 'FullJump', 'Total'],
                perfect: true
            }
        }
    },
    methods: {
        togglePaperSelect ({ rowid, checked }) {
            if(checked) {
                this.selectedPapers.add(rowid)
            }else {
                this.selectedPapers.delete(rowid)

            }
        },
        toggleAllPaperSelect ({ records, checked}) {
            if(checked) {
                records.forEach(item => this.selectedPapers.add(item.id))
            }else {
                this.tableData.forEach(item => this.selectedPapers.delete(item.id))
            }
        },
        loadData (params, cb) {
            this.loading = true
            getAction(this.url, params).then((res) => {
                const flag = this.isTree
                    ? res.success && res.result && res.result.length
                    : res.success && res.result && res.result.records && res.result.records.length
                if (flag) {
                    let result = this.isTree ?  res.result : res.result.records
                    result = result || []
                    this.tableData = result
                    this.tablePage.total = res.result.total
                    if (this.selectModel === 'single') {
                        this.$refs.selectGrid && this.$refs.selectGrid.clearRadioReserve()
                    }else {
                        this.$refs.selectGrid && this.$refs.selectGrid.clearCheckboxReserve()
                    }
                } else {
                    this.tableData = []
                    this.tablePage.total = 0
                    this.tablePage.currentPage = 1
                    
                }
                let table = this.$refs.selectGrid
                cb && cb(table)
                this.loading = false
            })
        },
        /**
         * @param {String} url 接口url
         * @param {Object} params 接口参数
         * @param {Array} columns 表格列配置
         * @param {String} selectModel 表格模式，single：单选，multiple：多选
         * @param {Object} checkedConfig 表格模式详细配置（已有详细配置，默认不传该值）
         */
        open (url, params, columns, selectModel, checkedConfig) {
            this.tablePage.currentPage = 1
            let tableColumns = columns ? [...columns] : []
            this.queryParams = {pageSize: this.tablePage.pageSize, pageNo: this.tablePage.currentPage}
            checkedConfig ? this.checkedConfig = {...this.checkedConfig, ...checkedConfig} : ''
            this.url = url
            if (selectModel) {
                this.selectModel = selectModel
            }
            tableColumns.unshift({ type: 'seq',  title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号'), width: 60 })
            if (this.selectModel === 'single') {
                tableColumns.unshift({ type: 'radio', width: 40 })
            }else if (this.selectModel === 'multiple') {
                tableColumns.unshift({ type: 'checkbox', width: 40 })
            }
            this.columns = tableColumns
            if (params) {
                this.queryParams = Object.assign({}, this.queryParams, params)
            }
            this.loadData(this.queryParams, (table) => {
                this.tableData.forEach(paper => {
                    if(this.selectedPapers.has(paper.id)) {
                        this.$nextTick(() => {
                            table.setCheckboxRow(table.getRowById(paper.id), true)
                        })
                    }
                })
            })
            this.visible = true
        },
        close () {
            this.visible = false
        },
        selectedOk () {
            let selectedData = this.$refs.selectGrid.getCheckboxRecords()
            if (this.selectModel === 'single') {
                selectedData = this.$refs.selectGrid.getRadioRecord() ? [this.$refs.selectGrid.getRadioRecord()] : []
            }
            // else {
            //     let selectedData = []
            //     this.selectedPapers.forEach(id => {
            //         this.tableData.forEach(data => {
            //             console.log(data)
            //             if(id == data.id) {
            //                 selectedData.push(data)
            //             }
            //         })
            //     })
            // }
            // console.log(selectedData)
            if (selectedData.length) {
                this.visible = false
                if (this.pageConfigData.itemColumns) { // 表行
                    selectedData.forEach(item => {
                        this.pageConfigData.itemColumns.forEach(el => {
                            if (el.defaultValue && (item[el.field] == '' || item[el.field] == null)) { // 模板有默认值且当前表单返回没有值
                                item[el.field] = el.defaultValue
                            }   
                        })
                    })
                }
                if (this.isEmit) {
                    this.$emit('ok', selectedData)
                } else {
                    this.$parent.fieldSelectOk(selectedData)
                }
            }else {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_selectDataMsg`, '请选择数据'))
            }
        },
        handlePageChange ({ currentPage, pageSize }) {
            this.tablePage.currentPage = currentPage
            this.tablePage.pageSize = pageSize
            let params = Object.assign({}, this.queryParams, {pageSize: pageSize, pageNo: currentPage})
            this.loadData(params, (table) => {
                this.tableData.forEach(paper => {
                    if(this.selectedPapers.has(paper.id)) {
                        this.$nextTick(() => {
                            table.setCheckboxRow(table.getRowById(paper.id), true)
                        })
                    }
                })
            })
        },
        onSearch (keyWord) {
            this.queryParams = Object.assign({}, this.queryParams, {keyWord: keyWord })
            let params = Object.assign({}, this.queryParams, { pageNo: 1})
            this.loadData(params, (table) => {
                this.tableData.forEach(paper => {
                    if(this.selectedPapers.has(paper.id)) {
                        this.$nextTick(() => {
                            table.setCheckboxRow(table.getRowById(paper.id), true)
                        })
                    }
                })
            })
        }
    }
}
</script>