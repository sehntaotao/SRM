import ListLayout from './ListLayout.vue'
import { getAction } from '@/api/manage'
import {ajaxFindDictItems, ajaxFindCount} from '@/api/api'
export const ListMixin = {
    components: {
        ListLayout
    },
    data () {
        return {
            showEditPage: false,
            showDetailPage: false,
            pageData: {
                publicBtn: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_Query`, '查询'), type: 'primary', icon: 'search', clickFn: this.searchEvent},
                    //{label: '高级查询', type: 'primary', icon: 'search', clickFn: this.superSearchEvent},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_reset`, '重置'), icon: 'reload', clickFn: this.resetEvent}
                ],
                button: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'), icon: 'plus', clickFn: this.handleAdd, type: 'primary'},
                    // {label: '删除', icon: 'delete', clickFn: this.handleDelete},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_export`, '导出'), icon: 'download', folded: true, clickFn: this.handleExportXls},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_improt`, '导入'), icon: 'import', folded: true, type: 'upload'},
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns},
                    {label: '帮助说明', icon: 'file-text', folded: true, clickFn: this.showHelpText},
                    {label: '说明附件', icon: 'file-pdf', folded: true, clickFn: this.showHelpPDF}
                ],
                showOptColumn: true,
                optColumnList: [
                    {type: 'view', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'), clickFn: this.handleView},
                    {type: 'edit', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'), clickFn: this.handleEdit},
                    {type: 'delete', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), clickFn: this.handleDelete},
                    {type: 'record', title: '记录', clickFn: this.handleRecord}
                ],
                optColumnWidth: 150,
                optColumnAlign: 'center',
                superQueryShow: true,
                isOrder: {
                    column: 'id',
                    order: 'desc'
                } 
            },
            tabsList: [],
            //当前点击的行数据
            currentEditRow: {},
            chatType: ''
        }
    },
    watch: {
        $route: {
            immediate: true,
            handler (to) {
                if (to.query.open) {
                    let row = {
                        id: to.query.id,
                        templateName: to.query.templateName,
                        templateNumber: to.query.templateNumber,
                        templateVersion: to.query.templateVersion
                    }
                    if (row.id) {
                        this.handleView(row)
                    }
                }
                // console.log(to.params);
                // const { open = false, id = '' } = to.params || {};
                // if (open) {
                //     let row = { id };
                //     this.handleView(row);
                    
                // }
            }
        }
    },
    methods: {
        // tab页签改变前
        handleAfterChangeTab ({_this, activeTabData, pageData, listGrid, tablePage}) {
            if(activeTabData.hasOwnProperty('rejectReason')||activeTabData.hasOwnProperty('itemStatus')){
                if(activeTabData.itemStatus=== '4') {
                    pageData.button.map((btn)=> {
                        if(btn.value==='confirm' || btn.value==='reject') {
                            btn.hide= false
                        }
                    })
                } else {
                    pageData.button.map((btn)=> {
                        if(btn.value==='confirm' || btn.value==='reject') {
                            btn.hide= true
                        }
                    })
                }
            }
            if(activeTabData.appealStatus==null||activeTabData.appealStatus!== '1') {
                pageData.button.map((btn)=> {
                    if(btn.value==='approval' || btn.value==='reject') {
                        btn.hide= true
                    }
                })
            } else if(activeTabData.appealStatus === '1'){
                pageData.button.map((btn)=> {
                    if(btn.value==='approval' || btn.value==='reject') {
                        btn.hide= false
                    }
                })
            }
            if (tablePage) {
                tablePage.currentPage = 1
            }
            if (listGrid) {
                listGrid.clearCheckboxReserve()
                listGrid.clearCheckboxRow()
                _this.loadData(activeTabData)
            }

        },
        // 要隐藏的列名，表格和要隐藏的列名
        autoHideColumns (grid, hideColumn) {
            let allColumns = grid.getTableColumn()
            if (allColumns.fullColumn) {
                allColumns.fullColumn.forEach((col)=> {
                    col.visible= true
                    if (hideColumn && hideColumn.length) {
                        hideColumn.forEach((hideCol)=> {
                            if (hideCol === col.property) {
                                col.visible= false
                            }
                        })
                    }
                })
            }
            grid.refreshColumn()
        },
        btnInvalidAuth (code) {
            return !this.$hasOptAuth(code)
        },
        // 改变tab页签时，按钮和列的动态显示和隐藏
        handleAfterChangeTabOpt ({_this, activeTabData, pageData, listGrid, tablePage}) {
            this.handleAfterChangeTab ({_this, activeTabData, pageData, listGrid, tablePage})
            // 传入按不同的逻辑要隐藏的数组列
            let hideCols =[] // 例如：activeTabData.title === '议价中'? ['templateName', 'enquiryNumber']: [ 'enquiryNumber']
            if(activeTabData.title === '合格'||activeTabData.title === '全部'){
                hideCols=['appealReason', 'replayFinishTime', 'replyResult_dictText', 'replyOption', 'autoReply', 'appealStatus_dictText', 'appealWindow', 'appealDeadTime', 'replyWindow', 'replyDeadTime', 'appealTime', 'appealUser', 'replyUser']
            }
            this.autoHideColumns(listGrid, hideCols)
        },
        showHelpText () {
            this.$refs.listPage.showHelpText()
        },
        showHelpPDF () {
            this.$refs.listPage.showHelpPDF()
        },
        modalFormOk () {
            // 新增/修改 成功时，重载列表
            this.$refs.listPage.loadData()
        },
        serachTabs (dictCode, field){
            let that = this
            if(dictCode) {
                let postData = {
                    busAccount: this.$ls.get('Login_elsAccount'),
                    dictCode: dictCode
                }
                ajaxFindDictItems(postData).then(res => {
                    if(res.success) {
                        let tabAll ={title: that.$srmI18n(`${that.$getLangAccount()}#i18n_title_all`, '全部')}
                        tabAll[field] = null
                        let options = []
                        options.push(tabAll)
                        res.result.map(item => {
                            let tab ={title: that.$srmI18n(`${that.$getLangAccount()}#${item.textI18nKey}`, item.title)} 
                            tab[field] = item.value
                            options.push(tab)
                        })
                        that.tabsList = options
                    }
                })
            }
        },
        serachCountTabs (url){
            let that = this
            ajaxFindCount(url).then(res => {
                if(res.success) {
                    let options = []
                    let array = res.result || []
                    array.forEach(data => {
                        let tab = {}
                        tab.title = data.title
                        tab[data.fileName] = data.value
                        tab.total = data.total
                        tab.rejectReason = data.rejectReason
                        options.push(tab)
                    })
                    that.tabsList = options
                }
            })
        },
        selectedTemplate (data) {
            if(data) {
                this.$refs.listPage.closeTemplateModal()
                this.currentEditRow = data
                this.showEditPage = true
                this.$store.dispatch('SetTabConfirm', true)
            }
        },
        handleView (row) {
            this.currentEditRow = row
            this.showDetailPage = true
            this.$store.dispatch('SetTabConfirm', true)
        },
        handleRecord (row) {
            this.currentEditRow = row
            this.$refs.listPage.showRecordModal()
        },
        handleAdd () {
            this.currentEditRow = {}
            this.$refs.listPage.openTemplateModal()
        },
        handleEdit (row) {
            this.currentEditRow = row
            this.showEditPage = true
        },
        handleDelete (row) {
            this.$refs.listPage.deleteRows(row)
            // add by gzh 20211014 删除列表上一条数据之后刷新列表
            this.searchEvent()
        },
        handleUpgrade (row) {
            this.$refs.listPage.upgradeVersion(row)
        },
        hideEditPage () {
            this.showEditPage = false
            this.showDetailPage = false
            this.$store.dispatch('SetTabConfirm', false)
            this.searchEvent(false)
        },
        confirmHideEditPage () {
            let that = this
            this.$confirm({
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmToReturn`, '是否确认返回？'),
                onOk: () => {
                    that.hideEditPage()
                }
            })
        },
        handleExportXls () {
            this.$refs.listPage.handleExportXls(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_files`, '文件'))
        },
        settingColumns () {
            this.$refs.listPage.settingColumnConfig()
        },
        searchEvent (flag) {
            this.$refs.listPage.handleQuery(flag)
        },
        resetEvent () {
            this.$refs.listPage.searchReset()
        },
        importExcel () {
            getAction('/base/excelHeader/getConfig/' + this.url.excelCode, null).then(res => {
                if(res.success) {
                    let isPreview = res.result.previewData
                    let previewColumns = res.result.excelDetailList.map(item => {
                        return {
                            title: item.columnName,
                            field: item.columnCode,
                            width: 120,
                            dataType: item.dataType,
                            dataFormat: item.dataFormat
                        }
                    })
                    this.$refs.listPage.$refs.importExcel.open(isPreview, previewColumns, res.result.excelName)
                }else {
                    this.$message.warning(res.message)
                }
            })
        }
    }
}