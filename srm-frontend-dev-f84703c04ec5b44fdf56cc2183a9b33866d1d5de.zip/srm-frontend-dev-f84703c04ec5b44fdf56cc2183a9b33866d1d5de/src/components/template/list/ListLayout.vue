<template>
  <div class="page-container">
    <a-tabs
      v-if="tabsListDatas && tabsListDatas.length"
      class="list-tabs-wrap"
      default-active-key="1"
      tab-position="top"
      @change="changeTab"
    >
      <a-tab-pane 
        v-for="(pane, index) in tabsListDatas"
        :key="index">
        <span slot="tab">
          <a-badge
            :number-style="{ backgroundColor: defaultColor }"
            :overflowCount="999"
            :offset="[10]"
            :count="pane.total">
            <span class="badge-box">{{ pane.title }}</span>
          </a-badge>
        </span>
      </a-tab-pane>
    </a-tabs>
    <a-form-model 
      ref="queryForm" 
      :model="form" 
      class="ant-advanced-search-form"
      @keyup.enter.native="handleQuery" 
      layout="inline" 
      v-bind="layout">
      <a-row
        :gutter="12"
        type="flex"
        justify="space-between">
        <a-col flex="0 1 660px">
          <a-col
            v-for="(item, i) in normalFieldList"
            :key="'field_'+i"
            :span="12">
            <a-form-model-item
              v-if="item.type==='input'"
              :prop="item.fieldName"
              :label="item.label">
              <a-input
                v-model="pageData.form[item.fieldName]"
                :placeholder="item.placeholder" />
            </a-form-model-item>
            <a-form-model-item
              v-if="item.type==='select'"
              :prop="item.fieldName"
              :label="item.label">
              <m-select
                v-model="pageData.form[item.fieldName]"
                :dict-code="item.dictCode"
                :placeholder="item.placeholder" />
            </a-form-model-item>
            <a-form-model-item
              v-if="item.type==='datepicker'"
              :prop="item.fieldName"
              :label="item.label">
              <a-date-picker
                v-model="pageData.form[item.fieldName]"
                :placeholder="item.placeholder"
                :valueFormat="(item.dataFormat || 'YYYY-MM-DD')">
              </a-date-picker>
            </a-form-model-item>
            <a-form-model-item
              v-if="item.type==='treeSelect'"
              :prop="item.fieldName"
              :label="item.label">
              <m-tree-select
                v-model="pageData.form[item.fieldName]"
                allowClear
                :disabled="item.disabled"
                :multiple="item.extend && item.extend.multiple || false"
                :maxTagCount="item.extend && item.extend.maxTagCount || 1"
                :sourceUrl="item.sourceUrl"/>
            </a-form-model-item>
          </a-col>
        </a-col>
        <a-col
          flex="0 0 360px"
          class="search-btn-groups">
          <a-button
            type="primary"
            icon="search"
            style="margin-right:12px"
            @click="handleQuery">{{ $srmI18n(`${$getLangAccount()}#i18n_title_Query`, '查询') }}</a-button>
          <a-button
            type="primary"
            icon="filter"
            v-if="pageData.superQueryShow"
            style="margin-right:12px"
            @click="superQuery">
            {{ $srmI18n(`${$getLangAccount()}#i18n_title_advancedQuery`, '高级查询') }}
          </a-button>
          <a-button
            type="default"
            icon="reload"
            @click="handleReset">{{ $srmI18n(`${$getLangAccount()}#i18n_title_reset`, '重置') }}</a-button>
          <a 
            v-if="foldedFieldList.length"
            style="margin-left:8px"
            @click="toggleExpand">
            {{ expand ? `${$srmI18n(`${$getLangAccount()}#i18n_title_collapsed`, '收起')}` : `${$srmI18n(`${$getLangAccount()}#i18n_title_expand`, '展开')}` }}
            <a-icon :type="expand ? 'up' : 'down'" />
          </a>
        </a-col>
      </a-row>
      <a-row 
        v-show="expand" 
        :gutter="12"
        class="expand-field">
        <a-col
          v-for="(item, i) in foldedFieldList"
          :key="'field_'+i"
          :span="8">
          <a-form-model-item
            v-if="item.type==='input'"
            :prop="item.fieldName"
            :label="item.label">
            <a-input
              v-model="pageData.form[item.fieldName]"
              :placeholder="item.placeholder" />
          </a-form-model-item>
          <a-form-model-item
            v-if="item.type==='select'"
            :prop="item.fieldName"
            :label="item.label">
            <m-select
              v-model="pageData.form[item.fieldName]"
              :dict-code="item.dictCode"
              :placeholder="item.placeholder" />
          </a-form-model-item>
          <a-form-model-item
            v-if="item.type==='datepicker'"
            :prop="item.fieldName"
            :label="item.label">
            <a-date-picker
              v-model="pageData.form[item.fieldName]"
              :placeholder="item.placeholder"
              :valueFormat="(item.dataFormat || 'YYYY-MM-DD')">
            </a-date-picker>
          </a-form-model-item>
          <a-form-model-item
            v-if="item.type == 'treeSelect'"
            :prop="item.fieldName"
            :label="item.label">
            <m-tree-select
              v-model="pageData.form[item.fieldName]"
              allowClear
              :disabled="item.disabled"
              :multiple="false"
              :maxTagCount="item.extend && item.extend.maxTagCount || 1"
              :sourceUrl="item.sourceUrl"/>
          </a-form-model-item>
        </a-col>
      </a-row>
    </a-form-model>
    <div 
      class="grid-box" 
      :class="{'reset-grid-box': tabsList && tabsList.length}">
      <vxe-grid
        row-id="id"
        ref="listGrid"
        v-bind="gridConfig"
        :seq-config="{startIndex: (tablePage.currentPage - 1) * tablePage.pageSize}"
        :loading="loading"
        :columns="tableColumns"
        :data="tableData"
        :pager-config="tablePage"
        :edit-config="editConfig"
        :edit-rules="editRules"
        :filter-config="filterConfig"
        :print-config="printConfig"
        @sort-change="sortChangeEvent"
        @filter-change="filterChangeEvent"
        @resizable-change="resizableChange"
        @page-change="handlePageChange">
        <template slot="empty">
          <a-empty />
        </template>
        <template #fbk1_default="{ row, column }">
          <span
            v-if="!!row._id"
            class="red">{{ row.orderNumber }}_{{ row.orderItemNumber }} {{ changeMap[row[column.property]] || '' }}</span>
          <a-select
            v-else
            :disabled="fbk1Disable(row,column)"
            v-model="row[column.property]"
            @change="(val) => handleChange(val, row, column)"
            :allowClear="true">
            <a-select-option
              v-for="(label, value) in changeMap"
              :key="value">{{ label }}</a-select-option>
          </a-select>
        </template>
        <template #fbk1_default1="{ row, column }">
          <span
            v-if="!!row._id"
            class="red">{{ row.orderNumber }}_{{ row.orderItemNumber }} {{ changeMap[row[column.property]] || '' }}</span>
          <a-select
            v-else
            :allowClear="true"
            :disabled="fbk1Disable(row,column)"
            v-model="row[column.property]"
            @change="(val) => handleChange(val, row, column)">
            <a-select-option
              v-for="(label, value) in changeMap1"
              :key="value">{{ label }}</a-select-option>
          </a-select>
        </template>
        <template #_handle_default="{row, column, $rowIndex}">
          <div v-show="row.fbk1 === '0'">
            <a
              href="javascript: void(0)"
              @click="handleAddItem(row, column, $rowIndex)">{{ $srmI18n(`${$getLangAccount()}#i18n_title_split`, '拆分') }}</a>
            <a
              class="del red"
              :class="!!row._id ? '' : 'disabled'"
              href="javascript: void(0)"
              @click="handleDelItem(row, column, $rowIndex)">{{ $srmI18n(`${$getLangAccount()}#i18n_title_delete`, '删除') }}</a>
          </div>
        </template>
        <!--自定义插槽 seq_header-->
        <template v-slot:grid_opration="{ row, column, $rowIndex, $columnIndex }">
          <a
            v-for="(item, i) in optColumnList"
            :key="'opt_'+ row.id + '_' + i"
            :title="item.title"
            style="margin:0 4px"
            :disabled="item.allow ? item.allow(row) : false"
            v-show="item.showCondition ? item.showCondition(row) : true"
            @click="toolbarButtonsCallBack(row, column, $rowIndex, $columnIndex, item.clickFn)">{{ item.title }}</a>
          <a-dropdown v-if="optColumnListMore.length > 0">
            <a
              class="ant-dropdown-link"
              @click="e => e.preventDefault()">
              {{ $srmI18n(`${$getLangAccount()}#i18n_title_more`, '更多') }}
              <a-icon type="down" />
            </a>
            <a-menu
              slot="overlay"
            >
              <a-menu-item
                v-show="itemMore.showCondition ? itemMore.showCondition(row) : true"
                :key="'opt_'+ row.id + '_' + more_index"
                v-for="(itemMore, more_index) in optColumnListMore">
                <a-button
                  type="link"
                  :title="itemMore.title"
                  style="margin:0 4px"
                  :disabled="itemMore.allow ? itemMore.allow(row) : false"
                  @click="toolbarButtonsCallBack(row, column, $rowIndex, $columnIndex, itemMore.clickFn)">
                  {{ itemMore.title }}
                </a-button>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
        </template>
        <template #toolbar_buttons>
          <template v-for="(item, i) in normalBtnList">
            <template v-if="item.type !== 'uploadFile'">
              <a-button
                :key="`button_${i}`"
                v-show="!item.hide"
                :disabled="item.allow? item.allow(): false"
                :type="item.type"
                :icon="item.icon"
                @click="item.clickFn"
              >
                {{ item.label }}
              </a-button>
            </template>
            <template v-else>
              <custom-upload
                isList
                :disabled="item.allow? item.allow(): false"
                :key="`button_${i}`"
                :single="item.single"
                :disabledItemNumber="item.disabledItemNumber"
                :requiredFileType="item.requiredFileType"
                :property="item.property"
                :visible.sync="item.modalVisible"
                :title="item.title"
                :itemInfo="itemInfo"
                :action="item.url || uploadUrl"
                :accept="accept"
                :headers="tokenHeader"
                :data="{businessType: item.businessType, headId: item.id}"
                @change="(info) => handleUploadChange(info, item, 'listGrid')"
              >
                <a-button
                  v-if="item.beforeChecked"
                  type="primary"
                  icon="cloud-upload"
                  @click="checkedGridSelect(item, 'listGrid', item.beforeCheckedCallBack)">{{ item.title }}</a-button>
              </custom-upload>
            </template>
          </template>
        
          <a-dropdown v-if="foldBtnList.length">
            <a-button icon="more">{{ $srmI18n(`${$getLangAccount()}#i18n_title_more`, '更多') }}</a-button>
            <a-menu slot="overlay">
              <a-menu-item
                v-show="item.showCondition ? item.showCondition(row) : true"
                v-for="(item, i) in foldBtnList"
                :key="'menu_button_'+i">
                <a-upload
                  v-if="item.type==='upload'"
                  name="file"
                  :show-upload-list="false"
                  :multiple="false"
                  :headers="tokenHeader"
                  :action="importExcelUrl"
                  @change="handleImportExcel"
                >
                  <a-icon
                    :type="item.icon"
                    style="margin-right:10px"></a-icon>
                  {{ $srmI18n(`${$getLangAccount()}#i18n_title_Improt`, '导入') }}
                </a-upload>
                <div
                  v-else
                  @click="item.clickFn">
                  <a-icon
                    :type="item.icon"
                    style="margin-right:10px"></a-icon>{{ item.label }}
                </div>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
        </template>
        <template v-slot:custom_render="{ row, column }">
          <slot 
            name="custom_column_render" 
            :row="row" 
            :column="column"/>
        </template>
        <!-- 富文本编辑器插槽 -->
        <template #rich_editor_dispaly_render="{ row, column }">
          <div
            class="rich-editor-display-box"
            v-html="row[column.property]"></div>
        </template>
        <!-- 阶梯价格 -->
        <template #ladder_price_json_render="{ row, column}">
          <a-tooltip
            placement="top"
            v-if="row[column.property]"
            overlayClassName="tip-overlay-class">
            <template slot="title">
              <vxe-table
                auto-resize
                border
                size="mini"
                :data="initRowLadderJson(row[column.property])">
                <vxe-table-column
                  type="seq"
                  :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_details`, '序号')}`"
                  width="80"></vxe-table-column>
                <vxe-table-column
                  field="ladderQuantity"
                  :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_ladderQuantity`, '阶梯数量')}`"
                  width="140"></vxe-table-column>
                <vxe-table-column
                  field="price"
                  :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_price`, '含税价')}`"
                  width="140"></vxe-table-column>
                <vxe-table-column
                  field="netPrice"
                  :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_netPrice`, '不含税价')}`"
                  width="140"></vxe-table-column>
              </vxe-table>
            </template>
            <div class="json-box"><a href="javascript: void(0)">{{ defaultRowLadderJson(row[column.property]) }}</a></div>
          </a-tooltip>
        </template>
      </vxe-grid>
    </div>
    <column-setting ref="columnSettingModal"></column-setting>
    <a-modal 
      centered
      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_selectTemplate`, '选择模板') }`"
      :width="360"
      v-model="visible"
      @ok="selectedTemplate">
      <template slot="footer">
        <a-button
          key="back"
          @click="handleCancel">
          {{ $srmI18n(`${$getLangAccount()}#i18n_title_cancle`, '取消') }}
        </a-button>
        <a-button
          key="submit"
          type="primary"
          :loading="submitLoading"
          @click="selectedTemplate">
          {{ $srmI18n(`${$getLangAccount()}#i18n_title_sure`, '确定') }}
        </a-button>
      </template>
      <m-select
        v-model="templateNumber"
        :options="templateOpts"
        :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_selectTemplateType`, '请选择模板')"
      />
    </a-modal>
    <import-excel
      ref="importExcel"
      :excelCode="url.excelCode" />
    <j-super-query
      :fieldList="fieldList"
      ref="superQueryModal"
      :tableCode="url.columns"
      @handleSuperQuery="handleSuperQuery"></j-super-query>

    <help-modal
      v-model="helpVisible"
      :helpDesc="helpDesc" />

    <record-modal
      v-model="recordVisible"
      :currentEditRow="currentEditRow"
    />
    
  </div>
</template>
<script>
import { getAction, downFile, postAction } from '@/api/manage'
import { ajaxGetColumns } from '@/api/api'
import { ACCESS_TOKEN, DEFAULT_COLOR, USER_ELS_ACCOUNT, DEFAULT_LANG } from '@/store/mutation-types'
import Sortable from 'sortablejs'
import columnSetting from '@comp/template/columnSetting'
import { ListConfig } from '@/plugins/table/gridConfig'
import {ajaxFindDictItems} from '@/api/api'
import ImportExcel from '@comp/template/import/ImportExcel'
import JSuperQuery from '@/components/els/JSuperQuery.vue'
import { PURCHASE_ORDER_ITEM_TABLE_CODE, PURCHASE_DELIVERY_NOTICE_LIST, SALE_DELIVER_NOTICE_LIST } from '@/utils/const.js'
import CustomUpload from '@comp/template/CustomUpload'
import RecordModal from './components/RecordModal'
import HelpModal from './components/HelpModal'
import {srmI18n, getLangAccount} from '@/utils/util'
const superQueryFieldList=[{
    type: 'date',
    value: 'birthday',
    text: srmI18n(`${getLangAccount()}#i18n_field_birthday`, '生日')
}, {
    type: 'string',
    value: 'name',
    text: srmI18n(`${getLangAccount()}#i18n_title_userName`, '用户名')
}, {
    type: 'int',
    value: 'age',
    text: srmI18n(`${getLangAccount()}#i18n_title_ages`, '年龄')
}]
export default {
    name: 'ListLayout',
    props: {
        pageData: { //页面数据
            type: Object,
            default: null
        },
        url: {  //后台接口
            type: Object,
            default: null
        },
        tableCode: {
            type: String,
            default: ()=>{
                return null
            }
        },
        tabsList: {
            type: Array,
            default: ()=> {
                return null
            }
        },
        activeMethod: {
            type: Function,
            default: () => true
        },
        currentEditRow: {
            type: Object,
            default () {
                return {}
            }
        }
    },
    components: {
        columnSetting,
        ImportExcel,
        JSuperQuery,
        CustomUpload,
        RecordModal,
        HelpModal
    },
    data () {
        return {
            helpVisible: false,
            helpDesc: '',
            recordVisible: false,
            changeMap: {
                3: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSelect`, '请选择'),
                0: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_refuse`, '拒绝'),
                1: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirm`, '确认'),
                2: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_change`, '变更')
            },
            changeMap1: {
                // 3: '请选择',
                0: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_refuse`, '拒绝'),
                1: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirm`, '确认')
            },
            form: {},
            fieldList: superQueryFieldList,
            superQueryFlag: false,
            superQueryParams: '',
            superQueryMatchType: '',
            gridConfig: ListConfig,
            expand: false,
            visible: false,
            submitLoading: false,
            normalFieldList: this.pageData.formField.slice(0, 2),
            foldedFieldList: this.pageData.formField.slice(2),
            layout: {
                labelCol: { span: 8 },
                wrapperCol: { span: 16 }
            },
            loading: false,
            tokenHeader: {'X-Access-Token': this.$ls.get(ACCESS_TOKEN)},
            accept: '.doc, .docx, .xls, .xlsx, .ppt, .png, .jpg, .jpeg, .gif, .pptx, .pdf',
            uploadUrl: '/attachment/purchaseAttachment/upload',
            filter: {},
            isOrder: {
                column: 'id',
                order: 'desc'
            },
            tableColumns: [],
            tableData: [],
            toolbarConfig: {
                slots: {buttons: 'toolbar_buttons'},
                // import: true,
                // export: true,
                print: true,
                zoom: true,
                // custom: true,
                perfect: true
            },
            printConfig: {
                dataFilterMethod: this.dataFilterMethod
            },
            tablePage: {
                total: 0,
                currentPage: 1,
                pageSize: 20,
                align: 'right',
                pageSizes: [20, 50, 100, 200, 500],
                layouts: ['Sizes', 'PrevPage', 'Number', 'NextPage', 'FullJump', 'Total'],
                perfect: true
            },
            filterConfig: {
                remote: true
            },
            templateNumber: undefined,
            templateOpts: [],
            editRules: {},
            editConfig: {
                trigger: 'click',
                mode: 'cell',
                showStatus: true,
                icon: 'fa fa-file-text-o',
                activeMethod: this.activeMethod
            }
        }
    },
    computed: {
        // 获取项目的主题色
        defaultColor () {
            return this.$ls.get(DEFAULT_COLOR)
        },
        tabsListDatas () {
            return this.tabsList
        },
        normalBtnList () {
            return this.pageData.button.filter(item => {
                return !item.folded
            })
        },
        foldBtnList () {
            return this.pageData.button.filter(item => {
                return item.folded
            })
        },
        importExcelUrl: function (){
            return `${this.$variateConfig['domianURL']}/${this.url.importExcelUrl}`
        },
        itemInfo () {
            let itemInfo = []
            const groups = this.pageData.groups || []
            const group = groups.find(n => n.groupCode === 'itemInfo')
            if (group) {
                const refName = group.custom.ref
                itemInfo = this.$refs[refName][0].getTableData().fullData || []
            }
            return itemInfo
        },
        // 操作列按钮
        optColumnList () {
            let newArr = [...this.pageData.optColumnList]
            return newArr.length > 4 ? newArr.slice(0, 3) : newArr
        },
        // 操作列按钮（更多）
        optColumnListMore () {
            let newArr = [...this.pageData.optColumnList]
            return newArr.length > 4 ? newArr.slice(3) : []
        }
    },
    beforeDestroy () {
        if (this.sortable) {
            this.sortable.destroy()
        }
    },
    created () {
        if(this.pageData.pageColumns){
            this.tableColumns = this.pageData.pageColumns
        }else{
            this.initColumns()
        }
        this.loadData()
        this.columnDrop()
    },
    methods: {
        // 打印前过滤,每次一行数据过滤
        dataFilterMethod (tableOpt) {
            let {row} = tableOpt
            let listGrid = this.$refs.listGrid
            if (listGrid && listGrid.getSelectRecords() && listGrid.getSelectRecords().length) {
                let flag = false
                let selectRows = listGrid.getSelectRecords()
                selectRows.forEach((item)=> {
                    if (item.id === row.id) {
                        flag = true
                    }
                })
                return flag
            } else {
                return true
            }
        },
        showHelpPDF () {
            const url = '/account/permission/queryByUrl'
            const params = {
                url: this.$route.fullPath || ''
            }
            getAction(url, params)
                .then((res) => {
                    const filePath = res.result.filePath || ''
                    if (filePath) {
                        window.open(filePath)
                    } else {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_noSetHelpAttachment`, '没有配置说明附件'))
                    }
                })
        },
        showHelpText () {
            const url = '/account/permission/queryByUrl'
            const params = {
                url: this.$route.fullPath || ''
            }
            getAction(url, params)
                .then((res) => {
                    this.helpDesc = res.result.helpDesc || ''
                    if (this.helpDesc) {
                        this.helpVisible = true
                    } else {
                        this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_noSetHelpWord`, '没有配置帮助说明'))
                    }
                })
        },
        showRecordModal () {
            this.recordVisible = true
        },
        //附件上传
        handleUploadChange (info, btn, refName) {
            btn.callBack && btn.callBack(info, refName)
        },
        checkedGridSelect (btn, refName, cb) {
            let selectData = null
            if (this.$refs[refName]) {
                selectData = this.$refs[refName][0].getCheckboxRecords() || this.$refs[refName][0].getRadioRecord()
            }
            if (selectData && selectData.length) {
                if (cb && typeof cb === 'function') {
                    cb(selectData).then(res=> {
                        if (res) {
                            btn.modalVisible = true
                        }
                    })
                } else {
                    this.modalVisible = true
                }
            } else {
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterChoose`, '请先选择'))
            }
        },
        fbk1Disable (row, column){
            console.log(column)
            if(row.noticeStatus=='4'||row.noticeStatus=='5'||row.noticeStatus=='0'){
                return true
            }
            if((this.url.columns === PURCHASE_DELIVERY_NOTICE_LIST||this.url.columns === 'purchaseDeliveryNoticeByOrderList')&&row.noticeStatus=='1'){
                return true
            }
            if((this.url.columns === SALE_DELIVER_NOTICE_LIST||this.url.columns === 'saleDeliveryNoticeByOrderList')&&(row.noticeStatus=='2'||row.noticeStatus=='3')){
                return true
            }
            return false
        },
        handleChange (val, row, column) {
            console.log(column)
            const { id = '' } = row || {}
            const fn = n => n._id && (n._id === id)
            const invert = x => (...args) => !x(...args)
            const flag = this.tableData.some(fn)
            if (flag) {
                this.tableData = this.tableData.filter(invert(fn))
            }
            this.$refs.listGrid.clearActived().then(() => {
                console.log('val', val)
                console.log(val === '0')
                if (val === '0'||val === '1'||val === '2') {
                    this.$refs.listGrid.setActiveCell(row, 'responsibleParty')
                }
            })
        },
        handleAddItem (row, column, i) {
            const record = Object.assign({}, row, {
                _id: row.id || row._id,
                planDeliveryDate: '', // 计划交货日期
                planDeliveryQuantity: '' // 计划交货数量
            })
            this.tableData.splice(i, 0, record)
            this.$refs.listGrid.setActiveRow(record)
        },
        handleDelItem (row, column, i) {
            if (row.id && !row._id) return
            this.tableData.splice(i, 1)
        },
        superQuery (){
            this.$refs.superQueryModal.show()
        },
        handleSuperQuery (arg, superQueryMatchType) {
            this.superQueryParams = ''
            if(arg){
                this.superQueryParams = JSON.stringify(arg)
            }
            this.superQueryMatchType = superQueryMatchType
            this.tablePage.currentPage = 1
            this.loadData()
        },
        // 导出
        handleExportXls (fileName, exportType, templateId, templateNumberVersion, itemGroupCode, jsonParam){
            this.loading = true
            fileName = fileName || this.$srmI18n(`${this.$getLangAccount()}#i18n_title_exportFile`, '导出文件')
            const records = this.$refs.listGrid.getCheckboxRecords() || []
            let params = !records.length
                ? Object.assign({}, this.pageData.form)
                : { selections: records.map(n => n.id).join(',') }
            if (this.url.columns) {
                this.$set(params, 'defineColumnCode', this.url.columns)
            }
            let isOrder = this.pageData.isOrder || this.isOrder
            this.$set(params, 'column', isOrder.column)
            this.$set(params, 'order', isOrder.order)
            this.$set(params, 'handlerName', this.url.handlerName)
            this.$set(params, 'fileName', fileName)
            // 针对采购申请试一下exportType head_item,templateId
            this.$set(params, 'exportType', exportType)
            this.$set(params, 'templateId', templateId)
            this.$set(params, 'templateNumberVersion', templateNumberVersion)
            this.$set(params, 'itemGroupCode', itemGroupCode)
            let _this = this
            if(jsonParam){
                jsonParam.forEach(item=>{
                    _this.$set(params, item.key, item.value)
                })
            }
            downFile(this.url.exportXlsUrl, params).then((data) => {
                if (!data) {
                    this.$message.error(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileDownloadFailed`, '文件下载失败'))
                    return
                }
                if (typeof window.navigator.msSaveBlob !== 'undefined') {
                    window.navigator.msSaveBlob(new Blob([data]), fileName+'.xls')
                } else {
                    let url = window.URL.createObjectURL(new Blob([data]))
                    let link = document.createElement('a')
                    link.style.display = 'none'
                    link.href = url
                    link.setAttribute('download', fileName+'.xls')
                    document.body.appendChild(link)
                    link.click()
                    document.body.removeChild(link) //下载完成移除元素
                    window.URL.revokeObjectURL(url) //释放掉blob对象
                }
            }).finally(() => {
                this.loading = false
            })
        },
        /* 导入 */
        handleImportExcel (info) {
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList)
            }
            if (info.file.status === 'done') {
                if (info.file.response.success) {
                    if (info.file.response.code === 201) {
                        let { message, result: { msg, fileUrl, fileName } } = info.file.response
                        let href = this.$variateConfig['domianURL'] + fileUrl
                        this.$warning({
                            title: message,
                            content: (
                                <div>
                                    <span>{msg}</span><br/>
                                    <span>
                                        { this.$srmI18n(`${this.$getLangAccount()}#i18n_title_detailContent`, '具体详情请') }
                                        <a href={href} target="_blank" download={fileName}>
                                            { this.$srmI18n(`${this.$getLangAccount()}#i18n_title_download`, '点击下载') }
                                        </a>
                                    </span>
                                </div>
                            )
                        })
                    } else {
                        let message = info.file.response.message || this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadSuccess`, '文件上传成功')
                        this.$message.success(message)
                    }
                    this.loadData()
                } else {
                    this.$message.error(`${info.file.name} ${info.file.response.message}.`)
                }
            } else if (info.file.status === 'error') {
                this.$message.error(`${this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadError`, '文件上传失败')} : ${info.file.msg}`)
            }
        },
        queryTemplateList (elsAccount) {
            let params = {elsAccount: elsAccount, businessType: this.pageData.businessType}
            return getAction('/template/templateHead/getListByType', params)
        },
        //获取数据
        loadData (tabData, callback) {
            this.loading = true
            let form = this.pageData.form
            let isOrder = this.pageData.isOrder || this.isOrder
            //不为id，则说明点了页面的排序
            if(this.isOrder.column != 'id'){
                isOrder = this.isOrder
            }
            let params = Object.assign(form, 
                {
                    pageSize: this.tablePage.pageSize, 
                    pageNo: this.tablePage.currentPage,
                    filter: this.filter
                }, isOrder)
            if(this.superQueryParams){
                params['superQueryParams']=encodeURI(this.superQueryParams)
                params['superQueryMatchType']=encodeURI(this.superQueryMatchType)
            }else{
                params['superQueryParams']=null
                params['superQueryMatchType']=null
            }
            if (tabData) {
                for (let key in tabData) {
                    if (key !== 'title') {
                        params[key] = tabData[key]
                    }
                }
            }
            if (this.$route.query.toElsAccount) {
                params.toElsAccount = this.$route.query.toElsAccount
            } else {
                delete params.toElsAccount
            }
            getAction(this.url.list, params).then((res) => {
                if(res.success) {
                    let list = [...res.result.records]
                    list.forEach(item => {
                        if(item.extendFields) {
                            Object.assign(item, JSON.parse(item.extendFields))
                        }
                    })
                    
                    // 加载完数据后调用自定义方法
                    if(typeof this.$parent.init === 'function') {
                      this.$parent.init(res.result)
                    }
                    
                    this.tableData = list
                    this.tablePage.total = res.result.total
                }
            }).finally(() => {
                this.loading = false
            })
        },
        // 获取表格列信息
        async initColumns (){
            const that = this
            ajaxGetColumns(this.url.columns, null).then((res) => {
                if(res.success) {

                    let columns= [{ type: 'checkbox', width: 36, fixed: 'left', headerAlign: 'left' }]
                    if(!this.pageData.notShowTableSeq) {
                        columns.push({ type: 'seq', width: 50, title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号'), align: 'center', fixed: 'left' })
                    }
                    if ((that.url.columns === PURCHASE_DELIVERY_NOTICE_LIST||that.url.columns === 'purchaseDeliveryNoticeByOrderList')) {
                        columns.push({ width: 150, fixed: 'left', align: 'center', dataIndex: 'fbk1', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), scopedSlots: { default: 'fbk1_default' } })
                    }
                    if (that.url.columns === SALE_DELIVER_NOTICE_LIST||this.url.columns === 'saleDeliveryNoticeByOrderList') {
                        columns.push({ width: 150, fixed: 'left', align: 'center', dataIndex: 'fbk1', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'), scopedSlots: { default: 'fbk1_default1' } })
                        columns.push({ width: 150, fixed: 'left', align: 'center', dataIndex: '_handle', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_FKWtk_aa471673`, '拒绝/操作'), scopedSlots: { default: '_handle_default' } })
                    }                       
                    columns = columns.concat(res.result)
                    // 字段转换
                    columns.forEach(item => {
                        // 交期
                        if ( item.dataIndex === 'requireDate'&&(that.url.columns === PURCHASE_DELIVERY_NOTICE_LIST ||that.url.columns === 'purchaseDeliveryNoticeByOrderList')) {
                            item.edit = '1'
                            item.required = '1'
                            item.fieldType = 'date'
                        }
                        // 需求数量
                        if ( item.dataIndex === 'requireQuantity'&& (that.url.columns === PURCHASE_DELIVERY_NOTICE_LIST||that.url.columns === 'purchaseDeliveryNoticeByOrderList') ) {
                            item.edit = '1'
                            item.required = '1'
                            item.fieldType = 'input'
                        }
                        // 责任方
                        if (item.dataIndex ==='responsibleParty'&& (that.url.columns === PURCHASE_DELIVERY_NOTICE_LIST || that.url.columns === 'purchaseDeliveryNoticeByOrderList')) {
                            item.edit = '1'
                            item.required = '1',
                            item.dictCode = 'srmOrderDeliveryResponsible'
                            item.fieldType = 'select'
                        }
                        // 责任方原因
                        if (item.dataIndex ==='responsibleReason') {
                            item.edit = '1'
                            item.required = '1',
                            item.dictCode = 'srmRejectReason'
                            item.fieldType = 'select'
                        }
                        // 回复数量
                        if ( item.dataIndex === 'replyQuantity'&& (that.url.columns === SALE_DELIVER_NOTICE_LIST||this.url.columns === 'saleDeliveryNoticeByOrderList') ) {
                            item.edit = '1'
                            item.required = '1'
                            item.fieldType = 'input'
                        }
                        // 回复日期
                        if ( item.dataIndex === 'replyDate'&& (that.url.columns === SALE_DELIVER_NOTICE_LIST||this.url.columns === 'saleDeliveryNoticeByOrderList') ) {
                            item.edit = '1'
                            item.required = '1'
                            item.fieldType = 'date'
                        }
                        // 富文本编辑器--详情的自定义列没有类型，先绑定澄清事项，待todo:按类型
                        if (item.dataIndex === 'clarificationMatter') {
                            item.slots= {default: 'rich_editor_dispaly_render'}
                        }
                        if (item.dataIndex === 'ladderPriceJson') {
                            item.slots= {default: 'ladder_price_json_render'}
                            item.showOverflow= false
                        }
                        item.field = item.dataIndex
                        item.columnId = item.id
                        if(item.sorter) {
                            item.sortable = item.sorter
                        }
                        if(item.filters && item.filters.length) {
                            item.filters.forEach(item2 => {
                                item2.label = item2.text
                            })
                        }
                        if(item.scopedSlots) {
                            item.slots = item.scopedSlots
                        }
                        if(item.fixType) {
                            item.fixed = item.fixType
                        }
                        if(item.edit == '1' && item.fieldType) {
                            switch(item.fieldType) {
                            case 'input':
                                item.editRender = { name: '$input' }
                                break
                            case 'select':
                                item.editRender = { name: '$select', options: [] }
                                break
                            case 'switch':
                                item.cellRender = { name: '$switch', props: { openValue: '1', closeValue: '0' } }
                                break
                            case 'date':
                                item.editRender = { name: 'mDatePicker' }
                                break
                            case 'number':
                                item.editRender = { name: '$input', props: {type: 'number'} }
                                break
                            }
                        }
                        if(item.required == '1') {
                            that.editRules[item.fieldName] = [{ required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fieldIsRequired`, '该字段为必填') }]
                        }
                        // 待确认交期订单订单号超链接
                        if (item.field === 'orderNumber' && that.url.columns === PURCHASE_ORDER_ITEM_TABLE_CODE ) {
                            item.slots = {
                                default: ({row})=> {
                                    return [
                                        (<a href="javascript:void(0)" onClick={()=> {that.detailPage(row)}}>{row[item.field]}</a>)
                                    ]
                                }
                            }
                        }
                        // 自定义列管理:自定义渲染（字段占用可以删除）
                        // if (item.customRender) {
                        //     item.slots = {
                        //         default: ({row})=> {
                        //             return [
                        //                 (<div domPropsInnerHTML={item.customRender}></div>)
                        //             ]
                        //         }
                        //     }
                        // }
                    })
                    columns.forEach(item => {
                        if(item.dictCode && item.fieldType == 'select') {
                            let postData = {
                                busAccount: that.$ls.get(USER_ELS_ACCOUNT),
                                dictCode: item.dictCode
                            }
                            ajaxFindDictItems(postData).then(res => {
                                if(res.success) {
                                    let options = res.result.map(item => {
                                        return {
                                            value: item.value,
                                            label: item.title,
                                            title: item.title
                                        }
                                    })
                                    if (item.editRender instanceof Object) {
                                        item.editRender.options = options
                                    }
                                }
                            })
                        }
                    })
                    if(this.pageData.showOptColumn) {
                        let width = 0
                        try {
                            // 简体 繁体
                            let lang = this.$ls.get(DEFAULT_LANG) || 'zh'
                            let strWidth = ['zh', 'cht'].includes(lang) ? 12 : 6
                            // 操作列表宽度修改
                            width = 0
                            // let strLength = this.pageData.optColumnList.filter((el, i) => {
                            //     return i <= 4
                            // }).map(el => el.title).join('').length
                            let strLength = 0
                            let optColumnListLength = this.pageData.optColumnList.length
                            for(let i = 0; i < optColumnListLength; i++) {
                                if (i == 4) break 
                                strLength += this.pageData.optColumnList[i].title.length
                            }
                            if (optColumnListLength > 4) {
                                //按钮数量的边框marging + 40的左右padding
                                let otherWidth = (4 * 8) + 40
                                let fourItemLength = this.pageData.optColumnList[3].title.length
                                width = fourItemLength > 2 ? (strLength - fourItemLength + 2) * strWidth + otherWidth : strLength * strWidth + otherWidth
                                if (this.$ls.get(DEFAULT_LANG) === 'en') width = width + 10
                            } else {
                                //按钮数量的边框marging + 26的左右padding
                                width = (strLength * strWidth) + (optColumnListLength * 8) + 26
                            }
                        } catch {
                            width = this.pageData.optColumnWidth
                        }
                        columns.push({
                            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'),
                            // width: this.pageData.optColumnWidth,
                            width: width || 180,
                            fixed: 'right',
                            align: this.pageData.optColumnAlign,
                            slots: { default: 'grid_opration' }
                        })
                    }
                    this.tableColumns = columns
                }
            })
        },
        handleQuery (flag = true) {
            // 点击查询默认跳到第一页
            this.expand = false
            if (flag) this.tablePage.currentPage = 1
            this.$refs.listGrid.clearCheckboxReserve()
            this.$refs.listGrid.clearCheckboxRow()
            this.loadData()
        },
        handleReset () {
            this.$refs.listGrid.clearCheckboxReserve()
            this.$refs.listGrid.clearCheckboxRow()
            this.pageData.form = {}
            this.superQueryParams = ''
            this.superQueryMatchType = ''
            this.loadData()
            this.expand = false
        },
        deleteRows (row) {
            const that = this
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmDelete`, '确认删除'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_deleteChosedData`, '是否删除选中数据'),
                onOk: function () {
                    that.loading = true
                    getAction(that.url.delete, {id: row.id}).then(res => {
                        if(res.success) {
                            that.$message.success(res.message)
                            that.loadData()
                        }else {
                            that.$message.warning(res.message)
                        }
                    }).finally(() => {
                        that.loading = false
                    })   
                }
            })
            
        },
        upgradeVersion (row) {
            const callback = () => {
                getAction(this.url.upgrade, {id: row.id}).then(res => {
                    if (res.success) {
                        this.$message.success(res.message)
                        this.loadData()
                    } else {
                        this.$message.warning(res.message)
                    }
                })
            }
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_upgradeVersion`, '升级'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmToUpgradeVersion`, '是否确认升级版本'),
                onOk () {
                    callback && callback()
                },
                onCancel () {
                    console.log('Cancel')
                }
            })
        },
        handlePageChange ({ currentPage, pageSize }) {
            this.tablePage.currentPage = currentPage
            this.tablePage.pageSize = pageSize
            this.loadData()
        },
        toggleExpand () {
            this.expand = !this.expand
        },
        //点击排序触发
        sortChangeEvent ({ column, property, order }) {
            if (column.sortable) {
                this.isOrder = {
                    order: order,
                    column: property
                }
                this.loadData()
            }
        },
        // 点击筛选触发
        filterChangeEvent ({ column, property, values}) {
            let reg = /(?=(_dictText$))/g
            if (reg.test(property)) {
                property = property.replace('_dictText', '')
            }
            if (column.filters && column.filters.length) {
                this.filter[property] = values.join(',')
                this.loadData()
            }
        },
        //报错列配置
        saveColumnsConfig (params) {
            let url = '/base/userColumnDefine/saveCurrentUserColumnDefine/' + this.url.columns
            postAction(url, params)
        },
        //修改列配置
        resizableChange ($rowIndex) {
            let columns = this.$refs.listGrid.getColumns()
            let index = $rowIndex.columnIndex
            let newColumns = []
            columns.forEach((item, i) => {
                if(item.own.id) {
                    let columnWidth = item.width
                    if(index == i) {
                        columnWidth = item.resizeWidth
                    }
                    newColumns.push({
                        columnId: item.own.id,
                        hidden: 0,
                        alignType: 'center',
                        columnWidth: columnWidth,
                        fixType: item.fixed
                    })
                }
            })
            this.saveColumnsConfig(newColumns)
        },
        //列自定义弹窗
        settingColumnConfig () {
            this.$refs.columnSettingModal.open(this.url.columns)
        },
        columnDrop () {
            this.$nextTick(() => {
                let listGrid = this.$refs.listGrid
                this.sortable = Sortable.create(listGrid.$el.querySelector('.body--wrapper>.vxe-table--header .vxe-header--row'), {
                    handle: '.vxe-header--column:not(.col--fixed)',
                    onEnd: ({ item, newIndex, oldIndex }) => {
                        let { fullColumn, tableColumn } = listGrid.getTableColumn()
                        let targetThElem = item
                        let wrapperElem = targetThElem.parentNode
                        console.log('wrapperElem', wrapperElem)
                        let newColumn = fullColumn[newIndex]
                        if (newColumn.fixed) {
                            // 错误的移动
                            if (newIndex > oldIndex) {
                                wrapperElem.insertBefore(targetThElem, wrapperElem.children[oldIndex])
                            } else {
                                wrapperElem.insertBefore(wrapperElem.children[oldIndex], targetThElem)
                            }
                            return this.$XModal.message({ message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cannoDragFixedColumn`, '固定列不允许拖动'), status: 'error' })
                        }
                        // 转换真实索引
                        let oldColumnIndex = listGrid.getColumnIndex(tableColumn[oldIndex])
                        let newColumnIndex = listGrid.getColumnIndex(tableColumn[newIndex])
                        // 移动到目标列
                        let currRow = fullColumn.splice(oldColumnIndex, 1)[0]
                        fullColumn.splice(newColumnIndex, 0, currRow)
                        listGrid.loadColumn(fullColumn)
                        let newColumns = []
                        fullColumn.forEach((item) => {
                            if(item.own.id) {
                                newColumns.push({
                                    columnId: item.own.id,
                                    hidden: 0,
                                    alignType: 'center',
                                    columnWidth: item.width,
                                    fixType: item.fixed
                                })
                            }
                        })
                        this.saveColumnsConfig(newColumns)
                    }
                })
            })
        },
        openTemplateModal () {
            this.queryTemplateList(this.$ls.get('Login_elsAccount')).then(res => {
                if(res.success) {
                    if(res.result.length > 0) {
                        let options = res.result.map(item => {
                            return {
                                value: item.templateNumber,
                                title: item.templateName,
                                version: item.templateVersion,
                                account: item.elsAccount
                            }
                        })
                        this.templateOpts = options
                        // 只有单个模板直接新建
                        if (this.templateOpts && this.templateOpts.length===1) {
                            this.templateNumber = this.templateOpts[0].value
                            this.selectedTemplate()
                        } else {
                            // 有多个模板先选择在新建
                            this.visible = true
                        }
                    } else {
                        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_setTemplateFirst`, '请先配置业务模板'))
                    }
                }else {
                    this.$message.warning(res.message)
                }
            })
            
        },
        closeTemplateModal () {
            this.visible = false
        },
        selectedTemplate () {
            if(this.templateNumber) {
                const that = this
                // this.submitLoading = true
                let template = this.templateOpts.filter(item => {
                    return item.value == that.templateNumber
                })
                let params = {
                    templateNumber: this.templateNumber,
                    templateName: template[0].title,
                    templateVersion: template[0].version,
                    templateAccount: template[0].account,
                    elsAccount: this.$ls.get(USER_ELS_ACCOUNT)
                }
                that.$parent.selectedTemplate(params)
                // that.visible = false
                // that.submitLoading = false
                // postAction(this.url.add, params).then(res => {
                //     if(res.success) {
                //         that.$parent.selectedTemplate(res.result)
                //     }else {
                //         that.$message.warning(res.message)
                //     }
                //     that.visible = false
                //     that.submitLoading = false
                // })
            }
        },
        handleCancel () {
            this.visible = false
        },
        // 详情页
        detailPage (row) {
            this.$emit('handleView', row)
        },
        // tab页签改变时
        changeTab (active) {
            let data = this.tabsList[active]
            this.$emit('afterChangeTab', {_this: this, activeTabData: data, pageData: this.pageData, listGrid: this.$refs.listGrid, tablePage: this.tablePage})
        },
        // toolbar_buttons方法封装，暴露更多属性外部使用
        toolbarButtonsCallBack (row, column, rowIndex, columnIndex, cb) {
            if (cb) {
                cb(row, column, rowIndex, columnIndex, this.tableData)
            }
        },
        // 阶梯报价json数据组装
        initRowLadderJson (jsonData) {
            let arr = []
            if (jsonData) {
                arr = JSON.parse(jsonData)
            }
            return arr
        },
        // 阶梯报价默认显示
        defaultRowLadderJson (jsonData) {
            let arrString = ''
            if (jsonData) {
                let arr = JSON.parse(jsonData)
                arr.forEach((item, index)=> {
                    let ladderQuantity = item.ladderQuantity
                    let price = item.price
                    let netPrice= item.netPrice
                    let str = `${ladderQuantity} ${price} ${netPrice} `
                    let separator = index===arr.length-1? '': ','
                    arrString +=str+ separator
                })
            }
            return arrString
        }
    }
}
</script>
<style lang="less" scoped>
.list-tabs-wrap {
    background-color: #fff;
    /deep/ .ant-tabs-bar.ant-tabs-top-bar {
        margin-bottom: 0;
        border: solid 1px #e7e9eb;
    }
}
.reset-grid-box {
    top: 103px;
}
.vxe-toolbar {
    .ant-btn {
        & +.CustomUpload {
            margin-left: 6px;
        }
    }

}
.rich-editor-display-box {
    height: 100%;
}

/deep/ .rich-editor-display-box p {
    margin-bottom: 0px;
}
.json-box {
    width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.disabled{
    color: #4f93f186;
}
</style>