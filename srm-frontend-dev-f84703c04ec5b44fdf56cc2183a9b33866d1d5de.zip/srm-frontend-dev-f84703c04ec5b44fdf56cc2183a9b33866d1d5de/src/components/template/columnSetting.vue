<!--
 * @Author: your name
 * @Date: 2021-03-31 10:21:40
 * @LastEditTime: 2021-08-20 10:55:35
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \srm-frontend_v4.5\src\components\template\columnSetting.vue
-->
<template>
  <a-modal
    centered
    :title="title"
    :width="1000"
    :visible="visible"
    :maskClosable="false"
    :confirmLoading="confirmLoading"
    @cancel="close">
    <vxe-grid
      border
      auto-resize
      height="300"
      row-id="id"
      size="small"
      ref="columnGrid"
      :data="tableData"
      :edit-config="{trigger: 'click', mode: 'cell'}"
      :columns="tableColumn">
      <template slot="empty">
        <a-empty />
      </template>
    </vxe-grid>
    <template slot="footer">
      <a-button
        key="reset"
        @click="reset">
        {{ this.$srmI18n(`${this.$getLangAccount()}#i18n_title_reset`, '重置') }}
      </a-button>
      <a-button
        key="back"
        @click="close">
        {{ this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cancle`, '取消') }}
      </a-button>
      <a-button
        key="submit"
        type="primary"
        @click="selectedOk">
        {{ this.$srmI18n(`${this.$getLangAccount()}#i18n_title_sure`, '确认') }}
      </a-button>
    </template>
  </a-modal>
</template>
<script>
import { Empty } from 'ant-design-vue'
import { ajaxGetAllColumns } from '@/api/api'
import { postAction } from '@/api/manage'
export default {
    name: 'ColumnSetting',
    components: {
        AEmpty: Empty
    },
    inject: ['routeReload'],
    data () {
        return {
            visible: false,
            confirmLoading: false,
            columnsCode: '',
            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'),
            tableColumn: [
                { type: 'checkbox', width: 40, fixed: 'left' },
                { type: 'seq', width: 50, align: 'center', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_seq`, '序号'), fixed: 'left' },
                { field: 'columnCode', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title__columnCoding`, '列编码'), sortable: true, align: 'center', width: 220},
                { field: 'columnName', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title__columnName`, '列名称'), sortable: true, align: 'center', width: 120 },
                { field: 'columnWidth', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_columnWidth`, '列宽'), align: 'center', width: 80, editRender: {name: 'AInput'} },
                { field: 'alignType', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_elsBarcodeRuleItemLista127_alignment`, '对齐方式'), align: 'center', editRender: { name: 'ASelect', options: [{value: 'left', label: '左对齐'}, {value: 'center', label: '中间对齐'}, {value: 'right', label: '右对齐'}] }},
                { field: 'fixType', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_fixType`, '固定方式'), align: 'center', editRender: { name: 'ASelect', options: [{value: '', label: '无固定'}, {value: 'left', label: '左固定'}, {value: 'right', label: '右固定'}] }},
                { field: 'hidden', title: this.$srmI18n(`${this.$getLangAccount()}#i18n_field_hidden`, '是否隐藏'), align: 'center', editRender: { name: 'mSwitch', type: 'visible', props: {closeValue: 0, openValue: 1} } }
            ],
            tableData: []
        }
    },
    methods: {
        getColumnsList (column) {
            this.columnsCode = column
            this.title = this.$srmI18n(`${this.$getLangAccount()}#i18n_title__tableCode`, '表格编码')+':'+column
            ajaxGetAllColumns(column, null).then((res) => {
                let list = res.result
                this.$refs.columnGrid.loadData(list)
            })
        },
        open (column) {
            this.getColumnsList(column)
            this.visible = true
        },
        close () {
            this.visible = false
        },
        // 重置
        reset (){
            let url = '/base/userColumnDefine/clearCurrentUserColumnDefine/' + this.columnsCode
            postAction(url).then(() => {
                this.routeReload()
            })
        },
        selectedOk () {
            let tableData = this.$refs.columnGrid.getTableData().fullData
            let columnList = []
            tableData.forEach(item => {
                columnList.push({
                    hidden: item.hidden,
                    columnId: item.id,
                    fixType: item.fixType,
                    columnWidth: item.columnWidth,
                    columnName: item.columnName,
                    alignType: item.alignType
                })
            })
            let url = '/base/userColumnDefine/saveCurrentUserColumnDefine/' + this.columnsCode
            postAction(url, columnList).then(() => {
                this.routeReload()
            })
        }
    }
}
</script>