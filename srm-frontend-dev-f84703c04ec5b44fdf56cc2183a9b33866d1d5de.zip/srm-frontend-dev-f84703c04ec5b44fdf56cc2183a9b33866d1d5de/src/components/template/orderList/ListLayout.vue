<template>
  <div class="page-container ListLayout">
    <a-form-model 
      ref="queryForm" 
      :model="form" 
      class="ant-advanced-search-form"
      @keyup.enter.native="handleQuery" 
      layout="inline" 
      v-bind="layout">
      <a-row :gutter="12">
        <a-col
          v-for="(item, i) in normalFieldList"
          :key="'field_'+i"
          :span="8">
          <a-form-model-item
            v-if="item.type==='input'"
            :prop="item.fieldName"
            :label="item.label">
            <a-input
              v-model="pageData.form[item.fieldName]"
              :placeholder="item.placeholder" />
          </a-form-model-item>
          <a-form-model-item
            v-if="item.type==='select'"
            :prop="item.fieldName"
            :label="item.label">
            <m-select
              v-model="pageData.form[item.fieldName]"
              :dict-code="item.dictCode"
              :placeholder="item.placeholder" />
          </a-form-model-item>
        </a-col>
        <a-col
          :span="8"
          class="search-btn-groups">
          <a-button
            type="primary"
            icon="search"
            style="margin-right:12px"
            @click="handleQuery">查询</a-button>
          <a-button
            type="default"
            icon="reload"
            @click="handleReset">重置</a-button>
          <a 
            v-if="foldedFieldList.length"
            style="margin-left:8px"
            @click="toggleExpand">
            {{ expand ? `${$srmI18n(`${$getLangAccount()}#i18n_title_collapsed`, '收起')}` : `${$srmI18n(`${$getLangAccount()}#i18n_title_expand`, '展开')}` }}
            <a-icon :type="expand ? 'up' : 'down'" />
          </a>
        </a-col>
      </a-row>
      <a-row    
        v-show="expand" 
        :gutter="12"
        class="expand-field">
        <a-col
          v-for="(item, i) in foldedFieldList"
          :key="'field_'+i"
          :span="8">
          <a-form-model-item
            v-if="item.type==='input'"
            :prop="item.fieldName"
            :label="item.label">
            <a-input
              v-model="pageData.form[item.fieldName]"
              :placeholder="item.placeholder" />
          </a-form-model-item>
          <a-form-model-item
            v-if="item.type==='select'"
            :prop="item.fieldName"
            :label="item.label">
            <m-select
              v-model="pageData.form[item.fieldName]"
              :dict-code="item.dictCode"
              :placeholder="item.placeholder" />
          </a-form-model-item>
        </a-col>
      </a-row>
    </a-form-model>
    <div class="grid-box">
      <vxe-grid
        row-id="id"
        ref="listGrid"
        v-bind="gridConfig"
        :seq-config="{startIndex: (tablePage.currentPage - 1) * tablePage.pageSize}"
        :loading="loading"
        :columns="tableColumns"
        :data="tableData"
        :pager-config="tablePage"
        :edit-config="editConfig"
        :edit-rules="editRules"
        :filter-config="filterConfig"
        @sort-change="sortChangeEvent"
        @filter-change="filterChangeEvent"
        @resizable-change="resizableChange"
        @page-change="handlePageChange">
        <template #empty>
          <a-empty />
        </template>
        <!--自定义插槽 seq_header-->
        <template
          v-if="pageData.showOptColumnList"
          #grid_opration="{ row, column }">
          <a
            v-for="(item, i) in optColumnList"
            :key="'opt_'+ row.id + '_' + i"
            :title="item.title"
            style="margin:0 4px"
            :disabled="item.allow ? item.allow(row) : false"
            v-show="item.showCondition ? item.showCondition(row) : true"
            @click="toolbarButtonsCallBack(row, column, $rowIndex, $columnIndex, item.clickFn)">{{ item.title }}</a>
          <a-dropdown v-if="optColumnListMore.length > 0">
            <a
              class="ant-dropdown-link"
              @click="e => e.preventDefault()">
              更多 <a-icon type="down" />
            </a>
            <a-menu
              slot="overlay"
            >
              <a-menu-item
                v-show="itemMore.showCondition ? itemMore.showCondition(row) : true"
                :key="'opt_'+ row.id + '_' + more_index"
                v-for="(itemMore, more_index) in optColumnListMore">
                <a-button
                  type="link"
                  :title="itemMore.title"
                  style="margin:0 4px"
                  :disabled="itemMore.allow ? itemMore.allow(row) : false"
                  @click="toolbarButtonsCallBack(row, column, $rowIndex, $columnIndex, itemMore.clickFn)">
                  {{ itemMore.title }}
                </a-button>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
        </template>
        <template #toolbar_buttons>
          <a-button
            v-for="(item, i) in normalBtnList"
            :type="item.type"
            :icon="item.icon"
            :key="'button_'+i"
            @click="item.clickFn"
          >
            {{ item.label }}
          </a-button>
          <a-dropdown v-if="foldBtnList.length">
            <a-button icon="more">更多</a-button>
            <a-menu slot="overlay">
              <a-menu-item
                v-for="(item, i) in foldBtnList"
                :key="'menu_button_'+i">
                <a-upload
                  v-if="item.type==='upload'"
                  name="file"
                  :show-upload-list="false"
                  :multiple="false"
                  :headers="tokenHeader"
                  :action="importExcelUrl"
                  @change="handleImportExcel"
                >
                  <a-icon
                    :type="item.icon"
                    style="margin-right:10px"></a-icon>导入
                </a-upload>
                <div
                  v-else
                  @click="item.clickFn">
                  <a-icon
                    :type="item.icon"
                    style="margin-right:10px"></a-icon>{{ item.label }}
                </div>
              </a-menu-item>
            </a-menu>
          </a-dropdown>
        </template>
        <template #custom_render="{ row, column }">
          <slot 
            name="custom_column_render" 
            :row="row"
            :column="column"/>
        </template>
        <template #fbk1_default="{ row, column }">
          <span
            v-if="!!row._id"
            class="red">{{ row.orderNumber }}_{{ row.orderItemNumber }} {{ changeMap[row[column.property]] || '' }}</span>
          <a-select
            v-else
            v-model="row[column.property]"
            @change="(val) => handleChange(val, row, column)">
            <a-select-option
              v-for="(label, value) in changeMap"
              :key="value">{{ label }}</a-select-option>
          </a-select>
        </template>
        <template #_handle_default="{row, column, $rowIndex}">
          <div v-show="row.fbk1 === '0'">
            <a
              href="javascript: void(0)"
              @click="handleAddItem(row, column, $rowIndex)">{{ $srmI18n(`${$getLangAccount()}#i18n_title_split`, '拆分') }}</a>
            <a
              class="del red"
              :class="!!row._id ? '' : 'disabled'"
              href="javascript: void(0)"
              @click="handleDelItem(row, column, $rowIndex)">{{ $srmI18n(`${$getLangAccount()}#i18n_title_delete`, '删除') }}</a>
          </div>
        </template>
      </vxe-grid>
    </div>
    <column-setting ref="columnSettingModal"></column-setting>
    <a-modal 
      centered
      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_selectTemplate`, '选择模板') }`"
      :width="360"
      v-model="visible"
      @ok="selectedTemplate">
      <template slot="footer">
        <a-button
          key="back"
          @click="handleCancel">
          {{ $srmI18n(`${$getLangAccount()}#i18n_title_cancle`, '取消') }}
        </a-button>
        <a-button
          key="submit"
          type="primary"
          :loading="submitLoading"
          @click="selectedTemplate">
          {{ $srmI18n(`${$getLangAccount()}#i18n_title_sure`, '确定') }}
        </a-button>
      </template>
      <m-select
        v-model="templateNumber"
        :options="templateOpts"
        :placeholder="$srmI18n(`${$getLangAccount()}#i18n_title_selectTemplateType`, '请选择模板')"
      />
    </a-modal>
    <import-excel
      ref="importExcel"
      :excelCode="url.excelCode" />
  </div>
</template>

<script>
import { getAction, downFile, postAction } from '@/api/manage'
import { ajaxGetColumns } from '@/api/api'
import { ACCESS_TOKEN, USER_ELS_ACCOUNT } from '@/store/mutation-types'
import Sortable from 'sortablejs'
import columnSetting from '@comp/template/columnSetting'
import { ListConfig } from '@/plugins/table/gridConfig'
import {ajaxFindDictItems} from '@/api/api'
import ImportExcel from '@comp/template/import/ImportExcel'
export default {
    name: 'ListLayout',
    props: {
        pageData: { //页面数据
            type: Object,
            default: null
        },
        url: {  //后台接口
            type: Object,
            default: null
        },
        activeMethod: {
            type: Function,
            default: () => true
        }
    },
    components: {
        columnSetting,
        ImportExcel
    },
    data () {
        return {
            changeMap: {
                0: '变更',
                1: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirm`, '确认')
            },
            form: {},
            gridConfig: ListConfig,
            expand: false,
            visible: false,
            submitLoading: false,
            normalFieldList: this.pageData.formField.slice(0, 2),
            foldedFieldList: this.pageData.formField.slice(2),
            layout: {
                labelCol: { span: 8 },
                wrapperCol: { span: 16 }
            },
            loading: false,
            tokenHeader: {'X-Access-Token': this.$ls.get(ACCESS_TOKEN)},
            filter: {},
            isOrder: {
                column: 'id',
                order: 'desc'
            },
            tableColumns: [],
            tableData: [],
            toolbarConfig: {
                slots: {buttons: 'toolbar_buttons'},
                // import: true,
                // export: true,
                print: true,
                zoom: true,
                // custom: true,
                perfect: true
            },
            tablePage: {
                total: 0,
                currentPage: 1,
                pageSize: 20,
                align: 'right',
                pageSizes: [20, 50, 100, 200, 500],
                layouts: ['Sizes', 'PrevPage', 'Number', 'NextPage', 'FullJump', 'Total'],
                perfect: true
            },
            filterConfig: {
                remote: true
            },
            templateNumber: undefined,
            templateOpts: [],
            editRules: {},
            editConfig: {
                trigger: 'dblclick',
                mode: 'row',
                showStatus: true,
                icon: 'fa fa-file-text-o',
                activeMethod: this.activeMethod
            }
        }
    },
    computed: {
        normalBtnList () {
            return this.pageData.button.filter(item => {
                return !item.folded
            })
        },
        foldBtnList () {
            return this.pageData.button.filter(item => {
                return item.folded
            })
        },
        importExcelUrl: function (){
            return `${this.$variateConfig['domianURL']}/${this.url.importExcelUrl}`
        },
        // 操作列按钮
        optColumnList () {
            let newArr = [...this.pageData.optColumnList]
            return newArr.length > 4 ? newArr.slice(0, 3) : newArr
        },
        // 操作列按钮（更多）
        optColumnListMore () {
            let newArr = [...this.pageData.optColumnList]
            return newArr.length > 4 ? newArr.slice(3) : []
        }
    },
    beforeDestroy () {
        if (this.sortable) {
            this.sortable.destroy()
        }
    },
    created () {
        this.initColumns()
        this.loadData()
        this.columnDrop()
    },
    methods: {
        handleChange (val, row, column) {
            const { id = '' } = row || {}
            const fn = n => n._id && (n._id === id)
            const invert = x => (...args) => !x(...args)
            const flag = this.tableData.some(fn)
            if (flag) {
                this.tableData = this.tableData.filter(invert(fn))
            }
            this.$refs.listGrid.clearActived().then(() => {
                console.log('val', val)
                console.log(val === '0')
                if (val === '0') this.$refs.listGrid.setActiveRow(row)
            })
        },
        handleAddItem (row, column, i) {
            const record = Object.assign({}, row, {
                _id: row.id || row._id,
                planDeliveryDate: '', // 计划交货日期
                planDeliveryQuantity: '' // 计划交货数量
            })
            this.tableData.splice(i, 0, record)
            this.$refs.listGrid.setActiveRow(record)
        },
        handleDelItem (row, column, i) {
            if (row.id && !row._id) return
            this.tableData.splice(i, 1)
        },
        // 导出
        handleExportXls (fileName){
            if(!fileName || typeof fileName != 'string'){
                fileName = '导出文件'
            }
            let param = {...this.pageData.form}
            if(this.selectedRowKeys && this.selectedRowKeys.length>0){
                param['selections'] = this.selectedRowKeys.join(',')
            }
            downFile(this.url.exportXlsUrl, param).then((data)=>{
                if (!data) {
                    this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fileDownloadFailed`, '文件下载失败'))
                    return
                }
                if (typeof window.navigator.msSaveBlob !== 'undefined') {
                    window.navigator.msSaveBlob(new Blob([data]), fileName+'.xls')
                }else{
                    let url = window.URL.createObjectURL(new Blob([data]))
                    let link = document.createElement('a')
                    link.style.display = 'none'
                    link.href = url
                    link.setAttribute('download', fileName+'.xls')
                    document.body.appendChild(link)
                    link.click()
                    document.body.removeChild(link) //下载完成移除元素
                    window.URL.revokeObjectURL(url) //释放掉blob对象
                }
            })
        },
        /* 导入 */
        handleImportExcel (info){
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList)
            }
            if (info.file.status === 'done') {
                if (info.file.response.success) {
                    if (info.file.response.code === 201) {
                        let { message, result: { msg, fileUrl, fileName } } = info.file.response
                        let href = this.$variateConfig['domianURL'] + fileUrl
                        this.$warning({
                            title: message,
                            content: (
                                <div>
                                    <span>{msg}</span><br/>
                                    <span>
                                        { this.$srmI18n(`${this.$getLangAccount()}#i18n_title_detailContent`, '具体详情请') }
                                        <a href={href} target="_blank" download={fileName}>
                                            { this.$srmI18n(`${this.$getLangAccount()}#i18n_title_download`, '点击下载') }
                                        </a>
                                    </span>
                                </div>
                            )
                        })
                    } else {
                        let message = info.file.response.message || this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadSuccess`, '文件上传成功')
                        this.$message.success(message)
                    }
                    this.loadData()
                } else {
                    this.$message.error(`${info.file.name} ${info.file.response.message}.`)
                }
            } else if (info.file.status === 'error') {
                this.$message.error(`${this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadError`, '文件上传失败')} : ${info.file.msg}`)
            }
        },
        queryTemplateList (elsAccount) {
            let params = {pageSize: 100, elsAccount: elsAccount, businessType: this.pageData.businessType, pageNo: 1}
            return getAction('/template/templateHead/getListByType', params)
        },
        //获取数据
        loadData () {
            this.loading = true
            let form = this.pageData.form
            let isOrder = this.pageData.isOrder || this.isOrder
            let params = Object.assign(form, 
                {
                    pageSize: this.tablePage.pageSize, 
                    pageNo: this.tablePage.currentPage,
                    filter: this.filter
                }, isOrder)
            getAction(this.url.list, params).then((res) => {
                if(res.success) {
                    let list = [...res.result.records]
                    list.forEach(item => {
                        if(item.extendFields) {
                            Object.assign(item, JSON.parse(item.extendFields))
                        }
                    })
                    this.tableData = list.map(({ fbk1, ...others }) => ({
                        _id: '',
                        fbk1: fbk1 || '',
                        ...others
                    }))
                    this.tablePage.total = res.result.total
                }
            }).finally(() => {
                this.loading = false
            })
        },
        // 获取表格列信息
        async initColumns (){
            const that = this
            ajaxGetColumns(this.url.columns, null).then((res) => {
                if(res.success) {
                    let columns = [
                        { type: 'checkbox', width: 36, fixed: 'left', headerAlign: 'left' },
                        { type: 'seq', width: 50, title: '序号', align: 'center', fixed: 'left' },
                        { width: 150, fixed: 'left', align: 'center', dataIndex: 'fbk1', title: '变更', scopedSlots: { default: 'fbk1_default' } },
                        { width: 150, fixed: 'left', align: 'center', dataIndex: '_handle', title: '变更操作', scopedSlots: { default: '_handle_default' } }
                    ]
                    columns = columns.concat(res.result)
                    // 字段转换
                    columns.forEach(item => {
                        // 计划交货日期
                        if ( item.dataIndex === 'planDeliveryDate' ) {
                            item.edit = '1'
                            item.required = '1'
                            item.fieldType = 'date'
                        }
                        // 计划交货数量
                        if ( item.dataIndex === 'planDeliveryQuantity' ) {
                            item.edit = '1'
                            item.required = '1'
                            item.fieldType = 'input'
                        }
                        
                        item.field = item.dataIndex
                        item.columnId = item.id
                        if(item.sorter) {
                            item.sortable = item.sorter
                        }
                        if(item.filters && item.filters.length) {
                            item.filters.forEach(item2 => {
                                item2.label = item2.text
                            })
                        }
                        if(item.scopedSlots) {
                            item.slots = item.scopedSlots
                        }
                        if(item.fixType) {
                            item.fixed = item.fixType
                        }
                        if(item.edit === '1' && item.fieldType) {
                            switch(item.fieldType) {
                            case 'input':
                                item.editRender = { name: '$input' }
                                break
                            case 'select':
                                item.editRender = { name: '$select', options: [] }
                                break
                            case 'switch':
                                item.cellRender = { name: '$switch', props: { openValue: '1', closeValue: '0' } }
                                break
                            case 'date':
                                item.editRender = { name: 'mDatePicker' }
                                break
                            case 'number':
                                item.editRender = { name: '$input', props: {type: 'number'} }
                                break
                            }
                        }
                        if (item.required == '1') {
                            that.editRules[item.fieldName] = [{ required: true, message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_fieldIsRequired`, '该字段为必填') }]
                        }
                    })
                    columns.forEach(item => {
                        if(item.dictCode && item.fieldType == 'select') {
                            let postData = {
                                busAccount: that.$ls.get(USER_ELS_ACCOUNT),
                                dictCode: item.dictCode
                            }
                            ajaxFindDictItems(postData).then(res => {
                                if(res.success) {
                                    let options = res.result.map(item => {
                                        return {
                                            value: item.value,
                                            label: item.title,
                                            title: item.title
                                        }
                                    })
                                    item.editRender.options = options
                                }
                            })
                        }
                    })
                    if(this.pageData.showOptColumn) {
                        let width = 0
                        try {
                            // 操作列表宽度修改
                            width = 0
                            // let strLength = this.pageData.optColumnList.filter((el, i) => {
                            //     return i <= 4
                            // }).map(el => el.title).join('').length
                            let strLength = 0
                            for(let i = 0; i < this.pageData.optColumnList.length; i++) {
                                strLength += this.pageData.optColumnList[i].title.length
                                if (i == 4) break 
                            }
                            if (this.pageData.optColumnList.length > 4) {
                                let fourItemLength = this.pageData.optColumnList[3].title.length
                                width = fourItemLength > 2 ? (strLength - fourItemLength + 2) * 12 + 50 : strLength * 12 + 50
                            } else {
                                width = strLength * 12 + 60
                            }
                        } catch {
                            width = this.pageData.optColumnWidth
                        }
                        columns.push({
                            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_operation`, '操作'),
                            // width: this.pageData.optColumnWidth,
                            width: width || 180,
                            fixed: 'right',
                            align: this.pageData.optColumnAlign,
                            slots: { default: 'grid_opration' }
                        })
                    }
                    this.tableColumns = columns
                }
            })
        },
        handleQuery () {
            // 点击查询默认跳到第一页
            this.expand = false
            this.tablePage.currentPage = 1
            this.$refs.listGrid.clearCheckboxReserve()
            this.$refs.listGrid.clearCheckboxRow()
            this.loadData()
        },
        handleReset () {
            this.$refs.listGrid.clearCheckboxReserve()
            this.$refs.listGrid.clearCheckboxRow()
            this.pageData.form = {}
            this.loadData()
            this.expand = false
        },
        deleteRows (row) {
            const that = this
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmDelete`, '确认删除'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_isConfirmDeletion`, '是否删除选中数据?'),
                onOk: function () {
                    that.loading = true
                    getAction(that.url.delete, {id: row.id}).then(res => {
                        if(res.success) {
                            that.$message.success(res.message)
                            that.loadData()
                        }else {
                            that.$message.warning(res.message)
                        }
                    })   
                }
            })
            
        },
        upgradeVersion (row) {
            const callback = () => {
                getAction(this.url.upgrade, {id: row.id}).then(res => {
                    if (res.success) {
                        this.$message.success(res.message)
                        this.loadData()
                    } else {
                        this.$message.warning(res.message)
                    }
                })
            }
            this.$confirm({
                title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_upgradeVersion`, '升级'),
                content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmToUpgradeVersion`, '是否确认升级版本'),
                onOk () {
                    callback && callback()
                },
                onCancel () {
                    console.log('Cancel')
                }
            })
        },
        handlePageChange ({ currentPage, pageSize }) {
            this.tablePage.currentPage = currentPage
            this.tablePage.pageSize = pageSize
            this.loadData()
        },
        toggleExpand () {
            this.expand = !this.expand
        },
        //点击排序触发
        sortChangeEvent ({ column, property, order }) {
            if (column.sortable) {
                this.isOrder = {
                    order: order,
                    column: property
                }
                this.loadData()
            }
        },
        // 点击筛选触发
        filterChangeEvent ({ column, property, values}) {
            let reg = /(?=(_dictText$))/g
            if (reg.test(property)) {
                property = property.replace('_dictText', '')
            }
            if (column.filters && column.filters.length) {
                this.filter[property] = values.join(',')
                this.loadData()
            }
        },
        //报错列配置
        saveColumnsConfig (params) {
            let url = '/base/userColumnDefine/saveCurrentUserColumnDefine/' + this.url.columns
            postAction(url, params)
        },
        //修改列配置
        resizableChange ($rowIndex) {
            let columns = this.$refs.listGrid.getColumns()
            let index = $rowIndex.columnIndex
            let newColumns = []
            columns.forEach((item, i) => {
                if(item.own.id) {
                    let columnWidth = item.width
                    if(index == i) {
                        columnWidth = item.resizeWidth
                    }
                    newColumns.push({
                        columnId: item.own.id,
                        hidden: 0,
                        alignType: 'center',
                        columnWidth: columnWidth,
                        fixType: item.fixed
                    })
                }
            })
            this.saveColumnsConfig(newColumns)
        },
        //列自定义弹窗
        settingColumnConfig () {
            this.$refs.columnSettingModal.open(this.url.columns)
        },
        columnDrop () {
            this.$nextTick(() => {
                let listGrid = this.$refs.listGrid
                this.sortable = Sortable.create(listGrid.$el.querySelector('.body--wrapper>.vxe-table--header .vxe-header--row'), {
                    handle: '.vxe-header--column:not(.col--fixed)',
                    onEnd: ({ item, newIndex, oldIndex }) => {
                        let { fullColumn, tableColumn } = listGrid.getTableColumn()
                        let targetThElem = item
                        let wrapperElem = targetThElem.parentNode
                        console.log('wrapperElem', wrapperElem)
                        let newColumn = fullColumn[newIndex]
                        if (newColumn.fixed) {
                            // 错误的移动
                            if (newIndex > oldIndex) {
                                wrapperElem.insertBefore(targetThElem, wrapperElem.children[oldIndex])
                            } else {
                                wrapperElem.insertBefore(wrapperElem.children[oldIndex], targetThElem)
                            }
                            return this.$XModal.message({ message: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_cannoDragFixedColumn`, '固定列不允许拖动'), status: 'error' })
                        }
                        // 转换真实索引
                        let oldColumnIndex = listGrid.getColumnIndex(tableColumn[oldIndex])
                        let newColumnIndex = listGrid.getColumnIndex(tableColumn[newIndex])
                        // 移动到目标列
                        let currRow = fullColumn.splice(oldColumnIndex, 1)[0]
                        fullColumn.splice(newColumnIndex, 0, currRow)
                        listGrid.loadColumn(fullColumn)
                        let newColumns = []
                        fullColumn.forEach((item) => {
                            if(item.own.id) {
                                newColumns.push({
                                    columnId: item.own.id,
                                    hidden: 0,
                                    alignType: 'center',
                                    columnWidth: item.width,
                                    fixType: item.fixed
                                })
                            }
                        })
                        this.saveColumnsConfig(newColumns)
                    }
                })
            })
        },
        openTemplateModal () {
            this.queryTemplateList(this.$ls.get('Login_elsAccount')).then(res => {
                if(res.success) {
                    if(res.result.length > 0) {
                        let options = res.result.map(item => {
                            return {
                                value: item.templateNumber,
                                title: item.templateName,
                                version: item.templateVersion,
                                account: item.elsAccount
                            }
                        })
                        this.templateOpts = options
                        // 只有单个模板直接新建
                        if (this.templateOpts && this.templateOpts.length===1) {
                            this.templateNumber = this.templateOpts[0].value
                            this.selectedTemplate()
                        } else {
                            // 有多个模板先选择在新建
                            this.visible = true
                        }
                    }else {
                        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_setTemplateFirst`, '请先配置业务模板'))
                    }
                }else {
                    this.$message.warning(res.message)
                }
            })
            
        },
        closeTemplateModal () {
            this.visible = false
        },
        selectedTemplate () {
            if(this.templateNumber) {
                const that = this
                this.submitLoading = true
                let template = this.templateOpts.filter(item => {
                    return item.value == that.templateNumber
                })
                let params = {
                    templateNumber: this.templateNumber,
                    templateName: template[0].title,
                    templateVersion: template[0].version,
                    templateAccount: template[0].account
                }
                postAction(this.url.add, params).then(res => {
                    if(res.success) {
                        that.$parent.selectedTemplate(res.result)
                    }else {
                        that.$message.warning(res.message)
                    }
                    that.visible = false
                    that.submitLoading = false
                })
            }
        },
        handleCancel () {
            this.visible = false
        }
    }
}
</script>

<style lang="less" scoped>
.ListLayout {
    .red {
        color: #f41616;
    }
    .del {
        margin-left: 10px;
        &.disabled {
            color: #ccc;
            cursor: not-allowed;
        }
    }
}
</style>
