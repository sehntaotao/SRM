import ListLayout from './ListLayout.vue'
import {getAction} from '@/api/manage'
export const ListMixin = {
    components: {
        ListLayout
    },
    data () {
        return {
            showEditPage: false,
            showDetailPage: false,
            pageData: {
                publicBtn: [
                    {label: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_Query`, '查询'), type: 'primary', icon: 'search', clickFn: this.searchEvent},
                    {label:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_reset`, '重置'), icon: 'reload', clickFn: this.resetEvent}
                ],
                button: [
                    {label:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_add`, '新增'), icon: 'plus', clickFn: this.handleAdd, type: 'primary'},
                    // {label: '删除', icon: 'delete', clickFn: this.handleDelete},
                    {label:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_export`, '导出'), icon: 'download', folded: true, clickFn: this.handleExportXls},
                    {label:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_improt`, '导入'), icon: 'import', folded: true, type: 'upload'},
                    {label:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_listCustom`, '列自定义'), icon: 'setting', clickFn: this.settingColumns}
                ],
                showOptColumn: true,
                optColumnList: [
                    {type: 'view', title:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_see`, '查看'), clickFn: this.handleView},
                    {type: 'edit', title:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_edit`, '编辑'), clickFn: this.handleEdit},
                    {type: 'delete', title:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_delete`, '删除'), clickFn: this.handleDelete}
                ],
                optColumnWidth: 130,
                optColumnAlign: 'center',
                isOrder: {
                    column: 'id',
                    order: 'desc'
                } 
            },
            //当前点击的行数据
            currentEditRow: {}
        }
    },
    methods: {
        modalFormOk () {
            // 新增/修改 成功时，重载列表
            this.$refs.listPage.loadData()
        },
        selectedTemplate (data) {
            if(data) {
                this.$refs.listPage.closeTemplateModal()
                this.currentEditRow = data
                this.showEditPage = true
                this.$store.dispatch('SetTabConfirm', true)
            }
        },
        handleView (row) {
            this.currentEditRow = row
            this.showDetailPage = true
            this.$store.dispatch('SetTabConfirm', true)
        },
        handleAdd () {
            this.currentEditRow = {}
            this.$refs.listPage.openTemplateModal()
        },
        handleEdit (row) {
            this.currentEditRow = row
            this.showEditPage = true
        },
        handleDelete (row) {
            this.$refs.listPage.deleteRows(row)
        },
        handleUpgrade (row) {
            this.$refs.listPage.upgradeVersion(row)
        },
        hideEditPage () {
            this.showEditPage = false
            this.showDetailPage = false
            this.$store.dispatch('SetTabConfirm', false)
            this.searchEvent()
        },
        confirmHideEditPage () {
            let that = this
            this.$confirm({
               content:this.$srmI18n(`${this.$getLangAccount()}#i18n_title_confirmToReturn`, '是否确认返回？'),
                onOk: () => {
                    that.hideEditPage()
                }
            })
        },
        handleExportXls () {
            this.$refs.listPage.handleExportXls(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_files`, '文件'))
        },
        settingColumns () {
            this.$refs.listPage.settingColumnConfig()
        },
        searchEvent () {
            this.$refs.listPage.handleQuery()
        },
        resetEvent () {
            this.$refs.listPage.searchReset()
        },
        importExcel () {
            getAction('/base/excelHeader/getConfig/' + this.url.excelCode, null).then(res => {
                if(res.success) {
                    let isPreview = res.result.previewData
                    let previewColumns = res.result.excelDetailList.map(item => {
                        return {
                            title: item.columnName,
                            field: item.columnCode,
                            width: 120,
                            dataType: item.dataType,
                            dataFormat: item.dataFormat
                        }
                    })
                    this.$refs.listPage.$refs.importExcel.open(isPreview, previewColumns, res.result.excelName)
                }else {
                    this.$message.warning(res.message)
                }
            })
        }
    }
}