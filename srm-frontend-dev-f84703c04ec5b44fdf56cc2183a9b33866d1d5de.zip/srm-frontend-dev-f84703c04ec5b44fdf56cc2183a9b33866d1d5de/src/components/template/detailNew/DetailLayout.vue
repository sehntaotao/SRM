<template>
  <div class="detailPage">
    <a-spin :spinning="confirmLoading">
      <div class="container">
        <div class="top">
          <div class="breadcrumb">
            <!-- <breadcrumb></breadcrumb> -->
          </div>
          <div class="btnGroups">
            <a-button
              v-for="(btn, index) in pageData.publicBtn"
              :key="'pub_btn_' + index"
              :type="btn.type"
              v-show="btn.showCondition ? btn.showCondition() : true"
              :disabled="btn.disabled"
              @click="btn.click"
            >
              {{ btn.title }}
            </a-button>
          </div>
        </div>
        <div class="content">
          <div class="tabs">
            <a-tabs v-model="activeKey">
              <a-tab-pane
                v-for="tab in pageData.groups"
                :key="tab.groupCode"
                forceRender
                :tab="tab.groupName"
              >
                <span slot="tab">
                  <a-badge :dot="tab.showDadgeDot">
                    {{ $srmI18n(`${busAccount}#${tab.groupNameI18nKey}`, tab.groupName) }}
                  </a-badge>
                </span>
                <div
                  v-if="tab.type && tab.type === 'grid'"
                  class="table"
                  :style="{ minHeight: `${minHeight}px` }"
                >
                  <vxe-grid
                    :ref="tab.custom.ref"
                    v-bind="defaultGridOption"
                    header-align="center"
                    :columns="tab.custom.columns"
                    :edit-config="tab.custom.editConfig || gridCustomEditConfig"
                    @cell-dblclick="dblclickHander"
                  >
                    <!-- 2021-10-09 新增一个插槽，通过options数组来渲染a标签，相比原来的grid_opration，不需要额外配置optColumnList，且只能限制使用1个 -->
                    <template #showBtn="{ row, column }">
                      <!-- 判断字段中的指定字段是否等于指定值，相等才显示 -->
                      <template v-if="column._own.isShow.default || row[column._own.isShow.key] === column._own.isShow.value">
                        <template v-for="(item, i) in column._own.options">
                          <!-- 上传 -->
                          <a-upload
                            v-if="item.type==='upload'"
                            :key="'opt_' + row.id + '_' + i"
                            :show-upload-list="false"
                            :multiple="false"
                            :headers="tokenHeader"
                            :data="{businessType: item.params.businessType, headId: row.headId || item.params.headId, uploadElsAccount: item.params.businessType}"
                            :action="item.url"
                            @change="(info) => item.clickFn(info, row, column)"
                          >
                            <span
                              v-if="item.isConfirm"
                              :ref="'upload' + row._XID"
                              style="margin:0 4px;color: #1890ff;cursor:pointer;"
                              @click="item.confirm($event, row, column, 'upload' + row._XID)"
                            >{{ item.title }}</span>
                            <span
                              v-else
                              style="margin:0 4px;color: #1890ff;cursor:pointer;"
                            >{{ item.title }}</span>
                          </a-upload>
                          <!-- 弹出窗 -->
                          <div
                            v-else-if="item.type==='selectModal'"
                            :key="'opt_' + row.id + '_' + i"
                            style="position: relative;min-height: 30px;padding-right: 20px;"
                          >
                            {{ row[item.field] }}
                            <a style="position: absolute;display: inline-block;font-size: 16px;right: 0px; top: 3px;z-index: 10; background: #fff;">
                              <a-icon
                                type="file-search"
                                @click="item.clickFn(row, column)"
                              />
                            </a>
                          </div>
                          <!-- a标签 -->
                          <a
                            v-else-if="row[item.disable.key]"
                            :key="'opt_' + row.id + '_' + i"
                            :title="item.title"
                            style="margin:0 4px"
                            @click="item.clickFn(row, column)"
                          >
                            {{ item.title }}
                          </a>
                          <span
                            v-else
                            :key="'opt_' + row.id + '_' + i"
                            style="margin:0 4px"
                          >
                            {{ item.title }}
                          </span>
                        </template>
                      </template>
                    </template>
                    <template #toolbar_buttons>
                      <div class="btns">
                        <span
                          v-for="(btn, info) in tab.custom.buttons"
                          :key="'btn_' + info"
                          style="margin-right: 10px"
                          v-show="btn.showCondition ? btn.showCondition() : true"
                        >
                          <a-button
                            v-if="btn.type !== 'upload' && btn.type !== 'import' && btn.type !== 'select'"
                            :type="btn.type"
                            :disabled="btn.disabled && btn.disabled(btn) || false"
                            @click="btn.click"
                          >
                            {{ btn.title }}
                          </a-button>
                          <a-upload
                            v-else-if="btn.type === 'import'"
                            :show-upload-list="false"
                            :multiple="false"
                            :headers="tokenHeader"
                            :data="btn.params"
                            :action="url.import"
                            :accept="btn.accept"
                            @change="(info) => handleUploadChange(info, btn, group.custom.ref)"
                          >
                            <a-button
                              @click="btn.beforeImport && btn.beforeImport($event)"
                              :disabled="btn.disabled && btn.disabled(btn) || false"
                              type="primary"
                            >{{ btn.title }}</a-button>
                          </a-upload>
                          <custom-upload
                            v-if="btn.type == 'upload'"
                            :single="btn.single"
                            :disabledItemNumber="btn.disabledItemNumber"
                            :requiredFileType="btn.requiredFileType"
                            :dictCodeType="btn.dictCodeType"
                            :property="btn.property"
                            :visible.sync="btn.modalVisible"
                            :title="btn.title"
                            :itemInfo="itemInfo"
                            :action="url.upload"
                            :accept="accept"
                            :headers="tokenHeader"
                            :data="{businessType: btn.businessType, headId: form.id}"
                            @change="(info) => handleUploadChange(info, btn, tab.custom.ref)"
                          >
                            <a-button
                              v-if="btn.beforeChecked"
                              :disabled="btn.disabled && btn.disabled(btn) || false"
                              type="primary"
                              icon="cloud-upload"
                              @click="checkedGridSelect(btn, tab.custom.ref, btn.beforeCheckedCallBack)"
                            >
                              {{ btn.title }}
                            </a-button>
                          </custom-upload>
                        </span>
                      </div>

                    </template>
                    <template #grid_opration="{ row, column }">
                      <a
                        v-for="(item, i) in tab.custom.optColumnList"
                        :key="'opt_' + row.id + '_' + i"
                        :title="item.title"
                        style="margin:0 4px"
                        :disabled="item.allow ? item.allow(row) : false"
                        v-show="item.showCondition ? item.showCondition(row) : true"
                        @click="item.clickFn(row, column)"
                      >{{ item.title }}</a>
                    </template>
                  </vxe-grid>
                </div>
                <div
                  v-else
                  bordered
                  class="description"
                  :style="{ minHeight: `${minHeight}px` }"
                >
                  <template v-if="tab.custom.formFields && tab.custom.formFields.length">
                    <a-descriptions
                      bordered
                      size="small"
                    >
                      <a-descriptions-item
                        v-for="field in tab.custom.formFields"
                        :key="field.fieldName"
                      >
                        <span slot="label">
                          {{ $srmI18n(`${busAccount}#${field.fieldLabelI18nKey}`, field.fieldLabel) }}
                          <a-tooltip
                            v-if="field.helpText"
                            :title="field.helpText"
                          >
                            <a-icon type="question-circle-o" />
                          </a-tooltip>
                        </span>
                        <template>
                          <span v-if="!tab.custom.parentObj">
                            <span v-if="field.fieldType == 'switch'">
                              {{
                                ['1', 'Y'].includes(form[field.fieldName])
                                  ? `${$srmI18n(`${$getLangAccount()}#i18n_title_yes`, '是')}`
                                  : `${$srmI18n(`${$getLangAccount()}#i18n_title_no`, '否')}`
                              }}
                            </span>
                            <a
                              :href="form[field.fieldName]"
                              target="_blank"
                              v-else-if="field.fieldType == 'link'"
                            >
                              <span>{{
                                $srmI18n(`${$getLangAccount()}#i18n_title_authenticationLink`, '认证链接')
                              }}</span>
                            </a>
                            <!-- 阶梯价格 -->
                            <template v-else-if="field.fieldName === 'ladderPriceJson'">
                              <a-tooltip
                                placement="top"
                                v-if="form['ladderPriceJson']"
                                overlayClassName="tip-overlay-class"
                              >
                                <template slot="title">
                                  <vxe-table
                                    auto-resize
                                    border
                                    size="mini"
                                    :data="initRowLadderJson(form['ladderPriceJson'])"
                                  >
                                    <vxe-table-column
                                      type="seq"
                                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_details`, '序号')}`"
                                      width="80"
                                    ></vxe-table-column>
                                    <vxe-table-column
                                      field="ladderQuantity"
                                      :title="
                                        `${$srmI18n(`${$getLangAccount()}#i18n_title_ladderQuantity`, '阶梯数量')}`
                                      "
                                      width="140"
                                    ></vxe-table-column>
                                    <vxe-table-column
                                      field="price"
                                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_price`, '含税价')}`"
                                      width="140"
                                    ></vxe-table-column>
                                    <vxe-table-column
                                      field="netPrice"
                                      :title="`${$srmI18n(`${$getLangAccount()}#i18n_title_netPrice`, '不含税价')}`"
                                      width="140"
                                    ></vxe-table-column>
                                  </vxe-table>
                                </template>
                                <div class="json-box">
                                  <a href="javascript: void(0)">{{ defaultRowLadderJson(form['ladderPriceJson']) }}</a>
                                </div>
                              </a-tooltip>
                            </template>
                            <span v-else>
                              {{
                                field.fieldType == 'select' || field.fieldType == 'multiple'
                                  ? form[field.fieldName + '_dictText']
                                  : form[field.fieldName]
                              }}
                            </span>
                          </span>
                          <span v-else-if="tab.custom.parentObj && form[tab.custom.parentObj]">
                            <span v-if="field.fieldType == 'switch'">
                              {{
                                ['1', 'Y'].includes(form[panel.custom.parentObj][field.fieldName])
                                  ? `${$srmI18n(`${$getLangAccount()}#i18n_title_yes`, '是')}`
                                  : `${$srmI18n(`${$getLangAccount()}#i18n_title_no`, '否')}`
                              }}
                            </span>
                            <a
                              :href="form[field.fieldName]"
                              target="_blank"
                              v-else-if="field.fieldType == 'link'"
                            >
                              <span>{{
                                $srmI18n(`${$getLangAccount()}#i18n_title_authenticationLink`, '认证链接')
                              }}</span>
                            </a>
                            <span v-else>
                              {{
                                field.fieldType == 'select' || field.fieldType == 'multiple'
                                  ? form[panel.custom.parentObj][field.fieldName + '_dictText']
                                  : form[panel.custom.parentObj][field.fieldName]
                              }}
                            </span>
                          </span>
                        </template>
                      </a-descriptions-item>
                    </a-descriptions>
                  </template>
                </div>
              </a-tab-pane>
            </a-tabs>
          </div>
        </div>
      </div>
    </a-spin>
  </div>
</template>

<script>
import { ajaxFindDictItems } from '@/api/api'
import { PURCHASEATTACHMENTDOWNLOADAPI } from '@/utils/const'
import { getAction, postAction } from '@/api/manage'
import { USER_ELS_ACCOUNT } from '@/store/mutation-types'
// import Breadcrumb from '@/components/tools/Breadcrumb.vue'
import CustomUpload from '@comp/template/CustomUpload'
export default {
  name: 'DetailLayout',
  components: {
    // Breadcrumb
    CustomUpload
  },
  props: {
    title: {
      type: String,
      default: '详情'
    },
    pageData: {
      type: Object,
      default: () => { }
    },
    url: {
      type: Object,
      default: () => { }
    }
  },
  data() {
    return {
      minHeight: 0,
      activeKey: '',
      confirmLoading: false,
      text: 'text',
      form: {},
      gridCustomEditConfig: {
        trigger: 'dblclick',
        mode: 'cell',
        showStatus: true
      },
      //默认表格配置
      defaultGridOption: {
        border: true,
        resizable: true,
        autoResize: true,
        height: 'auto',
        showOverflow: true,
        columnKey: true,
        showHeaderOverflow: true,
        size: 'mini',
        align: 'center',
        headerAlign: 'center',
        columns: [],
        data: [],
        checkboxConfig: { highlight: true, trigger: 'row' },
        editConfig: { trigger: 'dblclick', mode: 'cell' },
        toolbarConfig: { slots: { buttons: 'toolbar_buttons' } }
      },
      //附件上传配置
      tokenHeader: { 'X-Access-Token': this.$ls.get('Access-Token') },
      accept: '.doc, .docx, .xls, .xlsx, .ppt, .png, .jpg, .jpeg, .gif, .pptx, .pdf, .txt',
      accept2: '.png, .jpg, .jpeg, .gif'
    }
  },
  computed: {
    busAccount() {
      let account = this.$ls.get(USER_ELS_ACCOUNT)
      if (this.currentEditRow && this.currentEditRow.busAccount) {
        account = this.currentEditRow.busAccount || this.currentEditRow.elsAccount || this.$el.get(USER_ELS_ACCOUNT)
      }
      return account
    },
    itemInfo() {
      let itemInfo = []
      const groups = this.pageData.groups || []
      const group = groups.find(n => n.groupCode === 'itemInfo')
      if (group) {
        const refName = group.custom.ref
        itemInfo = this.$refs[refName][0].getTableData().fullData || []
      }
      return itemInfo
    },
    itemColumns() {
      const groups = this.pageData.groups || []
      let itemInfo = groups.filter(item => item.groupCode == 'itemInfo')
      if (itemInfo.length) {
        return itemInfo[0].custom.columns
      }
      return []
    },
  },
  watch: {
    itemColumns() {
      this.queryDictData()
    },
  },
  methods: {
    // 阶梯报价json数据组装
    initRowLadderJson(jsonData) {
      let arr = []
      if (jsonData) {
        arr = JSON.parse(jsonData)
      }
      return arr
    },
    // 阶梯报价默认显示
    defaultRowLadderJson(jsonData) {
      let arrString = ''
      if (jsonData) {
        let arr = JSON.parse(jsonData)
        arr.forEach((item, index) => {
          let ladderQuantity = item.ladderQuantity
          let price = item.price
          let netPrice = item.netPrice
          let str = `${ladderQuantity} ${price} ${netPrice} `
          let separator = index === arr.length - 1 ? '' : ','
          arrString += str + separator
        })
      }
      return arrString
    },
    // 文件下载
    handleDownload({ id, fileName }, url = '') {
      const params = {
        id
      }
      let downloadUrl = url || PURCHASEATTACHMENTDOWNLOADAPI
      if (this.url.download) {
        downloadUrl = this.url.download
      }
      getAction(downloadUrl, params, {
        responseType: 'blob'
      }).then(res => {
        // console.log(res)
        let url = window.URL.createObjectURL(new Blob([res]))
        let link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        link.setAttribute('download', fileName)
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link) //下载完成移除元素
        window.URL.revokeObjectURL(url) //释放掉blob对象
      })
    },
    queryDetail(id, cb) {
      let that = this
      this.confirmLoading = true
      getAction(this.url.detail, { id: id })
        .then(res => {
          that.activeKey = that.pageData.groups[0].groupCode
          if (res.success) {
            that.form = res.result
            that.pageData.groups.forEach(group => {
              if (group.type == 'grid') {
                let ref = group.custom.ref
                that.$refs[ref][0].loadData(res.result[ref])
                if (group.custom.expandColumnsMethod) {
                  let expandColumns = group.custom.expandColumnsMethod()
                  group.custom.columns = group.custom.columns.concat(expandColumns)
                  delete group.custom.expandColumnsMethod
                }

                if (Object.keys(group).includes('showDadgeDot')) {
                  //判断tab是否需要加红点
                  group.showDadgeDot = res.result[ref].length > 0
                }
              }
            })
          } else {
            that.$message.warning(res.message)
          }
          cb && cb(res.result)
        })
        .finally(() => {
          that.confirmLoading = false
        })
    },
    getPageData() {
      const that = this
      let params = { ...this.form }
      this.pageData.groups.forEach(group => {
        if (group.type == 'grid') {
          let ref = group.custom.ref
          params[ref] = that.$refs[ref][0].getTableData().fullData
        }
      })
      return params
    },
    setPromise() {
      let that = this
      let promise = this.pageData.groups.map(group => {
        if (group.type == 'grid') {
          return that.$refs[group.custom.ref][0].validate(true)
        } else {
          return that.$refs[group.groupCode][0].validate()
        }
      })
      return promise
    },
    handValidate(url, params, callback) {
      const handlePromise = (list = []) =>
        list.map(promise =>
          promise.then(
            res => ({
              status: 'success',
              res
            }),
            err => ({
              status: 'error',
              err
            })
          )
        )
      let promise = this.setPromise()
      Promise.all(handlePromise(promise))
        .then(result => {
          let flag = false
          for (let i = 0; i < result.length; i++) {
            if (result[i].status === 'success') {
              flag = true
            } else {
              this.currentStep = i
              return
            }
          }
          if (flag) return callback && callback(url, params, this)
        })
        .catch(err => {
          console.log(err)
        })
    },
    handleSend(type = 'public', callback) {
      const handlePromise = (list = []) =>
        list.map(promise =>
          promise.then(
            res => ({
              status: 'success',
              res
            }),
            err => ({
              status: 'error',
              err
            })
          )
        )
      let promise = this.setPromise()
      Promise.all(handlePromise(promise))
        .then(result => {
          let flag = false
          for (let i = 0; i < result.length; i++) {
            if (result[i].status === 'success') {
              flag = true
            } else {
              this.currentStep = i
              return
            }
          }
          if (flag) this.postData(type, callback)
        })
        .catch(err => {
          console.log(err)
        })
    },
    postData(type, callback) {
      let params = this.getPageData()
      let url = type === 'public' ? this.url.public : this.voucherId ? this.url.edit : this.url.add
      this.confirmLoading = true
      postAction(url, params)
        .then(res => {
          const messageType = res.success ? 'success' : 'error'
          this.$message[messageType](res.message)
          if (res.success && this.refresh) {
            this.queryDetail()
          }
          if (res.success && type === 'public') {
            this.$parent.goBack()
          } else {
            // 自定义回调
            return callback && callback(params, this)
          }
        })
        .finally(() => {
          this.confirmLoading = false
        })
    },
    showLoading() {
      this.confirmLoading = true
    },
    hideLoading() {
      this.confirmLoading = false
    },
    clickFn(row, column) {
      console.log(row, column)
    },
    // 2021-11-16新增，双击事件，如果配置中有clickFn，就触发该事件
    dblclickHander(table) {
      table.column._own.clickFn && table.column._own.clickFn(table)
    },
    //附件上传
    handleUploadChange(info, btn, refName) {
      btn.callBack && btn.callBack(info, refName)
    },
    checkedGridSelect(btn, refName, cb) {
      let selectData = null
      if (this.$refs[refName]) {
        if (this.$refs[refName][0]) {
          selectData = this.$refs[refName][0].getCheckboxRecords() || this.$refs[refName][0].getRadioRecord()
        }
      }
      if (selectData && selectData.length) {
        if (cb && typeof cb === 'function') {
          cb(selectData).then(res => {
            if (res) {
              btn.modalVisible = true
              // this.$refs[refName+'_upload'][0].$el.click()
            }
          })
        } else {
          this.modalVisible = true
          // this.$refs[refName+'_upload'][0].$el.click()
        }

      } else {
        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_afterChoose`, '请先选择'))
      }
    },

    // 获取表格下拉字典
    queryDictData() {
      let that = this
      this.pageData.groups.forEach(item => {
        if (item.type == 'grid') {
          item.custom.columns.forEach(item2 => {
            if (item2.dictCode) {

              let postData = {
                busAccount: that.busAccount || that.$ls.get(USER_ELS_ACCOUNT),
                dictCode: item2.dictCode
              }
              ajaxFindDictItems(postData).then(res => {
                if (res.success) {
                  let options = res.result.map(item3 => {
                    return {
                      value: item3.value,
                      label: item3.text,
                      title: item3.title
                    }
                  })
                  if (item2.editRender) {
                    item2.editRender.options = options
                  }
                  item2.dictOptions = options
                  that.$forceUpdate()
                }
              })
            }
            // else if(item2.dictCode && !item2.editRender) {
            //     item2.field = item2.field + '_dictText'
            // }
          })
        }
      })
    }
  },
  created() {
    const clientHeight = document.documentElement.clientHeight
    this.minHeight = clientHeight - 260
  }
}
</script>

<style lang="less" scoped>
.detailPage {
  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 1px 0px 0 1px;
    padding: 8px 40px;
    background: #fff;
    .btnGroups {
      text-align: right;
      .ant-btn {
        & + .ant-btn {
          margin-left: 10px;
        }
      }
    }
  }
  .btns {
    .ant-btn {
      margin-left: 6px;
    }
  }
  .content {
    margin: 0px 1px;
    padding: 8px;
    background: #fff;
  }

  /deep/ .ant-descriptions-bordered .ant-descriptions-item-label {
    background: #f8feff;
  }

  /deep/ .ant-descriptions-item-content {
    width: 16.66%;
    max-width: 16.66%;
  }
}
</style>
