<template>
  <div class="CustomUpload">
    <slot>
      <a-button
        :disabled="disabled"
        type="primary"
        icon="cloud-upload"
        @click="showModal"
      >
        {{ title }}
      </a-button>
    </slot>
    <custom-upload-form
      ref="customUploadForm"
      :isList="isList"
      :visible="visible"
      :srmFileType="srmFileType"
      :single="single"
      :requiredFileType="requiredFileType"
      :disabledItemNumber="disabledItemNumber"
      :property="property"
      v-bind="$attrs"
      @custom_upload_cancel="handleCancel"
      @custom_upload_create="handleCreate"
    />
  </div>
</template>

<script>
/**
 * CustomUpload
 * @description 自定义上传组件
 * @property {Boolean} single 是否单选
 * @property {Boolean} requiredFileType 是否校验文件类型, 默认为 false
 * @property {Boolean} disabledItemNumber 是否置灰文件所属行项目单选选项
 * @property {String} property 获取行项目下拉列表 label 名称，物料行项目取值, 默认取 'materialDesc'
 * @property {Boolean} visible 控制上传组件 modal 显隐
 * @property {String} title 标题
 * @property {String} dictCodeType 字典类型
 * @property {Array} itemInfo 父级物料行项目信息
 * @property {String} accept 接受上传的文件类型
 * @property {String} headers 配置 X-Access-Token
 * @property {Object} data 配置 businessType 各模块上传类型，headId 表头 id, 必填
 * @event {Function} beforeCheckedCallBack 上传前校验，须返回一个 promise
 * @event {Function} callback 点击确定上传文件, 完成后回调, 须绑定 callback 方法
 */
import { ajaxFindDictItems } from '@/api/api'
import { USER_INFO } from '@/store/mutation-types'
import CustomUploadForm from './CustomUploadForm.vue'

export default {
  components: { CustomUploadForm },
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: '附件上传'
    },
    isList: {
      type: Boolean,
      default: false
    },
    visible: {
      type: Boolean,
      default: false
    },
    single: {
      type: Boolean,
      default: false
    },
    requiredFileType: {
      type: Boolean,
      default: false
    },
    disabledItemNumber: {
      type: Boolean,
      default: false
    },
    property: {
      type: String,
      default: 'materialDesc'
    },
    dictCodeType: {
      typeof: String,
      default: 'srmFileType'
    }
  },
  data() {
    return {
      userInfo: {},
      srmFileType: []
    }
  },
  created() {
    this.getUserInfo()
    this.getSrmFileType()
  },
  methods: {
    getUserInfo() {
      this.userInfo = this.$ls.get(USER_INFO)
    },
    getSrmFileType() {
      const params = {
        busAccount: this.userInfo.elsAccount,
        dictCode: this.dictCodeType
      }
      ajaxFindDictItems(params).then(res => {
        if (res.success) {
          this.srmFileType = res.result || []
        }
      })
    },
    showModal() {
      if (this.$attrs.data && !this.$attrs.data.headId) {
        this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSaveDocumentFirst`, '请先保存单据！'))
        return
      }
      this.$emit('update:visible', true)
    },
    handleCancel() {
      this.$emit('update:visible', false)
    },
    handleCreate(result) {
      this.$emit('change', result)
      this.$refs.customUploadForm.form.resetFields()
      this.handleCancel()
    }
  }
}
</script>

<style lang="less">
.CustomUpload {
  display: inline-block;
}
</style>
