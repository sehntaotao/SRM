import CustomUpload from './src/main.vue'

CustomUpload.install = function (Vue) {
    Vue.component('CustomUpload', CustomUpload)
}

export default CustomUpload