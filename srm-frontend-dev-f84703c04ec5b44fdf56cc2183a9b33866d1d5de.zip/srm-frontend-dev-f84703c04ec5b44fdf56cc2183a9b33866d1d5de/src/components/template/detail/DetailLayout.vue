<template>
  <div class="detail-page">
    <a-spin :spinning="confirmLoading">
      <a-page-header 
        :title="title" 
        :class="[ fixPageHeader ? 'fixed-page-header' : '', ]">
        <template slot="extra">
          <a-button
            v-for="(btn,index) in pageData.publicBtn"
            :key="'pub_btn_' + index"
            :type="btn.type"
            v-show="btn.showCondition ? btn.showCondition() : true"
            @click="btn.click">{{ btn.title }}</a-button>
        </template>
      </a-page-header>
      <a-collapse v-model="activeKeys">
        <a-collapse-panel 
          v-for="panel in panels" 
          :key="panel.groupCode" 
          :header="panel.groupName">
          <a-descriptions>
            <a-descriptions-item 
              v-for="field in panel.custom.formFields" 
              :key="field.fieldName">
              <span slot="label">
                {{ field.fieldLabel }}
                <a-tooltip
                  v-if="field.helpText"
                  :title="field.helpText">
                  <a-icon type="question-circle-o" />
                </a-tooltip>
              </span>
              <span v-if="!panel.custom.parentObj">
                <span v-if="field.fieldType == 'switch'">
                  {{
                    ['1', 'Y'].includes(form[field.fieldName])
                      ? `${$srmI18n(`${$getLangAccount()}#i18n_title_yes`, '是')}`
                      : `${$srmI18n(`${$getLangAccount()}#i18n_title_no`, '否')}`
                  }}
                </span>
                <span v-else>
                  {{ field.fieldType == 'select' || field.fieldType == 'multiple' ? form[field.fieldName + '_dictText'] : form[field.fieldName] }}
                </span>
              </span>
              <span v-else-if="panel.custom.parentObj && form[panel.custom.parentObj]">
                <span v-if="field.fieldType == 'switch'">
                  {{
                    ['1', 'Y'].includes(form[panel.custom.parentObj][field.fieldName])
                      ? `${$srmI18n(`${$getLangAccount()}#i18n_title_yes`, '是')}`
                      : `${$srmI18n(`${$getLangAccount()}#i18n_title_no`, '否')}`
                  }}
                </span>
                <span v-else>
                  {{ field.fieldType == 'select' || field.fieldType == 'multiple' ? form[panel.custom.parentObj][field.fieldName + '_dictText'] : form[panel.custom.parentObj][field.fieldName] }}
                </span>
              </span>
            </a-descriptions-item>
          </a-descriptions>
        </a-collapse-panel>
      </a-collapse>
      <a-tabs type="card">
        <a-tab-pane 
          v-for="tab in tabs" 
          :key="tab.groupCode" 
          forceRender
          :tab="tab.groupName">
          <vxe-grid
            :ref="tab.custom.ref"
            v-bind="defaultGridOption"
            header-align="center"
            :columns="tab.custom.columns">
            <!-- 2021-10-09 新增一个插槽，通过options数组来渲染a标签，相比原来的grid_opration，不需要额外配置optColumnList，且只能限制使用1个 -->
            <template #showBtn="{ row, column }">
                <!-- 判断字段中的指定字段是否等于指定值，相等才显示 -->
                <template v-if="column._own.isShow.default || row[column._own.isShow.key] === column._own.isShow.value">
                  <template v-for="(item, i) in column._own.options">
                      <!-- 上传 -->
                      <a-upload
                      v-if="item.type==='upload'"
                      :key="'opt_' + row.id + '_' + i"
                      :show-upload-list="false"
                      :multiple="false"
                      :headers="tokenHeader"
                      :data="{businessType: item.params.businessType, headId: row.headId || item.params.headId, uploadElsAccount: item.params.businessType}"
                      :action="item.url"
                      @change="(info) => item.clickFn(info, row, column)"
                      >
                      <span v-if="item.isConfirm" :ref="'upload' + row._XID" style="margin:0 4px;color: #1890ff;cursor:pointer;"  @click="item.confirm($event, row, column, 'upload' + row._XID)">{{ item.title }}</span>
                      <span v-else style="margin:0 4px;color: #1890ff;cursor:pointer;">{{ item.title }}</span>
                      </a-upload>
                      <!-- 弹出窗 -->
                      <div v-else-if="item.type==='selectModal'" :key="'opt_' + row.id + '_' + i" style="position: relative;min-height: 30px;padding-right: 20px;">
                          {{row[item.field]}}
                          <a style="position: absolute;display: inline-block;font-size: 16px;right: 0px; top: 3px;z-index: 10; background: #fff;">
                              <a-icon type="file-search"  @click="item.clickFn(row, column)" />
                          </a>
                      </div>
                      <!-- a标签 -->
                      <a
                          v-else-if="row[item.disable.key]"
                          :key="'opt_' + row.id + '_' + i"
                          :title="item.title"
                          style="margin:0 4px"
                          @click="item.clickFn(row, column)"
                      >
                      {{ item.title }}
                      </a>
                      <span
                          v-else
                          :key="'opt_' + row.id + '_' + i"
                          style="margin:0 4px"
                      >
                      {{ item.title }}
                      </span>
                  </template>
                </template>
            </template>
            <template #toolbar_buttons>
              <a-button
                v-for="(btn, index3) in tab.custom.buttons"
                :key="'btn_' + index3"
                :type="btn.type"
                v-show="btn.showCondition ? btn.showCondition() : true"
                @click="btn.click">
                {{ btn.title }}
              </a-button>
            </template>
            <template #grid_opration="{ row, column }">
              <a
                v-for="(item, i) in tab.custom.optColumnList"
                :key="'opt_'+ row.id + '_' + i"
                :title="item.title"
                :disabled="item.allow ? item.allow(row) : false"
                v-show="item.showCondition ? item.showCondition(row) : true"
                @click="item.clickFn(row, column)">{{ item.title }}</a>
            </template>
          </vxe-grid>
        </a-tab-pane>
      </a-tabs>
    </a-spin>
  </div>
</template>

<script>
import { PURCHASEATTACHMENTDOWNLOADAPI } from '@/utils/const'

import { Descriptions } from 'ant-design-vue'
import { getAction, postAction } from '@/api/manage'

export default {
    name: 'DetailLayout',
    components: {
        ADescriptions: Descriptions,
        ADescriptionsItem: Descriptions.Item
    },
    props: {
        title: {
            type: String,
            default: '详情'
        },
        pageData: {
            type: Object,
            default: () => {}
        },
        url: {
            type: Object,
            default: () => {}
        }
    },
    data () {
        return {
            confirmLoading: false,
            fixPageHeader: false,
            text: 'text',
            form: {},
            activeKeys: [],
            //默认表格配置
            defaultGridOption: {
                toolbarConfig: {
                    slots: {buttons: 'toolbar_buttons'},
                    print: true,
                    zoom: true,
                    perfect: true
                },
                border: true,
                resizable: true,
                autoResize: true,
                height: '300',
                showOverflow: true,
                columnKey: true,
                highlightHoverRow: true,
                size: 'mini',
                align: 'center',
                headerAlign: 'center',
                columns: [],
                data: [],
                checkboxConfig: { highlight: true, trigger: 'row' },
                editConfig: { trigger: 'click', mode: 'row' }
                // toolbarConfig: { slots: {buttons: 'toolbar_buttons'} }
            }
        }
    },
    computed: {
        panels () {
            let panels = this.pageData.groups.filter(group => {
                return group.type != 'grid'
            })
            return panels
        },
        tabs () {
            let tabs = this.pageData.groups.filter(group => {
                return group.type == 'grid'
            })
            return tabs
        },
        activeKey () {
            let panels = this.pageData.groups.filter(group => {
                return group.type != 'grid'
            })
            let keys = panels.map(panel => {
                return panel.groupCode
            })
            return keys
        }
    },
    watch: {
        activeKey (val) {
            this.activeKeys = val
        }
    },
    mounted () {
        window.addEventListener('scroll', this.handleScroll)
        this.activeKeys = this.activeKey
    },
    beforeDestroy () {
        window.removeEventListener('scroll', this.handleScroll)
    },
    methods: {
        handleDownload ({ id, fileName }, url = '') {
            const params = {
                id
            }
            let downloadUrl = url || PURCHASEATTACHMENTDOWNLOADAPI
            if(this.url.download){
                downloadUrl = this.url.download
            }
            getAction(downloadUrl, params, {
                responseType: 'blob'
            }).then(res => {
                console.log(res)
                let url = window.URL.createObjectURL(new Blob([res]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', fileName)
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link) //下载完成移除元素
                window.URL.revokeObjectURL(url) //释放掉blob对象
            })
        },
        handleScroll () {
            var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
            if (scrollTop > 50) {
                this.fixPageHeader = true
            }else {
                this.fixPageHeader = false
            }
        },
        queryDetail (id) {
            let that = this
            this.confirmLoading = true
            getAction(this.url.detail, {id: id}).then(res => {
                this.$emit('loadSuccess',  { res: res })
                if(res.success) {
                    that.form = res.result
                    that.pageData.groups.forEach(group => {
                        if(group.type == 'grid') {
                            let ref = group.custom.ref
                            that.$refs[ref][0].loadData(res.result[ref])
                            if(group.custom.expandColumnsMethod) {
                                let expandColumns = group.custom.expandColumnsMethod()
                                group.custom.columns = group.custom.columns.concat(expandColumns)
                            }
                        }
                    })
                }else {
                    that.$message.warning(res.message)
                }
            }).finally(() => {
                that.confirmLoading = false
            })
        },
        getPageData () {
            const that = this
            let params = {...this.form}
            this.pageData.groups.forEach(group => {
                if(group.type == 'grid') {
                    let ref = group.custom.ref
                    params[ref] = that.$refs[ref][0].getTableData().fullData
                }
            })
            return params
        },
        setPromise () {
            let that = this
            let promise = this.pageData.groups.map(group => {
                if(group.type == 'grid') {
                    return that.$refs[group.custom.ref][0].validate(true)
                }else {
                    return that.$refs[group.groupCode][0].validate()
                }
            })
            return promise
        },
        handleSend (type = 'public', callback) {
            const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
                status: 'success',
                res
            }), err => ({
                status: 'error',
                err
            })))
            let promise = this.setPromise()
            Promise.all(handlePromise(promise)).then(result => {
                let flag = false
                for (let i = 0; i < result.length; i++) {
                    if (result[i].status === 'success') {
                        flag = true
                    } else {
                        this.currentStep = i
                        return
                    }
                }
                if (flag) this.postData(type, callback)
            }).catch(err => {
                console.log(err)
            })
        },
        postData (type, callback) {
            let params = this.getPageData()
            let url =  type === 'public'
                ? this.url.public
                : this.voucherId
                    ? this.url.edit
                    : this.url.add
            this.confirmLoading = true
            postAction(url, params).then(res => {
                const type = res.success ? 'success' : 'error'
                this.$message[type](res.message)
                if (res.success && this.refresh) {
                    this.queryDetail()
                }
                if (res.success && type === 'public') {
                    this.$parent.goBack()
                } else {
                    // 自定义回调
                    return callback && callback(params, this)
                }
            }).finally(() => {
                this.confirmLoading = false
            })
        },
        showLoading () {
            this.confirmLoading = true
        },
        hideLoading () {
            this.confirmLoading = false
        }
    }
}
</script>