import tileEditPage from './tileEditPage'
export const tileEditPageMixin = {
    components: {
        tileEditPage
    },
    props: {
        currentEditRow: {
            type: Object,
            default: null
        }
    },
    data () {
        return {
            pageData: {
                publicBtn: [
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_save`, '保存'), type: 'primary', clickFn: this.saveEvent },
                    { title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_back`, '返回'), clickFn: this.goBack }
                ]
            }
        }
    },
    mounted () {
        this.init()
    },
    methods: {
        init () {
            if(this.currentEditRow && this.currentEditRow.id) {
                this.$refs.editPage.requestTabsData(this.currentEditRow.id)
            }
        },
        goBack () {
            this.$emit('hide')
        },
        downloadEvent (row) {
            this.$refs.editPage.handleDownload(row)
        },
        refreshList () {
            this.$emit('ok')
        },
        saveEvent () {
            this.$refs.editPage.saveEvent()
        },
        requestAfter (data) {
            console.log(data)
        }
    }
}