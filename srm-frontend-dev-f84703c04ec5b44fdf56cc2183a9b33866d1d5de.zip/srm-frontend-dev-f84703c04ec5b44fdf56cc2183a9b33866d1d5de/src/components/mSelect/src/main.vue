<template>
  <div>
    <a-select
      style="width:100%"
      show-search
      option-filter-prop="children"
      :filter-option="filterOption"
      :mode="mode"
      :placeholder="placeholder"
      :value="realValue"
      :disabled="disabled"
      :allowClear="true"
      v-bind="$attrs"
      @change="changeEvent">
      <template
        v-if="showMaxTagPlaceholder"
        slot="maxTagPlaceholder">
        <span class="maxTagPlaceholder">+{{ length }}</span>
      </template>
      <a-select-option
        v-if="!noEmptyOpt"
        value="">
        {{ $srmI18n(`${$getLangAccount()}#i18n_title_pleaseChoose`, '请选择') }}
      </a-select-option>
      <a-select-option
        v-for="(option, key) in realOptions"
        :key="'option_' + key"
        :title="$srmI18n(`${$getLangAccount()}#${option.textI18nKey}`, option[titleMap] )"
        :value="option[valueMap]">
        {{ showOptValue ? option[valueMap]+'_'+$srmI18n(`${$getLangAccount()}#${option.textI18nKey}`, option[titleMap] ) : $srmI18n(`${$getLangAccount()}#${option.textI18nKey}`, option[titleMap] ) }}
      </a-select-option>
    </a-select>
  </div>
</template>
<script>
import { getAction } from '@api/manage'
import { USER_ELS_ACCOUNT } from '@/store/mutation-types'
import {ajaxFindDictItems} from '@/api/api'
export default {
    name: 'MSelect',
    model: {
        prop: 'value',
        event: 'change'
    },
    props: {
        disabled: {
            type: Boolean,
            default: false
        },
        mode: {
            type: String,
            default: 'default'
        },
        placeholder: {
            type: String,
            default: ''
        },
        value: {
            type: String || Number,
            default: null
        },
        options: {
            type: Array,
            default: () => []
        },
        sourceUrl: {
            type: String,
            defalt: ''
        },
        sourceMap: {
            type: Object,
            default: null
        },
        dictCode: String,
        showOptValue: {
            type: Boolean,
            default: false
        },
        noEmptyOpt: {
            type: Boolean,
            default: true
        },
        titleMap: {
            type: String,
            default: 'title'
        },
        valueMap: {
            type: String,
            default: 'value'
        },
        currentEditRow: {
            type: Object,
            default: ()=> {
                return null
            }
        },
        // change方法返回选项的title
        returnTitle: {
            type: Boolean,
            default: false
        }
    },
    data () {
        return {
            realOptions: this.options
        }
    },
    computed: {
        busAccount () {
            let account = this.$ls.get(USER_ELS_ACCOUNT)
            if (this.currentEditRow && this.currentEditRow.busAccount) {
                account = this.currentEditRow.busAccount || this.currentEditRow.elsAccount
            }
            return account
        },
        realValue () {
            if(this.mode === 'multiple' || this.mode === 'tags') {
                return this.value ? this.value.split(',') : []
            }
            return this.value
        },
        showMaxTagPlaceholder () {
            let { maxTagCount } = this.$attrs || {}
            if (!maxTagCount) return false
            let min = maxTagCount + 1
            return ['multiple', 'tags'].includes(this.mode)
                && Array.isArray(this.realValue)
                && this.realValue.length >= min
        },
        length () {
            if (!this.showMaxTagPlaceholder) return ''
            let { maxTagCount } = this.$attrs || {}
            maxTagCount = maxTagCount || 1
            return this.realValue.length - maxTagCount
        }
    },
    watch: {
        options (newVal) {
            this.realOptions = newVal
        },
        sourceUrl: {
            immediate: true,
            handler () {
                this.querySourceData()
            }
        },
        dictCode: {
            immediate: true,
            handler () {
                this.initDictData()
            }
        }
    },
    methods: {
        filterOption (input, option) {
            return (
                option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
            )
        },
        changeEvent (val, opt) {
            let realValue = '',
                oldVal = this.realValue, Rtitle = ''
            if(this.mode === 'multiple' || this.mode === 'tags') {
                realValue = val.join(',')
            }else {
                realValue = val || ''
            }
            if (this.returnTitle) {
                this.realOptions.map(({value, title}) => {
                    if (value == realValue) Rtitle = title
                })
            }
            // configData 当前form表单数据，相当于主模板的bindFunction 挂着引用主件上 如：<m-select ...  :configData='panel.content.list'></m-select>
            this.$emit('change', realValue, opt, oldVal, this.$attrs.configData, Rtitle)
        },
        loadSuccess () {
            this.$emit('load', this.realOptions)
        },
        querySourceData () {
            if(this.sourceUrl) {
                getAction(this.sourceUrl, this.sourceMap).then(res => {
                    if(res.success) {
                        this.realOptions = res.result
                        this.loadSuccess()
                    }
                })
            }
        },
        initDictData () {
            if(this.dictCode) {
                //根据字典Code, 初始化字典数组
                let postData = {
                    busAccount: this.busAccount || this.$ls.get(USER_ELS_ACCOUNT),
                    dictCode: this.dictCode
                }             
                ajaxFindDictItems(postData).then((res) => {
                    if (res.success) {
                        this.realOptions = res.result
                        this.loadSuccess()
                    }
                })
            }
        }
    }
}
</script>