import MSelect from './src/main.vue'

MSelect.install = function (Vue) {
    Vue.component('MSelect', MSelect)
}

export default MSelect