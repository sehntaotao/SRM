import AccessMethod from './src/main.vue'

AccessMethod.install = function (Vue) {
    Vue.component('AccessMethod', AccessMethod)
}

export default AccessMethod