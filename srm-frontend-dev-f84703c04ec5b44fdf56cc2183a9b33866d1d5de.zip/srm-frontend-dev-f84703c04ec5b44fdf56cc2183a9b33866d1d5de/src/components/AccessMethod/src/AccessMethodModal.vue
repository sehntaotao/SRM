<template>
  <a-modal
    v-model="madalVisible"
    centered
    :width="800"
    :title="$srmI18n(`${$getLangAccount()}#i18n_title_accessSetting`, '选择准入方式')"
    @ok="setLadderOk">
    <a-spin :spinning="confirmLoading">
      <div class="compare-page-container">
        <div class="page-content-right">
          <div style="margin-bottom: 12px">
            <vxe-grid
              border
              ref="headerGrid"
              row-id="ladderQuantity"
              show-overflow
              size="small"
              height="350"
              :columns="tableHeaderColumn"
              :data="tableHeaderData"
              :edit-config="{trigger: 'click', mode: 'cell'}"
              :radio-config="{highlight: true, reserve: true}"
              :toolbar="{ slots: { buttons: 'toolbar_buttons' }}"
            >
              <template v-slot:toolbar_buttons>
                <div style="margin-top:-8px;text-align:right">
                  <a-button
                    @click="addLadderQuantity"
                    type="primary"
                    style="margin-left:8px"
                    slot="tabBarExtraContent">  {{ $srmI18n(`${$getLangAccount()}#i18n_title_add`, '添加') }}
                  </a-button>
                  <a-button
                    @click="deleteLadder"
                    type=""
                    style="margin-left:8px"
                    slot="tabBarExtraContent">{{ $srmI18n(`${$getLangAccount()}#i18n_title_delete`, '删除') }}
                  </a-button>
                </div>
              </template>
            </vxe-grid>
          </div>
        </div>
      </div>
    </a-spin>
  </a-modal>
</template>
<script>
import {List} from 'ant-design-vue'
export default {
    name: 'AccessMethodModal',
    props: {
        currentEditRow: {
            type: Object,
            default: ()=> {
                return {}
            }
        },
        isEmit: {
            type: Boolean,
            default: false
        },
        form: {
            type: Object,
            default: ()=> {
                return {}
            }
        }
    },
    components: {
        AList: List,
        AListItem: List.Item
    },
    data () {
        return {
            headObj: {},
            ladderQuantity: '',
            orderList: [],
            confirmLoading: false,
            listData: [],
            madalVisible: false,
            currentRow: null,
            tableHeaderData: [],
            tableHeaderColumn: [
                { type: 'radio', width: 40, align: 'center'},
                { 
                    field: 'order', 
                    title: '顺序', 
                    align: 'center', 
                    editRender: {name: '$select', options: []}
                },
                { 
                    field: 'regulationType', 
                    title: '准入方式', 
                    align: 'center', 
                    editRender: {name: '$select', options: []}
                }
            ]
        }
    },
    mounted () {
        
    },
    methods: {
        open (row, list) {
            let that = this
            this.madalVisible = true
            const order = ['', '0', '1', '2', '3', '4']
            let orderList = []
            let regulationTypeList = []
            regulationTypeList.push('')
            for(let item of order){
                orderList.push({label: item, value: item})
            }
            for(let item of list){
                regulationTypeList.push({label: item.text, value: item.text})
            }
            this.tableHeaderColumn.forEach(item => {
                if(item.field == 'order'){
                    item.editRender = {name: 'select', options: orderList}
                }else if(item.field == 'regulationType'){
                    item.editRender = {name: 'select', options: regulationTypeList}
                }
            })
            let currentRow = row.regulationType || ''
            if(currentRow){
                const arr = currentRow.split(',')
                const list = []
                for(var i=0;i<arr.length;i++){
                    var obj = {}
                    obj.order = arr[i].substring(0, arr[i].indexOf('_'))
                    obj.regulationType = arr[i].substring(2, arr[i].length)
                    list.push(obj)
                }
                this.$nextTick(() => {
                    that.$refs.headerGrid.loadData(list)
                })
            }else{
                this.$nextTick(() => {
                    that.$refs.headerGrid.loadData([])
                })
            }
        },
        goBack () {
            this.$emit('hide')
        },
        // 新增
        addLadderQuantity (){
            let grid = this.$refs.headerGrid
            let itemList = grid.getTableData().fullData
            // 判断是否内容为空
            if(itemList.length > 0) {
                for(var i=0;i<itemList.length;i++){
                    if(itemList[i].order == null || itemList[i].order == '' || itemList[i].regulationType == null || itemList[i].regulationType == ''){
                        return this.$message.warning('请选择顺序和准入方式')
                    }
                }
            }
            grid.insert()
            this.ladderQuantity = ''
        },
        deleteLadder (){
            let currentItem = this.$refs.headerGrid.getRadioRecord()
            if(!currentItem){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseSelectDataDelete`, '请选择需要删除的数据！'))
                return
            }
            this.$refs.headerGrid.removeRadioRow()
        },
        setLadderOk (){
            let itemList = this.$refs.headerGrid.getTableData().fullData
            if(itemList.length == 0 ){
                this.$message.warning(this.$srmI18n(`${this.$getLangAccount()}#i18n_title_pleaseAddAccessInfo`, '请添加准入方式！'))
                return
            }
            // 获取选中的值
            this.madalVisible = false
            for(var i=0;i<itemList.length;i++){
                if(itemList[i].order == null || itemList[i].order == '' || itemList[i].regulationType == null || itemList[i].regulationType == ''){
                    return this.$message.warning('请选择顺序和准入方式')
                }
            }
            if (this.isEmit) {
                this.$emit('ok', itemList)
            } else {
                this.$parent.fieldSelectOk(itemList)
            }
        },
    }
}
</script>
<style lang="less">
    .compare-page-container {
        display: flex;
        .page-content-right {
            flex: 1;
            width: 1000px;
            background-color: #fff
        }
    }
</style>