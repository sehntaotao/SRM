import CodeEditorModel from './src/main.vue'
CodeEditorModel.install = function (Vue) {
    Vue.component('CodeEditorModel', CodeEditorModel)
}
export default CodeEditorModel