<template>
  <div class="hall-layout">
    <a-layout>
      <a-layout-header class="header">
        <div class="logo">{{ title }}</div>
        <div class="info">
          <span class="item">
            <span class="tit">{{ $srmI18n(`${$getLangAccount()}#i18n_SaleMassProdHeadList_projectName`, '项目名称') }}</span>
            {{ currentEditRow.projectName }} 
          </span>
          <span class="item">
            <span class="tit">{{ $srmI18n(`${$getLangAccount()}#i18n_title_projectNumber`, '项目编号') }}</span>
            {{ currentEditRow.biddingNumber }}
          </span>
        </div>
      </a-layout-header>
      <a-layout
        class="siderLayout"
        style="min-height: calc(100vh - 50px)">
        <a-layout-sider
          width="200">
          <s-menu
            :collapsed="false"
            :menu="menus"
            :theme="navTheme"
            @select="onSelect"
            :style="style"
            :userIconFont="true"
          />
        </a-layout-sider>
        <a-layout style="padding: 8px;">
          <a-layout-content
            :style="{ position: 'relative' }">
            <route-view />
          </a-layout-content>
        </a-layout>
      </a-layout>
    </a-layout>
    
  </div>
</template>

<script>
import RouteView from '@/components/layouts/RouteView'
import SMenu from '@/components/menu/index.js'
import { mapState } from 'vuex'
import { SET_HALL_CURRENTROW } from '@/store/mutation-types'
export default {
    name: 'HallLayout',
    components: {
        SMenu,
        RouteView
    },
    computed: {
        ...mapState({
            navTheme: state => state.app.theme
        }),
        style () {
            return {
                padding: 0,
                height: '100%',
                overflowX: 'hidden',
                overflowY: 'auto'
            }
        }
    },
    data () {
        return {
            title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingHall`, '招标大厅'),
            menus: [],
            collapsed: false,
            currentRow: {}
        }
    },
    provide () {
        return {
            currentEditRow: this.$ls.get(SET_HALL_CURRENTROW)
        }
    },
    watch: {
        $route: {
            immediate: true,
            handler ({ path }) {
                this.title = path.indexOf('/applyHall') !== -1
                    ? this.$srmI18n(`${this.$getLangAccount()}#i18n_title_supBiddingHall`, '投标大厅')
                    : this.$srmI18n(`${this.$getLangAccount()}#i18n_title_biddingHall`, '招标大厅')
            }
        }
    },
    methods: {
        getCurrentRow () {
            this.currentEditRow = this.$ls.get(SET_HALL_CURRENTROW) || {}
        },
        getMenu () {
            let HALLROUTERNAME = this.$route.path.includes('hall') ? 'hall' : 'applyHall'
            const { children = [] } = this.$router.options.routes.find(n => n.name === HALLROUTERNAME) || {}
            this.menus = children
        },
        onSelect (obj) {
            console.log('obj', obj)
        },
        init () {
            this.getCurrentRow()
            this.getMenu()
        }
    },
    created () {
        this.init()
    }
}
</script>

<style lang="less" scoped>
.hall-layout {
	.header {
		display: flex;
		justify-content: space-between;
		padding: 0 16px 0 0;
		height: 50px;
		background: #4e85ff;
		line-height: 50px;
		.logo {
			width: 200px;
			text-align: center;
			font-weight: 400;
			font-size: 25px;
			color: #fff;
		}
		.info {
			font-weight: 400;
			font-size: 14px;
			color: #fff;
			.item {
				+ .item {
					position: relative;
					margin-left: 23px;
					&::before {
						position: absolute;
						left: -11px;
						top: 0;
						width: 1px;
						height: 16px;
						background-color: #fff;
						content: "";
					}
				}
				.tit {
					&::after {
						margin-right: 8px;
						content: ":";
					}
				}
			}
		}
	}
  // 菜单高度修改(因为SMenu是一个js组件)
  /deep/ .ant-menu-inline > .ant-menu-item{
      height: 28px;
      line-height: 28px;
  }
  /deep/ .ant-menu-inline > .ant-menu-submenu > .ant-menu-submenu-title{
      height: 28px;
      line-height: 28px;
  }
  /deep/ .ant-menu-sub.ant-menu-inline > .ant-menu-item, .ant-menu-sub.ant-menu-inline > .ant-menu-submenu > .ant-menu-submenu-title{
      height: 28px;
      line-height: 28px;
  }
}
</style>
