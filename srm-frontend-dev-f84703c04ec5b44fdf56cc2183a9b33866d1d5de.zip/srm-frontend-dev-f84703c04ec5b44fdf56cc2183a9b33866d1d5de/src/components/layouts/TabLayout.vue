<template>
  <global-layout @dynamicRouterShow="dynamicRouterShow">
    <contextmenu
      :item-list="menuItemList"
      :visible.sync="menuVisible"
      style="z-index: 9999;"
      @select="onMenuSelect"
    />

    <a-tabs
      @contextmenu.native="e => onContextmenu(e)"
      v-if="multipage"
      :active-key="activePage"
      class="tab-layout-tabs"
      :hide-add="true"
      type="editable-card"
      @change="changePage"
      @tabClick="tabCallBack"
      @edit="editPage"
      id="tab-layout-tabs-js"
    >
      <a-tab-pane
        :id="page.fullPath"
        :key="page.fullPath"
        v-for="page in pageList"
        :closable="page.fullPath !== indexKey"
      >
        <span
          slot="tab"
          :pagekey="page.fullPath"
        >{{ handleTitle(page.meta) }}</span>
      </a-tab-pane>
    </a-tabs>
    <div
      ref="tabContentBox"
      class="tab-content-box content-box-wrap"
      :style="{height: tabContentBoxToTop}">
      <!-- <transition name="page-toggle"> -->
      <keep-alive v-if="multipage">
        <router-view v-if="reloadFlag" />
      </keep-alive>
      <template v-else>
        <router-view v-if="reloadFlag" />
      </template>
      <!-- </transition> -->
    </div>
  </global-layout>
</template>

<script>
import GlobalLayout from '@/components/page/GlobalLayout'
import Contextmenu from '@/components/menu/Contextmenu'
import { mixin, mixinDevice } from '@/utils/mixin.js'
// import { triggerWindowResizeEvent } from '@/utils/util'
import {
    DEFAULT_FIXED_HEADER,
    DEFAULT_COLOR
} from '@/store/mutation-types'

const indexKey = '/dashboard-srm'

export default {
    name: 'TabLayout',
    components: {
        GlobalLayout,
        Contextmenu
    },
    mixins: [mixin, mixinDevice],
    data () {
        return {
            indexKey,
            pageList: [],
            linkList: [],
            activePage: '',
            menuVisible: false,
            menuItemList: [
                { key: '4', icon: 'reload', text: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_refresh`, '刷 新') },
                { key: '1', icon: 'arrow-left', text: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_closeLeft`, '关闭左侧') },
                { key: '2', icon: 'arrow-right', text: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_closeRight`, '关闭右侧') },
                { key: '3', icon: 'close', text: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_closeOther`, '关闭其它') }
            ],
            reloadFlag: true
        }
    },

    provide (){
        return{
            closeCurrent: this.closeCurrent,
            routeReload: this.routeReload
        }
    },

    computed: {
        tabContentBoxToTop () {
            let fixedHeader = this.$ls.get(DEFAULT_FIXED_HEADER)
            let height = document.body.clientHeight -59-34
            if (fixedHeader) {
                height =  (document.body.clientHeight -59)
            }
            return height + 'px'
        },
        multipage () {
        //判断如果是手机模式，自动切换为单页面模式
            if (this.isMobile()) {
                return false
            } else {
                return this.$store.state.app.multipage
            }
        }
    },
    created () {
        // if (this.$route.path != indexKey) {
        //     this.pageList.push({
        //         name: 'dashboard-srm',
        //         path: indexKey,
        //         fullPath: indexKey,
        //         meta: {
        //             icon: 'dashboard',
        //             title: '首页'
        //         }
        //     })
        //     this.linkList.push(indexKey)
        // }
        this.pageList.push(this.$route)
        this.linkList.push(this.$route.fullPath)
        this.activePage = this.$route.fullPath
    },
    mounted () {
        this.$ls.on(DEFAULT_COLOR, function () {
            console.log(111)
        })
    },
    watch: {
        '$route': function (newRoute) {
            this.activePage = newRoute.fullPath
            if (!this.multipage) {
                this.linkList = [newRoute.fullPath]
                this.pageList = [Object.assign({}, newRoute)]
            } else if (this.linkList.indexOf(newRoute.fullPath) < 0) {
                this.linkList.push(newRoute.fullPath)
                this.pageList.push(Object.assign({}, newRoute))
            } else if (this.linkList.indexOf(newRoute.fullPath) >= 0) {
                let oldIndex = this.linkList.indexOf(newRoute.fullPath)
                let oldPositionRoute = this.pageList[oldIndex]
                this.pageList.splice(oldIndex, 1, Object.assign({}, newRoute, {meta: oldPositionRoute.meta}))
            }
        },
        'activePage': function (key) {
            let index = this.linkList.lastIndexOf(key)
            let waitRouter = this.pageList[index]
            this.$router.push(Object.assign({}, waitRouter))
            this.activeTabBg()
        },
        'multipage': function (newVal) {
            if(this.reloadFlag){
                if (!newVal) {
                    this.linkList = [this.$route.fullPath]
                    this.pageList = [this.$route]
                }
            }
        }
    },
    methods: {
        // tab添加背景色
        activeTabBg () {
            this.$nextTick(() => {
                const $obj = document.querySelector('#tab-layout-tabs-js')
                if ($obj) {
                    let actDom = $obj.querySelector('.ant-tabs-nav-wrap .ant-tabs-tab-active')
                    let tabsDom = [...$obj.querySelectorAll('.ant-tabs-nav-wrap [role="tab"]')]
                    tabsDom.forEach(rs => {
                        rs.style.cssText = ''
                    })
                    console.log(this.$ls.get(DEFAULT_COLOR))
                    let themeColor = this.$ls.get(DEFAULT_COLOR)
                    // 17 为 16进制颜色透明度 0.1
                    if (/^#/.test(themeColor)) {
                        actDom.style.cssText = `background: ${themeColor}17 !important;`
                    }
                }
            })
        },
        changePage (key) {
            let that = this
            if(this.$store.state.app.changeTabConfirm) {
                this.$confirm({
                    content: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_currentIsEditingStatusSureToLeave`, '当前处于编辑状态，是否确定离开'),
                    onOk: () => {
                        that.activePage = key
                        this.$store.dispatch('SetTabConfirm', false)
                    }
                })
            }else {
                this.activePage = key
            }
        },
        tabCallBack () {
            // this.$nextTick(() => {
            //     triggerWindowResizeEvent()
            // })
        },
        editPage (key, action) {
            this[action](key)
        },
        remove (key) {
            // if (key == indexKey) {
            //     this.$message.warning('首页不能关闭!')
            //     return
            // }
            if (this.pageList.length === 1) {
                // this.$message.warning('这是最后一页，不能再关闭了啦')
                this.pageList = []
                this.linkList = []
                this.pageList.push({
                    name: 'dashboard-srm',
                    path: indexKey,
                    fullPath: indexKey,
                    meta: {
                        icon: 'dashboard',
                        title: this.$srmI18n(`${this.$getLangAccount()}#i18n_title_home`, '首页')
                    }
                })
                this.linkList.push(indexKey)
                this.activePage = indexKey
                return
            }
            this.pageList = this.pageList.filter(item => item.fullPath !== key)
            let index = this.linkList.indexOf(key)
            this.linkList = this.linkList.filter(item => item !== key)
            index = index >= this.linkList.length ? this.linkList.length - 1 : index
            this.activePage = this.linkList[index]
        },
        onContextmenu (e) {
            const pagekey = this.getPageKey(e.target)
            if (pagekey !== null) {
                e.preventDefault()
                this.menuVisible = true
            }
        },
        handleTitle (meta) {
            let t = meta.title
            if (meta.titleI18nKey) {
                t = this.$srmI18n(`${this.$getLangAccount()}#${meta.titleI18nKey}`, meta.title)
            }
            return t
        },
        getPageKey (target, depth) {
            depth = depth || 0
            if (depth > 2) {
                return null
            }
            let pageKey = target.getAttribute('pagekey')
            pageKey = pageKey || (target.previousElementSibling ? target.previousElementSibling.getAttribute('pagekey') : null)
            return pageKey || (target.firstElementChild ? this.getPageKey(target.firstElementChild, ++depth) : null)
        },
        onMenuSelect (key, target) {
            let pageKey = this.getPageKey(target)
            switch (key) {
            case '1':
                this.closeLeft(pageKey)
                break
            case '2':
                this.closeRight(pageKey)
                break
            case '3':
                this.closeOthers(pageKey)
                break
            case '4':
                this.routeReload()
                break
            default:
                break
            }
        },

        closeCurrent (){
            this.remove(this.activePage)
        },

        closeOthers (pageKey) {
            let index = this.linkList.indexOf(pageKey)
            if (pageKey == indexKey || pageKey.indexOf('?ticke=')>=0) {
                this.linkList = this.linkList.slice(index, index + 1)
                this.pageList = this.pageList.slice(index, index + 1)
                this.activePage = this.linkList[0]
            } else {
                let indexContent = this.pageList.slice(0, 1)[0]
                this.linkList = this.linkList.slice(index, index + 1)
                this.pageList = this.pageList.slice(index, index + 1)
                this.linkList.unshift(indexContent.fullPath)
                this.pageList.unshift(indexContent)
                this.activePage = this.linkList[1]
            }
        },
        closeLeft (pageKey) {
            if (pageKey == indexKey) {
                return
            }
            let tempList = [...this.pageList]
            let indexContent = tempList.slice(0, 1)[0]
            let index = this.linkList.indexOf(pageKey)
            this.linkList = this.linkList.slice(index)
            this.pageList = this.pageList.slice(index)
            this.linkList.unshift(indexContent.fullPath)
            this.pageList.unshift(indexContent)
            if (this.linkList.indexOf(this.activePage) < 0) {
                this.activePage = this.linkList[0]
            }
        },
        closeRight (pageKey) {
            let index = this.linkList.indexOf(pageKey)
            this.linkList = this.linkList.slice(0, index + 1)
            this.pageList = this.pageList.slice(0, index + 1)
            if (this.linkList.indexOf(this.activePage < 0)) {
                this.activePage = this.linkList[this.linkList.length - 1]
            }
        },

        dynamicRouterShow (key, title){
            let keyIndex = this.linkList.indexOf(key)
            if(keyIndex>=0){
                let currRouter = this.pageList[keyIndex]
                let meta = Object.assign({}, currRouter.meta, {title: title})
                this.pageList.splice(keyIndex, 1, Object.assign({}, currRouter, {meta: meta}))
            }
        },



        routeReload (){
            this.reloadFlag = false
            let ToggleMultipage = 'ToggleMultipage'
            this.$store.dispatch(ToggleMultipage, false)
            this.$nextTick(()=>{
                this.$store.dispatch(ToggleMultipage, true)
                this.reloadFlag = true
            })
        }

    }
}
</script>
<style lang="less" scoped>
  /*
 * The following styles are auto-applied to elements with
 * transition="page-transition" when their visibility is toggled
 * by Vue.js.
 *
 * You can easily play with the page transition by editing
 * these styles.
 */

  /deep/ .page-transition-enter {
    opacity: 0;
  }

  /deep/ .page-transition-leave-active {
    opacity: 0;
  }

  /deep/ .page-transition-enter .page-transition-container,
  /deep/ .page-transition-leave-active .page-transition-container {
    -webkit-transform: scale(1.1);
    transform: scale(1.1);
  }

  /*美化弹出Tab样式*/
  /deep/ .tab-layout-tabs.ant-tabs.ant-tabs-card .ant-tabs-nav-container {
    margin-top: 4px;
    margin-bottom: 0;
  }

  /* 修改 ant-tabs 样式 */
  /deep/ .tab-layout-tabs.ant-tabs {
    /* border-bottom: 1px solid #ccc; */
    /* border-left: 1px solid #ccc; */
    background-color: white;
    padding: 0 6px;

    .ant-tabs-bar {
      margin: 0;
      /* border: none; */
    }

  }

  /deep/ .tab-layout-tabs.ant-tabs {

    &.ant-tabs-card .ant-tabs-tab {

      padding: 0 24px !important;
      background-color: white !important;
      margin-right: 10px !important;

      .ant-tabs-close-x {
        width: 12px !important;
        height: 12px !important;
        opacity: 0 !important;
        cursor: pointer !important;
        font-size: 12px !important;
        margin: 0 !important;
        position: absolute;
        top: 36%;
        right: 6px;
      }

      &:hover .ant-tabs-close-x {
        opacity: 1 !important;
      }

    }

  }

  /deep/ .tab-layout-tabs.ant-tabs.ant-tabs-card > .ant-tabs-bar {
    .ant-tabs-tab {
      border: none !important;
      border-bottom: 1px solid transparent !important;
    }
    .content-box-wrap {
        margin: 6px 6px 0;
    }
    .ant-tabs-tab-active {
        // background-color: @primary-color;
    //   border-color: @primary-color !important;
    } 
  }
  /* .tab-layout-tabs.ant-tabs.ant-tabs-card .ant-tabs-card-bar .ant-tabs-ink-bar {
      visibility: visible;
  } */

</style>