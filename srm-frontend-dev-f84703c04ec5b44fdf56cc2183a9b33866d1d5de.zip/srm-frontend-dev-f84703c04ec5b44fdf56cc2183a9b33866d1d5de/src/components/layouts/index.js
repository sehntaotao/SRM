// import UserLayout from '@/components/layouts/UserLayout'
import UserLayout from '@/components/layouts/UserLayoutNew'
import BlankLayout from '@/components/layouts/BlankLayout'
import BasicLayout from '@/components/layouts/BasicLayout'
import RouteView from '@/components/layouts/RouteView'
import PageView from '@/components/layouts/PageView'
import TabLayout from '@/components/layouts/TabLayout'
import HallLayout from '@/components/layouts/HallLayout'
import MallLayout from '@/components/layouts/MallLayout'

export { UserLayout, BasicLayout, BlankLayout, RouteView, PageView, TabLayout, HallLayout, MallLayout }