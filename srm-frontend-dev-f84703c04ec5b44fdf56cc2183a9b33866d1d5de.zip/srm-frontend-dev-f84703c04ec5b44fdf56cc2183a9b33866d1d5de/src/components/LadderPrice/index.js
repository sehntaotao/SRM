import LadderPrice from './src/main.vue'

LadderPrice.install = function (Vue) {
    Vue.component('LadderPrice', LadderPrice)
}

export default LadderPrice