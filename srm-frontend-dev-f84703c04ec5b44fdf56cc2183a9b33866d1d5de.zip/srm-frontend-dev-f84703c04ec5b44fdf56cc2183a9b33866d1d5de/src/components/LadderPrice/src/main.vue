<template>
  <div>
    <div class="LadderPrice">
      <div class="content">
        <slot :openFunc="showModal">
          <a-input
            readOnly
            :disabled="config.disabled"
            :value="value"
            :placeholder="config.placeholder"
            @click="showModal">
            <a-icon
              v-if="!config.disabled"
              slot="suffix"
              type="close-circle"
              @click="clearInputValue"></a-icon>
          </a-input>
        </slot>
      </div>
      <ladder-price-modal
        isEmit
        v-on="$listeners"
        ref="LadderPriceModal"
      />
    </div>
  </div>
</template>

<script>
import LadderPriceModal from './LadderPriceModal'
export default {
    name: 'Main',
    model: {
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: String,
            default: ''
        },
        config: {
            type: Object,
            default () {
                return {}
            }
        },
        isRow: {
            type: Boolean,
            default: false
        },
        row: {
            type: Object,
            default () {
                return {}
            }
        },
        column: {
            type: Object,
            default () {
                return {}
            }
        },
        form: {
            type: Object,
            default () {
                return {}
            }
        },
        pageData: {
            type: Object,
            default () {
                return {
                    groups: [{
                        custom: {
                            form: {},
                            formFields: [],
                            validateRules: {}
                        },
                        extend: null,
                        groupCode: null,
                        groupName: null,
                        sortOrder: null
                    }]
                }
            }
        },
        isFromTileEditPage: {
            type: Boolean,
            default: false
        }
    },

    data () {
        return {
        }
    },
    components: {LadderPriceModal},

    mounted () {
        
    },
    computed: {
        // 配置下标，当弹窗配置为数组时
        current () {
            return this.config && this.config.extend && this.config.extend.current || 0
        },
        // 当前配置项
        curConfig () {
            let extend = this.config && this.config.extend || {}
            if (extend.modalConfigs && Array.isArray(extend.modalConfigs)) {
                return extend.modalConfigs[this.current]
            }
            return extend
        },
        groupData () {
            if (this.isFromTileEditPage) {
                return this.pageData.panels[this.currentStep] || {}
            }
            return this.pageData.groups[this.currentStep] || {}
        }
    },

    methods: {
        showModal () {
            console.log(this.pageData)
            let beforeCheckedCallBack = this.curConfig.beforeCheckedCallBack || (() => window.Promise.resolve())
            this.changeSelectModalValue(beforeCheckedCallBack).then(() => {
                const curInfo = this.isRow ? this.row : this.form
                this.$refs.LadderPriceModal.open(curInfo)
            }).catch((errTxt) => {
                this.$message.error(errTxt)
                if (this.isRow) {
                    this.$emit('error', errTxt)
                }
            })
        },
        handleCancel () {
            // this.visible = false
            // this.$emit('update:visible', false)
            // this.$refs.LadderPriceModal.hide('a')
        },
        clearInputValue () {
            let beforeCheckedCallBack = this.curConfig.beforeCheckedCallBack || (() => window.Promise.resolve())
            let afterClearCallBack = this.curConfig.afterClearCallBack || (f => f)
            this.changeSelectModalValue(beforeCheckedCallBack).then(() => {
                this.$emit('change', '')
                this.$emit('afterClearCallBack', afterClearCallBack)
            }).catch((errTxt) => {
                this.$message.error(errTxt)
                if (this.isRow) {
                    this.$emit('error', errTxt)
                }
            })
        },
        // 统一表头、表行回调参数
        changeSelectModalValue (cb) {
            if (this.isRow) {
                return cb && cb(this, this.row, this.column, this.form)
            } else {
                return cb && cb(this, this.pageData, this.groupData, this.form)
            }
        }
    }
}
</script>

<style lang="scss" scoped>

</style>