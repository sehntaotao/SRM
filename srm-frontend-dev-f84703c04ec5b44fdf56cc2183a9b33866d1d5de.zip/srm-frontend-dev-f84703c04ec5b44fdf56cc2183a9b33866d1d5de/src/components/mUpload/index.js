import MUpload from './src/main.vue'

MUpload.install = function (Vue) {
    Vue.component('MUpload', MUpload)
}

export default MUpload