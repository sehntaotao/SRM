<template>
  <div class="m-upload">

    <span class="ant-upload-picture-card-wrapper">
      <div class="ant-upload-list ant-upload-list-picture-card">
        <a-upload
          v-show="defaultFileList.length < limit"
          ref="upload"
          list-type="picture-card"
          v-bind="attrs.uploadAttrs"
          v-on="$listeners"
          :action="action"
          :default-file-list="defaultFileList"
          :showUploadList="false"
          @change="handleUploadChange"
        >
          <div>
            <div class="uploadBtn">
              <a-icon type="plus" />
              <div class="ant-upload-text">
                {{ $srmI18n(`${$getLangAccount()}#i18n_title_upload`, '上传') }}
              </div>
            </div>
          </div>
        </a-upload>
        <template v-for="el in defaultFileList">
          <div
            :key="el.id"
            class="ant-upload-list-picture-card-container">
            <span>
              <div class="ant-upload-list-item ant-upload-list-item-done ant-upload-list-item-list-type-picture-card">
                <div class="ant-upload-list-item-info">
                  <span>
                    <a
                      :href="el.url"
                      target="_blank"
                      class="ant-upload-list-item-thumbnail">
                      <img
                        :src="el.url"
                        class="ant-upload-list-item-image"></a>
                  </span>
                </div>
                <span class="ant-upload-list-item-actions">
                  <a
                    :href="el.url"
                    target="_blank"
                    title="预览文件">
                    <a-icon
                      @click.prevent="handlePreview(el)"
                      class="anticon anticon-eye-o"
                      type="eye" />
                    <a-icon
                      @click.prevent="handleRemove"
                      type="delete" />
                  </a>
                </span>
              </div>
            </span>
          </div>
        </template>

      </div>
    </span>

    <a-modal
      :visible="previewVisible"
      :footer="null"
      @cancel="handleCancel">
      <img
        alt="example"
        style="width: 100%"
        :src="previewImage" />
    </a-modal>
  </div>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'MUpload',
    props: {
        value: {
            type: String,
            default: ''
        }
    },
    data () {
        return {
            domianURL: '',
            previewVisible: false,
            previewImage: '',
            action: '/els/attachment/purchaseAttachment/upload'
        }
    },
    computed: {
        limit () {
            const { limit = 1 } = this.$attrs || {}
            return limit
        },
        // 父级传参
        attrs () {
            const { ...others } = this.$attrs || {}
            return {
                uploadAttrs: { ...others }
            }
        },
        defaultFileList () {
            let fileList = []
            if (this.value) {
                const url = `${this.domianURL}${this.value}`
                fileList = [{ name: 'image', status: 'done', url, thumbUrl: url, uid: +new Date()  }]
            }
            return fileList
        }
    },
    mounted () {
        const { protocol = '', hostname = '' } = window.location || {}
        this.domianURL = `${protocol}//${hostname}/opt/upFiles`
    },
    methods: {
        handleRemove () {
            this.$emit('update:value', '')
        },
        handleCancel () {
            this.previewVisible = false
        },
        handlePreview ({ url }) {
            this.previewImage = url
            this.previewVisible = true
        },
        handleUploadChange ({ file, fileList, event }) {
            if (file.status === 'done') {
                if (file.response.success) {
                    if (file.response.code === 201) {
                        let { message, result: { msg, fileUrl, fileName } } = file.response
                        let href = this.$variateConfig['domianURL'] + fileUrl
                        this.$warning({
                            title: message,
                            content: (
                                <div>
                                    <span>{msg}</span><br/>
                                    <span>
                                        { $srmI18n(`${$getLangAccount()}#i18n_title_detailContent`, '具体详情请') }
                                        <a href={href} target="_blank" download={fileName}>
                                            { $srmI18n(`${$getLangAccount()}#i18n_title_download`, '点击下载') }
                                        </a>
                                    </span>
                                </div>
                            )
                        })
                    } else {
                        let message = file.response.message || this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadSuccess`, '文件上传成功')
                        this.$message.success(message)
                        const filePath = file.response.result.filePath
                        this.$emit('update:value', filePath)
                    }
                } else {
                    this.$message.error(`${file.name} ${file.response.message}.`)
                }
            } else if (file.status === 'error') {
                this.$message.error(
                    `${this.$srmI18n(`${this.$getLangAccount()}#i18n_title_uploadError`, '文件上传失败')} : ${file.msg}`
                )
            }
        }
    }
}
</script>

<style lang="less" scoped>
.m-upload {
    .uploadBtn {
        i {
            font-size: 32px;
            color: #999;
        }
        .ant-upload-text {
            margin-top: 8px;
            color: #666;
        }
    }
}
</style>
