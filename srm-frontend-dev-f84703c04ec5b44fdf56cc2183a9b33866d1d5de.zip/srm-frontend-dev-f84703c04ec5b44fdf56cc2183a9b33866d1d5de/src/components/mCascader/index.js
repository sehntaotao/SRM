import MCascader from './src/main.vue'

MCascader.install = function (Vue) {
    Vue.component('MCascader', MCascader)
}

export default MCascader