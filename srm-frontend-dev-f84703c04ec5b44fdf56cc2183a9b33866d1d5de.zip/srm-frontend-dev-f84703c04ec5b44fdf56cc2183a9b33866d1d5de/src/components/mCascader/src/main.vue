<template>
  <div>
    <a-cascader
      :defaultValue="realValue"
      :field-names="fieldNames"
      :options="options"
      v-bind="$attrs"
      v-on="mixListeners" />
  </div>
</template>

<script>
import { getAction } from '@api/manage'

export default {
    name: 'MCascader',
    model: {
        prop: 'value',
        event: 'change'
    },
    props: {
        value: {
            type: String,
            default: ''
        },
        mode: {
            type: String,
            default: 'executive'
        },
        fieldNames: {
            type: Object,
            default: () => {
                return { label: 'orgName', value: 'id', children: 'children' }
            }
        }
    },
    data () {
        return {
            loading: false,
            realValue: [],
            options: []
        }
    },
    computed: {
        mixListeners () {
            let vm = this
            // `Object.assign` 将所有的对象合并为一个新对象
            return Object.assign({},
                // 我们从父级添加所有的监听器
                this.$listeners,
                // 然后我们添加自定义监听器，
                // 或覆写一些监听器的行为
                {
                    // 这里确保组件配合 `v-model` 的工作
                    change (val) {
                        console.log('val', val)
                        const id = val.slice(-1).join('')
                        console.log('id', id)
                        vm.$emit('change', id)
                    }
                }
            )
        }
    },
    watch: {
        value: {
            immediate: true,
            handler (val) {
                this.realValue = val && val.split(',') || []
            }
        },
        mode: {
            immediate: true,
            handler (val) {
                console.log('modeVal', val)
                this.getTreeData()
            }
        }
    },
    methods: {
        getTreeData () {
            this.loading = true
            getAction('/org/purchaseOrganizationInfo/getSuperOrg', null).then((res) => {
                const { result } = res || {}
                const mode = this.mode || 'executive'
                this.options = result[mode] || []
                console.log('this.options', this.options)
            }).finally(() => {
                this.loading = false
            })
        }
    }
}
</script>
