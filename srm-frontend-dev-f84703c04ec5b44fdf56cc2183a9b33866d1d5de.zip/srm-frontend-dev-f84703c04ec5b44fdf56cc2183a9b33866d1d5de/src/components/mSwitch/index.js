import MSwitch from './src/main.vue'

MSwitch.install = function (Vue) {
    Vue.component('MSwitch', MSwitch)
}

export default MSwitch