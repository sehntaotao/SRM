import Vue from 'vue'
import store from '@/store/'
import i18n from '@/i18n'
import * as api from '@/api/api'
import { isURL } from '@/utils/validate'
import { downFile } from '@/api/manage'
import { ACCESS_TOKEN, USER_ELS_ACCOUNT, DEFAULT_LANG, USER_COMPANYSET } from '@/store/mutation-types'
import { variateConfig } from '@/utils/variateConfig.js'
let isOnloadSign = false // onload触发标识
let onloadCallbackArr = [] // onload时间触发后调用，记录回调函数

export function timeFix () {
    const time = new Date()
    const hour = time.getHours()
    let lang = Vue.ls.get(DEFAULT_LANG) === 'en' ? true : false
    // return hour < 9 ? srmI18n(`${getLangAccount()}#i18n_title_goodMorning`, '早上好') : (hour <= 11 ? srmI18n(`${getLangAccount()}#i18n_title_goodMorning`, '上午好') : (hour <= 13 ? srmI18n(`${getLangAccount()}#i18n_title_goodNoon`, '中午好') : (hour < 20 ? srmI18n(`${getLangAccount()}#i18n_title_goodAfternoon`, '下午好') :srmI18n(`${getLangAccount()}#i18n_title_goodAfternoon`, '晚上好') )))
    return hour < 9 ? (lang ? 'good morning' : '早上好') : (hour <= 11 ? (lang ? 'good morning' : '上午好') : (hour <= 13 ? (lang ? 'Good noon' : '中午好') : (hour < 20 ? (lang ? 'Good afternoon' : '下午好') :(lang ? 'good evening' : '晚上好') )))
}

export function welcome () {
    let tips1=srmI18n(`${getLangAccount()}#i18n_title_takeABreak`, '休息一会儿吧')
    let tips2=srmI18n(`${getLangAccount()}#i18n_title_whatAreYouGoingToEat`, '准备吃什么呢?')
    let tips3=srmI18n(`${getLangAccount()}#i18n_title_doYouWantToPlayDota`, '要不要打一把 DOTA')
    let tips4=srmI18n(`${getLangAccount()}#i18n_title_guessYouMayBeTired`, '我猜你可能累了')

    const arr = [tips1, tips2, tips3, tips4]
    let index = Math.floor((Math.random()*arr.length))
    return arr[index]
}

/**
 * 触发 window.resize
 */
export function triggerWindowResizeEvent () {
    let event = document.createEvent('HTMLEvents')
    event.initEvent('resize', true, true)
    event.eventType = 'message'
    window.dispatchEvent(event)
}

/**
 * 过滤对象中为空的属性
 * @param obj
 * @returns {*}
 */
export function filterObj (obj) {
    if (!(typeof obj == 'object')) {
        return
    }

    for ( var key in obj) {
        if (obj.hasOwnProperty(key)
      && (obj[key] == null || obj[key] == undefined || obj[key] === '')) {
            delete obj[key]
        }
    }
    return obj
}

/**
 * 时间格式化
 * @param value
 * @param fmt
 * @returns {*}
 */
export function formatDate (value, fmt) {
    var regPos = /^\d+(\.\d+)?$/
    if(regPos.test(value)){
    //如果是数字
        let getDate = new Date(value)
        let o = {
            'M+': getDate.getMonth() + 1,
            'd+': getDate.getDate(),
            'h+': getDate.getHours(),
            'm+': getDate.getMinutes(),
            's+': getDate.getSeconds(),
            'q+': Math.floor((getDate.getMonth() + 3) / 3),
            'S': getDate.getMilliseconds()
        }
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (getDate.getFullYear() + '').substr(4 - RegExp.$1.length))
        }
        for (let k in o) {
            if (new RegExp('(' + k + ')').test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
            }
        }
        return fmt
    }else{
    //TODO
        value = value.trim()
        return value.substr(0, fmt.length)
    }
}

// 生成首页路由
export function generateIndexRouter (data) {
    let homePath = data[0].path
    let indexRouter = [{
        path: '/',
        name: 'dashboard',
        //component: () => import('@/components/layouts/BasicLayout'),
        component: resolve => require(['@/components/layouts/TabLayout'], resolve),
        meta: { title: '首页' },
        redirect: homePath,
        children: [
            ...generateChildRouters(data)
        ]
    }, {
        'path': '*', 'redirect': '/404', 'hidden': true
    }]
    return indexRouter
}

// 生成嵌套路由（子路由）

function  generateChildRouters (data) {
    const routers = []
    for (var item of data) {
        let component = ''
        if(item.component.indexOf('layouts')>=0){
            component = 'components/'+item.component
        }else{
            component = 'views/'+item.component
        }
        // item.meta.url = '{{  variateConfig["domianURL"] }}/uflo/designer'
        // item.meta.url = '{{ window._CONFIG["domianURL"] }}/uflo/designer'
        // eslint-disable-next-line
        let URL = (item.meta.url || '').replace(/{{([^}}]+)?}}/g, (s1, s2) => {
            let val = s2.trim()
            val = variateConfig[val]
            return val
        }) // URL支持{{ window.xxx }}占位符变量
        if (isURL(URL)) {
            item.meta.url = URL
        }
        let menu =  {
            path: item.path,
            name: item.name,
            redirect: item.redirect,
            component: resolve => require(['@/' + component+'.vue'], resolve),
            hidden: item.hidden,
            //component:()=> import(`@/views/${item.component}.vue`),
            meta: {
                title: item.meta.title,
                icon: item.meta.icon,
                url: item.meta.url,
                permissionList: item.meta.permissionList,
                keepAlive: item.meta.keepAlive,
                /*update_begin author:wuxianquan date:20190908 for:赋值 */
                internalOrExternal: item.meta.internalOrExternal
                /*update_end author:wuxianquan date:20190908 for:赋值 */
            }
        }
        if(item.alwaysShow){
            menu.alwaysShow = true
            menu.redirect = menu.path
        }
        if (item.children && item.children.length > 0) {
            menu.children = [...generateChildRouters( item.children)]
        }

        //判断是否生成路由
        if(item.route && item.route === '0'){
            //console.log(' 不生成路由 item.route：  '+item.route);
            //console.log(' 不生成路由 item.path：  '+item.path);
        }else{
            routers.push(menu)
        }

    }
    return routers
}

/**
 * 深度克隆对象、数组
 * @param obj 被克隆的对象
 * @return 克隆后的对象
 */
export function cloneObject (obj) {
    return JSON.parse(JSON.stringify(obj))
}

/**
 * 随机生成数字
 *
 * 示例：生成长度为 12 的随机数：randomNumber(12)
 * 示例：生成 3~23 之间的随机数：randomNumber(3, 23)
 *
 * @param1 最小值 | 长度
 * @param2 最大值
 * @return int 生成后的数字
 */
export function randomNumber () {
    // 生成 最小值 到 最大值 区间的随机数
    const random = (min, max) => {
        return Math.floor(Math.random() * (max - min + 1) + min)
    }
    if (arguments.length === 1) {
        let [length] = arguments
        // 生成指定长度的随机数字，首位一定不是 0
        let nums = [...Array(length).keys()].map((i) => (i > 0 ? random(0, 9) : random(1, 9)))
        return parseInt(nums.join(''))
    } else if (arguments.length >= 2) {
        let [min, max] = arguments
        return random(min, max)
    } else {
        return Number.NaN
    }
}

/**
 * 随机生成字符串
 * @param length 字符串的长度
 * @param chats 可选字符串区间（只会生成传入的字符串中的字符）
 * @return string 生成的字符串
 */
export function randomString (length, chats) {
    if (!length) length = 1
    if (!chats) chats = '0123456789qwertyuioplkjhgfdsazxcvbnm'
    let str = ''
    for (let i = 0; i < length; i++) {
        let num = randomNumber(0, chats.length - 1)
        str += chats[num]
    }
    return str
}

/**
 * 随机生成uuid
 * @return string 生成的uuid
 */
export function randomUUID () {
    let chats = '0123456789abcdef'
    return randomString(32, chats)
}

/**
 * 下划线转驼峰
 * @param string
 * @returns {*}
 */
export function underLine2CamelCase (string){
    return string.replace( /_([a-z])/g, function ( all, letter ) {
        return letter.toUpperCase()
    })
}

/**
 * 判断是否显示办理按钮
 * @param bpmStatus
 * @returns {*}
 */
export function showDealBtn (bpmStatus){
    if(bpmStatus!='1'&&bpmStatus!='3'&&bpmStatus!='4'){
        return true
    }
    return false
}

/**
 * 增强CSS，可以在页面上输出全局css
 * @param css 要增强的css
 * @param id style标签的id，可以用来清除旧样式
 */
export function cssExpand (css, id) {
    let style = document.createElement('style')
    style.type = 'text/css'
    style.innerHTML = `@charset "UTF-8"; ${css}`
    // 清除旧样式
    if (id) {
        let $style = document.getElementById(id)
        if ($style != null) $style.outerHTML = ''
        style.id = id
    }
    // 应用新样式
    document.head.appendChild(style)
}

/**
 * 重复值验证工具方法
 *
 * 使用示例：
 * { validator: (rule, value, callback) => validateDuplicateValue('sys_fill_rule', 'rule_code', value, this.model.id, callback) }
 *
 * @param tableName 被验证的表名
 * @param fieldName 被验证的字段名
 * @param fieldVal 被验证的值
 * @param dataId 数据ID，可空
 * @param callback
 */
export function validateDuplicateValue (tableName, fieldName, fieldVal, dataId, callback) {
    let params = { tableName, fieldName, fieldVal, dataId }
    api.duplicateCheck(params).then(res => {
        res['success'] ? callback() : callback(res['message'])
    }).catch(err => {
        callback(err.message || err)
    })
}
// 直接提取子节点p标签中的innerHtml 转换为对象方便后续处理
export function getInnerMulLang (ele) {
    const json = {}
    const $sel = [...ele.querySelectorAll('[data-lang]')]
    $sel.forEach($e => {
        const name = $e.getAttribute('data-lang')
        if (name) {
            json[name] = $e.innerHTML
        }
    })
    // 暂时不释放
    // ele.innerHTML = ''
    return json
}
// onload完成后触发
export function onloadAfterEmit () {
    isOnloadSign = true // 标识
    onloadCallbackArr.forEach(fn => {
        if (fn && typeof fn === 'function') fn()
    })
    onloadCallbackArr = [] // 清空数组
    // 检测全局调用
    if (window._onloadCallback_ && Array.isArray(window._onloadCallback_)) {
        window._onloadCallback_.forEach(fn => {
            if (fn && typeof fn === 'function') fn()
        })
        window._onloadCallback_ = null
    }
}
// onload全局调用
export function onloadCallback  (fn) {
    if (typeof fn !== 'function') return false
    if (isOnloadSign === true) fn()
    else onloadCallbackArr.push(fn)
}

/**
 *多组模板验证方法
 * @export
 * @param {*} validTaget, 当前组件的ref
 * @param {*} pageConfig, 当前的配置
 */
export function handValidate (validTaget, pageConfig) {
    const handlePromise = (list = []) => list.map(promise => promise.then(res => ({
        status: 'success',
        res
    }), err => ({
        status: 'error',
        err
    })))
    let setPromise= (groups)=> {
        return groups.filter(rs => rs.show =! false).map(group => {
            if (group.groupType === 'item') {
                const Gdom = validTaget.$refs[group.groupCode+'grid']
                let gridParentRef = Gdom && Gdom[0]
                return gridParentRef && gridParentRef.$refs[group.groupCode].validate(true)
            } else {
                const Fdom = validTaget.$refs[group.groupCode+'form']
                let formParentRef = Fdom && Fdom[0]
                return formParentRef && formParentRef.$refs[group.groupCode].validate()
            }
        }).filter(promise => promise)
    }
    let promise = setPromise(pageConfig.groups)
    return new Promise((resolve, reject)=> {
        Promise.all(handlePromise(promise)).then(result => {
            let currentStep = null
            let flag = true
            for (let i = 0; i < result.length; i++) {
                if (result[i].status === 'error') {
                    currentStep = i
                    flag = false
                }
            }
            if (flag) {
                let resolveData = { validStatus: true, currentStep: currentStep, message: '验证成功'}
                resolve(resolveData)
            } else {
                let resolveData = { validStatus: false, currentStep: currentStep, message: '验证失败，请处理'}
                resolve(resolveData)
            }
        }).catch(err => {
            reject(err)
        })
    })
}

//根据字典Code, 初始化字典数组
function initDictData (dictCode, busAccount) {
    let postData = {
        busAccount,
        dictCode
    }             
    return api.ajaxFindDictItems(postData)
}
/**
 * 根据选中值获取对应obj同级的字段
 * 暂支持select 单选和多选，其他需要扩展
 * codeObj object 填入已选择的code 比如 {factory: '1004'}；
 * formFields 当前pageData.formFields 模板返回或者前端页面写死 获取比如：this.$refs.editPage.pageData.formFields
 * busAccount 获取初始化字典数组 必要字段 如：this.busAccount || this.$ls.get(USER_ELS_ACCOUNT)
 */
export function getValueByCode (codeObj, formFields, busAccount) {
    return new Promise ((resolve, reject) => {
        let obj = {}
        let nameArr = Object.keys(codeObj)
        let request = formFields.filter(el => nameArr.includes(el.fieldName) && el.dictCode).map(rs => initDictData(rs.dictCode, busAccount))
        Promise.all(request).then(function (posts) {
            posts = posts.map(ts => ts.result)
            posts.forEach( (p, idx) => {
                let name = `${nameArr[idx]}_text`
                // 兼容单选和多选
                obj[name] = p.filter(f => codeObj[nameArr[idx]].includes(f.value)).map(tx => tx.text).join(',')
            } )
            resolve(obj)
        }).catch(function (reason){
            reject(reason)
        })
    })
}
/**
* @method
* @param option 传入参数
* @param url 下载url
* @param id 可以在this.$refs.editPage.getPageData()里面取
* @param handlerName {String} eg：'purchaseEnquiryItemExcelHandler'
* @param roelCode {String} eg：'purchase'
* @param callback {Function} 完成回调，处理loadingor其他
* @desc 下载模板
*/
export function downloadTemplate (option) { 
    let params = {
        'id': option.id || '',
        'handlerName': option.handlerName || '',
        'roelCode': option.roelCode || '',
        'data': option.data || ''
    }
    downFile(option.url, params).then((data) => {
        if (!data) {
            this.$message.error('文件下载失败')
            return
        }
        if (typeof window.navigator.msSaveBlob !== 'undefined') {
            window.navigator.msSaveBlob(new Blob([data]), '模板.xlsx')
        } else {
            let url = window.URL.createObjectURL(new Blob([data]))
            let link = document.createElement('a')
            link.style.display = 'none'
            link.href = url
            link.setAttribute('download', '模板.xlsx')
            document.body.appendChild(link)
            link.click()
            document.body.removeChild(link) //下载完成移除元素
            window.URL.revokeObjectURL(url) //释放掉blob对象
        }
    }).finally(() => {
        option.cb && option.cb()
    })
}
// 获取当前的所属的国际化账号
export function getLangAccount (account) {
    // 如果传入account,表示返回的所属的归属方
    if (Vue.ls.get(ACCESS_TOKEN)) {
        if (account) {
            return account
        } else {
            return Vue.ls.get(USER_ELS_ACCOUNT)
        }
    } else {
        return'100000'
    }
}
// 检查是否显示国际化默认值
export function srmI18n (i18nKey, defaultValue, isShowKey) {
    try {
        if (store.state.switchLanguage.currentLangData[`${i18nKey}`]) {
            return i18n.t(i18nKey)
        } else if (isShowKey) {
            return i18nKey
        } else {
            return defaultValue
        }
    } catch (error) {
        console.error(error)
    }
}
// 检查操作权限,返回true有权限，返回false无权限
export function hasOptAuth (authCode) {
    let companySet = this.$ls.get(USER_COMPANYSET) || {}
    if (companySet && companySet.permissionOpt==='0') {
        return true
    } else {
        try {
            if (store.state.user.sysAuth && store.state.user.sysAuth.length) {
                let flag = false
                store.state.user.sysAuth.forEach((auth)=> {
                    if (auth.action === authCode) {
                        flag = true
                    }
                })
                return flag
            } else {
                return false
            }
        } catch (error) {
            console.error(error)
        }
    }
}
export function injectScript (src, onload, async, id, onerror) {
    document.getElementById(id) && document.getElementById(id).remove()
    let head = document.getElementsByTagName('head')[0],
        script = document.createElement('script')
    script.type = 'text/javascript'
    script.src = src
    script.async = async || false
    script.onload = onload || function () {}
    id ? script.id = id : ''
    script.onerror = onerror || function () {}
    head.appendChild(script)
}

/**
 * 递归扁平化数组
 * 
 * @export
 * @param {*} [arr=[]]
 * @returns
 */
export function deepFlatten (arr = []) {
    let result = []
    arr.map(v => {
        if (Array.isArray(v)) {
            result = result.concat(deepFlatten(v))
        } else {
            result.push(v)
        }
    })
    return result
}

/**
 * Compose 函数组合
 *
 * @export
 * @param {*} fns
 * @returns
 */
export function compose (...fns) {
    return function composed (result) {
        // 拷贝一份保存函数的数组
        let list = fns.slice()
        while (list.length > 0) {
            // 取出队列尾部最后一个函数
            // 并执行
            result = list.pop()(result)
        }
        return result
    }
}

/**
 * Compose 异步函数组合
 *
 * @export
 * @param {*} fns
 * @returns
 */
export function composePromise (...fns) {
    const init = fns.pop()
    return function (...args) {
        return fns.reverse().reduce(function (sequence, func) {
            return sequence.then(function (result) {
                return func.call(null, result)
            })
        }, Promise.resolve(init.apply(null, args)))
    }
}


// 判断是否为对象（排除null）
export function isObject (obj) {
    return obj !== null && typeof obj === 'object'
}
  
// 判断是否为Promise对象
export function isPromise (val) {
    return val && typeof val.then === 'function'
}

export function createPromise (fn) {
    return new Promise((resolve, reject) => {
        fn && fn(resolve, reject)
    })
}