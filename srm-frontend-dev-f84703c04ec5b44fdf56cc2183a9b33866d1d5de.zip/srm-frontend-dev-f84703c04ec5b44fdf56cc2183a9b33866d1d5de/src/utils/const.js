/*
 * @Author: your name
 * @Date: 2021-06-15 09:58:52
 * @LastEditTime: 2021-09-27 11:29:13
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \srm-frontend_v4.5\src\utils\const.js
 */
import { ROWSELECTMODALCONST } from './selectModalConst'

// report的地址
const reportAddress = () => {
    let reportHost = location.origin
    if (/localhost/g.test(reportHost)) {
        // reportHost = '//localhost:8085'
        reportHost = '//10.99.9.102'
    }
    return reportHost
}
const REPORT_ADDRESS= reportAddress()
const REPORT_JMREPORT_ADDRESS_SUFFIX = '/els/report/jmreport/list'
// 待确认交期订单tableCode
const PURCHASE_ORDER_ITEM_TABLE_CODE= 'purchaseOrderItem'
// 采购送货通知单tableCode
const PURCHASE_DELIVERY_NOTICE_LIST = 'purchaseDeliveryNoticeList'
// 销售tablecode
const SALE_DELIVER_NOTICE_LIST='saleDeliveryNoticeList'
// 采购送货通知单(基于订单)tableCode
const PURCHASE_DELIVERY_NOTICE_BY_ORDER_LIST = 'purchaseDeliveryNoticeByOrderList'
// 销售送货通知单(基于订单)tablecode
const SALE_DELIVER_NOTICE_BY_ORDER_LIST='saleDeliveryNoticeByOrderList'
// 路由白名单
const ROUTER_WHITE_LIST = ['/user/login', '/user/register', '/user/register-result', '/user/alteration', '/user/noticeList', '/user/noticeDetail', '/user/noticeDetailTemplate', '/user/service', '/user/suggestion', '/designForm', '/designForm/home', '/user/supplierRegister', '/oauth2/authorize', '/thirdPartyEmail', '/personalSettingsIndex', '/user/forgetPassword', '/registrationGuidePage', '/user/qcLogin', '/questionnaire/observe', '/questionnaire/result', '/user/QcCodeBinding' ]
// 下载地址
const PURCHASEATTACHMENTDOWNLOADAPI =  '/attachment/purchaseAttachment/download'
const SALEATTACHMENTDOWNLOADAPI =  '/attachment/saleAttachment/download'
export {
    REPORT_ADDRESS,
    REPORT_JMREPORT_ADDRESS_SUFFIX,
    PURCHASE_ORDER_ITEM_TABLE_CODE,
    PURCHASE_DELIVERY_NOTICE_LIST,
    SALE_DELIVER_NOTICE_LIST,
    ROUTER_WHITE_LIST,
    PURCHASEATTACHMENTDOWNLOADAPI,
    SALEATTACHMENTDOWNLOADAPI,
    ROWSELECTMODALCONST
}