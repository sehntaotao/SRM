import router from '../../router'
import {getAction, postAction} from '@api/manage'
import { ctxMenu } from './contextmenu'
import { init as groupSortInit } from './groupSort'
import { imUrl } from './tools'
let { BASE_URL, wsUrl } = imUrl()
const im = {
    BASE_URL,
    prefix: '/apis',
    token: '',
    currentUserId: '',
    socket: null,
    currentChatId: null,
    LAYIM: null,
    lockReconnect: false,
    baseSet () {
        const urlQuery = router.app.$route.query
        // 测试环境
        this.token = localStorage.getItem('t_token') || urlQuery.token
        if (!window.layui) { // 刷新路由bug
            window.setTimeout( () => {
                this.baseSet()
            }, 500)
            return
        }
        const _this = this
        window.layui.use(['layim'], function (layim) {
            _this.LAYIM = layim
            //  基础配置
            const opts = configOption(_this)
            layim.config(opts)
            
            // layim 事件监听
            imEventBind(layim)
            
            // 其他处理方法这里
            ctxMenu(_this)
        })
    },
    socketInit () {
        const url = `${wsUrl}?token=${this.token}`
        try {
            if ('WebSocket' in window) {
                this.socket = new WebSocket(url)
            }
            this.socketListener()
        } catch(e){
            this.reconnect(url)
        }
    },
    reconnect (url) {
        if(this.lockReconnect) return
        this.lockReconnect = true
        setTimeout( () => {     //没连接上会一直重连，设置延迟避免请求过多
            this.socketInit(url)
            this.lockReconnect = false
        }, 2000)
    },
    // 获取离线消息
    getUnreadMessage () {
        const sendData = {
            code: 1, // 0 心跳检测，1 链接就绪，2 消息
            message: {
            }
        }
        this.socket.send(JSON.stringify(sendData))
    },
    socketListener () {
        let _this = this
        if (this.socket) {
            this.socket.onerror = function () {
                console.log('通讯连接失败!')
            }
            // 连接成功建立的回调方法
            this.socket.onopen = function () {
                heartCheck.reset().start()  //心跳检测重置
                // 发送code=1 就绪
                _this.getUnreadMessage()
                console.log('通讯连接成功!')
            }
            // 接收到消息的回调方法
            this.socket.onmessage = function (res) {
                heartCheck.reset().start() //拿到任何消息都说明当前连接是正常的
                // 结构统一后，集中处理
                _this.handleMessage(res.data)
            }
            // 连接关闭的回调方法
            this.socket.onclose = function () {
                console.log('连接关闭，你与服务器断开连接，正在尝试重新连接！')
            }
        }
    },
    handleMessage (data) {
        const mydata = eval('('+data+')')
        const layim = this.LAYIM
        const type = mydata['msg_type']
        if (type && layim && mydata) {
            messageProcessor[type]({mydata, layim})
        }
    }

}
// 配置选项
const configOption = (_this) => {
    let opt = {
        // 初始化
        init: {
            url: `${_this.BASE_URL}/user/init?X-Access-Token=${_this.token}`,
            data: {}
        },

        // 查看群员接口
        members: {
            url: `${_this.BASE_URL}/user/getMembers`,
            data: {
                'X-Access-Token': _this.token
            }
        },

        // 上传图片接口
        uploadImage: {
            url: `${_this.BASE_URL}/user/uploadFiles?X-Access-Token=${_this.token}`,
            type: '', // 默认post
            callback: function (res) {
            }
        },

        // 上传文件接口
        uploadFile: {
            url: `${_this.BASE_URL}/user/uploadFiles?X-Access-Token=${_this.token}`,
            type: '' // 默认post
        },
        isAudio: false, // 开启聊天工具栏音频
        isVideo: false, // 开启聊天工具栏视频
        title: ' ', // 自定义主面板最小化时的标题
        initSkin: '3.jpg', // 1-5 设置初始背景
        min: true, // 是否始终最小化主面板，默认false
        notice: true, // 是否开启桌面消息提醒，默认false
  
        msgbox: `${location.origin}/im/layim-v3.9.6/dist/css/modules/layim/html/msgbox.html`, // 消息盒子页面地址
        find: `${location.origin}/im/layim-v3.9.6/dist/css/modules/layim/html/find.html`, // 发现页面地址
        chatLog: `${location.origin}/im/layim-v3.9.6/dist/css/modules/layim/html/chatlog.html`, // 聊天记录页面地址
        selectMember: `${location.origin}/im/layim-v3.9.6/dist/css/modules/layim/html/selectMember.html`,
        setMinWinOffset: function () {  // 设置入口模块位置
            let right = document.querySelector('.nav-right-part').offsetWidth || 0 
            let winW = document.body.offsetWidth || 0
            let imW = 140 // im 入口宽度
            let x = '0'
            let y = winW + 5000 + 'px'
            return [x, y]
        }
    }
    return opt
}
// 消息处理 映射
const messageProcessor = {
    msg_ping () {
        // console.log('心跳')
    },
    msg_message ({ mydata, layim }) {
        const message = mydata.data
        const cache = layim.cache()
        // console.log('收到信息', message)
        if ((message.type == 'friend' || message.type == 'group') && cache.mine.id == message.fromid) { // 当前接收信息是群组，剔除自己的信息
            return
        }
        message.id =  message.type == 'friend' ? message.fromid : message.id
        layim.getMessage(message)
    },
    //添加 用户
    addUser ({ mydata, layim }) {
        let cache = layim.cache()
        if (cache.srmParams.frendsRequest.length > 0){
            // 加入到消息缓存中
            cache.srmParams.frendsRequest.push(mydata.data)
        } else {
            cache.srmParams.frendsRequest = []
            cache.srmParams.frendsRequest.push(mydata.data)
        }
        // 弹消息盒子
        layim.msgbox(1)
    },
    //同意 用户
    agree ({ mydata, layim }) {
        // 弹消息盒子
        let obj = {
            type: 'friend',
            avatar: mydata.data.avatar || '', //好友头像
            username: mydata.data.username, //好友昵称
            groupid: mydata.data.status, //所在的分组id
            id: mydata.data.id, //好友ID
            sign: '' //好友签名
        }
        layim.addList(obj)
    },
    //删除 用户
    delUser ({ mydata, layim }) {
        layim.removeList({
            type: 'friend',
            id: mydata.data.id //好友或者群组ID
        })
    },
    //离线消息
    unread ({ mydata, layim }) {
        if (mydata.data && mydata.data.length == 0) { return }
        mydata.data.forEach(rs => {
            window.setTimeout(function (){layim.getMessage(rs)}, 1000)
        })
    },
    // 添加 分组信息
    addGroup ({ mydata, layim }) {
        layim.addList(mydata.data)
    },
    addChatGroup ({ mydata, layim }) {
        const message = mydata.data
        let obj = {
            type: 'group',
            avatar: '',
            groupname: message.groupname,
            id: message.id
        }
        layim.addList(obj)
    },
    // 删除组
    delGroup ({ mydata, layim }) {
        layim.removeList({
            type: 'group',
            id: mydata.data.id //好友或者群组ID
        })
    },
    // 检测聊天数据
    chatMessage ({ mydata, layim }) {
        layim.getMessage(mydata.data)
    },
    // 用户登录 更新用户列表
    online ({ mydata, layim }) {
        layim.setFriendStatus(mydata.id, 'online')
    },
    // 用户退出 更新用户列表
    logout ({ mydata, layim }) {
        layim.setFriendStatus(mydata.id, 'offline')
    }
}

// layim 事件监听器
const eventProcessor = {
    // 监听layim建立就绪 init直接赋值mine、friend的情况下（只有设置了url才会执行 ready 事件）
    ready (res) {
        im.currentUserId = res.mine.id
        sessionStorage.setItem('currentUserId', im.currentUserId)
        // 组移动
        groupSortInit(im.LAYIM)
        // websocket 初始化
        im.socketInit()
    },
    // 监听发送消息
    sendMessage (data) {
        const mine = data.mine
        const to = data.to
        const sendData = {
            code: 2, // 0 心跳检测，1 链接就绪，2 消息
            message: {
                avatar: mine.avatar,
                id: im.currentChatId,
                fromid: mine.id,
                type: to.type,
                username: mine.username,
                content: mine.content
            }
        }
        console.log(JSON.stringify(sendData))
        im.socket.send(JSON.stringify(sendData))
    },
    // 监听聊天窗口的切换
    chatChange (res) {
        im.currentChatId = res.data.id
    }
}
const imEventBind = (layim) => {
    Object.keys(eventProcessor).forEach(evt => {
        console.log(evt)
        layim.on(evt, eventProcessor[evt])
    })
}
//心跳检测
const heartCheck = {
    timeout: 30000,        //30s发一次心跳
    timeoutObj: null,
    serverTimeoutObj: null,
    reset: function (){
        clearTimeout(this.timeoutObj)
        
        clearTimeout(this.serverTimeoutObj)
        return this
    },
    start: function (){
        var self = this
        this.timeoutObj = setTimeout(function (){
            //这里发送一个心跳，后端收到后，返回一个心跳消息，
            //onmessage拿到返回的心跳就说明连接正常
            const sendData = {
                code: 0, // 0 心跳检测，1 链接就绪，2 消息
                message: {
                }
            }
            im.socket.send(JSON.stringify(sendData))
            self.serverTimeoutObj = setTimeout(function (){//如果超过一定时间还没重置，说明后端主动断开了
                im.socke.close()  //如果onclose会执行reconnect，我们执行ws.close()就行了.如果直接执行reconnect 会触发onclose导致重连两次
            }, self.timeout)
        }, this.timeout)
    }
}
// 单聊
const createChat = (obj) => {
    let api = BASE_URL + '/user/getRecordPerson'
    if (!obj.type) {
        alert('请输入模块type')
        return false
    }
    if (!obj.id) { // 订单id不存在
        alert('id不存在')
        return
    }
    let params = {
        type: obj.type,
        id: obj.id
    }
    getAction(api, params).then(res => {
        if (res.success && !res.result.groupChat && res.result.imUserList.length> 0) {
            let data = res.result.imUserList[0]
            let layim = im.LAYIM
            layim.chat({
                name: data.username,
                type: 'friend', //群组类型
                avatar: data.avatar || '/im/layim-v3.9.6/dist/css/modules/layim/skin/default.png',
                id: data.id
            })
        } else {
            window.alert('没有找到用户id！')
        }
    }).catch((e) =>{
        window.alert(e)
    })
}

const selectMember = (obj) => {
    let layim = im.LAYIM
    let cache = layim.cache()
    cache.srmParams.selectMemberObj = obj
    if (!cache.base.selectMember) {
        return window.layer.msg('添加成员模板没有创建')
    }
    window.layer.close(im.index)
    return (im.index = window.layer.open({
        type: 2,
        title: '创建聊天',
        shade: false,
        maxmin: true,
        area: ['600px', '520px'],
        skin: 'layui-box layui-layer-border',
        resize: false,
        content: cache.base.selectMember
    })
    )
}
const creatGruopChat = (obj) => {
    if (!obj.type) {
        alert('请输入模块type')
        return false
    }
    if (!obj.id) { // 订单id不存在
        alert('id不存在')
        return
    }
    console.log(im.LAYIM)
    let layim = im.LAYIM
    let cache = layim && layim.cache()
    let groupId = obj.id + '_' + cache.mine.id
    let curChat = cache.group.find(rs => rs.id == groupId)
    // 存窗口id
    if (curChat) { // 群聊已经存在
        // 打开群聊
        layim.chat({
            name: curChat.groupname,
            type: 'group', //群组类型
            brief: '1', //群组类型
            avatar: curChat.avatar || 'http://tp2.sinaimg.cn/5488749285/50/5719808192/1',
            id: curChat.id, //定义唯一的id方便你处理信息
            members: 0  //成员数，不好获取的话，可以设置为0
        })
        return
    }
    let index = selectMember(obj)
    if (cache) {
        cache.srmParams.winIndex = index
    }
}
const init = () => {
    im.baseSet()
}
export default { init, createChat, selectMember, im, creatGruopChat}