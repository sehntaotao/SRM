import { getInnerMulLang } from '../util'
import router from '../../router'
import { menuInit } from './rightMenu'
import { popModify, friendGroupAdd, friendGroupRemoveClear, moveToGroup} from './firendGroup'
let fListInfo = {} // 好友列表信息

// 右键菜单配置项
const config = {
    rightMenu: []
}
const ctxMenu = (im) => {
    const layim = im.LAYIM
    config.rightMenu = menuInit()
    const $ = window.layui.jquery
    // 阻止浏览器默认右键点击事件
    document.oncontextmenu = function () {
        return false
    }
    // 单击聊天主界面事件
    $('body').on('click', '.layui-layim', function (){
        emptyTips()
    })
    // 右击聊天主界面事件
    $('body').on('mousedown', '.layui-layim', function (){
        emptyTips()
    })
    /* 监听鼠标滚轮事件 */
    $('body').on('mousewheel DOMMouseScroll', '.layim-tab-content', function (){
        emptyTips()
    })
    /* 绑定好友右击事件 */
    $('body').on('mousedown', '.layim-list-friend li ul li', function (e){
        // 清空所有右击弹框
        emptyTips()
        if(3 != e.which) {
            return
        }
        // 不再派发事件
        e.stopPropagation()
        
        var othis = $(this)
        if (othis.hasClass('layim-null')) return
        
        // 移除所有选中的样式
        $('.layim-list-friend li ul li').removeAttr('style', '')
        // 标注为选中
        othis.css({'background-color': 'rgba(0,0,0,.05)'})
        console.log(othis)
        let friend_id = othis[0].className.replace(/^layim-friend/g, '').split(' ')
        friend_id = friend_id && friend_id[0]
        // 获取当前li的原接口信息
        var $infoDom = othis.find('.js-attr-list-box')[0] || null
        fListInfo = getInnerMulLang($infoDom)
        console.log(fListInfo)
        // var mineId = $(this).data('mineid')
        var uid = Date.now().toString(36)
        // var space_icon = '&nbsp;&nbsp;'
        var space_text = ''
        let html = ''

        html +=  '<ul id="contextmenu_'+uid + '" data-avatar="1" data-name="'+friend_id+'" data-groudId="'+ fListInfo.groupId +'" data-id="'+friend_id+'" data-index="'+othis.index()+'" data-mold="1">'
        let { mine, friend } = layim.cache()
        const friendGroupArr = friend.filter(f => f.id != fListInfo.groupId).map(fs => ({
            groupname: fs.groupname,
            id: fs.id
        }))
        config.rightMenu.forEach(el => {
            if (el.id == 'deleteFriend' && friend_id == mine.id) { // 删除好友，排除自己
                html += ''
            } else if (el.id == 'moveToGroup') { // 移动好友
                html += `<li data-id="${el.id}" class="move-to-group-wrap" data-type="${el.handleFnName}" ><span class='text'>${space_text}${el.title}</span>`
                html += '        <select name="city" class="move-to-group-otp" style="width: 50px;" lay-verify="" lay-search>'
                html += '            <option value="选择">请选择</option>'
                friendGroupArr.forEach(fr => {
                    html += `          <option value="${fr.id}">${fr.groupname}</option>`
                })
                html += '        </select>'
            } else {
                html += `<li data-id="${el.id}" data-type="${el.handleFnName}"><span class='text'>${space_text}${el.title}</span></li>`
            }
        })
        html +=  '</ul>'
        
        window.layer.tips(html, othis, {
            tips: 1,
            time: 0,
            shift: 5,
            fix: true,
            skin: 'ayui-box layui-layim-contextmenu',
            success: function (layero){
                var liCount = (html.split('</li>')).length
                var stopmp = function (e) { 
                    window.stope(e)
                }
                layero.off('mousedowm', stopmp).on('mousedowm', stopmp)
                var layerobj = $('#contextmenu_'+uid).parents('.layui-layim-contextmenu')
                // 移动弹框位置
                var top = layerobj.css('top').toLowerCase().replace('px', '')
                var left = layerobj.css('left').toLowerCase().replace('px', '')
                top = getTipTop(1, top, liCount)
                left = 30 + parseInt(left)
                layerobj.css({'width': '150px', 'left': left+'px', 'top': top+'px'})
                $('.layui-layim-contextmenu li').css({ 'padding-left': '18px' })
                // 移动好友分组选中事件
                $('.move-to-group-wrap').on('change', '.move-to-group-otp', function (ev) {
                    let vaule = ev.target.value
                    console.log(vaule)
                    console.log(fListInfo)
                    // let id = $(this).parent().data('id')
                    let index = $(this).parent().parent().data('index')
                    let groudId = $(this).parent().parent().data('groudid') || ''
                    console.log(index)
                    let obj = {
                        curFirendId: fListInfo.id,
                        curFirendIndex: index,
                        curGroupId: groudId, // 当前组id
                        toGroupId: vaule, // 选择的组id
                        type: 'friend',
                        curlistInfo: fListInfo
                    }
                    moveToGroup(obj, layim)
                    emptyTips()
                })
            }
        })
    })
    /* 绑定分组右击事件 */
    $('body').on('mousedown', '.layim-list-friend li h5', function (e){
        // 清空所有右击弹框
        emptyTips()
        if(3 != e.which) {
            return
        }
        // 不再派发事件
        e.stopPropagation()
         
        var othis = $(this)
        if (othis.hasClass('layim-null')) return
        let groupId = othis.data('groupid')
        // let groupName = othis.data('groupname')
        let groupName = othis.find('span').text()
        let uid = Date.now().toString(36)
        let space_text = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
         
        var html = [
            '<ul id="contextmenu_'+uid+'" data-id="'+groupId+'" data-index="'+ othis.parent().index() +'" data-groupname="'+groupName +'">',
            '<li data-type="groupInsert">'+space_text+'添加分组</li>',
            '<li data-type="groupRename">'+space_text+'重命名</li>',
            '<li data-type="groupRemove" data-mold="1">'+space_text+'删除分组</li></ul>'
        ].join('')
         
        window.layer.tips(html, othis, {
            tips: 1
            , time: 0
            , shift: 5
            , fix: true
            , skin: 'ayui-box layui-layim-contextmenu'
            , success: function (layero){
                var liCount = (html.split('</li>')).length
                var stopmp = function (e) { window.stope(e) }
                layero.off('mousedowm', stopmp).on('mousedowm', stopmp)
                var layerobj = $('#contextmenu_'+uid).parents('.layui-layim-contextmenu')
                // 移动弹框位置
                var top = layerobj.css('top').toLowerCase().replace('px', '')
                var left = layerobj.css('left').toLowerCase().replace('px', '')
                top = getTipTop(2, top, liCount)
                left = 30 + parseInt(left)
                layerobj.css({'width': '150px', 'left': left+'px', 'top': top+'px'})
                $('.layui-layim-contextmenu li').css({'padding-left': '18px'})
            }
        })
    })
    // 清空所有右击弹框
    var emptyTips = function () {
        // 移除所有好友选中的样式
        $('.layim-list-friend li ul li').removeAttr('style', '')
        // 移除所有群组选中的样式
        $('.layim-list-group li').removeAttr('style', '')
        // 关闭右键菜单
        window.layer.closeAll('tips')
    }
    
   
    // 获取窗口的文档显示区的高度
    var currentHeight = getViewSizeWithScrollbar()
    function getViewSizeWithScrollbar (){
        var clientHeight = 0
        if(window.innerWidth){
            clientHeight = window.innerHeight
        }else if(document.documentElement.offsetWidth == document.documentElement.clientWidth){ 
            clientHeight = document.documentElement.offsetHeight
        }else{ 
            clientHeight = document.documentElement.clientHeight
        } 
        clientHeight = clientHeight-180
        return clientHeight
    }
   
    /**
    *计算tip定位的高度
    * @param type 类型(1好友、群组，2分组)
    * @param top 原弹框高度
    * @param liCount 弹框层中li数量
    */
    var getTipTop = function (type, top, liCount) {
        liCount--
        if(top > (currentHeight-45*liCount)){
            top = parseInt(top) - 45
        }else{
            if(type == 1){
                top = parseInt(top) + 30*liCount - 10
            }else{
                top = parseInt(top) + 30*(liCount - 1) + 28
            }
        }
        return top
    }
    let jumpFn = (ctx) => {
        let id = ctx.data('id')
        let data = config.rightMenu.find(rs => rs.id == id)
        if (!data) {
            return false
        }
        // 这里可以做相关路由操作
        router.push({path: data.path + `?toElsAccount=${fListInfo.elsAccount}`})
    }
    // 绑定右击菜单中选项的点击事件
    var active = {
        menuChat: function (){
            console.log(layim)
            /*发送即时消息*/
            var mineId = $(this).parent().data('id')
            var moldId = $(this).parent().data('mold')
            var name = $(this).parent().data('name')
            var avatar = $(this).parent().data('avatar')
            layim.chat({
                type: moldId == 1 ? 'friend' : 'group',
                name,
                avatar,
                id: mineId,
                status: '好友当前离线状态'
            })
        },
        menuHistory: function (){
            /*消息记录*/
            // cache必须从初始化配置里面拿，插件有做动态处理
            let { base } = layim.cache()
            if (!base.chatLog) {
                return window.layer.msg('未开启更多聊天记录')
            }
            
            window.layer.close(active.menuHistory.index)
            return (active.menuHistory.index = window.layer.open({
                type: 2,
                maxmin: true,
                title: '与 ' + fListInfo.username + ' 的聊天记录',
                area: ['450px', '100%'],
                shade: false,
                offset: 'rb',
                skin: 'layui-box',
                anim: 2,
                id: 'layui-layim-chatlog',
                // content: cache.base.chatLog + '?id=' + thatChat.data.id + '&type=' + thatChat.data.type
                content: base.chatLog + '?id=' + fListInfo.id + '&type=' + 'friend' // type 暂时固定
            }))
        },
        menuBindEvent: function () {
            // 集中处理
            jumpFn($(this))
        },
        // 删除好友
        menuDeleteFriend: function () {
            console.log(11)
            $.ajax({
                headers: {
                    'X-Access-Token': im.token
                },
                url: im.BASE_URL + '/user/deleteFriend?friendId=' + fListInfo.id,
                type: 'get',
                success: function (res) {
                    console.log('ajax success', res)
                    if (res.code === 200) {
                        console.log('success', res)
                        im.LAYIM.removeList({
                            type: 'friend', //或者group
                            id: fListInfo.id //好友或者群组ID
                        })
                        window.layer.msg('删除成功')
                    } else {
                        console.log('error', res.message)
                        window.layer.msg(res.message)
                    }
                },
                error: function () {
                    window.layer.msg('ajax error')
                }
            })
        },
        groupRename: function () {
            let curName = $(this).parent().data('groupname')
            let id = $(this).parent().data('id')
            let index = $(this).parent().data('index')
            console.log(curName)
            let obj = {
                curName,
                id,
                index
            }
            popModify(obj, layim)
        },
        groupInsert: function () {
            friendGroupAdd(layim)
        },
        groupRemove: function () {
            let id = $(this).parent().data('id')
            let index = $(this).parent().data('index')
            let obj = {
                index,
                id
            }
            friendGroupRemoveClear(obj, layim)
        },
        moveToGroup: function () {
            console.log(fListInfo)
            // let id = $(this).parent().data('id')
            // let index = $(this).parent().data('index')
            // let obj = {
            //     index,
            //     curFirendId: id,
            //     curGroupId: id,
            //     type: 'friend'
            // }
            // moveToGroup(obj, layim)
        }
    }
    $('body').on('click', '.layui-layer-tips li', function () {
        console.log(1111)
        var type = $(this).data('type')
        active[type] ? active[type].call(this) : ''
        if (type != 'moveToGroup') { // 排除好友移动
            // 清空所有右击弹框
            emptyTips()
        }
    })
}
export { ctxMenu }