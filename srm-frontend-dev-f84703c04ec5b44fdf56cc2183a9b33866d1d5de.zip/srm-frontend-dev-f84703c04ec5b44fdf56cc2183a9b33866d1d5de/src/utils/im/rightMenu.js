import store from '../../store'
// 系统菜单交互
const sysMenu = [
    {
        id: '1284051076171304961', // 菜单id
        title: '采购订单', // 菜单标
        handleFnName: 'menuBindEvent',
        isV5Menu: true
    },
    // {
    //     id: '1283606528798396417', // 菜单id
    //     title: '询价管理', // 菜单标
    //     handleFnName: 'menuBindEvent',
    //     isV5Menu: true
    // },
    {
        id: '1285103684332396546', // 菜单id
        title: '销售订单', // 菜单标
        handleFnName: 'menuBindEvent',
        isV5Menu: true
    }
]
// im菜单交互
const baseMenu = [
    {
        id: 'deleteFriend', // 菜单id
        title: '删除好友', // 菜单标
        handleFnName: 'menuDeleteFriend',
        isV5Menu: false
    },
    {
        id: 'moveToGroup', // 菜单id
        title: '好友移到', // 菜单标
        handleFnName: 'moveToGroup',
        isV5Menu: false
    }
]
// 递归获取系统菜单id
const findSupLink = (data, supplierId) => {
    //传入
    const it = (i, n) => {
        if (i && i.length > 0) {
            for (let v of i) {
                if (v.id == n) {
                    return v
                } else {
                    if (v.children && v.children.length > 0) {
                        let re = it(v.children, n)
                        if (re) {
                            return re
                        }
                    }
                }
            }
        }
    }
    let ret = it(data, supplierId)
    return ret
}
const menuInit = () => {
    // 系统菜单
    let sysMenuList = store.getters.permissionList
    let menu = []
    sysMenu.forEach(el => {
        let ls = findSupLink(sysMenuList, el.id)
        if (ls) {
            el.path = ls.path
            el.component = ls.component
            el.name = ls.name
            el.route = ls.route
            menu.push(el)
        }
    })
    console.log(menu)
    menu = [...menu, ...baseMenu]
    // 得到最后的匹配菜单
    return menu
}
export { menuInit }