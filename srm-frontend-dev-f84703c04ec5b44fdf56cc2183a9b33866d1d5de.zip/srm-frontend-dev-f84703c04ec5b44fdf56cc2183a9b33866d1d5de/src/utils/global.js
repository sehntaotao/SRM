import { variateConfig } from '@/utils/variateConfig.js'
// 这里可以处理参数逻辑 或 定义全局方法
// ...
export default {
    install: function (Vue) {
        Vue.prototype.$variateConfig = variateConfig
    }
}
