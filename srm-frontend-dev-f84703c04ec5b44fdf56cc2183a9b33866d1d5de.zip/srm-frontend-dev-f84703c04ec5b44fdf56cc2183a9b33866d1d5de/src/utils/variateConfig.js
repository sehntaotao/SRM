
const domianURL = `${window.location.origin}/els`
export const variateConfig = {
    domianURL,
    casPrefixUrl: 'http://cas.example.org:8443/cas',
    configFiles: `${window.location.protocol}//${window.location.host}/opt/upFiles/js`,
    // configFiles: 'http://v5sit.51qqt.com/opt/upFiles/js',
    configUpFiles: `${window.location.protocol}//${window.location.host}/opt/upFiles`,
    // configFiles: 'http://v5sit.51qqt.com/opt/upFiles/js',
    imgDomainURL: `${domianURL}/sys/common/view`,
    downloadUrl: `${domianURL}/sys/common/download`,
    pdfDomainURL: `${domianURL}/sys/common/pdf/pdfPreviewIframe`,
    report: 'http://localhost:8085'
}