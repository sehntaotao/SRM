/**
 * 购物车
 */
import {
    MODULE_CART_PUSHTOCAR,
    MODULE_CART_INCREMENT,
    MODULE_CART_DECREMENT,
    MODULE_CART_SETLOADING,
    MODULE_CART_SETDATA,
    ADD_SELECTIONDATA,
    SUB_SELECTIONDATA,
    SET_SELECTIONDATA,
    MODULE_CART_INCREATECOMPARISONPANEL,
    MODULE_CART_DECEATECOMPARISONPANEL,
    MODULE_CART_SETCOMPARISONPANEL,
    MODULE_CART_CLEARCOMPARISONPANEL,
    MODULE_CART_SETSHOWPANEL
} from '../mutation-types'

import { postAction, getAction } from '@/api/manage'

const moduleLogin = {
    namespaced: true, // 命名空间
    state () {
        return {
            products: [],
            selectionData: [], // 已选商品
            loading: false,
            comparisonPanel: [], // 比价面板商品数据
            showPanel: false
        }
    },
    getters: {
        num (state) {
            return state.products.length
        }
    },
    actions: {
        // 加入比价
        async addToPannel ({
            commit
        }, el) {
            commit(MODULE_CART_SETSHOWPANEL, true)
            try {
                let payload = {
                    product: el
                }
                commit(MODULE_CART_INCREATECOMPARISONPANEL, payload)
                commit(MODULE_CART_SETLOADING, false)
            } catch (err) {
                commit(MODULE_CART_SETLOADING, false)
            }
        },
        // 购物车查询
        async getCartData ({
            commit
        }) {
            try {
                commit(MODULE_CART_SETLOADING, true)
                // const res = await purchaseUserCartFindAll()
                const res = await getAction('/product/purchaseUserCart/list')
                let payload = {
                    products: res.result.records || []
                }
                commit(MODULE_CART_SETDATA, payload)
                commit(MODULE_CART_SETLOADING, false)
            } catch (err) {
                commit(MODULE_CART_SETLOADING, false)
            }
        },
        async deleteCart ({
            commit,
            dispatch
        }, ids) {
            // 编辑后数量
            try {
                commit(MODULE_CART_SETLOADING, true)
                let str = ids.join(',')
                await getAction('product/purchaseUserCart/deleteBatch', { ids: str })
                commit(MODULE_CART_SETLOADING, false)
                dispatch('getCartData')
            } catch (err) {
                commit(MODULE_CART_SETLOADING, false)
            }
        }
    },
    mutations: {
        // 添加新商品
        [MODULE_CART_PUSHTOCAR] (state, {
            row
        }) {
            state.products.push(Object.assign({}, row))
        },
        // 自增一
        [MODULE_CART_INCREMENT] (state, {
            id
        }) {
            const item = state.products.find(n => n.id === id)
            item.productCount++
        },
        // 自减一
        [MODULE_CART_DECREMENT] (state, {
            id
        }) {
            const item = state.products.find(n => n.id === id)
            item.productCount--
        },
        [MODULE_CART_SETLOADING] (state, bool) {
            state.loading = !!bool
        },
        [MODULE_CART_SETDATA] (state, {
            products
        }) {
            state.products = JSON.parse(JSON.stringify(products))
        },
        [ADD_SELECTIONDATA] (state, {
            id
        }) {
            state.selectionData = [...state.selectionData, id]
        },
        [SUB_SELECTIONDATA] (state, {
            id
        }) {
            state.selectionData = state.selectionData.filter(n => n !== id)
        },
        // 设置已选数据
        [SET_SELECTIONDATA] (state, {
            selectionData
        }) {
            state.selectionData = JSON.parse(JSON.stringify(selectionData))
        },
        // 增加比价产品数据
        [MODULE_CART_INCREATECOMPARISONPANEL] (state, {
            product
        }) {
            state.comparisonPanel.push(product)
        },
        // 删除比价产品数据
        [MODULE_CART_DECEATECOMPARISONPANEL] (state, { id }) {
            state.comparisonPanel = state.comparisonPanel.filter(n => n.id !== id)
        },
        // 设置比价产品数据
        [MODULE_CART_SETCOMPARISONPANEL] (state, {
            data = []
        }) {
            state.comparisonPanel = data
        },
        // 清空比价产品数据
        [MODULE_CART_CLEARCOMPARISONPANEL] (state) {
            state.comparisonPanel = []
        },
        [MODULE_CART_SETSHOWPANEL] (state, bool) {
            state.showPanel = !!bool
        }
    }
}

export default moduleLogin